"""Generates a fake, deliberately messy Salesforce org (Data Loader-style CSVs) for trying the tool.
Every name, company, email and phone number here is made up."""
from __future__ import annotations

import csv
import datetime as dt
import random
import re
from pathlib import Path

FIRST = ["Robert", "William", "Michael", "James", "Thomas", "David", "Christopher", "Daniel",
         "Joseph", "Katherine", "Elizabeth", "Jennifer", "Matthew", "Nicholas", "Steven",
         "Anthony", "Richard", "Andrew", "Sarah", "Laura", "Maria", "Priya", "Wei", "Carlos",
         "Aisha", "Emily", "Rachel", "Kevin", "Brian", "Megan", "Olivia", "Jason", "Tanya",
         "Hector", "Grace", "Samuel", "Natalie", "Derek", "Monica", "Raj"]
LAST = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez",
        "Martinez", "Hernandez", "Lopez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore",
        "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark",
        "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott",
        "Torres", "Nguyen", "Hill", "Flores", "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera",
        "Campbell", "Mitchell", "Carter", "Patel", "Kowalski"]
NICK = {"Robert": "Bob", "William": "Bill", "Michael": "Mike", "James": "Jim", "Thomas": "Tom",
        "Christopher": "Chris", "Katherine": "Kate", "Elizabeth": "Liz", "Jennifer": "Jen",
        "Matthew": "Matt", "Steven": "Steve", "Anthony": "Tony", "Andrew": "Andy", "Daniel": "Dan"}
W1 = ["Summit", "Harbor", "Keystone", "Pinnacle", "Bluewater", "Ironbridge", "Northgate", "Crescent",
      "Liberty", "Granite", "Meridian", "Redwood", "Atlas", "Beacon", "Cedar", "Evergreen", "Frontier",
      "Highland", "Lakeside", "Patriot", "Riverside", "Silverline", "Trident", "Vanguard", "Westfield",
      "Brightpath", "Clearview", "Oakmont", "Stonebridge", "Tristate", "Garden State", "Hudson",
      "Delaware Valley", "Shoreline", "Copper"]
W2 = [("Technologies", "IT Services"), ("IT Solutions", "IT Services"), ("Networks", "IT Services"),
      ("Managed Services", "IT Services"), ("Staffing", "Staffing & Recruiting"),
      ("Talent Partners", "Staffing & Recruiting"), ("Insurance Group", "Insurance"),
      ("Risk Advisors", "Insurance"), ("Manufacturing", "Manufacturing"), ("Logistics", "Transportation"),
      ("Health Partners", "Healthcare"), ("Builders", "Construction"), ("Financial", "Financial Services")]
SUFFIX = ["Inc", "LLC", "Corp", "", "", "Co", "Inc."]
INDUSTRY_VARIANTS = {"IT Services": ["IT services", "It Services", "IT Services"],
                     "Staffing & Recruiting": ["Staffing and Recruiting", "staffing & recruiting"],
                     "Manufacturing": ["manufacturing", "MANUFACTURING"],
                     "Insurance": ["insurance"]}
STATES = [("NJ", ["New Jersey", "N.J.", "nj"]), ("NY", ["New York", "N.Y."]), ("PA", ["Pennsylvania", "Penn"]),
          ("CT", ["Connecticut"]), ("MA", ["Massachusetts", "Mass"]), ("FL", ["Florida"]), ("TX", ["Texas"])]
COUNTRY_VARIANTS = ["United States", "US", "USA", "U.S.", "United States of America"]
AREA = ["201", "973", "908", "732", "212", "646", "718", "516", "215", "610", "203", "617", "305", "512"]
TITLES = ["CEO", "President", "Owner", "CFO", "CTO", "COO", "VP of Sales", "VP Operations",
          "Vice President, IT", "Director of IT", "IT Director", "Director of Talent Acquisition",
          "Head of Operations", "IT Manager", "Office Manager", "Operations Manager", "HR Manager",
          "Recruiting Manager", "Network Engineer", "Systems Administrator", "Account Executive",
          "Recruiter", "Controller", "Procurement Specialist", "Benefits Coordinator", "Analyst"]
SOURCES = ["Web", "Referral", "Trade Show", "Purchased List", "Partner", "Cold Call", "Webinar"]
OPP_TYPES = ["New Business", "Renewal", "Expansion", "Managed Services Agreement", "Hardware Refresh",
             "Staff Augmentation", "Cyber Assessment", "Benefits Package", "Q3 Project"]
OPEN_STAGES = ["Prospecting", "Qualification", "Needs Analysis", "Proposal/Price Quote", "Negotiation/Review"]
LOSS_REASONS = ["Price", "Went with competitor", "No decision", "Timing", "Lost contact"]
PROBABILITY = {"Prospecting": 10, "Qualification": 20, "Needs Analysis": 40, "Proposal/Price Quote": 60,
               "Negotiation/Review": 80, "Closed Won": 100, "Closed Lost": 0}


def _sfid(prefix, n):
    return f"{prefix}5g00000{n:08d}"


def _ts(d: dt.datetime):
    return d.strftime("%Y-%m-%dT%H:%M:%S.000Z")


def _d(d: dt.date):
    return d.strftime("%Y-%m-%d")


def _phone(rng):
    a, e, l = rng.choice(AREA), rng.randint(200, 989), rng.randint(0, 9999)
    if e == 555:
        e = 556
    fmt = rng.choices(["paren", "dash", "dot", "plus", "raw"], [60, 20, 8, 5, 7])[0]
    return {"paren": f"({a}) {e}-{l:04d}", "dash": f"{a}-{e}-{l:04d}", "dot": f"{a}.{e}.{l:04d}",
            "plus": f"+1 {a} {e} {l:04d}", "raw": f"{a}{e}{l:04d}"}[fmt]


def _write(path: Path, rows: list[dict]):
    cols = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)


def generate(out: Path, seed=7, audit_date: dt.date | None = None) -> Path:
    rng = random.Random(seed)
    today = audit_date or dt.date.today()
    now = dt.datetime.combine(today, dt.time(9, 0))
    out.mkdir(parents=True, exist_ok=True)

    def days_ago(lo, hi):
        return now - dt.timedelta(days=rng.uniform(lo, hi), hours=rng.uniform(0, 8))

    # Users: 8 reps, 2 have left the company
    users = []
    for i in range(8):
        users.append({"Id": _sfid("005", i + 1), "Name": f"{rng.choice(FIRST)} {rng.choice(LAST)}",
                      "IsActive": "false" if i in (5, 7) else "true",
                      "Email": f"rep{i + 1}@example.com",
                      "Profile": "System Administrator" if i == 0 else "Standard User"})
    active = [u["Id"] for u in users if u["IsActive"] == "true"]
    inactive = [u["Id"] for u in users if u["IsActive"] == "false"]
    integ = _sfid("005", 9)  # a marketing-automation sync that creates records without matching
    users.append({"Id": integ, "Name": "Marketing Sync", "IsActive": "true", "Email": "sync@example.com",
                  "Profile": "Integration User"})

    def creator(bad=False, base=0.2):
        return integ if rng.random() < (0.75 if bad else base) else rng.choice(active)

    def owner():
        x = rng.random()
        if x < 0.04:
            return rng.choice(inactive)
        if x < 0.045:
            return ""
        return rng.choice(active)

    # Accounts
    names, accounts = set(), []
    while len(accounts) < 300:
        w1, (w2, ind) = rng.choice(W1), rng.choice(W2)
        base = f"{w1} {w2}"
        if base in names:
            continue
        names.add(base)
        sfx = rng.choice(SUFFIX)
        domain = re.sub(r"[^a-z]", "", (w1 + w2.split()[0]).lower()) + rng.choice([".com", ".com", ".net", ".io"])
        state, variants = rng.choice(STATES)
        industry = ind if rng.random() > 0.12 else rng.choice(INDUSTRY_VARIANTS.get(ind, [ind]))
        if rng.random() < 0.04:
            industry = "Other"
        web = rng.choice([f"www.{domain}", f"https://www.{domain}", f"http://{domain}/", domain])
        accounts.append({
            "Id": _sfid("001", len(accounts) + 1), "Name": f"{base} {sfx}".strip(),
            "Website": web if rng.random() > 0.10 else "",
            "Industry": industry if rng.random() > 0.15 else "",
            "NumberOfEmployees": str(rng.choice([8, 15, 25, 40, 60, 120, 250, 600])) if rng.random() > 0.22 else "",
            "BillingCity": rng.choice(["Newark", "Princeton", "Hoboken", "Edison", "New York", "Stamford",
                                       "Philadelphia", "Boston", "Miami", "Austin"]) if rng.random() > 0.1 else "",
            "BillingState": (state if rng.random() > 0.15 else rng.choice(variants)) if rng.random() > 0.06 else "",
            "BillingCountry": rng.choices(["United States", rng.choice(COUNTRY_VARIANTS), ""], [70, 20, 10])[0],
            "OwnerId": owner(), "CreatedById": creator(),
            "CreatedDate": _ts(days_ago(200, 2200)), "LastModifiedDate": _ts(days_ago(1, 900)),
            "Tier__c": rng.choice(["Gold", "Silver", "Bronze"]) if rng.random() < 0.45 else "",
            "Region__c": rng.choice(["North", "Central", "South"]) if rng.random() < 0.6 else "",
            "Legacy_ERP_ID__c": f"ERP-{rng.randint(1000, 9999)}" if rng.random() < 0.03 else "",
            "Old_Territory__c": "T-9" if rng.random() < 0.01 else "",
            "_domain": domain, "_state": state,
        })
    base_accounts = list(accounts)
    # Duplicate accounts with name variants
    for a in rng.sample(base_accounts, 11):
        dup = dict(a)
        nm = a["Name"]
        dup["Name"] = rng.choice([nm.upper(), nm.replace(" Inc", ", Inc.").replace(" LLC", ", L.L.C."),
                                  "The " + nm, re.sub(r"\s(Inc\.?|LLC|Corp|Co)$", "", nm)])
        dup["Website"] = rng.choice([f"https://{a['_domain']}", f"www.{a['_domain']}/contact", ""])
        dup["Id"] = _sfid("001", len(accounts) + 1)
        dup["OwnerId"] = owner()
        dup["CreatedById"] = creator(bad=True)
        dup["CreatedDate"] = _ts(days_ago(1, 300))
        accounts.append(dup)

    # Contacts
    contacts = []

    def make_contact(acct, first=None, last=None, email=None, bad=False):
        first = first or rng.choice(FIRST)
        last = last or rng.choice(LAST)
        email = email or f"{first.lower()}.{last.lower()}@{acct['_domain']}"
        stale = rng.random() < 0.38
        la = "" if (stale and rng.random() < 0.5) else _d((days_ago(400, 1500) if stale else days_ago(1, 330)).date())
        lm = days_ago(380, 1400) if (stale and rng.random() < 0.8) else days_ago(1, 360)
        x = rng.random()
        phone = "" if x < 0.10 else (rng.choice(["555-1234", "123", "000-000-0000", "N/A", "(999) 999-9999"])
                                     if x < 0.14 else _phone(rng))
        st = acct["_state"]
        c = {
            "Id": _sfid("003", len(contacts) + 1), "FirstName": first, "LastName": last, "Email": email,
            "Phone": phone, "MobilePhone": _phone(rng) if rng.random() < 0.3 else "",
            "Title": rng.choice(TITLES) if rng.random() > 0.12 else "",
            "AccountId": acct["Id"] if rng.random() > 0.04 else "",
            "OwnerId": acct["OwnerId"] if (acct["OwnerId"] and rng.random() > 0.15) else owner(),
            "LeadSource": rng.choice(SOURCES) if rng.random() < 0.72 else "",
            "MailingState": (st if rng.random() > 0.18 else rng.choice(dict(STATES)[st])) if rng.random() > 0.3 else "",
            "MailingCountry": rng.choices(["United States", rng.choice(COUNTRY_VARIANTS), ""], [55, 15, 30])[0],
            "HasOptedOutOfEmail": "true" if rng.random() < 0.04 else "false",
            "CreatedDate": _ts(lm - dt.timedelta(days=rng.uniform(0, 1500))), "LastModifiedDate": _ts(lm), "LastActivityDate": la,
            "Seniority__c": rng.choice(["C-Level", "VP", "Director", "Manager", "Staff"]) if rng.random() < 0.35 else "",
            "LinkedIn_URL__c": f"https://linkedin.com/in/{first.lower()}{last.lower()}" if rng.random() < 0.25 else "",
            "Fax_Extension__c": "",
            "Legacy_Contact_ID__c": f"LC{rng.randint(10000, 99999)}" if rng.random() < 0.02 else "",
            "Webinar_2019__c": "Attended" if rng.random() < 0.04 else "",
            "Preferred_Name__c": rng.choice(FIRST) if rng.random() < 0.03 else "",
        }
        r = rng.random()
        if r < 0.02:
            c["FirstName"], c["LastName"] = c["FirstName"].upper(), c["LastName"].upper()
        elif r < 0.03:
            c["FirstName"], c["LastName"] = c["FirstName"].lower(), c["LastName"].lower()
        elif r < 0.035:
            c["FirstName"], c["LastName"], c["Email"] = "Test", "Test", "test@test.com"
        elif r < 0.04:
            c["Email"] = c["Email"].replace("@", " @")
        elif r < 0.06:
            c["Title"] = rng.choice(["TBD", "Contact", "Employee"])
        bad = bad or r < 0.06
        c["CreatedById"] = creator(bad=bad)
        if bad and rng.random() < 0.6:  # most of the mess is recent: it's still coming in
            c["CreatedDate"] = _ts(days_ago(1, 170))
            c["LastModifiedDate"] = c["CreatedDate"]
        contacts.append(c)
        return c

    for acct in base_accounts:
        for _ in range(rng.choice([1, 2, 2, 3, 3, 4, 5, 6])):
            make_contact(acct)
    by_acct = {a["Id"]: a for a in accounts}
    originals = list(contacts)
    # Exact email duplicates (case differences, different owner)
    for c in rng.sample(originals, int(len(originals) * 0.035)):
        acct = by_acct.get(c["AccountId"]) or rng.choice(base_accounts)
        d = make_contact(acct, c["FirstName"], c["LastName"],
                         rng.choice([c["Email"], c["Email"].title(), " " + c["Email"].upper()]), bad=True)
        d["AccountId"] = c["AccountId"]
    # Fuzzy duplicates: nickname or typo with a personal email
    for c in rng.sample(originals, int(len(originals) * 0.03)):
        acct = by_acct.get(c["AccountId"])
        if not acct or not c["FirstName"].istitle():
            continue
        first = NICK.get(c["FirstName"], c["FirstName"][:-1] if len(c["FirstName"]) > 4 else c["FirstName"])
        make_contact(acct, first, c["LastName"],
                     f"{first.lower()}{c['LastName'].lower()}{rng.randint(1, 99)}@{rng.choice(['gmail.com', 'yahoo.com', 'outlook.com'])}",
                     bad=True)
    # Placeholder values typed to get past required fields
    for c in rng.sample(originals, 4):
        c["Email"], c["CreatedById"] = "noemail@noemail.com", integ
    shared_acct = set()
    for c in originals:
        if c["AccountId"] not in shared_acct and len(shared_acct) < 7 and rng.random() < 0.05:
            c["Phone"] = "(800) 234-5678"
            shared_acct.add(c["AccountId"])

    # Opportunities
    opps, history = [], []
    acct_contacts = {}
    for c in contacts:
        acct_contacts.setdefault(c["AccountId"], []).append(c["Id"])
    for i in range(260):
        acct = rng.choice(base_accounts)
        is_open = rng.random() < 0.45
        if is_open:
            stage, closed, won = rng.choice(OPEN_STAGES), "false", "false"
            close = now.date() + dt.timedelta(days=rng.randint(-90, 120))
            la = "" if rng.random() < 0.15 else _d((days_ago(1, 29) if rng.random() < 0.6 else days_ago(31, 200)).date())
        else:
            won_b = rng.random() < 0.4
            stage, closed, won = ("Closed Won" if won_b else "Closed Lost"), "true", "true" if won_b else "false"
            close = now.date() - dt.timedelta(days=rng.randint(1, 720))
            la = _d(dt.datetime.combine(close, dt.time()) .date())
        short = re.sub(r"\s(Inc\.?|LLC|Corp|Co)$", "", acct["Name"])
        cids = acct_contacts.get(acct["Id"], [])
        created_dt = days_ago(60, 900)
        oid = _sfid("006", i + 1)
        # Close-date history: how many times the date was pushed later
        k = rng.choices([0, 1, 2, 3, 4, 5], [45, 20, 12, 12, 7, 4])[0] if is_open else \
            rng.choices([0, 1, 2], [60, 30, 10])[0]
        dates = [close]
        for _ in range(k):
            dates.insert(0, dates[0] - dt.timedelta(days=rng.randint(14, 60)))
        span = max((now - created_dt).total_seconds(), 1)
        stamps = sorted(created_dt + dt.timedelta(seconds=rng.uniform(0, span)) for _ in range(k))
        for d_, at in zip(dates, [created_dt] + stamps):
            history.append({"Id": _sfid("008", len(history) + 1), "OpportunityId": oid, "StageName": stage,
                            "CloseDate": _d(d_), "CreatedDate": _ts(at)})
        opps.append({
            "Id": oid, "Name": f"{short} - {rng.choice(OPP_TYPES)}",
            "AccountId": acct["Id"] if rng.random() > 0.03 else "", "StageName": stage,
            "IsClosed": closed, "IsWon": won, "CloseDate": _d(close),
            "Amount": str(rng.choice([5, 8, 12, 15, 24, 36, 48, 60, 85, 120]) * 1000) if rng.random() > 0.05 else "",
            "OwnerId": acct["OwnerId"] or rng.choice(active), "LastActivityDate": la,
            "ContactId": rng.choice(cids) if cids and rng.random() < 0.75 else "",
            "Loss_Reason__c": rng.choice(LOSS_REASONS) if stage == "Closed Lost" and rng.random() < 0.55 else "",
            "Probability": str(PROBABILITY[stage]),
            "CreatedDate": _ts(created_dt),
        })
    open_opps = [o for o in opps if o["IsClosed"] == "false" and o["AccountId"]]
    for o in rng.sample(open_opps, 6):
        d = dict(o)
        d["Id"] = _sfid("006", len(opps) + 1)
        d["Name"] = rng.choice([o["Name"], o["Name"] + " 2", o["Name"].lower()])
        d["OwnerId"] = rng.choice(active)
        opps.append(d)
    # Placeholder values reps type just to save the record
    picks = rng.sample(open_opps, 12)
    for o in picks[:4]:
        o["Amount"] = "1"
    for o in picks[4:7]:
        o["CloseDate"] = "2099-12-31"
    for o in picks[7:12]:
        o["Probability"] = rng.choice(["100", "0"])

    # Leads: some are people already in the CRM, some come from existing accounts
    real_contacts = [c for c in contacts if "@" in c["Email"] and not c["Email"].startswith(("test@", "noemail@"))]

    # Leads and tasks
    leads, tasks = [], []
    for i in range(220):
        created = days_ago(0, 120)
        lid = _sfid("00Q", i + 1)
        first, last = rng.choice(FIRST), rng.choice(LAST)
        x = rng.random()
        if x < 0.09:  # already a contact
            c = rng.choice(real_contacts)
            first, last, email = c["FirstName"].title(), c["LastName"].title(), c["Email"].strip().lower()
            company = by_acct.get(c["AccountId"], {}).get("Name") or "Unknown"
        elif x < 0.22:  # new person at a company that's already an account
            a = rng.choice(base_accounts)
            email, company = f"{first.lower()}.{last.lower()}@{a['_domain']}", a["Name"]
        else:
            w = rng.choice(W1).replace(" ", "")
            email, company = f"{first.lower()}.{last.lower()}@{w.lower()}{rng.randint(2, 999)}.com", f"{w} {rng.choice(W2)[0]}"
        converted = rng.random() < 0.12
        touched = rng.random() < 0.72
        last_act = ""
        if touched:
            delay = rng.uniform(0.2, 30) if rng.random() < 0.72 else rng.uniform(50, 240)
            t1 = created + dt.timedelta(hours=delay)
            if t1 < now:
                tasks.append({"Id": _sfid("00T", len(tasks) + 1), "WhoId": lid, "Subject": "Call",
                              "CreatedDate": _ts(t1), "ActivityDate": _d(t1.date())})
                last_act = _d(t1.date())
        leads.append({
            "Id": lid, "FirstName": first, "LastName": last, "Company": company, "Email": email,
            "CreatedById": integ if rng.random() < 0.55 else rng.choice(active),
            "Status": "Qualified" if converted else rng.choice(["Open - Not Contacted", "Working - Contacted",
                                                                "Closed - Not Converted"]),
            "IsConverted": "true" if converted else "false", "LeadSource": rng.choice(SOURCES),
            "OwnerId": owner() or rng.choice(active), "CreatedDate": _ts(created), "LastActivityDate": last_act,
        })

    for rows in (accounts,):
        for a in rows:
            a.pop("_domain", None)
            a.pop("_state", None)
    rng.shuffle(contacts)
    _write(out / "users.csv", users)
    _write(out / "accounts.csv", accounts)
    _write(out / "contacts.csv", contacts)
    _write(out / "opportunities.csv", opps)
    _write(out / "leads.csv", leads)
    _write(out / "tasks.csv", tasks)
    _write(out / "opportunity_history.csv", history)
    (out / "audit.toml").write_text(SAMPLE_TOML.format(date=today.isoformat()), encoding="utf-8")
    return out


SAMPLE_TOML = """# Settings for the fake sample org. Every value here is made up.
client = "Sample Co (fake data)"
crm = "Salesforce"
audit_date = "{date}"
phone_region = "US"

[weights]
"1" = 20
"2" = 25
"3" = 15
"4" = 20
"5" = 10
"6" = 10

[impact]
reps = 10
touches_per_rep_per_day = 60
minutes_per_bad_touch = 2
selling_days = 230
hourly_cost = 40
lead_to_customer_rate_pct = 10
admin_hours_per_week = 3

[measured]
"2.1" = 3.8
"2.2" = 7.5
"2.3" = 14
"2.6" = 18
"6.5" = 5.5

[manual_scores]
"1.5" = 0
"2.7" = 2
"3.7" = 1
"4.3" = 1
"4.5" = 0
"5.1" = 1
"5.3" = 0
"5.4" = 1
"5.5" = 0
"5.6" = 1
"6.1" = 0
"6.2" = 0
"6.3" = 1
"6.4" = 0
"6.6" = 2
"""
