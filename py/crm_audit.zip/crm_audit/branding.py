"""White-label branding: the consultant's (or a reseller partner's) name, logo, color and contact line
on the reports. Set in the [branding] table of audit.toml, or in the iPad app's "Your branding" panel.

With nothing set, every report comes out exactly as it always has."""
from __future__ import annotations

import base64
import re
from dataclasses import dataclass, field
from pathlib import Path

MAX_LOGO_BYTES = 1024 * 1024  # about 1 MB
DEFAULT_ACCENT = "#1f3a5f"
_HEX = re.compile(r"^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
_DATA_URI = re.compile(r"^data:(image/(?:png|jpeg|svg\+xml));base64,([A-Za-z0-9+/=\s]+)$")
_MIME_BY_EXT = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml"}


@dataclass
class Branding:
    prepared_by: str = ""
    contact: str = ""
    accent: str | None = None          # "#rrggbb" when a valid color was given
    logo_bytes: bytes | None = None
    logo_mime: str | None = None
    show_powered_by: bool = True
    warnings: list[str] = field(default_factory=list)
    xlsx_logo: bool = False            # set by the Excel writer when the logo made it onto the workbook

    @property
    def active(self) -> bool:
        """True when anything was set. With nothing set the reports are left exactly as they were."""
        return bool(self.prepared_by or self.contact or self.accent or self.logo_bytes)

    @property
    def white_label(self) -> bool:
        """Branded, with the "Powered by Uroboric" line turned off: the tool's own name is left out too."""
        return self.active and not self.show_powered_by

    @property
    def logo_uri(self) -> str | None:
        if not self.logo_bytes:
            return None
        return f"data:{self.logo_mime};base64,{base64.b64encode(self.logo_bytes).decode('ascii')}"

    @property
    def tool_name(self) -> str:
        return "" if self.white_label else "Uroboric "


def _sniff(raw: bytes) -> str | None:
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if raw.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if b"<svg" in raw[:4096].lower():
        return "image/svg+xml"
    return None


def _truthy(v) -> bool:
    if isinstance(v, str):
        return v.strip().lower() not in ("false", "no", "off", "0", "")
    return bool(v) if v is not None else True


def resolve(cfg: dict) -> Branding:
    """Read the [branding] settings into a Branding. Problems become plain-English warnings; the audit
    carries on without the part that didn't work."""
    raw = cfg.get("branding") or {}
    b = Branding(prepared_by=str(raw.get("prepared_by") or "").strip(),
                 contact=str(raw.get("contact") or "").strip(),
                 show_powered_by=_truthy(raw.get("show_powered_by", True)))

    color = str(raw.get("accent_color") or "").strip()
    if color:
        m = _HEX.match(color)
        if m:
            h = m.group(1)
            if len(h) == 3:
                h = "".join(ch * 2 for ch in h)
            b.accent = "#" + h.lower()
        else:
            b.warnings.append(f"The accent color '{color}' isn't a color code like #1F3A5F, so the usual blue "
                              "was used. Check the accent_color line in the [branding] section of audit.toml.")

    data_uri = str(raw.get("logo_data") or "").strip()  # the iPad app passes the logo this way
    path_text = str(raw.get("logo") or "").strip()
    if data_uri:
        m = _DATA_URI.match(data_uri)
        try:
            blob = base64.b64decode(m.group(2)) if m else b""
        except ValueError:
            blob = b""
        _take_logo(b, blob, "the logo you added", m.group(1) if m else None)
    elif path_text:
        p = Path(path_text)
        if not p.is_absolute():
            p = Path(cfg.get("_base_dir") or ".") / p
        try:
            if not p.is_file():
                b.warnings.append(f"The logo file '{path_text}' couldn't be found, so the report has no logo. "
                                  "Check the logo line in the [branding] section of audit.toml.")
            elif p.stat().st_size > MAX_LOGO_BYTES:
                b.warnings.append(f"The logo '{p.name}' is bigger than 1 MB, so the report has no logo. "
                                  "Use a smaller picture.")
            else:
                _take_logo(b, p.read_bytes(), f"The logo '{p.name}'", _MIME_BY_EXT.get(p.suffix.lower()))
        except OSError:
            b.warnings.append(f"The logo file '{path_text}' couldn't be read, so the report has no logo.")
    return b


def _take_logo(b: Branding, blob: bytes, what: str, claimed: str | None):
    what = what[0].upper() + what[1:]
    if not blob:
        b.warnings.append(f"{what} couldn't be read, so the report has no logo. Use a PNG, JPG or SVG picture.")
    elif len(blob) > MAX_LOGO_BYTES:
        b.warnings.append(f"{what} is bigger than 1 MB, so the report has no logo. Use a smaller picture.")
    else:
        mime = _sniff(blob)
        if mime is None or (claimed and claimed != mime):
            b.warnings.append(f"{what} isn't a PNG, JPG or SVG picture, so the report has no logo.")
        else:
            b.logo_bytes, b.logo_mime = blob, mime


def apply(data, cfg: dict) -> Branding:
    """Resolve the branding and add any warnings to the ones the report already shows."""
    b = resolve(cfg)
    if hasattr(data, "warnings"):
        data.warnings.extend(b.warnings)
    return b


# ---------------------------------------------------------------- HTML pieces

def html_css(b: Branding) -> str:
    """Extra styles, added only when branding is set."""
    if not b.active:
        return ""
    css = ("\n.brandbar{display:flex;align-items:center;gap:16px;margin-bottom:14px;padding-bottom:14px;"
           "border-bottom:3px solid var(--navy)}\n"
           ".brandbar img{display:block;max-height:64px;max-width:240px;width:auto;height:auto}\n"
           ".brandbar .prep{font-size:15px;color:var(--muted)}\n"
           ".brandbar .prep b{color:var(--ink)}\n"
           ".brandbar .con{font-size:13px;color:var(--faint)}\n"
           "footer .closing{color:var(--muted);font-size:14px;margin-bottom:8px}\n"
           "footer .closing b{color:var(--ink)}\n"
           "footer .powered{margin-top:6px}\n"
           "@media print{.brandbar{break-inside:avoid;-webkit-print-color-adjust:exact;print-color-adjust:exact}"
           ".brandbar img{max-height:56px}}\n")
    if b.accent:
        css = f"\n:root{{--navy:{b.accent}}}\nh2{{color:var(--navy)}}" + css
    return css
