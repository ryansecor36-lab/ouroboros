"""Scorecard (category scores and grade) and the business-impact calculator."""
from __future__ import annotations

from dataclasses import dataclass

from .checklist import CATEGORIES, CHECKS, DEFAULT_WEIGHTS, grade_for


@dataclass
class CategoryScore:
    number: int
    name: str
    weight: float
    earned: int
    possible: int
    total_checks: int
    unscored: int

    @property
    def pct(self):
        return self.earned / self.possible if self.possible else None

    @property
    def score(self):
        return self.pct * self.weight if self.pct is not None else None


@dataclass
class Scorecard:
    categories: list[CategoryScore]
    overall: float | None
    grade: str | None
    meaning: str | None
    unscored: int
    weights_note: str | None


def build_scorecard(results, cfg) -> Scorecard:
    note = None
    try:
        raw_w = {int(k): float(v) for k, v in cfg.get("weights", {}).items()}
        if any(v < 0 for v in raw_w.values()):
            raise ValueError("negative weight")
    except (TypeError, ValueError):
        raw_w = {}
        note = "The weights in audit.toml weren't numbers 0 or higher; the standard weights were used."
    weights = {c: raw_w.get(c, 0.0) for c in CATEGORIES}
    total_w = sum(weights.values())
    if total_w <= 0:  # all zero (or missing): grade with the checklist's own weights
        weights = {c: float(DEFAULT_WEIGHTS[c]) for c in CATEGORIES}
        total_w = 100.0
        note = note or "The weights in audit.toml added up to 0; the standard weights were used."
    if abs(total_w - 100) > 0.01:
        note = f"Weights in audit.toml add up to {total_w:g}, not 100; they were scaled to 100."
        weights = {c: w * 100 / total_w for c, w in weights.items()}
    cats = []
    for num, name in CATEGORIES.items():
        # checks that don't apply to this CRM are left out entirely (they aren't "still to score")
        checks = [c for c in CHECKS if c.category == num and results[c.id].status != "not applicable"]
        scores = [results[c.id].score for c in checks if results[c.id].score is not None]
        cats.append(CategoryScore(num, name, weights[num], sum(scores), 2 * len(scores),
                                  len(checks), len(checks) - len(scores)))
    scored = [c for c in cats if c.score is not None]
    w_scored = sum(c.weight for c in scored)
    overall = sum(c.score for c in scored) * 100 / w_scored if w_scored else None
    grade, meaning = grade_for(overall) if overall is not None else (None, None)
    return Scorecard(cats, overall, grade, meaning, sum(c.unscored for c in cats), note)


def _num(v):
    try:
        return float(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


def _pos(v):
    """A number above zero, or None (zero or negative reps, minutes or days make no sense)."""
    x = _num(v)
    return x if x is not None and x > 0 else None


def build_impact(results, cfg) -> dict:
    imp = cfg.get("impact", {})
    A, B = _pos(imp.get("reps")), _pos(imp.get("touches_per_rep_per_day"))
    D = _pos(imp.get("minutes_per_bad_touch")) or 2.0   # the checklist's own defaults stand in
    E = _pos(imp.get("selling_days")) or 230.0          # for anything missing or nonsensical
    F = _pos(imp.get("hourly_cost")) or 40.0
    C = _num(imp.get("bad_touch_pct"))
    if C is not None and not 0 <= C <= 100:
        C = None
    c_src = "Entered in audit.toml"
    if C is None:
        parts = [(cid, results[cid].value) for cid in ("2.1", "2.2", "2.3", "2.4")
                 if results[cid].value is not None]
        if parts:
            C = sum(v for _, v in parts) / len(parts)
            names = {"2.1": "bounced emails", "2.2": "dead email addresses", "2.3": "contacts who left",
                     "2.4": "bad phone numbers"}
            c_src = "Average of " + ", ".join(f"{names[cid]} ({v:.1f}%)" for cid, v in parts)
        else:
            c_src = "Not available: enter bad_touch_pct or run checks 2.1-2.4"

    inputs = [
        ("A. Number of reps", A, "Client" if A is not None else "Enter reps in audit.toml"),
        ("B. Dials and emails per rep per day", B,
         "Client or activity report" if B is not None else "Enter touches_per_rep_per_day"),
        ("C. % of touches hitting bad data", round(C, 1) if C is not None else None, c_src),
        ("D. Minutes wasted per bad touch", D, "Checklist default is 2 unless the client says otherwise"),
        ("E. Selling days per year", E, "Checklist default is 230"),
        ("F. Loaded hourly cost per rep ($)", F, "Salary + commission / 2,000 hrs (default $40)"),
    ]
    hours = cost = None
    if None not in (A, B, C, D, E):
        hours = A * B * (C / 100) * D * E / 60
        cost = hours * F if F is not None else None

    extras = []
    stale = results["4.4"].extras.get("stale_amount")
    if stale is not None:
        extras.append(("Stale pipeline (forecast overstated by)", stale,
                       "Open deals past their close date or with no activity in 30+ days. Not lost "
                       "money, but the forecast is overstated by this amount."))
    dup_amt = results["1.4"].extras.get("amount")
    if dup_amt:
        extras.append(("Pipeline counted twice (duplicate deals)", dup_amt,
                       "Value of the extra copies of duplicate open deals"))
    unworked = results["4.2"].extras.get("unworked_count")
    rate = _num(imp.get("lead_to_customer_rate_pct"))
    avg = _num(imp.get("avg_deal_size")) or results["4.4"].extras.get("avg_won_amount")
    avg_src = "entered" if _num(imp.get("avg_deal_size")) else "average won deal in the export"
    if unworked is not None:
        if rate is not None and avg:
            extras.append(("Unworked leads (revenue at risk, per 90 days)", unworked * rate / 100 * avg,
                           f"{unworked:,} unworked leads x {rate:g}% lead-to-customer x ${avg:,.0f} "
                           f"avg deal ({avg_src})"))
        else:
            extras.append(("Unworked leads (revenue at risk, per 90 days)", None,
                           f"{unworked:,} unworked leads; enter lead_to_customer_rate_pct "
                           + ("" if avg else "and avg_deal_size ") + "to value them"))
    adm_h = _num(imp.get("admin_hours_per_week"))
    if adm_h is not None:
        adm_c = _num(imp.get("admin_hourly_cost")) or F
        extras.append(("Admin time fixing data (per year)", adm_h * adm_c * 50,
                       f"{adm_h:g} hrs/week x ${adm_c:,.0f}/hr x 50 weeks"))
    return {"inputs": inputs, "hours": hours, "cost": cost, "extras": extras,
            "fte": hours / 2000 if hours is not None else None}
