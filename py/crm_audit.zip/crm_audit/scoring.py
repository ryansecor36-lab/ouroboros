"""Scorecard (category scores and grade) and the business-impact calculator."""
from __future__ import annotations

from dataclasses import dataclass

from .checklist import CATEGORIES, CHECKS, DEFAULT_WEIGHTS, grade_for


GRADE_PROVISIONAL_BELOW = 0.60   # measured checks cover less than this share of the checklist: "Provisional"
GRADE_WITHHELD_BELOW = 0.35      # less than this: no letter at all


@dataclass
class CategoryScore:
    number: int
    name: str
    weight: float
    earned: int
    possible: int
    total_checks: int
    unscored: int

    @property
    def pct(self):
        return self.earned / self.possible if self.possible else None

    @property
    def score(self):
        return self.pct * self.weight if self.pct is not None else None


@dataclass
class Scorecard:
    categories: list[CategoryScore]
    overall: float | None
    grade: str | None
    meaning: str | None
    unscored: int
    weights_note: str | None
    needs_input: int = 0    # checks waiting for an answer (interview or a number measured outside the CRM)
    coverage: float = 1.0   # share of the checklist's weight (n/a checks removed) that was measured
    measured: int = 0       # checks that carry a score
    applicable: int = 0     # checks that apply to this CRM
    status: str = "ok"      # ok | provisional | withheld (see the two constants below)
    raw_overall: float | None = None   # the score before a withheld grade was hidden
    not_checked: int = 0    # automated checks the export couldn't support (left out of the grade)
    partial: int = 0        # automated checks that could only be measured in part (in the grade, labelled)


def build_scorecard(results, cfg) -> Scorecard:
    note = None
    try:
        raw_w = {int(k): float(v) for k, v in cfg.get("weights", {}).items()}
        if any(v < 0 for v in raw_w.values()):
            raise ValueError("negative weight")
    except (TypeError, ValueError):
        raw_w = {}
        note = "The weights in audit.toml weren't numbers 0 or higher; the standard weights were used."
    weights = {c: raw_w.get(c, 0.0) for c in CATEGORIES}
    total_w = sum(weights.values())
    if total_w <= 0:  # all zero (or missing): grade with the checklist's own weights
        weights = {c: float(DEFAULT_WEIGHTS[c]) for c in CATEGORIES}
        total_w = 100.0
        note = note or "The weights in audit.toml added up to 0; the standard weights were used."
    if abs(total_w - 100) > 0.01:
        note = f"Weights in audit.toml add up to {total_w:g}, not 100; they were scaled to 100."
        weights = {c: w * 100 / total_w for c, w in weights.items()}
    cats = []
    for num, name in CATEGORIES.items():
        # checks that don't apply to this CRM are left out entirely (they aren't "still to score")
        checks = [c for c in CHECKS if c.category == num and results[c.id].status != "not applicable"]
        scores = [results[c.id].score for c in checks if results[c.id].score is not None]
        cats.append(CategoryScore(num, name, weights[num], sum(scores), 2 * len(scores),
                                  len(checks), len(checks) - len(scores)))
    scored = [c for c in cats if c.score is not None]
    w_scored = sum(c.weight for c in scored)
    overall = sum(c.score for c in scored) * 100 / w_scored if w_scored else None
    live = [c for c in cats if c.total_checks]
    w_live = sum(c.weight for c in live)
    coverage = (sum(c.weight * (c.total_checks - c.unscored) / c.total_checks for c in live) / w_live
                if w_live else 0.0)
    status = "ok"
    raw = overall
    if overall is not None and coverage < GRADE_WITHHELD_BELOW:
        status, overall = "withheld", None
    elif coverage < GRADE_PROVISIONAL_BELOW:
        status = "provisional"
    grade, meaning = grade_for(overall) if overall is not None else (None, None)
    applicable = [c for c in CHECKS if results[c.id].status != "not applicable"]
    not_checked = sum(1 for c in applicable if c.mode == "auto" and results[c.id].score is None)
    needs_input = sum(1 for c in applicable if c.mode != "auto" and results[c.id].score is None)
    partial = sum(1 for c in applicable if results[c.id].coverage == "partial" and results[c.id].score is not None)
    return Scorecard(cats, overall, grade, meaning, sum(c.unscored for c in cats), note,
                     needs_input=needs_input, not_checked=not_checked, partial=partial, coverage=coverage,
                     measured=len(applicable) - sum(c.unscored for c in cats), applicable=len(applicable),
                     status=status, raw_overall=raw)


def grade_basis(card) -> str:
    """The one line that says what a grade rests on, used wherever a grade is shown."""
    n = f"{card.measured} of {card.applicable} checks"
    part = f", {card.partial} partly checked" if card.partial else ""
    pct = f"{card.coverage * 100:.0f}%"
    if card.status == "withheld" or card.overall is None:
        return (f"Not enough could be checked to give a grade: the {n} that were measured cover only {pct} of the "
                "checklist. The findings below still stand.")
    head = f"Grade {card.grade} ({card.overall:.0f}/100), based on {n}{part}"
    if card.status == "provisional":
        return head + f". Provisional: these checks cover {pct} of the checklist, so the grade may move a lot."
    return head


def _num(v):
    try:
        return float(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


def _pos(v):
    """A number above zero, or None (zero or negative reps, minutes or days make no sense)."""
    x = _num(v)
    return x if x is not None and x > 0 else None


BAD_TOUCH_FORMULA = ("Share of touches that hit bad data = w x E + (1 - w) x P. E = share of emails that reach a dead "
                     "address (invalid emails if measured, otherwise the bounce rate). P = share of contacts with no "
                     "valid phone or mobile number (check 2.4). w = the email share of touches (email_share, default "
                     "0.5: half emails, half calls). A channel that wasn't measured contributes 0, so the rate is "
                     "never scaled up to look complete. Contacts who changed jobs are a finding of their own and are "
                     "not priced.")
MINUTES_LOW, MINUTES_MID, MINUTES_HIGH = 1.0, 2.0, 3.0


def bad_touch_rate(results, email_share: float = 0.5) -> dict:
    """The share of touches that hit bad data, from the audit's own measurements (see BAD_TOUCH_FORMULA)."""
    def val(cid):
        r = results.get(cid)
        return r.value if r is not None and r.value is not None else None

    w = 0.5 if email_share is None or not 0 <= email_share <= 1 else email_share
    if val("2.2") is not None:
        email, email_src = val("2.2"), "invalid emails"
    else:
        email, email_src = val("2.1"), "bounced emails"
    phone = val("2.4")
    left = val("2.3")
    used, missing = [], []
    if email is not None:
        used.append(f"{email_src} {email:.1f}%")
    else:
        missing.append("email failures weren't measured (checks 2.1/2.2), so they aren't priced")
    if phone is not None:
        used.append(f"contacts with no valid phone {phone:.1f}%")
    else:
        missing.append("phone failures weren't measured (check 2.4), so they aren't priced")
    base = {"used": used, "missing": missing, "formula": BAD_TOUCH_FORMULA, "email": email, "phone": phone,
            "email_share": w, "left": left}
    if email is None and phone is None:
        return {**base, "pct": None, "source": "Not available: enter bad_touch_pct or measure checks 2.1, 2.2 or 2.4"}
    pct = w * (email or 0.0) + (1 - w) * (phone or 0.0)
    src = f"{w:g} x email + {1 - w:g} x phone, from " + ", ".join(used)
    if missing:
        src += ". " + "; ".join(missing)
    return {**base, "pct": pct, "source": src}


def _round_to(v, step):
    return round(v / step) * step


def build_impact(results, cfg) -> dict:
    """Estimated cost of bad data, as a range. Every figure is an ESTIMATE built from the inputs in `inputs`.
    hours/cost are the midpoint (kept for history and comparisons); hours_low/high and cost_low/high are the
    rounded range (1 and 3 minutes per bad touch by default); `defaults` names inputs nobody entered."""
    imp = cfg.get("impact", {})
    A, B = _pos(imp.get("reps")), _pos(imp.get("touches_per_rep_per_day"))
    D_in, E_in, F_in = _pos(imp.get("minutes_per_bad_touch")), _pos(imp.get("selling_days")), _pos(imp.get("hourly_cost"))
    Lo_in, Hi_in = _pos(imp.get("minutes_low")), _pos(imp.get("minutes_high"))
    D, E, F = D_in or MINUTES_MID, E_in or 230.0, F_in or 40.0
    lo_m, hi_m = Lo_in or MINUTES_LOW, Hi_in or MINUTES_HIGH
    lo_m, hi_m = min(lo_m, D), max(hi_m, D)
    share_in = _num(imp.get("email_share"))
    share = share_in if share_in is not None and 0 <= share_in <= 1 else 0.5
    C = _num(imp.get("bad_touch_pct"))
    if C is not None and not 0 <= C <= 100:
        C = None
    bt = bad_touch_rate(results, share)
    if C is not None:
        c_src, c_from_audit = "Entered in audit.toml", False
    else:
        C, c_src, c_from_audit = bt["pct"], bt["source"], bt["pct"] is not None

    def src(entered, text):
        return text if entered else f"DEFAULT, not entered: {text}"

    inputs = [
        ("A. Number of reps", A, "Entered" if A is not None else "MISSING: enter reps in audit.toml"),
        ("B. Dials and emails per rep per day", B,
         "Entered" if B is not None else "MISSING: enter touches_per_rep_per_day in audit.toml"),
        ("C. % of touches hitting bad data", round(C, 1) if C is not None else None, c_src),
        ("D. Minutes wasted per bad touch (midpoint)", D,
         src(D_in is not None, f"assumed 2; the range uses {lo_m:g} and {hi_m:g} minutes")),
        ("E. Selling days per year", E, src(E_in is not None, "the checklist assumes 230")),
        ("F. Loaded hourly cost per rep ($)", F, src(F_in is not None, "salary + commission / 2,000 hrs; assumes $40")),
    ]
    if C is not None and c_from_audit:
        inputs.append(("w. Email share of touches", share,
                       "Entered in audit.toml (email_share)" if share_in is not None else
                       "DEFAULT, not entered: half the touches are emails and half are calls (email_share = 0.5; "
                       "the iPad app has no field for it)"))
    defaults = [n for n, v in (("minutes per bad touch", D_in), ("selling days", E_in), ("hourly cost", F_in))
                if v is None]
    if c_from_audit and share_in is None:
        defaults.append("email share of touches")
    missing_inputs = [n for n, v in (("number of reps", A), ("touches per rep per day", B)) if v is None]

    def hours_at(m):
        return A * B * (C / 100) * m * E / 60

    hours = cost = hours_low = hours_high = cost_low = cost_high = None
    if None not in (A, B, C, D, E):
        hours = hours_at(D)
        cost = hours * F
        hours_low, hours_high = _round_to(hours_at(lo_m), 10), _round_to(hours_at(hi_m), 10)
        cost_low, cost_high = _round_to(hours_at(lo_m) * F, 500), _round_to(hours_at(hi_m) * F, 500)
    hours_text = cost_text = headline = basis = None
    if cost is not None:
        hours_text = f"{hours_low:,.0f}\u2013{hours_high:,.0f}"
        cost_text = f"${cost_low:,.0f}\u2013${cost_high:,.0f}"
        headline = f"About {hours_text} rep hours a year (estimated {cost_text})"
        basis = (f"Estimate (a modelled range, not a measurement): {A:g} reps x {B:g} touches a day x {C:.0f}% hitting "
                 f"bad data x {lo_m:g} to {hi_m:g} minutes each x {E:g} days at ${F:,.0f}/hour")
        if defaults:
            basis += f" (assumed, not entered: {', '.join(defaults)})"
    elif missing_inputs:
        basis = f"Can't be estimated yet: enter the {' and the '.join(missing_inputs)} in audit.toml"

    extras = []
    left = bt.get("left")
    if left is not None:
        extras.append(("Contacts who have changed jobs (not priced)", None,
                       f"{left:g}% of the key contacts checked have left their company. This is a finding of its own "
                       "and is not included in any dollar figure."))
    stale = results["4.4"].extras.get("stale_amount")
    if stale is not None:
        extras.append(("Pipeline that needs review", stale,
                       "Open deals past their close date or with no activity in 30+ days. Not lost money and not "
                       "necessarily wrong: some may be fine. This is the amount to review before trusting the forecast."))
    dup_amt = results["1.4"].extras.get("amount")
    if dup_amt:
        extras.append(("Possible double-counted pipeline (duplicate deals)", dup_amt,
                       "Value of the extra copies of open deals that look like duplicates; confirm before removing"))
    unworked = results["4.2"].extras.get("unworked_count")
    rate = _num(imp.get("lead_to_customer_rate_pct"))
    avg = _num(imp.get("avg_deal_size")) or results["4.4"].extras.get("avg_won_amount")
    avg_src = "entered" if _num(imp.get("avg_deal_size")) else "average won deal in the export"
    if unworked is not None:
        if rate is not None and avg:
            extras.append(("Estimated revenue at risk from unworked leads (per 90 days)", unworked * rate / 100 * avg,
                           f"{unworked:,} unworked leads x {rate:g}% lead-to-customer x ${avg:,.0f} "
                           f"avg deal ({avg_src}). A rough estimate, not a forecast"))
        else:
            extras.append(("Estimated revenue at risk from unworked leads (per 90 days)", None,
                           f"{unworked:,} unworked leads; enter lead_to_customer_rate_pct "
                           + ("" if avg else "and avg_deal_size ") + "to estimate their value"))
    adm_h = _num(imp.get("admin_hours_per_week"))
    if adm_h is not None:
        adm_c = _num(imp.get("admin_hourly_cost")) or F
        extras.append(("Estimated admin time fixing data (per year)", adm_h * adm_c * 50,
                       f"{adm_h:g} hrs/week x ${adm_c:,.0f}/hr x 50 weeks"))
    return {"inputs": inputs, "hours": hours, "cost": cost, "extras": extras,
            "fte": hours / 2000 if hours is not None else None,
            "hours_low": hours_low, "hours_high": hours_high, "cost_low": cost_low, "cost_high": cost_high,
            "hours_text": hours_text, "cost_text": cost_text, "headline": headline,
            "minutes_low": lo_m, "minutes_high": hi_m,
            "basis": basis, "defaults": defaults, "missing_inputs": missing_inputs,
            "bad_touch": {**bt, "pct": C, "from_audit": c_from_audit}}
