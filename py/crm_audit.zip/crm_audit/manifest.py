"""The integrity manifest: a compact record of every change the kit proposed.

The kit writes it into the review workbook (hidden sheets) and next to the kit as a small .json file.
apply-review checks the returned workbook against it, so a changed Record ID, field or "current value"
can't slip into the load files, and a row that was never proposed is ignored.
Values are stored as short hashes, never as the CRM's text.
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import re
import zlib

CHUNK = 30000   # an Excel cell holds at most 32,767 characters


def norm(v) -> str:
    """A cell as clean text. Excel turns IDs such as 0031234 or 5001 into numbers; they come back as text."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "Yes" if v else "No"
    if isinstance(v, float) and v == v and v == int(v):
        return str(int(v))
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, float) and v != v:
        return ""
    return re.sub(r"[ \t\r\n]+$", "", str(v)).lstrip()


def h(v) -> str:
    return hashlib.sha256(norm(v).encode("utf-8")).hexdigest()[:16]


def entry(sheet, obj, rid, field, cur, new, kind) -> dict:
    return {"s": sheet, "o": str(obj), "r": norm(rid), "f": str(field), "c": h(cur), "p": h(new), "k": kind}


def group_hash(ids, names, same, fill, keep) -> str:
    """One hash for a duplicate group's hidden facts (who is in it, who is suggested, what can be copied)."""
    blob = {"ids": [norm(i) for i in ids], "names": {norm(i): norm(names.get(i)) for i in ids},
            "same": {norm(i): bool(same.get(i)) for i in ids},
            "fill": {norm(i): {str(k): norm(v) for k, v in (fill.get(i) or {}).items()} for i in ids},
            "keep": norm(keep)}
    return h(json.dumps(blob, sort_keys=True))


def table_hash(cols, rows) -> str:
    """One hash for a whole information-only sheet (Rep to-do, Enrich): its header and every cell."""
    return h(json.dumps([[str(c) for c in cols], [[norm(v) for v in r] for r in rows]], sort_keys=True))


def canonical(m: dict) -> str:
    return json.dumps(m, sort_keys=True, separators=(",", ":"))


def pack(m: dict) -> list[str]:
    """The manifest as a few short strings that fit in spreadsheet cells."""
    raw = base64.b64encode(zlib.compress(canonical(m).encode("utf-8"), 9)).decode("ascii")
    return [raw[i:i + CHUNK] for i in range(0, len(raw), CHUNK)] or [""]


def unpack(chunks: list[str]) -> dict:
    return json.loads(zlib.decompress(base64.b64decode("".join(chunks))).decode("utf-8"))


def digest(chunks: list[str]) -> str:
    return hashlib.sha256("".join(chunks).encode("ascii")).hexdigest()
