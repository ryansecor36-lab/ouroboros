"""Where the bad data comes from: traces every problem record back to who (or which integration)
created it and through which lead source, and whether problems are still coming in.

This answers the most common CRM complaint: "we clean it up and it's dirty again next week."
"""
from __future__ import annotations

from collections import Counter

import pandas as pd

# Which checks' flagged records count as a problem, and what to call the problem.
ISSUE_LABEL = {
    "1.1": "duplicate", "1.2": "duplicate", "1.3": "duplicate", "1.6": "lead already a contact",
    "3.5": "junk or badly formatted entry", "3.8": "made-up value",
}
TRACED = "duplicates, made-up values, junk entries and leads that already exist"
OBJECT_LABEL = {"contacts": "Contact", "accounts": "Account", "leads": "Lead"}
RECENT_DAYS = 180
MIN_RECORDS = 10  # don't rank a creator or source with fewer records than this


def analyze(ctx, results) -> dict | None:
    frames = []
    for obj in ("contacts", "accounts", "leads"):
        df = getattr(ctx, obj)
        if df is None or "creator" not in df or df["creator"].isna().all():
            continue
        issues: dict[str, list[str]] = {}
        for cid, label in ISSUE_LABEL.items():
            for rid in results[cid].flagged.get(obj, ()):
                lst = issues.setdefault(rid, [])
                if label not in lst:
                    lst.append(label)
        f = pd.DataFrame({
            "object": OBJECT_LABEL[obj], "id": df["id"], "creator": df["creator"].fillna("(unknown)"),
            "integration": df["creator_is_integration"], "created": df.get("created"),
            "lead_source": df["lead_source"] if "lead_source" in df else None,
        })
        f["issues"] = f["id"].map(lambda i: issues.get(i, []))
        frames.append(f)
    if not frames:
        return None
    allr = pd.concat(frames, ignore_index=True)
    allr["has_problem"] = allr["issues"].map(bool)
    total_problems = int(allr["has_problem"].sum())
    if not total_problems:
        return None

    def top_issue(s):
        c = Counter(x for lst in s for x in lst)
        return ", ".join(k for k, _ in c.most_common(2))

    g = allr.groupby("creator")
    by_creator = pd.DataFrame({
        "Records created": g.size(),
        "Records with a problem": g["has_problem"].sum().astype(int),
        "Automated integration": g["integration"].any(),
        "Most common problems": g["issues"].agg(top_issue),
    })
    by_creator["Problem rate %"] = (100 * by_creator["Records with a problem"] / by_creator["Records created"]).round(1)
    by_creator["Share of all problems %"] = (100 * by_creator["Records with a problem"] / total_problems).round(1)
    by_creator = by_creator.sort_values("Records with a problem", ascending=False)
    by_creator.index.name = "Created by"

    # How much of the trouble comes from automation vs people
    integ_share = 100 * allr.loc[allr["integration"], "has_problem"].sum() / total_problems
    top_name = by_creator.index[0]
    top = by_creator.iloc[0]

    by_source = None
    src = allr.dropna(subset=["lead_source"])
    if len(src):
        gs = src.groupby("lead_source")
        by_source = pd.DataFrame({
            "Records": gs.size(),
            "Records with a problem": gs["has_problem"].sum().astype(int),
            "Most common problems": gs["issues"].agg(top_issue),
        })
        by_source = by_source[by_source["Records"] >= MIN_RECORDS]
        by_source["Problem rate %"] = (100 * by_source["Records with a problem"] / by_source["Records"]).round(1)
        by_source = by_source.sort_values("Problem rate %", ascending=False)
        by_source.index.name = "Lead source"

    trend = None
    if allr["created"].notna().any():
        cutoff = ctx.audit_date - pd.Timedelta(days=RECENT_DAYS)
        recent = allr[allr["created"] >= cutoff]
        older = allr[allr["created"] < cutoff]
        if len(recent) >= MIN_RECORDS and len(older) >= MIN_RECORDS:
            r_rate, o_rate = 100 * recent["has_problem"].mean(), 100 * older["has_problem"].mean()
            trend = {"recent_rate": r_rate, "older_rate": o_rate, "recent_count": len(recent),
                     "recent_problems": int(recent["has_problem"].sum())}
            if r_rate >= o_rate * 0.8:
                trend["sentence"] = (f"Records created in the last 6 months have problems {r_rate:.0f}% of the time "
                                     f"(older records: {o_rate:.0f}%). Bad data is still coming in, so a one-time "
                                     "cleanup won't last unless the source is fixed.")
            else:
                trend["sentence"] = (f"Records created in the last 6 months have problems {r_rate:.0f}% of the time, "
                                     f"down from {o_rate:.0f}% for older records. New data is cleaner, so most of "
                                     "the work is cleaning up the backlog.")

    kind = " (an automated integration)" if top["Automated integration"] else ""
    headline = (f"{top_name}{kind} created {top['Share of all problems %']:.0f}% of the problem records "
                f"({int(top['Records with a problem']):,} of {total_problems:,})")
    others = allr[allr["creator"] != top_name]
    if len(others):
        other_rate = 100 * others["has_problem"].mean()
        if top["Problem rate %"] >= 1.5 * other_rate and other_rate > 0:
            headline += (f". {top['Problem rate %']:.0f}% of the records it creates have a problem, "
                         f"compared with {other_rate:.0f}% for everyone else")
    return {
        "headline": headline, "top_creator": top_name, "top_share": float(top["Share of all problems %"]),
        "top_is_integration": bool(top["Automated integration"]), "integration_share": float(integ_share),
        "total_problems": total_problems, "by_creator": by_creator.reset_index(),
        "by_source": by_source.reset_index() if by_source is not None else None, "trend": trend,
        "traced": TRACED,
    }
