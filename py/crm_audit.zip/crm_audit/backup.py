"""Backs up the client work that lives only on this laptop (clients, history, reports, your branding files)
into one zip, and puts it back. The program itself is never backed up: it is in git.

  python -m crm_audit backup [--to <folder>]
  python -m crm_audit restore --from <zip> [--force]

Nothing leaves the laptop except into the folder you choose (by default your OneDrive, if you have one,
otherwise Documents). The backup holds client data, so keep it somewhere private."""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import stat
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIRS = ("clients", "history", "reports", "branding")       # folders under the repo that are backed up
EXTRA_SUFFIXES = {".toml", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico"}   # branding / settings not in git
CODE_DIRS = {"crm_audit", "tests", "tools", "site", "webapp", "webapp_src", "samples", "sales", ".git", ".cache",
             ".venv", ".claude", "__pycache__", "node_modules"}
KEEP = 10
STAMP = re.compile(r"^Uroboric-backup-(\d{4}-\d{2}-\d{2}-\d{4}(?:\d{2})?)(?:-(\d+))?\.zip$")  # old and new names
STALE_DAYS = 7
PRIVACY = "This backup contains client data. Keep it somewhere private."
NOTE_NAME = "UROBORIC_BACKUP.txt"


def settings_file() -> Path:
    base = os.environ.get("APPDATA")
    return (Path(base) if base else Path.home() / ".config") / "Uroboric" / "settings.json"


def read_settings(path: Path | None = None) -> dict:
    try:
        data = json.loads((path or settings_file()).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_settings(updates: dict, path: Path | None = None) -> None:
    path = path or settings_file()
    data = read_settings(path)
    data.update(updates)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError:
        pass  # a settings file that can't be saved only means the choice isn't remembered


def default_destination(env=None, home: Path | None = None, settings: dict | None = None) -> Path:
    """The folder remembered from last time; else OneDrive\\Uroboric backups when OneDrive exists; else
    Documents\\Uroboric backups."""
    env = os.environ if env is None else env
    saved = (settings if settings is not None else read_settings()).get("backup_folder")
    if saved:
        return Path(saved)
    for name in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        folder = env.get(name)
        if folder and Path(folder).is_dir():
            return Path(folder) / "Uroboric backups"
    return (home or Path.home()) / "Documents" / "Uroboric backups"


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _untracked(root: Path) -> list[Path]:
    """Files git doesn't track (and that aren't in its ignore list): your own logos and settings."""
    try:
        r = subprocess.run(["git", "ls-files", "-z", "--others", "--exclude-standard"], cwd=root,
                           capture_output=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        r = None
    if r is not None and r.returncode == 0:
        return [root / n for n in r.stdout.decode("utf-8", "replace").split("\0") if n]
    return [p for p in root.iterdir() if p.is_file()]   # no git: look at the top level only


def is_link(path: Path) -> bool:
    """A symbolic link or a Windows junction / other reparse point: it can lead outside the folder."""
    try:
        if os.path.islink(path):
            return True
        attrs = getattr(os.lstat(path), "st_file_attributes", 0)
        return bool(attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    except OSError:
        return False


def collect(root: Path, notes: list | None = None) -> list[tuple[Path, str]]:
    """(file, name inside the zip) for everything to back up, in a steady order. Links and junctions are
    never followed (they could lead outside the folder); each one skipped is added to `notes`."""
    notes = notes if notes is not None else []
    found: dict[str, Path] = {}
    for d in DATA_DIRS:
        base = root / d
        if is_link(base):
            notes.append(f"{d} is a shortcut (link) to another place, so it was not backed up")
            continue
        if not base.is_dir():
            continue
        for here, dirs, names in os.walk(base):
            for d2 in list(dirs):
                if is_link(Path(here) / d2) or d2 == "__pycache__":
                    dirs.remove(d2)
                    if d2 != "__pycache__":
                        notes.append(f"{(Path(here) / d2).relative_to(root).as_posix()} is a link, so it was skipped")
            for n in names:
                p = Path(here) / n
                if is_link(p):
                    notes.append(f"{p.relative_to(root).as_posix()} is a link, so it was skipped")
                else:
                    found[p.relative_to(root).as_posix()] = p
    for p in _untracked(root):
        rel = p.relative_to(root)
        if p.is_file() and not is_link(p) and p.suffix.lower() in EXTRA_SUFFIXES \
                and not (set(rel.parts[:-1]) & CODE_DIRS):
            found.setdefault(rel.as_posix(), p)
    return [(found[k], k) for k in sorted(found)]


def _size(n: int) -> str:
    return f"{n / 1_048_576:.1f} MB" if n >= 1_048_576 else f"{max(1, n // 1024)} KB"


def prune(folder: Path, keep: int = KEEP) -> list[Path]:
    """Delete all but the newest backups in the folder. Only files named like our own backups are touched."""
    def order(p):  # oldest first: by time stamp (minutes or seconds), then by the -2, -3 suffix
        m = STAMP.match(p.name)
        return (m.group(1).replace("-", "").ljust(14, "0"), int(m.group(2) or 1))
    mine = sorted((p for p in folder.iterdir() if p.is_file() and not is_link(p) and STAMP.match(p.name)), key=order)
    old = mine[:-keep] if len(mine) > keep else []
    for p in old:
        try:
            p.unlink()
        except OSError:
            pass
    return old


def make_backup(dest: Path, root: Path = ROOT, now: dt.datetime | None = None) -> dict:
    now = now or dt.datetime.now()
    dest = Path(dest)
    if _inside(dest, root):
        raise ValueError(f"The backup can't go inside the Uroboric folder ({root}). Pick another folder, for example "
                         "your OneDrive or Documents.")
    notes: list[str] = []
    files = collect(root, notes)
    if not files:
        raise ValueError("There is nothing to back up yet: the clients, history and reports folders are empty.")
    try:
        dest.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ValueError(f"I couldn't use {dest} for the backup ({e.strerror or e}). Pick another folder with: "
                         "backup --to <folder>") from None
    counts: dict[str, int] = {}
    target, handle = None, None
    for n in range(1, 1000):  # a second backup in the same second gets -2, -3 ...; nothing is ever replaced
        name = f"Uroboric-backup-{now:%Y-%m-%d-%H%M%S}" + (f"-{n}" if n > 1 else "") + ".zip"
        try:
            handle = open(dest / name, "xb")
            target = dest / name
            break
        except FileExistsError:
            continue
        except OSError as e:
            raise ValueError(f"The backup couldn't be written to {dest} ({e.strerror or e}).") from None
    if handle is None:
        raise ValueError(f"Too many backups were made in the same second in {dest}. Try again.")
    try:
        with handle, zipfile.ZipFile(handle, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr(NOTE_NAME, f"Uroboric backup made {now:%Y-%m-%d %H:%M}.\n{PRIVACY}\n"
                                  "Put it back with:  python -m crm_audit restore --from <this file>\n")
            for p, name in files:
                z.write(p, name)
                top = name.split("/")[0] if "/" in name else "settings and logos"
                counts[top] = counts.get(top, 0) + 1
    except OSError as e:
        target.unlink(missing_ok=True)  # only the half-written file this call created
        raise ValueError(f"The backup couldn't be written to {dest} ({e.strerror or e}). Is the disk full?") from None
    removed = prune(dest)
    return {"zip": target, "files": len(files), "counts": counts, "size": target.stat().st_size,
            "removed": removed, "time": now, "notes": notes}


def cmd_backup(args) -> dict:
    explicit = getattr(args, "to", None)
    dest = Path(explicit) if explicit else default_destination()
    sm = make_backup(dest)
    write_settings({"backup_folder": str(dest), "last_backup": sm["time"].isoformat(timespec="minutes")})
    parts = ", ".join(f"{n:,} in {k}" for k, n in sm["counts"].items())
    print(f"Backup saved: {sm['zip']}")
    print(f"  {sm['files']:,} files ({parts}), {_size(sm['size'])}.")
    if sm["removed"]:
        print(f"  Removed {len(sm['removed'])} older backup{'s' if len(sm['removed']) != 1 else ''} "
              f"(the newest {KEEP} are kept).")
    for n in sm["notes"]:
        print(f"  Note: {n}.")
    print(f"  {PRIVACY}")
    if not explicit:
        print("  To use a different folder next time: backup --to <folder>")
    if getattr(args, "open", False) and not os.environ.get("UROBORIC_NO_OPEN"):
        try:
            os.startfile(dest)
        except (AttributeError, OSError):
            pass
    return sm


def last_backup(settings: dict | None = None) -> dt.datetime | None:
    raw = (settings if settings is not None else read_settings()).get("last_backup")
    try:
        return dt.datetime.fromisoformat(raw) if raw else None
    except (TypeError, ValueError):
        return None


def tip_line(now: dt.datetime | None = None, settings: dict | None = None) -> str:
    """One reminder line when the last backup is over a week old (or there never was one); else ''."""
    now = now or dt.datetime.now()
    last = last_backup(settings)
    if last is None:
        return "Tip: your client files haven't been backed up yet. Double-click 'Back up Uroboric'."
    if now - last > dt.timedelta(days=STALE_DAYS):
        return (f"Tip: your client files haven't been backed up since {last:%b} {last.day}, {last.year}. "
                "Double-click 'Back up Uroboric'.")
    return ""


def _allowed(name: str) -> bool:
    parts = name.replace("\\", "/").split("/")
    if name.startswith(("/", "\\")) or ".." in parts or re.match(r"^[A-Za-z]:", name):
        return False
    if len(parts) == 1:
        return Path(name).suffix.lower() in EXTRA_SUFFIXES
    if parts[0] in DATA_DIRS:
        return True
    return Path(name).suffix.lower() in EXTRA_SUFFIXES and not (set(parts[:-1]) & CODE_DIRS)


def _zip_time(info: zipfile.ZipInfo) -> float:
    return time.mktime(info.date_time + (0, 0, -1))


def restore_backup(source: Path, root: Path = ROOT, force: bool = False) -> dict:
    source = Path(source)
    if not source.is_file():
        raise ValueError(f"I couldn't find the backup file {source}.")
    try:
        z = zipfile.ZipFile(source)
    except zipfile.BadZipFile:
        raise ValueError(f"{source.name} isn't a backup file (it can't be opened as a zip).") from None
    with z:
        members = [i for i in z.infolist() if not i.is_dir() and i.filename != NOTE_NAME]
        ok = [i for i in members if _allowed(i.filename)]
        skipped = [i.filename for i in members if not _allowed(i.filename)]
        if not ok:
            raise ValueError(f"{source.name} doesn't look like a Uroboric backup, so nothing was restored.")
        root_real = Path(root).resolve()
        unsafe = []
        for i in ok:
            target = Path(root) / i.filename
            try:
                inside = target.resolve().is_relative_to(root_real)
            except (OSError, ValueError):
                inside = False
            cur, link = Path(root), False
            for part in Path(i.filename).parts:
                cur = cur / part
                if os.path.lexists(cur) and is_link(cur):
                    link = True
                    break
            if not inside or link:
                unsafe.append(i.filename)
        if unsafe:
            shown = ", ".join(unsafe[:5]) + (f" and {len(unsafe) - 5} more" if len(unsafe) > 5 else "")
            raise ValueError("Nothing was restored: these backup files would be written through a shortcut (link or "
                             f"junction) to somewhere outside the Uroboric folder: {shown}. Remove the shortcut, "
                             "or restore into a clean copy of the folder.")
        conflicts = []
        for i in ok:
            target = root / i.filename
            if target.is_file() and target.stat().st_mtime > _zip_time(i) + 2:
                conflicts.append(i.filename)
        if conflicts and not force:
            shown = "\n".join(f"    {c}" for c in conflicts[:15])
            more = f"\n    ...and {len(conflicts) - 15} more" if len(conflicts) > 15 else ""
            raise ValueError(f"{len(conflicts)} file{'s' if len(conflicts) != 1 else ''} on this laptop "
                             f"{'are' if len(conflicts) != 1 else 'is'} newer than the backup, so nothing was restored:"
                             f"\n{shown}{more}\n  To restore anyway (the newer versions are replaced), add --force.")
        for i in ok:
            target = root / i.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(i) as src, open(target, "wb") as out:
                out.write(src.read())
            t = _zip_time(i)
            os.utime(target, (t, t))
    return {"restored": len(ok), "replaced_newer": len(conflicts), "skipped": skipped}


def cmd_restore(args) -> dict:
    sm = restore_backup(Path(args.source), ROOT, force=args.force)
    print(f"Restored {sm['restored']:,} files into {ROOT}.")
    if sm["replaced_newer"]:
        print(f"  {sm['replaced_newer']:,} newer file{'s were' if sm['replaced_newer'] != 1 else ' was'} replaced.")
    if sm["skipped"]:
        print(f"  {len(sm['skipped'])} file{'s' if len(sm['skipped']) != 1 else ''} in the zip weren't "
              "client files, so they were left out.")
    return sm


if __name__ == "__main__":  # pragma: no cover
    sys.exit("Use:  python -m crm_audit backup")
