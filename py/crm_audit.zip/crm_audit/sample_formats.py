"""Turns the fake sample company (generated in Salesforce format) into what HubSpot,
Microsoft Dynamics 365, Bullhorn and Crelate exports look like, so the tool can be tried and demoed on all five CRMs.
Every record is made up."""
from __future__ import annotations

import csv
import random
import uuid
from datetime import datetime
from pathlib import Path

from . import normalize as N


def _read(folder: Path, name: str) -> list[dict]:
    with open(folder / name, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _when(ts: str):
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "").replace(".000", ""))
    except ValueError:
        return None


def _write_csv(path: Path, rows: list[dict]):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def _users(folder):
    users = {u["Id"]: u for u in _read(folder, "users.csv")}
    integ = {i for i, u in users.items() if u.get("Profile") == "Integration User"}
    return users, integ


# ------------------------------------------------------------------ HubSpot

HS_STAGE = {"Prospecting": "Appointment Scheduled", "Qualification": "Qualified To Buy",
            "Needs Analysis": "Presentation Scheduled", "Proposal/Price Quote": "Decision Maker Bought-In",
            "Negotiation/Review": "Contract Sent", "Closed Won": "Closed Won", "Closed Lost": "Closed Lost"}
HS_SOURCE = {"Web": "Organic Search", "Referral": "Referrals", "Trade Show": "Offline Sources",
             "Purchased List": "Offline Sources", "Partner": "Referrals", "Cold Call": "Offline Sources",
             "Webinar": "Offline Sources"}


def write_hubspot(sf: Path, out: Path, today) -> Path:
    rng = random.Random(11)
    users, integ = _users(sf)

    def owner(uid):
        u = users.get(uid)
        if not u:
            return ""
        return u["Name"] + (" (Deactivated User)" if u["IsActive"] == "false" else "")

    def source(uid):  # HubSpot records which tool created a record, not who
        if uid in integ:
            return "INTEGRATION", "Marketing Sync"
        return rng.choice(["CRM_UI", "CRM_UI", "CRM_UI", "IMPORT"]), ""

    def hs_time(ts):
        d = _when(ts)
        return d.strftime("%Y-%m-%d %H:%M") if d else ""

    ids = {}

    def rid(sfid, base):
        if sfid not in ids:
            ids[sfid] = str(base + len(ids) + 1)
        return ids[sfid]

    accounts = _read(sf, "accounts.csv")
    acct_name = {a["Id"]: a["Name"] for a in accounts}
    companies = []
    for a in accounts:
        rs, rsd = source(a.get("CreatedById"))
        companies.append({
            "Record ID": rid(a["Id"], 7_000_000_000), "Company name": a["Name"],
            "Company Domain Name": N.norm_domain(a["Website"]) or "", "Website URL": a["Website"],
            "Industry": a["Industry"], "Number of Employees": a["NumberOfEmployees"], "City": a["BillingCity"],
            "State/Region": a["BillingState"], "Country/Region": a["BillingCountry"],
            "Company owner": owner(a["OwnerId"]), "Create Date": hs_time(a["CreatedDate"]),
            "Last Modified Date": hs_time(a["LastModifiedDate"]), "Record source": rs, "Record source detail 1": rsd,
        })

    # HubSpot won't hold two contacts with the same email, so the exact-email copies don't exist there
    seen, contacts = set(), []
    for c in _read(sf, "contacts.csv"):
        e = N.norm_email(c["Email"])
        if e and e in seen and not N.is_placeholder_email(e):
            continue
        seen.add(e)
        rs, rsd = source(c.get("CreatedById"))
        contacts.append({
            "Record ID": rid(c["Id"], 100_000), "First Name": c["FirstName"], "Last Name": c["LastName"],
            "Email": c["Email"], "Phone Number": c["Phone"], "Mobile Phone Number": c["MobilePhone"],
            "Job Title": c["Title"], "Associated Company IDs (Primary)": ids.get(c["AccountId"], ""),
            "Associated Company": acct_name.get(c["AccountId"], ""), "Contact owner": owner(c["OwnerId"]),
            "Lifecycle Stage": rng.choice(["Customer", "Customer", "Opportunity", "Sales Qualified Lead"]),
            "Lead Source": HS_SOURCE.get(c["LeadSource"], ""), "State/Region": c["MailingState"],
            "Country/Region": c["MailingCountry"], "Unsubscribed from all email": c["HasOptedOutOfEmail"],
            "Create Date": hs_time(c["CreatedDate"]), "Last Modified Date": hs_time(c["LastModifiedDate"]),
            "Last Activity Date": c["LastActivityDate"], "Seniority": c.get("Seniority__c", ""),
            "Record source": rs, "Record source detail 1": rsd,
        })
    # Leads are contacts in an early lifecycle stage (skipping any HubSpot would have merged by email)
    for l in _read(sf, "leads.csv"):
        e = N.norm_email(l["Email"])
        if e in seen:
            continue
        seen.add(e)
        rs, rsd = source(l.get("CreatedById"))
        contacts.append({
            "Record ID": rid(l["Id"], 100_000), "First Name": l["FirstName"], "Last Name": l["LastName"],
            "Email": l["Email"], "Phone Number": "", "Mobile Phone Number": "", "Job Title": "",
            "Associated Company IDs (Primary)": "", "Associated Company": l["Company"],
            "Contact owner": owner(l["OwnerId"]),
            "Lifecycle Stage": "Sales Qualified Lead" if l["IsConverted"] == "true" else rng.choice(["Lead", "Marketing Qualified Lead"]),
            "Lead Source": HS_SOURCE.get(l["LeadSource"], ""), "State/Region": "", "Country/Region": "",
            "Unsubscribed from all email": "false", "Create Date": hs_time(l["CreatedDate"]),
            "Last Modified Date": hs_time(l["CreatedDate"]), "Last Activity Date": l["LastActivityDate"],
            "Seniority": "", "Record source": rs or "FORM", "Record source detail 1": rsd,
        })

    deals = []
    for o in _read(sf, "opportunities.csv"):
        p = o.get("Probability", "")
        deals.append({
            "Record ID": rid(o["Id"], 30_000_000), "Deal Name": o["Name"], "Pipeline": "Sales Pipeline",
            "Deal Stage": HS_STAGE.get(o["StageName"], o["StageName"]), "Amount": o["Amount"],
            "Close Date": o["CloseDate"], "Deal owner": owner(o["OwnerId"]),
            "Associated Company IDs (Primary)": ids.get(o["AccountId"], ""),
            "Associated Company": acct_name.get(o["AccountId"], ""),
            "Associated Contact IDs": ids.get(o["ContactId"], ""),
            "Deal probability": f"{float(p) / 100:g}" if p else "",
            "Closed Lost Reason": o["Loss_Reason__c"], "Create Date": hs_time(o["CreatedDate"]),
            "Last Activity Date": o["LastActivityDate"],
        })
    out.mkdir(parents=True, exist_ok=True)
    stamp = f"{today:%Y-%m-%d}"
    _write_csv(out / f"hubspot-crm-exports-all-companies-{stamp}.csv", companies)
    _write_csv(out / f"hubspot-crm-exports-all-contacts-{stamp}.csv", contacts)
    _write_csv(out / f"hubspot-crm-exports-all-deals-{stamp}.csv", deals)
    return out


# ------------------------------------------------------------------ Dynamics 365

DYN_STAGE = {"Prospecting": "1-Qualify", "Qualification": "1-Qualify", "Needs Analysis": "2-Develop",
             "Proposal/Price Quote": "3-Propose", "Negotiation/Review": "4-Close"}


def write_dynamics(sf: Path, out: Path, today) -> Path:
    from openpyxl import Workbook

    users, integ = _users(sf)
    guid = lambda sfid: str(uuid.uuid5(uuid.NAMESPACE_URL, "ouroboros-sample/" + sfid)) if sfid else None  # noqa: E731
    name = lambda uid: users[uid]["Name"] if uid in users else None  # noqa: E731

    def sheet(path: Path, entity: str, header: list[str], rows: list[list]):
        wb = Workbook()
        ws = wb.active
        ws.title = entity
        ws.append(header)
        for r in rows:
            ws.append(r)
        for i, h in enumerate(header, 1):  # Dynamics hides its "(Do Not Modify)" columns
            if h.startswith("(Do Not Modify)"):
                ws.column_dimensions[ws.cell(1, i).column_letter].hidden = True
        hidden = wb.create_sheet("hiddenSheet")
        hidden["A1"] = entity.lower()
        hidden.sheet_state = "veryHidden"
        wb.save(path)

    dnm = ["(Do Not Modify) Row Checksum", "(Do Not Modify) Modified On"]
    stamp = f"{today:%m-%d-%Y} 9-21-22 AM"
    out.mkdir(parents=True, exist_ok=True)

    accounts = _read(sf, "accounts.csv")
    acct_name = {a["Id"]: a["Name"] for a in accounts}
    sheet(out / f"Active Accounts {stamp}.xlsx", "Account",
          ["(Do Not Modify) Account", *dnm, "Account Name", "Website", "Industry", "Number of Employees",
           "Address 1: City", "Address 1: State/Province", "Address 1: Country/Region", "Owner", "Created On",
           "Created By"],
          [[guid(a["Id"]), uuid.uuid4().hex[:24], _when(a["LastModifiedDate"]), a["Name"], a["Website"],
            a["Industry"], int(a["NumberOfEmployees"]) if a["NumberOfEmployees"] else None, a["BillingCity"],
            a["BillingState"], a["BillingCountry"], name(a["OwnerId"]), _when(a["CreatedDate"]),
            name(a.get("CreatedById"))] for a in accounts])

    contacts = _read(sf, "contacts.csv")
    full = {c["Id"]: f"{c['FirstName']} {c['LastName']}".strip() for c in contacts}
    sheet(out / f"Active Contacts {stamp}.xlsx", "Contact",
          ["(Do Not Modify) Contact", *dnm, "Full Name", "First Name", "Last Name", "Email", "Business Phone",
           "Mobile Phone", "Job Title", "Company Name", "Address 1: State/Province", "Address 1: Country/Region",
           "Owner", "Do not allow Emails", "Created On", "Modified On", "Created By"],
          [[guid(c["Id"]), uuid.uuid4().hex[:24], _when(c["LastModifiedDate"]), full[c["Id"]], c["FirstName"],
            c["LastName"], c["Email"], c["Phone"], c["MobilePhone"], c["Title"], acct_name.get(c["AccountId"]),
            c["MailingState"], c["MailingCountry"], name(c["OwnerId"]),
            "Do Not Allow" if c["HasOptedOutOfEmail"] == "true" else "Allow", _when(c["CreatedDate"]),
            _when(c["LastModifiedDate"]), name(c.get("CreatedById"))] for c in contacts])

    rows = []
    for o in _read(sf, "opportunities.csv"):
        status = "Open" if o["IsClosed"] == "false" else ("Won" if o["IsWon"] == "true" else "Lost")
        reason = {"Open": "In Progress", "Won": "Won", "Lost": "Out-Sold"}[status]
        rows.append([guid(o["Id"]), uuid.uuid4().hex[:24], _when(o["CreatedDate"]), o["Name"],
                     acct_name.get(o["AccountId"]), full.get(o["ContactId"]), status, reason,
                     DYN_STAGE.get(o["StageName"], "4-Close"), _when(o["CloseDate"] + "T00:00:00") if o["CloseDate"] else None,
                     float(o["Amount"]) if o["Amount"] else None,
                     int(o["Probability"]) if o.get("Probability") else None, name(o["OwnerId"]),
                     _when(o["CreatedDate"])])
    sheet(out / f"Open Opportunities {stamp}.xlsx", "Opportunity",
          ["(Do Not Modify) Opportunity", *dnm, "Topic", "Potential Customer", "Contact", "Status", "Status Reason",
           "Sales Stage", "Est. Close Date", "Est. Revenue", "Probability", "Owner", "Created On"], rows)

    rows = []
    for l in _read(sf, "leads.csv"):
        status = "Qualified" if l["IsConverted"] == "true" else ("Disqualified" if "Closed" in l["Status"] else "Open")
        rows.append([guid(l["Id"]), uuid.uuid4().hex[:24], _when(l["CreatedDate"]),
                     f"{l['Company']} - inquiry", l["FirstName"], l["LastName"], l["Email"], l["Company"],
                     l["LeadSource"], status, name(l["OwnerId"]), _when(l["CreatedDate"]), name(l.get("CreatedById"))])
    sheet(out / f"My Open Leads {stamp}.xlsx", "Lead",
          ["(Do Not Modify) Lead", *dnm, "Topic", "First Name", "Last Name", "Email", "Company Name",
           "Lead Source", "Status", "Owner", "Created On", "Created By"], rows)

    sheet(out / f"Enabled Users {stamp}.xlsx", "SystemUser",
          ["(Do Not Modify) User", *dnm, "Full Name", "Status", "Access Mode"],
          [[guid(u["Id"]), uuid.uuid4().hex[:24], None, u["Name"],
            "Enabled" if u["IsActive"] == "true" else "Disabled",
            "Non-interactive" if u["Id"] in integ else "Read-Write"] for u in users.values()])
    return out



# ------------------------------------------------------------------ Bullhorn

BH_STATUS = {"Prospecting": "Prospective", "Qualification": "Prospective", "Needs Analysis": "Active",
             "Proposal/Price Quote": "Proposal Sent", "Negotiation/Review": "Negotiating"}


def write_bullhorn(sf: Path, out: Path, today) -> Path:
    """Bullhorn list exports (Selected > Export as CSV): display-label headers, MM/DD/YYYY dates, owners and
    companies as names, companies with several owners in one cell, and "TBD" for contacts with no company.
    Built from Bullhorn's documentation, not from a real export."""
    rng = random.Random(13)
    users, integ = _users(sf)

    def us(ts):  # "2026-01-28" or an ISO timestamp -> "01/28/2026"
        if not ts:
            return ""
        d = _when(ts) or _when(ts + "T00:00:00")
        return d.strftime("%m/%d/%Y") if d else ""

    def owner(uid):
        u = users.get(uid)
        return u["Name"] if u else ""

    ids = {}

    def rid(sfid, base):
        if sfid not in ids:
            ids[sfid] = str(base + len(ids) + 1)
        return ids[sfid]

    def status(archive_rate=0.03, other="Active"):
        return "Archive" if rng.random() < archive_rate else other

    people = [u["Id"] for u in users.values() if u["Id"] not in integ]
    accounts = _read(sf, "accounts.csv")
    acct_name = {a["Id"]: a["Name"] for a in accounts}
    companies = []
    for a in accounts:
        owners = owner(a["OwnerId"])
        if rng.random() < 0.15:  # a company can have several owners; Bullhorn puts them in one cell
            owners += rng.choice([", ", "; "]) + owner(rng.choice(people))
        companies.append({
            "ID": rid(a["Id"], 5_000), "Name": a["Name"], "Company URL": a["Website"],
            "Business Sector": a["Industry"], "Number of Employees": a["NumberOfEmployees"],
            "City": a["BillingCity"], "State": a["BillingState"], "Country": a["BillingCountry"],
            "Owners": owners, "Status": status(), "Date Added": us(a["CreatedDate"]),
            "Date Last Modified": us(a["LastModifiedDate"]),
        })

    contacts = []
    full = {}
    for c in _read(sf, "contacts.csv"):
        full[c["Id"]] = f"{c['FirstName']} {c['LastName']}".strip()
        contacts.append({
            "ID": rid(c["Id"], 100_000), "First Name": c["FirstName"], "Last Name": c["LastName"],
            "Email": c["Email"], "Phone": c["Phone"], "Mobile": c["MobilePhone"], "Occupation": c["Title"],
            "Client Corporation": acct_name.get(c["AccountId"]) or "TBD",  # Bullhorn insists on a company
            "Owner": owner(c["OwnerId"]), "Status": status(), "Source": c["LeadSource"],
            "State": c["MailingState"], "Country": c["MailingCountry"],
            "Date Added": us(c["CreatedDate"]), "Date Last Modified": us(c["LastModifiedDate"]),
            "Date Last Visit": us(c["LastActivityDate"]),
        })

    deals = []
    for o in _read(sf, "opportunities.csv"):
        closed = o["IsClosed"] == "true"
        st = ("Closed-Won" if o["IsWon"] == "true" else "Closed-Lost") if closed \
            else BH_STATUS.get(o["StageName"], "Active")
        deals.append({
            "ID": rid(o["Id"], 2_000), "Title": o["Name"], "Client Corporation": acct_name.get(o["AccountId"], ""),
            "Client Contact": full.get(o["ContactId"], ""), "Status": st, "Owner": owner(o["OwnerId"]),
            "Deal Value": o["Amount"], "Win Probability": o["Probability"],
            "Expected Close Date": us(o["CloseDate"]), "Actual Close Date": us(o["CloseDate"]) if closed else "",
            "Reason Closed": o["Loss_Reason__c"] if st == "Closed-Lost" else "",
            "Date Added": us(o["CreatedDate"]), "Date Last Modified": us(o["LastActivityDate"] or o["CreatedDate"]),
        })

    leads = []
    for l in _read(sf, "leads.csv"):
        leads.append({
            "ID": rid(l["Id"], 3_000), "First Name": l["FirstName"], "Last Name": l["LastName"],
            "Email": l["Email"], "Company": l["Company"],
            "Status": "Converted" if l["IsConverted"] == "true"
            else status(0.03, rng.choice(["New Lead", "Active", "Prospect"])),
            "Lead Source": l["LeadSource"], "Owner": owner(l["OwnerId"]), "Date Added": us(l["CreatedDate"]),
            "Date Last Visit": us(l["LastActivityDate"]),
        })

    staff = []
    for u in users.values():
        first, last = u["Name"].split()[0].lower(), u["Name"].split()[-1].lower()
        api = u["Id"] in integ
        staff.append({
            "ID": rid(u["Id"], 1_000), "Name": u["Name"],
            "Username": "api.marketing" if api else f"{first}.{last}", "Email": u["Email"],
            "Enabled": u["IsActive"], "User Type": "API" if api else "Standard",
        })

    out.mkdir(parents=True, exist_ok=True)
    _write_csv(out / "ClientCorporation.csv", companies)
    _write_csv(out / "ClientContact.csv", contacts)
    _write_csv(out / "Opportunity.csv", deals)
    _write_csv(out / "Lead.csv", leads)
    _write_csv(out / "CorporateUser.csv", staff)
    return out


# ------------------------------------------------------------------ Crelate

CR_STAGE = {"Prospecting": "Lead", "Qualification": "Qualified", "Needs Analysis": "Discovery",
            "Proposal/Price Quote": "Proposal Sent", "Negotiation/Review": "Negotiation"}
CR_JOB_TITLES = ["Senior Accountant", "Java Developer", "Project Manager", "Help Desk Technician", "Recruiter",
                 "Payroll Specialist", "Network Engineer", "Warehouse Supervisor", "Business Analyst", "QA Engineer"]
CR_PREVIOUS = ["Acme Corp", "Initech", "Globex", "Umbrella Group", "Hooli", "Stark Logistics", "Wayne Health"]


def write_crelate(sf: Path, out: Path, today) -> Path:
    """Crelate list exports (Contacts, Companies, Opportunities > Export > CSV, All Columns, with the Id): labels as
    headers, ISO dates, owners as names (several in one cell, "; "-separated), Entity Status and Tags, and a
    Contacts list that mixes candidates in with client contacts. Built from Crelate's API definition, not from a
    real export (its list-export headers aren't published)."""
    rng = random.Random(17)
    users, integ = _users(sf)

    def day(ts):
        if not ts:
            return ""
        d = _when(ts) or _when(ts + "T00:00:00")
        return d.strftime("%Y-%m-%d") if d else ""

    people = [u["Id"] for u in users.values() if u["Id"] not in integ]
    active = [u["Id"] for u in users.values() if u["Id"] not in integ and u["IsActive"] == "true"]

    def owner(uid):
        u = users.get(uid)
        return u["Name"] if u else ""

    def owners(uid, multi=0.12):
        names = owner(uid)
        if names and rng.random() < multi:  # a record can have several owners; the first one is primary
            names += "; " + owner(rng.choice(people))
        return names

    ids = {}

    def rid(key):
        if key not in ids:
            ids[key] = str(uuid.UUID(int=rng.getrandbits(128)))
        return ids[key]

    def entity(rate=0.03):
        return "Archived" if rng.random() < rate else "Active"

    accounts = _read(sf, "accounts.csv")
    acct_name = {a["Id"]: a["Name"] for a in accounts}
    companies = []
    for a in accounts:
        companies.append({
            "Id": rid(a["Id"]), "Name": a["Name"], "Website": a["Website"], "Industry": a["Industry"],
            "Business City": a["BillingCity"], "Business State": a["BillingState"],
            "Business Country": a["BillingCountry"], "Owners": owners(a["OwnerId"]),
            "Entity Status": entity(), "Status": rng.choice(["Client", "Client", "Prospect", "Target"]),
            "Tags": rng.choice(["Client", "Client", "Prospect", "Staffing Client; Direct Hire", ""]),
            "Created On": day(a["CreatedDate"]), "Modified On": day(a["LastModifiedDate"]),
        })

    contacts, full = [], {}
    for c in _read(sf, "contacts.csv"):
        full[c["Id"]] = f"{c['FirstName']} {c['LastName']}".strip()
        x = rng.random()
        tags = ("Client Contact" if x < 0.66 else "Client Contact; Hiring Manager" if x < 0.86
                else "Prospect" if x < 0.96 else "")
        engaged = c["LastActivityDate"] if rng.random() < 0.5 else ""
        personal = f"{c['FirstName'].lower()}{rng.randint(1, 99)}@gmail.com" if rng.random() < 0.08 else ""
        contacts.append({
            "Id": rid(c["Id"]), "First Name": c["FirstName"], "Last Name": c["LastName"],
            "Full Name": full[c["Id"]], "Email (Work)": c["Email"], "Email (Personal)": personal,
            "Phone (Work Main)": c["Phone"], "Phone (Mobile)": c["MobilePhone"], "Current Position": c["Title"],
            "Current Company": acct_name.get(c["AccountId"], ""),
            "Business State": c["MailingState"], "Business Country": c["MailingCountry"],
            "Owners": owners(c["OwnerId"]), "Entity Status": entity(),
            "Status": rng.choice(["Active", "Active", "Active", "Cold", "Do Not Contact"]) if tags else "",
            "Source": c["LeadSource"], "Tags": tags, "Created On": day(c["CreatedDate"]),
            "Modified On": day(c["LastModifiedDate"]),
            "Last Activity Date": day(c["LastActivityDate"]), "Last Engagement Date": day(engaged),
        })

    # Candidates live in the same list: personal email, a mobile number, no client company
    names = list(full.values())
    for _ in range(int(len(contacts) * 0.3)):
        first, last = rng.choice(names).split()[0], rng.choice(names).split()[-1]
        born = day(rng.choice(accounts)["CreatedDate"])
        x = rng.random()
        tags = ("Candidate" if x < 0.6 else "Candidate; Available" if x < 0.8 else "Candidate; Placed" if x < 0.9
                else "Candidate; Client Contact" if x < 0.95 else "Reference")
        domain = rng.choice(["gmail.com", "yahoo.com", "outlook.com"])
        contacts.append({
            "Id": str(uuid.UUID(int=rng.getrandbits(128))), "First Name": first, "Last Name": last,
            "Full Name": f"{first} {last}", "Email (Work)": "",
            "Email (Personal)": f"{first.lower()}.{last.lower()}{rng.randint(1, 99)}@{domain}",
            "Phone (Work Main)": "", "Phone (Mobile)": f"({rng.choice(['201', '973', '908', '732'])}) 555-{rng.randint(1000, 9999)}",
            "Current Position": rng.choice(CR_JOB_TITLES), "Current Company": rng.choice(CR_PREVIOUS),
            "Business State": "", "Business Country": "", "Owners": owner(rng.choice(active)),
            "Entity Status": "Active", "Status": "Reference" if tags == "Reference" else "Candidate",
            "Source": "", "Tags": tags, "Created On": born,
            "Modified On": born, "Last Activity Date": born, "Last Engagement Date": "",
        })
    rng.shuffle(contacts)

    deals = []
    for o in _read(sf, "opportunities.csv"):
        closed = o["IsClosed"] == "true"
        won = o["IsWon"] == "true"
        job = rng.random() < 0.06  # Jobs are an opportunity type next to sales opportunities
        stage = ("Won" if won else "Lost") if closed else CR_STAGE.get(o["StageName"], "Lead")
        amount = o["Amount"]
        deals.append({
            "Id": rid(o["Id"]), "Name": ("Job - " if job else "") + o["Name"],
            "Company": acct_name.get(o["AccountId"], ""),
            "Opportunity Type": "Job" if job else rng.choice(["Business Development", "Business Development", "Sales"]),
            "Workflow Stage": stage, "Owners": owners(o["OwnerId"]),
            "Expected Value": amount if rng.random() < 0.75 else "", "Potential Value": amount,
            "Probability": o["Probability"], "Estimated Close Date": day(o["CloseDate"]),
            "Closed On": day(o["CloseDate"]) if closed else "",
            "Loss Reason": o["Loss_Reason__c"] if closed and not won else "",
            "Hiring Manager": full.get(o["ContactId"], ""), "Created On": day(o["CreatedDate"]),
            "Modified On": day(o["LastActivityDate"] or o["CreatedDate"]),
            "Last Activity Date": day(o["LastActivityDate"]),
        })

    staff = []
    for u in users.values():
        staff.append({"Id": rid(u["Id"]), "Full Name": u["Name"], "Email": u["Email"],
                      "User State": "Active" if u["IsActive"] == "true" else "Inactive",
                      "User Type": "Integration" if u["Id"] in integ else "Standard"})

    out.mkdir(parents=True, exist_ok=True)
    _write_csv(out / "Contacts.csv", contacts)
    _write_csv(out / "Companies.csv", companies)
    _write_csv(out / "Opportunities.csv", deals)
    _write_csv(out / "Users.csv", staff)
    return out
