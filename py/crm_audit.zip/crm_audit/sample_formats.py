"""Turns the fake sample company (generated in Salesforce format) into what HubSpot and
Microsoft Dynamics 365 exports look like, so the tool can be tried and demoed on all three CRMs.
Every record is made up."""
from __future__ import annotations

import csv
import random
import uuid
from datetime import datetime
from pathlib import Path

from . import normalize as N


def _read(folder: Path, name: str) -> list[dict]:
    with open(folder / name, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _when(ts: str):
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "").replace(".000", ""))
    except ValueError:
        return None


def _write_csv(path: Path, rows: list[dict]):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def _users(folder):
    users = {u["Id"]: u for u in _read(folder, "users.csv")}
    integ = {i for i, u in users.items() if u.get("Profile") == "Integration User"}
    return users, integ


# ------------------------------------------------------------------ HubSpot

HS_STAGE = {"Prospecting": "Appointment Scheduled", "Qualification": "Qualified To Buy",
            "Needs Analysis": "Presentation Scheduled", "Proposal/Price Quote": "Decision Maker Bought-In",
            "Negotiation/Review": "Contract Sent", "Closed Won": "Closed Won", "Closed Lost": "Closed Lost"}
HS_SOURCE = {"Web": "Organic Search", "Referral": "Referrals", "Trade Show": "Offline Sources",
             "Purchased List": "Offline Sources", "Partner": "Referrals", "Cold Call": "Offline Sources",
             "Webinar": "Offline Sources"}


def write_hubspot(sf: Path, out: Path, today) -> Path:
    rng = random.Random(11)
    users, integ = _users(sf)

    def owner(uid):
        u = users.get(uid)
        if not u:
            return ""
        return u["Name"] + (" (Deactivated User)" if u["IsActive"] == "false" else "")

    def source(uid):  # HubSpot records which tool created a record, not who
        if uid in integ:
            return "INTEGRATION", "Marketing Sync"
        return rng.choice(["CRM_UI", "CRM_UI", "CRM_UI", "IMPORT"]), ""

    def hs_time(ts):
        d = _when(ts)
        return d.strftime("%Y-%m-%d %H:%M") if d else ""

    ids = {}

    def rid(sfid, base):
        if sfid not in ids:
            ids[sfid] = str(base + len(ids) + 1)
        return ids[sfid]

    accounts = _read(sf, "accounts.csv")
    acct_name = {a["Id"]: a["Name"] for a in accounts}
    companies = []
    for a in accounts:
        rs, rsd = source(a.get("CreatedById"))
        companies.append({
            "Record ID": rid(a["Id"], 7_000_000_000), "Company name": a["Name"],
            "Company Domain Name": N.norm_domain(a["Website"]) or "", "Website URL": a["Website"],
            "Industry": a["Industry"], "Number of Employees": a["NumberOfEmployees"], "City": a["BillingCity"],
            "State/Region": a["BillingState"], "Country/Region": a["BillingCountry"],
            "Company owner": owner(a["OwnerId"]), "Create Date": hs_time(a["CreatedDate"]),
            "Last Modified Date": hs_time(a["LastModifiedDate"]), "Record source": rs, "Record source detail 1": rsd,
        })

    # HubSpot won't hold two contacts with the same email, so the exact-email copies don't exist there
    seen, contacts = set(), []
    for c in _read(sf, "contacts.csv"):
        e = N.norm_email(c["Email"])
        if e and e in seen and not N.is_placeholder_email(e):
            continue
        seen.add(e)
        rs, rsd = source(c.get("CreatedById"))
        contacts.append({
            "Record ID": rid(c["Id"], 100_000), "First Name": c["FirstName"], "Last Name": c["LastName"],
            "Email": c["Email"], "Phone Number": c["Phone"], "Mobile Phone Number": c["MobilePhone"],
            "Job Title": c["Title"], "Associated Company IDs (Primary)": ids.get(c["AccountId"], ""),
            "Associated Company": acct_name.get(c["AccountId"], ""), "Contact owner": owner(c["OwnerId"]),
            "Lifecycle Stage": rng.choice(["Customer", "Customer", "Opportunity", "Sales Qualified Lead"]),
            "Original Source": HS_SOURCE.get(c["LeadSource"], ""), "State/Region": c["MailingState"],
            "Country/Region": c["MailingCountry"], "Unsubscribed from all email": c["HasOptedOutOfEmail"],
            "Create Date": hs_time(c["CreatedDate"]), "Last Modified Date": hs_time(c["LastModifiedDate"]),
            "Last Activity Date": c["LastActivityDate"], "Seniority": c.get("Seniority__c", ""),
            "Record source": rs, "Record source detail 1": rsd,
        })
    # Leads are contacts in an early lifecycle stage (skipping any HubSpot would have merged by email)
    for l in _read(sf, "leads.csv"):
        e = N.norm_email(l["Email"])
        if e in seen:
            continue
        seen.add(e)
        rs, rsd = source(l.get("CreatedById"))
        contacts.append({
            "Record ID": rid(l["Id"], 100_000), "First Name": l["FirstName"], "Last Name": l["LastName"],
            "Email": l["Email"], "Phone Number": "", "Mobile Phone Number": "", "Job Title": "",
            "Associated Company IDs (Primary)": "", "Associated Company": l["Company"],
            "Contact owner": owner(l["OwnerId"]),
            "Lifecycle Stage": "Sales Qualified Lead" if l["IsConverted"] == "true" else rng.choice(["Lead", "Marketing Qualified Lead"]),
            "Original Source": HS_SOURCE.get(l["LeadSource"], ""), "State/Region": "", "Country/Region": "",
            "Unsubscribed from all email": "false", "Create Date": hs_time(l["CreatedDate"]),
            "Last Modified Date": hs_time(l["CreatedDate"]), "Last Activity Date": l["LastActivityDate"],
            "Seniority": "", "Record source": rs or "FORM", "Record source detail 1": rsd,
        })

    deals = []
    for o in _read(sf, "opportunities.csv"):
        p = o.get("Probability", "")
        deals.append({
            "Record ID": rid(o["Id"], 30_000_000), "Deal Name": o["Name"], "Pipeline": "Sales Pipeline",
            "Deal Stage": HS_STAGE.get(o["StageName"], o["StageName"]), "Amount": o["Amount"],
            "Close Date": o["CloseDate"], "Deal owner": owner(o["OwnerId"]),
            "Associated Company IDs (Primary)": ids.get(o["AccountId"], ""),
            "Associated Company": acct_name.get(o["AccountId"], ""),
            "Associated Contact IDs": ids.get(o["ContactId"], ""),
            "Deal probability": f"{float(p) / 100:g}" if p else "",
            "Closed Lost Reason": o["Loss_Reason__c"], "Create Date": hs_time(o["CreatedDate"]),
            "Last Activity Date": o["LastActivityDate"],
        })
    out.mkdir(parents=True, exist_ok=True)
    stamp = f"{today:%Y-%m-%d}"
    _write_csv(out / f"hubspot-crm-exports-all-companies-{stamp}.csv", companies)
    _write_csv(out / f"hubspot-crm-exports-all-contacts-{stamp}.csv", contacts)
    _write_csv(out / f"hubspot-crm-exports-all-deals-{stamp}.csv", deals)
    return out


# ------------------------------------------------------------------ Dynamics 365

DYN_STAGE = {"Prospecting": "1-Qualify", "Qualification": "1-Qualify", "Needs Analysis": "2-Develop",
             "Proposal/Price Quote": "3-Propose", "Negotiation/Review": "4-Close"}


def write_dynamics(sf: Path, out: Path, today) -> Path:
    from openpyxl import Workbook

    users, integ = _users(sf)
    guid = lambda sfid: str(uuid.uuid5(uuid.NAMESPACE_URL, "ouroboros-sample/" + sfid)) if sfid else None  # noqa: E731
    name = lambda uid: users[uid]["Name"] if uid in users else None  # noqa: E731

    def sheet(path: Path, entity: str, header: list[str], rows: list[list]):
        wb = Workbook()
        ws = wb.active
        ws.title = entity
        ws.append(header)
        for r in rows:
            ws.append(r)
        for i, h in enumerate(header, 1):  # Dynamics hides its "(Do Not Modify)" columns
            if h.startswith("(Do Not Modify)"):
                ws.column_dimensions[ws.cell(1, i).column_letter].hidden = True
        hidden = wb.create_sheet("hiddenSheet")
        hidden["A1"] = entity.lower()
        hidden.sheet_state = "veryHidden"
        wb.save(path)

    dnm = ["(Do Not Modify) Row Checksum", "(Do Not Modify) Modified On"]
    stamp = f"{today:%m-%d-%Y} 9-21-22 AM"
    out.mkdir(parents=True, exist_ok=True)

    accounts = _read(sf, "accounts.csv")
    acct_name = {a["Id"]: a["Name"] for a in accounts}
    sheet(out / f"Active Accounts {stamp}.xlsx", "Account",
          ["(Do Not Modify) Account", *dnm, "Account Name", "Website", "Industry", "Number of Employees",
           "Address 1: City", "Address 1: State/Province", "Address 1: Country/Region", "Owner", "Created On",
           "Created By"],
          [[guid(a["Id"]), uuid.uuid4().hex[:24], _when(a["LastModifiedDate"]), a["Name"], a["Website"],
            a["Industry"], int(a["NumberOfEmployees"]) if a["NumberOfEmployees"] else None, a["BillingCity"],
            a["BillingState"], a["BillingCountry"], name(a["OwnerId"]), _when(a["CreatedDate"]),
            name(a.get("CreatedById"))] for a in accounts])

    contacts = _read(sf, "contacts.csv")
    full = {c["Id"]: f"{c['FirstName']} {c['LastName']}".strip() for c in contacts}
    sheet(out / f"Active Contacts {stamp}.xlsx", "Contact",
          ["(Do Not Modify) Contact", *dnm, "Full Name", "First Name", "Last Name", "Email", "Business Phone",
           "Mobile Phone", "Job Title", "Company Name", "Address 1: State/Province", "Address 1: Country/Region",
           "Owner", "Do not allow Emails", "Created On", "Modified On", "Created By"],
          [[guid(c["Id"]), uuid.uuid4().hex[:24], _when(c["LastModifiedDate"]), full[c["Id"]], c["FirstName"],
            c["LastName"], c["Email"], c["Phone"], c["MobilePhone"], c["Title"], acct_name.get(c["AccountId"]),
            c["MailingState"], c["MailingCountry"], name(c["OwnerId"]),
            "Do Not Allow" if c["HasOptedOutOfEmail"] == "true" else "Allow", _when(c["CreatedDate"]),
            _when(c["LastModifiedDate"]), name(c.get("CreatedById"))] for c in contacts])

    rows = []
    for o in _read(sf, "opportunities.csv"):
        status = "Open" if o["IsClosed"] == "false" else ("Won" if o["IsWon"] == "true" else "Lost")
        reason = {"Open": "In Progress", "Won": "Won", "Lost": "Out-Sold"}[status]
        rows.append([guid(o["Id"]), uuid.uuid4().hex[:24], _when(o["CreatedDate"]), o["Name"],
                     acct_name.get(o["AccountId"]), full.get(o["ContactId"]), status, reason,
                     DYN_STAGE.get(o["StageName"], "4-Close"), _when(o["CloseDate"] + "T00:00:00") if o["CloseDate"] else None,
                     float(o["Amount"]) if o["Amount"] else None,
                     int(o["Probability"]) if o.get("Probability") else None, name(o["OwnerId"]),
                     _when(o["CreatedDate"])])
    sheet(out / f"Open Opportunities {stamp}.xlsx", "Opportunity",
          ["(Do Not Modify) Opportunity", *dnm, "Topic", "Potential Customer", "Contact", "Status", "Status Reason",
           "Sales Stage", "Est. Close Date", "Est. Revenue", "Probability", "Owner", "Created On"], rows)

    rows = []
    for l in _read(sf, "leads.csv"):
        status = "Qualified" if l["IsConverted"] == "true" else ("Disqualified" if "Closed" in l["Status"] else "Open")
        rows.append([guid(l["Id"]), uuid.uuid4().hex[:24], _when(l["CreatedDate"]),
                     f"{l['Company']} - inquiry", l["FirstName"], l["LastName"], l["Email"], l["Company"],
                     l["LeadSource"], status, name(l["OwnerId"]), _when(l["CreatedDate"]), name(l.get("CreatedById"))])
    sheet(out / f"My Open Leads {stamp}.xlsx", "Lead",
          ["(Do Not Modify) Lead", *dnm, "Topic", "First Name", "Last Name", "Email", "Company Name",
           "Lead Source", "Status", "Owner", "Created On", "Created By"], rows)

    sheet(out / f"Enabled Users {stamp}.xlsx", "SystemUser",
          ["(Do Not Modify) User", *dnm, "Full Name", "Status", "Access Mode"],
          [[guid(u["Id"]), uuid.uuid4().hex[:24], None, u["Name"],
            "Enabled" if u["IsActive"] == "true" else "Disabled",
            "Non-interactive" if u["Id"] in integ else "Read-Write"] for u in users.values()])
    return out
