"""Progress since the last audit.

Every audit saves a small snapshot: the grade, area scores, each check's measured value and
score, and the dollar figures. A snapshot holds no customer records, only the numbers. The next
audit of the same company compares against it, which shows a retainer client their CRM getting
healthier (or catches it slipping back).
"""
from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

from .checklist import CHECKS, CHECKS_BY_ID, GRADES, grade_for
from .plain import PLAIN, money, nice_date
from .versions import engine

VERSION = 1
# hidden sheet in the detail workbook that carries the snapshot; older files used the name in OLD_SHEETS
SHEET = "Uroboric snapshot"
OLD_SHEETS = ("Ouroboros snapshot",)


def snapshot(client, audit_date, card, results, impact, data) -> dict:
    return {
        "version": VERSION,
        "client": str(client),
        "audit_date": f"{audit_date:%Y-%m-%d}",
        "overall": round(card.overall, 1) if card.overall is not None else None,
        "grade": card.grade,
        "unscored": card.unscored,
        "areas": {str(c.number): (round(c.pct, 4) if c.pct is not None else None) for c in card.categories},
        # which checks were measured (and which only partly), so the next audit can compare like with like
        "coverage": {"measured": [c.id for c in CHECKS if results[c.id].score is not None],
                     "partial": [c.id for c in CHECKS if results[c.id].coverage == "partial"
                                 and results[c.id].score is not None]},
        "weights": {str(c.number): c.weight for c in card.categories},
        # what each check actually looked at: a check measured on different information is not comparable
        "scopes": {c.id: results[c.id].scope for c in CHECKS if results[c.id].score is not None},
        "grade_status": card.status, "grade_coverage": round(card.coverage, 3),
        "checks": {cid: {"value": (round(r.value, 3) if r.value is not None else None), "score": r.score}
                   for cid, r in results.items()},
        "impact": {"cost": impact.get("cost"), "hours": impact.get("hours"),   # the midpoint, as in every earlier version
                   "channels": sorted(k for k, v in (("email", (impact.get("bad_touch") or {}).get("email")),
                                                     ("phone", (impact.get("bad_touch") or {}).get("phone")))
                                      if v is not None) if (impact.get("bad_touch") or {}).get("from_audit") else ["entered"],
                   "cost_low": impact.get("cost_low"), "cost_high": impact.get("cost_high"),
                   "hours_low": impact.get("hours_low"), "hours_high": impact.get("hours_high"),
                   **{label: value for label, value, _ in impact.get("extras", [])}},
        "records": {t.name: len(t) for t in data.values()},
        "engine": engine(),
    }


# ------------------------------------------------------------------ demo only

EXAMPLE_LABEL = "Example earlier audit"


def example_earlier(snap: dict) -> dict:
    """A made-up earlier snapshot for the guided demo on the SAMPLE company only, so the progress section
    has something to show. Lower score, a few checks one step worse, clearly labelled. Never built for real
    uploads and never saved anywhere: the caller passes it straight to compare()."""
    prev = json.loads(json.dumps(snap))
    prev["label"] = EXAMPLE_LABEL
    prev["audit_date"] = f"{date.fromisoformat(snap['audit_date']) - timedelta(days=90):%Y-%m-%d}"
    if snap.get("overall") is not None:
        prev["overall"] = round(max(snap["overall"] - 14, 0), 1)
        prev["grade"] = next(letter for floor, letter, _ in GRADES if prev["overall"] >= floor)
    worse = 0
    for cid, c in prev["checks"].items():
        if worse >= 6:
            break
        if c.get("score") in (1, 2) and c.get("value") is not None:
            c["score"] -= 1
            c["value"] = round(c["value"] * 1.6 + 1, 3) if _lower_is_better(cid) else round(c["value"] * 0.6, 3)
            worse += 1
    cost = prev.get("impact", {}).get("cost")
    if cost:
        prev["impact"]["cost"] = round(cost * 1.3)
        if prev["impact"].get("hours"):
            prev["impact"]["hours"] = round(prev["impact"]["hours"] * 1.3)
    return prev


# ------------------------------------------------------------------ comparing

def _minor(v) -> str:
    return ".".join(str(v).split(".")[:2])


def version_notes(prev: dict, cur: dict) -> list[str]:
    """Plain-English notes when the two audits were made by different versions of Uroboric or its
    libraries, so a shift caused by an update isn't mistaken for a change in the CRM."""
    pe, ne = prev.get("engine"), cur.get("engine")
    if not isinstance(ne, dict):
        return []
    if not isinstance(pe, dict):
        return ["The earlier audit predates version tracking, so we can't tell whether an update to Uroboric "
                "changed any numbers."]
    notes = []
    pu, nu = pe.get("uroboric"), ne.get("uroboric")
    if pu != nu:
        notes.append(f"This audit used Uroboric {nu}, the last one used {pu}; small differences can come "
                     "from the update, not the data.")
    elif _minor(pe.get("pandas")) != _minor(ne.get("pandas")):
        notes.append(f"A supporting library (pandas) changed from {pe.get('pandas')} to {ne.get('pandas')} "
                     "since the last audit; small differences can come from that, not the data.")
    pf, nf = str(pe.get("fuzzy", "")).split(" ")[0], str(ne.get("fuzzy", "")).split(" ")[0]
    if pf != nf:
        notes.append("The last audit and this one matched similar names with different tools "
                     f"({pe.get('fuzzy')} then, {ne.get('fuzzy')} now), so fuzzy duplicate counts can differ slightly.")
    return notes

def _lower_is_better(cid) -> bool:
    rule = CHECKS_BY_ID[cid].rule
    return rule is None or rule[0] in ("max", "within", "zero")


def fmt_value(cid, v) -> str:
    if v is None:
        return "-"
    unit = CHECKS_BY_ID[cid].unit
    if unit == "%":
        return f"{v:.1f}%"
    return f"{v:g} {unit}"


def comparable(prev: dict, cur: dict):
    """(like-for-like check ids, ids measured differently, ids that can't be compared) for two snapshots, or None
    when either snapshot lacks coverage or scope records (then nothing can be called better or worse).
    A check is like for like only when both audits measured it AND looked at the same information with the same
    method (`scopes`)."""
    pc, nc, ps, ns = prev.get("coverage"), cur.get("coverage"), prev.get("scopes"), cur.get("scopes")
    if not (isinstance(pc, dict) and isinstance(nc, dict) and isinstance(ps, dict) and isinstance(ns, dict)):
        return None
    both = set(pc.get("measured", [])) & set(nc.get("measured", []))
    differently = {cid for cid in both if ps.get(cid) != ns.get(cid)}
    return both - differently, differently, set()


def like_for_like(prev: dict, cur: dict):
    """The overall score of each audit, worked out over only the checks that were measured in BOTH on the same
    information, using the current audit's area weights. Returns (before, after, n_checks) or None when the
    snapshots don't say which checks were measured (audits made before 1.4) or no check qualifies."""
    comp = comparable(prev, cur)
    weights = {int(k): float(v) for k, v in (cur.get("weights") or {}).items()}
    if comp is None or not comp[0] or not weights:
        return None
    both = comp[0]

    def overall(snap):
        earned, possible = {}, {}
        for cid in both:
            sc = (snap.get("checks", {}).get(cid) or {}).get("score")
            if sc is None:
                return None
            cat = CHECKS_BY_ID[cid].category
            earned[cat] = earned.get(cat, 0) + sc
            possible[cat] = possible.get(cat, 0) + 2
        tw = sum(weights.get(c, 0) for c in possible)
        return sum(weights.get(c, 0) * earned[c] / possible[c] for c in possible) * 100 / tw if tw else None

    b, a = overall(prev), overall(cur)
    return (b, a, len(both)) if b is not None and a is not None else None


def _row(c, p, n, status):
    ps, ns = (p or {}).get("score"), (n or {}).get("score")
    pv, nv = (p or {}).get("value"), (n or {}).get("value")
    return {"#": c.id, "Check": PLAIN[c.id][0], "Before": fmt_value(c.id, pv), "Now": fmt_value(c.id, nv),
            "Score before": ps, "Score now": ns, "Change": status,
            "_gain": (ns or 0) - (ps or 0) if ps is not None and ns is not None else 0,
            "_move": abs((nv or 0) - (pv or 0)) if pv is not None and nv is not None else 0}


def _cost_sentence(prev: dict, cur: dict):
    pc, nc = prev.get("impact", {}).get("cost"), cur.get("impact", {}).get("cost")
    if pc is None or nc is None:
        return None
    text = f"Estimated rep time lost to bad data (midpoint): {money(pc)} a year then, {money(nc)} now"
    pch, nch = prev.get("impact", {}).get("channels"), cur.get("impact", {}).get("channels")
    if pch is None:
        text += " (the earlier estimate didn't record how it was built, so the two aren't directly comparable)"
    elif pch != nch:
        text += " (built from different measurements, so not directly comparable)"
    return text


def _baseline(prev: dict, cur: dict, rows: list) -> dict:
    """The earlier audit has no measurement records (or the new one has none): no direction is claimed. This audit
    sets the baseline; the earlier values are listed beside the new ones with no better/worse label."""
    po, no = prev.get("overall"), cur.get("overall")
    try:
        when = nice_date(date.fromisoformat(prev["audit_date"]))
    except (KeyError, ValueError):
        when = "the last audit"
    if prev.get("label"):
        when = f"{prev['label']} ({when})"
    earlier = (f"Earlier score: {prev.get('grade')} ({po:.0f})" if po is not None and prev.get("grade")
               else "Earlier score: not recorded")
    headline = ("This is the first audit with full measurement records, so it sets the baseline. "
                f"{earlier} on {when} (measured before like-for-like tracking; not directly comparable).")
    for r in rows:
        r["Change"] = "Not compared" if (r["Before"] != "-" or r["Now"] != "-") else "Not measured"
        r.pop("_gain", None), r.pop("_move", None)
    notes = version_notes(prev, cur)
    if prev.get("label") == EXAMPLE_LABEL:
        notes.insert(0, "This earlier audit is an example made up for the demo, so the progress shown is "
                        "illustrative, not this company's history.")
    return {
        "notes": notes, "headline": headline, "previous_date": when, "score_change": None, "baseline": True,
        "grade_before": prev.get("grade"), "grade_now": cur.get("grade"), "score_before": None, "score_now": None,
        "raw_before": po, "raw_now": no, "raw_grade_before": prev.get("grade"), "raw_grade_now": cur.get("grade"),
        "like_for_like": None, "cost_before": prev.get("impact", {}).get("cost"),
        "cost_now": cur.get("impact", {}).get("cost"),
        "better": [], "worse": [], "newly_measured": [], "no_longer_measured": [], "measured_differently": [],
        "rows": rows, "cost_sentence": _cost_sentence(prev, cur),
    }


def compare(prev: dict, cur: dict) -> dict:
    """Progress since an earlier audit. When both snapshots say which checks were measured, the headline compares
    ONLY the checks measured both times ("like for like"), so a check that was added or lost between audits can't
    pose as improvement or decline. A check that appears or disappears is listed as such, never as "no change"."""
    has_cov = isinstance(prev.get("coverage"), dict) and isinstance(cur.get("coverage"), dict)
    pm = set(prev.get("coverage", {}).get("measured", [])) if has_cov else set()
    nm = set(cur.get("coverage", {}).get("measured", [])) if has_cov else set()
    rows = []
    comp_sets = comparable(prev, cur) if has_cov else None
    differently = comp_sets[1] if comp_sets else set()
    cant = comp_sets[2] if comp_sets else set()
    for c in CHECKS:
        p = prev.get("checks", {}).get(c.id)
        n = cur.get("checks", {}).get(c.id)
        if n is None:
            continue
        ps, ns = (p or {}).get("score"), n.get("score")
        pv, nv = (p or {}).get("value"), n.get("value")
        if p is None:
            status = "New check"
        elif has_cov and c.id in nm and c.id not in pm:
            status = "Newly measured"
        elif has_cov and c.id in pm and c.id not in nm:
            status = "No longer measured"
        elif c.id in differently:
            status = "Measured differently"
        elif c.id in cant:
            status = "Can't compare"
        elif ps is not None and ns is not None and ns != ps:
            status = "Better" if ns > ps else "Worse"
        elif pv is not None and nv is not None and abs(nv - pv) > max(0.5, 0.05 * abs(pv)):
            # small shifts (under half a point, or 5%) are noise from the database growing or shrinking
            better = (nv < pv) if _lower_is_better(c.id) else (nv > pv)
            status = "Better" if better else "Worse"
        else:
            status = "No change" if (ps is not None or pv is not None or ns is not None) else "Not measured"
        rows.append(_row(c, p, n, status))
    if has_cov:  # checks measured before that the new snapshot no longer carries at all
        for c in CHECKS:
            if c.id in pm and c.id not in cur.get("checks", {}):
                rows.append(_row(c, prev["checks"].get(c.id), None, "No longer measured"))

    if comp_sets is None:  # an earlier audit without measurement records can't support "up" or "down"
        return _baseline(prev, cur, rows)
    better = [r for r in rows if r["Change"] == "Better"]
    worse = [r for r in rows if r["Change"] == "Worse"]
    newly = [r for r in rows if r["Change"] == "Newly measured"]
    dropped = [r for r in rows if r["Change"] == "No longer measured"]
    different = [r for r in rows if r["Change"] in ("Measured differently", "Can't compare")]
    better.sort(key=lambda r: (-r["_gain"], -r["_move"]))
    worse.sort(key=lambda r: (r["_gain"], -r["_move"]))
    po, no = prev.get("overall"), cur.get("overall")
    raw_delta = round(no - po) if po is not None and no is not None else None
    lfl = like_for_like(prev, cur)
    pc, nc = prev.get("impact", {}).get("cost"), cur.get("impact", {}).get("cost")
    try:
        when = nice_date(date.fromisoformat(prev["audit_date"]))
    except (KeyError, ValueError):
        when = "the last audit"
    if prev.get("label"):
        when = f"{prev['label']} ({when})"
    notes = version_notes(prev, cur)
    like = None
    if lfl is not None:
        b, a, n_checks = lfl
        delta = round(a) - round(b)
        like = {"before": round(b), "after": round(a), "checks": n_checks, "change": delta}
        tail = f"from {round(b)} to {round(a)} on the {n_checks} checks measured both times"
        if delta > 0:
            headline = f"Up {delta} points since {when}: {tail}"
        elif delta < 0:
            headline = f"Down {-delta} points since {when}: {tail}"
        else:
            headline = f"No change since {when}: {round(a)} on the {n_checks} checks measured both times"
        score_before, score_now = b, a
        grade_before, grade_now = grade_for(b)[0], grade_for(a)[0]
        if po is not None and no is not None and (prev.get("grade") != cur.get("grade") or raw_delta != delta):
            notes.insert(0, f"Raw overall scores, which also reflect which checks could be measured: "
                            f"{prev.get('grade')} ({po:.0f}) then, {cur.get('grade')} ({no:.0f}) now.")
        if different:
            notes.append(f"{len(different)} check{'s were' if len(different) != 1 else ' was'} measured on different "
                         "information this time (for example company links only, or a column that is now empty), so "
                         "they are listed separately and left out of the like-for-like score.")
        if len(newly) + len(dropped) > 3:
            notes.insert(0, f"The two audits covered different checks: {len(newly)} measured now that weren't "
                            f"before, {len(dropped)} measured before that aren't now. Compare the like-for-like "
                            "number, not the raw scores.")
    else:
        delta = raw_delta
        if has_cov:
            headline = f"No checks were measured in both audits, so the scores can't be compared with {when}"
            delta = None
        elif delta is None:
            headline = f"Compared with the audit on {when}"
        elif delta > 0:
            headline = f"Up {delta} points since {when}: from {prev.get('grade')} ({po:.0f}) to {cur.get('grade')} ({no:.0f})"
        elif delta < 0:
            headline = f"Down {-delta} points since {when}: from {prev.get('grade')} ({po:.0f}) to {cur.get('grade')} ({no:.0f})"
        else:
            headline = f"No change in the overall score since {when}: still {cur.get('grade')} ({no:.0f})"
        score_before, score_now = po, no
        grade_before, grade_now = prev.get("grade"), cur.get("grade")
        if not has_cov:
            notes.insert(0, "The earlier audit didn't record which checks it measured, so these are the overall "
                            "scores compared directly. If different checks could be measured this time, part of the "
                            "change comes from that, not from the CRM.")
    for r in rows:
        r.pop("_gain"), r.pop("_move")
    if prev.get("label") == EXAMPLE_LABEL:
        notes.insert(0, "This earlier audit is an example made up for the demo, so the progress shown is "
                        "illustrative, not this company's history.")
    return {
        "notes": notes,
        "headline": headline, "previous_date": when, "score_change": delta,
        "grade_before": grade_before, "grade_now": grade_now,
        "score_before": score_before, "score_now": score_now,
        "raw_before": po, "raw_now": no, "raw_grade_before": prev.get("grade"), "raw_grade_now": cur.get("grade"),
        "like_for_like": like,
        "cost_before": pc, "cost_now": nc,
        "better": better, "worse": worse, "newly_measured": newly, "no_longer_measured": dropped, "measured_differently": different,
        "rows": rows,
        "cost_sentence": _cost_sentence(prev, cur),
    }


# ------------------------------------------------------------------ storing (desktop)

def load_history(path: Path) -> list[dict]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError, OSError):
        return []
    # keep only entries that look like snapshots, so a damaged or hand-edited file can't break an audit
    return [s for s in data if isinstance(s, dict) and isinstance(s.get("audit_date"), str)] \
        if isinstance(data, list) else []


def previous_for(history: list[dict], cur: dict) -> dict | None:
    """The most recent earlier audit (a re-run on the same day replaces that day's snapshot)."""
    earlier = [s for s in history if s.get("audit_date", "") < cur["audit_date"]]
    return max(earlier, key=lambda s: s["audit_date"]) if earlier else None


def save_history(path: Path, history: list[dict], cur: dict):
    kept = [s for s in history if s.get("audit_date") != cur["audit_date"]] + [cur]
    kept.sort(key=lambda s: s["audit_date"])
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(kept, indent=1), encoding="utf-8")


def read_snapshot(path: Path) -> dict:
    """A snapshot from a saved history .json, or from a previous detail workbook (.xlsx)."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"--previous file not found: {path}")
    if path.suffix.lower() == ".json":
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            raise ValueError(f"{path.name} isn't a saved Uroboric history file.") from None
        snap = data[-1] if isinstance(data, list) and data else data
        if not isinstance(snap, dict) or not isinstance(snap.get("audit_date"), str):
            raise ValueError(f"{path.name} doesn't hold a Uroboric audit snapshot.")
        return snap
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True)
    try:
        name = next((n for n in (SHEET, *OLD_SHEETS) if n in wb.sheetnames), None)
        if name is None:
            raise ValueError(f"{path.name} has no Uroboric snapshot (it was made by an older version)")
        text = "".join(str(row[0]) for row in wb[name].iter_rows(values_only=True) if row and row[0])
    finally:
        wb.close()  # read-only workbooks keep the file locked until closed
    return json.loads(text)


def add_snapshot_sheet(wb, snap: dict):
    ws = wb.create_sheet(SHEET)
    text = json.dumps(snap)
    for i in range(0, len(text), 30000):  # an Excel cell holds at most 32,767 characters
        ws.cell(i // 30000 + 1, 1, text[i:i + 30000])
    ws.sheet_state = "hidden"
