"""Progress since the last audit.

Every audit saves a small snapshot: the grade, area scores, each check's measured value and
score, and the dollar figures. A snapshot holds no customer records, only the numbers. The next
audit of the same company compares against it, which shows a retainer client their CRM getting
healthier (or catches it slipping back).
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

from .checklist import CHECKS, CHECKS_BY_ID
from .plain import PLAIN, money, nice_date

VERSION = 1
# hidden sheet in the detail workbook that carries the snapshot; older files used the name in OLD_SHEETS
SHEET = "Uroboric snapshot"
OLD_SHEETS = ("Ouroboros snapshot",)


def snapshot(client, audit_date, card, results, impact, data) -> dict:
    return {
        "version": VERSION,
        "client": str(client),
        "audit_date": f"{audit_date:%Y-%m-%d}",
        "overall": round(card.overall, 1) if card.overall is not None else None,
        "grade": card.grade,
        "unscored": card.unscored,
        "areas": {str(c.number): (round(c.pct, 4) if c.pct is not None else None) for c in card.categories},
        "checks": {cid: {"value": (round(r.value, 3) if r.value is not None else None), "score": r.score}
                   for cid, r in results.items()},
        "impact": {"cost": impact.get("cost"), "hours": impact.get("hours"),
                   **{label: value for label, value, _ in impact.get("extras", [])}},
        "records": {t.name: len(t) for t in data.values()},
    }


# ------------------------------------------------------------------ comparing

def _lower_is_better(cid) -> bool:
    rule = CHECKS_BY_ID[cid].rule
    return rule is None or rule[0] in ("max", "within", "zero")


def fmt_value(cid, v) -> str:
    if v is None:
        return "-"
    unit = CHECKS_BY_ID[cid].unit
    if unit == "%":
        return f"{v:.1f}%"
    return f"{v:g} {unit}"


def compare(prev: dict, cur: dict) -> dict:
    rows = []
    for c in CHECKS:
        p = prev.get("checks", {}).get(c.id)
        n = cur.get("checks", {}).get(c.id)
        if n is None:
            continue
        ps, ns = (p or {}).get("score"), n.get("score")
        pv, nv = (p or {}).get("value"), n.get("value")
        if p is None:
            status = "New check"
        elif ps is not None and ns is not None and ns != ps:
            status = "Better" if ns > ps else "Worse"
        elif pv is not None and nv is not None and abs(nv - pv) > max(0.5, 0.05 * abs(pv)):
            # small shifts (under half a point, or 5%) are noise from the database growing or shrinking
            better = (nv < pv) if _lower_is_better(c.id) else (nv > pv)
            status = "Better" if better else "Worse"
        else:
            status = "No change" if (ps is not None or pv is not None or ns is not None) else "Not measured"
        rows.append({"#": c.id, "Check": PLAIN[c.id][0], "Before": fmt_value(c.id, pv), "Now": fmt_value(c.id, nv),
                     "Score before": ps, "Score now": ns, "Change": status,
                     "_gain": (ns or 0) - (ps or 0) if ps is not None and ns is not None else 0,
                     "_move": abs((nv or 0) - (pv or 0)) if pv is not None and nv is not None else 0})

    better = [r for r in rows if r["Change"] == "Better"]
    worse = [r for r in rows if r["Change"] == "Worse"]
    better.sort(key=lambda r: (-r["_gain"], -r["_move"]))
    worse.sort(key=lambda r: (r["_gain"], -r["_move"]))
    po, no = prev.get("overall"), cur.get("overall")
    delta = round(no - po) if po is not None and no is not None else None
    pc, nc = prev.get("impact", {}).get("cost"), cur.get("impact", {}).get("cost")
    try:
        when = nice_date(date.fromisoformat(prev["audit_date"]))
    except (KeyError, ValueError):
        when = "the last audit"
    if delta is None:
        headline = f"Compared with the audit on {when}"
    elif delta > 0:
        headline = f"Up {delta} points since {when}: from {prev.get('grade')} ({po:.0f}) to {cur.get('grade')} ({no:.0f})"
    elif delta < 0:
        headline = f"Down {-delta} points since {when}: from {prev.get('grade')} ({po:.0f}) to {cur.get('grade')} ({no:.0f})"
    else:
        headline = f"No change in the overall score since {when}: still {cur.get('grade')} ({no:.0f})"
    for r in rows:
        r.pop("_gain"), r.pop("_move")
    return {
        "headline": headline, "previous_date": when, "score_change": delta,
        "grade_before": prev.get("grade"), "grade_now": cur.get("grade"),
        "score_before": po, "score_now": no,
        "cost_before": pc, "cost_now": nc,
        "better": better, "worse": worse, "rows": rows,
        "cost_sentence": (f"Rep time lost to bad data: {money(pc)} a year then, {money(nc)} now"
                          if pc is not None and nc is not None else None),
    }


# ------------------------------------------------------------------ storing (desktop)

def load_history(path: Path) -> list[dict]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError, OSError):
        return []
    # keep only entries that look like snapshots, so a damaged or hand-edited file can't break an audit
    return [s for s in data if isinstance(s, dict) and isinstance(s.get("audit_date"), str)] \
        if isinstance(data, list) else []


def previous_for(history: list[dict], cur: dict) -> dict | None:
    """The most recent earlier audit (a re-run on the same day replaces that day's snapshot)."""
    earlier = [s for s in history if s.get("audit_date", "") < cur["audit_date"]]
    return max(earlier, key=lambda s: s["audit_date"]) if earlier else None


def save_history(path: Path, history: list[dict], cur: dict):
    kept = [s for s in history if s.get("audit_date") != cur["audit_date"]] + [cur]
    kept.sort(key=lambda s: s["audit_date"])
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(kept, indent=1), encoding="utf-8")


def read_snapshot(path: Path) -> dict:
    """A snapshot from a saved history .json, or from a previous detail workbook (.xlsx)."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"--previous file not found: {path}")
    if path.suffix.lower() == ".json":
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            raise ValueError(f"{path.name} isn't a saved Uroboric history file.") from None
        snap = data[-1] if isinstance(data, list) and data else data
        if not isinstance(snap, dict) or not isinstance(snap.get("audit_date"), str):
            raise ValueError(f"{path.name} doesn't hold a Uroboric audit snapshot.")
        return snap
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True)
    try:
        name = next((n for n in (SHEET, *OLD_SHEETS) if n in wb.sheetnames), None)
        if name is None:
            raise ValueError(f"{path.name} has no Uroboric snapshot (it was made by an older version)")
        text = "".join(str(row[0]) for row in wb[name].iter_rows(values_only=True) if row and row[0])
    finally:
        wb.close()  # read-only workbooks keep the file locked until closed
    return json.loads(text)


def add_snapshot_sheet(wb, snap: dict):
    ws = wb.create_sheet(SHEET)
    text = json.dumps(snap)
    for i in range(0, len(text), 30000):  # an Excel cell holds at most 32,767 characters
        ws.cell(i // 30000 + 1, 1, text[i:i + 30000])
    ws.sheet_state = "hidden"
