"""What each automated check needs to see in the export, and what to do when it isn't there.

Every field in every file is in one of three states (see loader.Table.state):

  absent     no such column in the file           -> "not in the export" (we can't know what the CRM holds)
  blank      the column is there, empty for all   -> real CRM data: nobody filled it in (HubSpot and Dynamics
                                                     exports include every property, so this is common)
  populated  at least one record has a value

Each check declares the evidence it NEEDS below. A need is REQUIRED (the check can't say anything without it)
or OPTIONAL (it covers part of the question). `any_of` lists keys of which at least one must be usable.

Outcomes
  all needs usable                         -> checked in full (scored as always)
  a required need absent / unusable        -> NOT CHECKED: "not in the export: add <column> to the <file> export";
                                              left out of the grade exactly like a check that needs input
  an optional need absent / unusable       -> PARTLY CHECKED: score what could be measured and say what it covered
  a need blank (column present, no values) -> depends on its blank rule:

  RULE          blank column means ...                                   outcome when blank
  team          owner: a real finding only when the exports show two    finding if 2+ different people appear (ids and
                or more different people                                 names of one person count once); else it can't
                                                                         be judged (single-user CRM or export gap)
  finding       nothing to compare (state, country, industry ...)       measured; nothing to flag
  unmeasurable  everything else (activity dates, phone, title, deal     the part can't be assessed: PARTLY CHECKED when
                links, lead source, an empty email column ...): a        other evidence exists, NOT CHECKED when none
                blank column is not proof the CRM holds nothing          does; the report says "column X is empty"
  not_used      an optional custom field (seniority, persona)            NOT CHECKED, labelled "not used": never a zero

Missing whole files are left to each check ("Needs <file> export"); an OPTIONAL need whose file is missing makes
the check partial.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .loader import TABLE_LABELS


@dataclass(frozen=True)
class Need:
    key: str
    label: str                 # a noun phrase: "contact links", "last-activity dates"
    alts: tuple                # ((table, field), ...): any one satisfies the need
    hint: str                  # the column to add, in the CRM's words
    level: str = "required"    # required | optional
    blank: str = "unmeasurable"  # team | finding | unmeasurable | not_used  (see the table above)
    finding: str = ""          # what a blank column means, e.g. "no record has an owner"
    extra: tuple = ()          # (crm, text) pairs appended to a not-checked reason
    unusable: str = ""         # sentence for "blank, so this part can't be assessed" ({col} = the column)


def _n(key, label, alts, hint, level="required", blank="unmeasurable", finding="", extra=(), unusable=""):
    return Need(key, label, tuple(alts), hint, level, blank, finding, tuple(extra), unusable)


def _all(*pairs):
    """An alternative that needs several fields at once (every one must be populated)."""
    return ("ALL", tuple(pairs))


def _c(*fields):
    return [("contacts", f) for f in fields]


def _a(*fields):
    return [("accounts", f) for f in fields]


def _o(*fields):
    return [("opportunities", f) for f in fields]


DEAL_OPEN = _o("is_closed", "stage", "status", "is_open")

# check id -> (needs, any_of)
SPECS: dict[str, tuple[list[Need], tuple[str, ...]]] = {
    "1.1": ([_n("email", "email addresses", _c("email"), "Email", blank="unmeasurable")], ()),
    "1.2": ([_n("name", "contact names", _c("first_name", "last_name", "name"), "First Name and Last Name",
                blank="unmeasurable"),
             _n("domain", "company domains", _c("email") + _a("website"), "Email (or the company Website)",
                blank="unmeasurable")], ()),
    "1.3": ([_n("name", "company names or websites", _a("name", "website"), "Company Name and Website",
                blank="unmeasurable")], ()),
    "1.4": ([_n("name", "deal names", _o("name"), "Deal Name", blank="unmeasurable"),
             _n("acct", "company links", _o("account_id", "account_name"), "Account (company)",
                blank="unmeasurable"),
             _n("open", "deal stages", DEAL_OPEN, "Stage", blank="unmeasurable")], ()),
    "1.6": ([_n("lead", "lead email addresses", [("leads", "email")], "Email", blank="unmeasurable"),
             _n("contact", "contact email addresses", _c("email"), "Email", blank="unmeasurable")], ()),
    "2.4": ([_n("phone", "phone numbers", _c("phone"), "Phone", "optional",
                finding="no contact has a phone number"),
             _n("mobile", "mobile numbers", _c("mobile"), "Mobile Phone", "optional",
                finding="no contact has a mobile number")], ("phone", "mobile")),
    "2.5": ([_n("act", "last-activity dates", _c("last_activity"), "Last Activity Date", "optional",
                finding="no contact has a recorded activity date"),
             _n("mod", "last-modified dates", _c("last_modified"), "Last Modified Date", "optional",
                finding="no contact has a modified date")], ("act", "mod")),
    "3.1": ([_n("email", "emails", _c("email"), "Email", "optional", finding="no contact has an email"),
             _n("phone", "phone numbers", _c("phone", "mobile"), "Phone", "optional",
                finding="no contact has a phone number"),
             _n("title", "job titles", _c("title"), "Job Title", "optional", finding="no contact has a job title"),
             _n("account", "company links", _c("account_id", "account_name"), "Company",
                "optional", finding="no contact is linked to a company")],
            ("email", "phone", "title", "account")),
    "3.2": ([_n("industry", "industries", _a("industry"), "Industry", "optional",
                finding="no company has an industry"),
             _n("employees", "employee counts", _a("employees"), "Number of Employees", "optional",
                finding="no company has an employee count"),
             _n("location", "locations", _a("state", "city", "country"), "City, State or Country", "optional",
                finding="no company has a location"),
             _n("website", "websites", _a("website"), "Website", "optional", finding="no company has a website")],
            ("industry", "employees", "location", "website")),
    "3.3": ([_n("contacts", "contact states and countries", _c("state", "country"), "State and Country",
                "optional", blank="finding", finding="nothing to compare"),
             _n("accounts", "company states, countries and industries", _a("state", "country", "industry"),
                "State, Country and Industry", "optional", blank="finding", finding="nothing to compare")],
            ("contacts", "accounts")),
    "3.4": ([_n("seniority", "a seniority or persona field", _c("seniority"), "Seniority (or Persona)",
                blank="not_used")], ()),
    "3.5": ([_n("fields", "contact names, emails or phone numbers",
                _c("first_name", "last_name", "email", "phone"), "First Name, Last Name, Email and Phone",
                blank="unmeasurable")], ()),
    "3.8": ([_n("deals", "deal amounts and dates", _o("amount", "close_date", "expected_close", "actual_close", "probability"),
                "Amount, Close Date and Probability", "optional", blank="finding", finding="nothing to compare"),
             _n("contacts", "contact titles, emails and phones", _c("phone", "title", "email"),
                "Job Title, Email and Phone", "optional", blank="finding", finding="nothing to compare"),
             _n("accounts", "company industries and sizes", _a("industry", "employees"),
                "Industry and Number of Employees", "optional", blank="finding", finding="nothing to compare")],
            ("deals", "contacts", "accounts")),
    "4.1": ([_n("contacts", "contact owners", _c("owner_id", "owner_name"), "Contact Owner", "optional",
                blank="team", finding="no contact has an owner"),
             _n("accounts", "company owners", _a("owner_id", "owner_name"), "Company Owner", "optional",
                blank="team", finding="no company has an owner")], ("contacts", "accounts")),
    "4.2": ([_n("created", "lead created dates", [("leads", "created")], "Created Date", blank="unmeasurable"),
             _n("activity", "lead activity",
                [("leads", "last_activity"), _all(("tasks", "who_id"), ("tasks", "created"), ("leads", "id"))],
                "Last Activity Date (or a tasks export with WhoId and CreatedDate)",
                finding="no lead has a recorded activity")], ()),
    "4.4": ([_n("open", "deal stages", DEAL_OPEN, "Stage", blank="unmeasurable"),
             _n("close", "close dates", _o("close_date", "expected_close", "actual_close"), "Close Date", "optional",
                finding="no deal has a close date"),
             _n("act", "last-activity dates", _o("last_activity"), "Last Activity Date", "optional",
                unusable="deal activity could not be assessed: the {col} column is empty on every exported deal"),
             _n("amount", "deal amounts", _o("amount"), "Amount", "optional", finding="no deal has an amount")],
            ("close", "act")),
    "4.6": ([_n("acct", "company links", _o("account_id", "account_name"), "Account (company)", "optional",
                finding="no deal is linked to a company"),
             _n("contact", "contact links", _o("contact_id", "contact_name") + [("contact_roles", "opportunity_id")],
                "Primary Contact (or an Opportunity Contact Roles export)", "optional",
                finding="no deal is linked to a contact")], ("acct", "contact")),
    "4.7": ([_n("reason", "loss reasons", _o("loss_reason"), "Closed Lost Reason", finding="no lost deal has a reason"),
             _n("open", "deal stages", DEAL_OPEN, "Stage", blank="unmeasurable")], ()),
    "5.2": ([_n("source", "lead sources", _c("lead_source") + [("leads", "lead_source")], "Lead Source",
                finding="no record has a lead source",
                extra=(("hubspot", "HubSpot fills in Original Source by itself (imports are all 'Offline "
                        "Sources'), so it can't show whether reps record where a lead came from."),))], ()),
}


@dataclass
class Evidence:
    status: str = "ok"                      # ok | partial | not_checked
    usable: set = field(default_factory=set)
    missing: list = field(default_factory=list)        # labels of optional evidence that isn't usable
    heads_up: list = field(default_factory=list)       # blank-column findings, in plain words
    reason: str = ""                        # not_checked: why, in one sentence
    how: str = ""                           # not_checked / partial: how to include it next time
    scope: str = ""                         # partial: "checked X only; Y wasn't in the export"
    blank_keys: set = field(default_factory=set)       # needs measured as blank (a finding)
    blank_columns: dict = field(default_factory=dict)  # key -> column header(s)
    not_used: bool = False                  # not_checked because an optional field exists but nobody uses it
    display: str = ""                       # the short result text for a not-checked check

    @property
    def scope_key(self) -> str:
        """What this check actually looked at (the fields it could use); two audits are only comparable when equal."""
        return "|".join(sorted(self.usable)) if self.status != "not_checked" else ""

    def can(self, key: str) -> bool:
        return key in self.usable


def _table(ctx, name):
    if name in ctx.empty_tables:
        return None
    t = ctx.data.get(name)
    if t is None and name == "leads" and ctx.leads is not None:
        t = ctx.data.get("contacts")  # HubSpot has no lead file: leads are contacts in an early stage
    return t


def _state(ctx, need: Need):
    """('populated'|'blank'|'absent'|'no_table', [blank column headers])"""
    states, cols = [], []
    for alt in need.alts:
        if alt[0] == "ALL":          # every part must be usable: tasks only count with lead ids AND timestamps
            parts = []
            for table, f in alt[1]:
                t = _table(ctx, table)
                parts.append("no_table" if t is None else t.state(f))
                if t is not None and parts[-1] == "blank":
                    cols.append(t.blank.get(f) or t.mapping.get(f) or f)
            if all(p == "populated" for p in parts):
                states.append("populated")
            elif "no_table" in parts:
                states.append("no_table")
            elif "absent" in parts:
                states.append("absent")
            else:
                states.append("blank")
            continue
        table, f = alt
        t = _table(ctx, table)
        if t is None:
            states.append("no_table")
            continue
        st = t.state(f)
        states.append(st)
        if st == "blank":
            cols.append(t.blank.get(f) or t.mapping.get(f) or f)
    for s in ("populated", "blank", "absent"):
        if s in states:
            return s, cols
    return "no_table", cols


def _blank_outcome(ctx, need: Need) -> str:
    """finding | unmeasurable | not_used for a need whose column(s) are blank."""
    if need.blank == "team":
        return "finding" if ctx.team_size() >= 2 else "unmeasurable"
    return need.blank


def _file(table: str) -> str:
    return TABLE_LABELS.get(table, table).lower()


def _where(need: Need) -> str:
    tables = list(dict.fromkeys(a[0] if a[0] != "ALL" else a[1][0][0] for a in need.alts))
    return " or ".join(f"the {_file(t)}" for t in tables[:2]) + " export"


def assess(ctx, check_id: str) -> Evidence:
    spec = SPECS.get(check_id)
    ev = Evidence()
    if spec is None:
        return ev
    needs, any_of = spec
    states = {}
    for n in needs:
        st, cols = _state(ctx, n)
        states[n.key] = (st, cols, n)
        if st == "populated":
            ev.usable.add(n.key)
        elif st == "blank":
            out = _blank_outcome(ctx, n)
            colname = " / ".join(dict.fromkeys(cols))
            if out == "finding":
                ev.usable.add(n.key)
                ev.blank_keys.add(n.key)
                ev.blank_columns[n.key] = colname
                if n.finding and n.finding != "nothing to compare":
                    ev.heads_up.append(f"The {colname} column is empty for every record ({n.finding}).")
                elif n.finding == "":
                    ev.heads_up.append(f"The {colname} column is empty for every record.")
        elif st == "no_table" and n.level == "required":
            ev.usable.add(n.key)  # a missing file is the check's own "needs the X export" answer
    problems = []   # (need, kind, columns, how, state)
    for key, (st, cols, n) in states.items():
        if key in ev.usable:
            continue
        kind = "absent"
        if st == "blank":
            kind = "not_used" if _blank_outcome(ctx, n) == "not_used" else (n.blank if n.blank == "team" else "blank")
        if kind == "not_used":
            ev.not_used = True
        how = {"absent": f"Add {n.hint} to {_where(n)}.",
               "not_used": "Nothing to do unless you start using the field.",
               "team": f"If your team has several users, include {n.hint} and a users export next time.",
               "blank": f"Export again once {n.hint} is filled in."}[kind]
        problems.append((n, kind, list(dict.fromkeys(cols)), how, st))

    def phrase(items):
        """One sentence for the problems of the same kind (so two owner columns read as one reason)."""
        n0, kind = items[0][0], items[0][1]
        cols = [c for it in items for c in it[2]]
        names = " and ".join(dict.fromkeys(f"the {c}" for c in cols)) if kind != "absent" else ""
        plural = len(cols) > 1
        col_txt = (f"{names} columns are" if plural else f"{names} column is") if names else ""
        if kind == "absent":
            labels = " and ".join(dict.fromkeys(it[0].label for it in items))
            txt = f"{labels} aren't in the export"
            for crm, extra in n0.extra:
                if ctx.crm == crm:
                    txt += ". " + extra.rstrip(".")
            return txt
        if kind == "not_used":
            return (f"{col_txt} in the export but empty for every record, so this isn't used in your CRM and "
                    "there is nothing to score")
        if kind == "team":
            return (f"{col_txt} empty for every record and the exports show only one person, so it can't be told "
                    "whether records are unowned or this is a single-user CRM")
        if n0.unusable:
            return "; ".join(dict.fromkeys(it[0].unusable.format(col=" / ".join(it[2])) for it in items if it[0].unusable))
        return f"{col_txt} empty for every record, so there is nothing to look at"

    def reasons(plist):
        groups: dict = {}
        for it in plist:
            groups.setdefault(it[1], []).append(it)
        return "; ".join(phrase(g) for g in groups.values())

    # required needs that can't be used -> not checked; optional ones -> partial
    req_bad = [p for p in problems if p[0].level == "required"]
    opt_bad = [p for p in problems if p[0].level == "optional"]
    if any_of and not any(k in ev.usable for k in any_of):
        req_bad += opt_bad  # none of the alternatives can be used: the check has nothing to go on
        opt_bad = []
    if req_bad:
        ev.status = "not_checked"
        why = reasons(req_bad)
        ev.reason = why[:1].upper() + why[1:] + ("" if why.endswith(".") else ".")
        ev.how = " ".join(dict.fromkeys(p[3] for p in req_bad))
        ev.display = ("Not used in this CRM" if ev.not_used else
                      "Not in the export" if any(p[1] == "absent" for p in req_bad) else "Column empty in the export")
        ev.usable = set()
        return ev
    if opt_bad:
        ev.status = "partial"
        ev.missing = [p[0].label for p in opt_bad]
        done = [n.label for n in needs if n.key in ev.usable and n.key in (any_of or [n.key])]
        gone = reasons(opt_bad)
        ev.scope = (f"Checked {', '.join(dict.fromkeys(done))} only; {gone}."
                    if done else f"Only part of this could be checked; {gone}.")
        ev.how = " ".join(dict.fromkeys(p[3] for p in opt_bad))
    return ev
