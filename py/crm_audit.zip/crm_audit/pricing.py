"""Quote calculator for the consultant. INTERNAL: nothing in here is ever written into the client's
HTML report, details workbook or cleanup kit. Every price and threshold lives in DEFAULT_PRICING and
can be changed in the [pricing] table of audit.toml."""
from __future__ import annotations

import copy
import math

DEFAULT_PRICING = {
    # Audit (fixed price) by number of records = contacts + accounts + leads + opportunities
    "small_below": 5000,        # fewer records than this: the small price
    "large_above": 25000,       # more records than this: the large price (in between: the medium price)
    "audit_small": 1500,
    "audit_medium": 2500,
    "audit_large": 3500,
    "multi_crm_min": 3500,      # clients that use 2+ CRMs pay at least this
    "pilot_audit": 750,         # flat price for your first few clients
    "pilot_label": "Pilot price (first 3 clients)",
    # Cleanup project
    "cleanup_base": 1500,
    "per_ready": 0.50,          # each fix that is ready to load
    "per_decide": 1.50,         # each record that needs a decision
    "per_enrich": 1.00,         # each record to enrich
    "round_to": 250,
    "cleanup_min": 3000,
    "cleanup_max": 10000,
    # Booking the cleanup soon after the audit earns a credit
    "credit_pct": 50,
    "credit_days": 30,
    # Monthly retainer by number of reps: [up to this many reps, price per month]
    "retainer_tiers": [[10, 750], [25, 1250], [50, 2000]],
    "retainer_over_price": 2500,  # more reps than the last tier
}

DASH = "–"


def money(v) -> str:
    return f"${v:,.0f}"


def _num(p: dict, key: str) -> float:
    try:
        v = float(p[key])
    except (KeyError, TypeError, ValueError):
        raise ValueError(f"[pricing] {key} in audit.toml must be a number") from None
    if math.isnan(v) or v < 0:
        raise ValueError(f"[pricing] {key} in audit.toml must be zero or more")
    return v


def merged(overrides: dict | None) -> dict:
    """DEFAULT_PRICING with anything from audit.toml's [pricing] table on top, checked."""
    p = copy.deepcopy(DEFAULT_PRICING)
    if overrides:
        p.update({k: v for k, v in overrides.items() if k in DEFAULT_PRICING})
    for k, v in DEFAULT_PRICING.items():
        if k not in ("retainer_tiers", "pilot_label"):
            _num(p, k)
    try:
        tiers = sorted((float(a), float(b)) for a, b in p["retainer_tiers"])
    except (TypeError, ValueError):
        raise ValueError("[pricing] retainer_tiers must look like [[10, 750], [25, 1250]]") from None
    if not tiers:
        raise ValueError("[pricing] retainer_tiers needs at least one [reps, price] pair")
    p["retainer_tiers"] = tiers
    p["round_to"] = p["round_to"] or 1
    return p


def count_records(data) -> int:
    """Contacts + accounts + leads + opportunities rows loaded."""
    return sum(len(data[k]) for k in ("contacts", "accounts", "leads", "opportunities") if k in data)


def reps_from_audit(cfg: dict, ctx) -> tuple[int | None, str]:
    """Rep count and where it came from: audit.toml if set (same rule as the impact calculator),
    else the active people in the users export (integrations and inactive users left out)."""
    from .scoring import _pos
    n = _pos((cfg.get("impact") or {}).get("reps"))
    if n is not None:
        return int(round(n)), "set in audit.toml"
    if getattr(ctx, "users_loaded", False):
        ids = ctx.data["users"].text("id")
        people = {i for i in ids if isinstance(i, str)} - ctx.inactive_ids - ctx.integration_ids
        if people:
            return len(people), "active users in the export"
    return None, ""


def round_to(x: float, step: float) -> float:
    return math.floor(x / step + 0.5) * step


def audit_price(records: int, crm_count: int, p: dict) -> tuple[float, str]:
    if records < p["small_below"]:
        price, tier = p["audit_small"], f"under {p['small_below']:,.0f}"
    elif records <= p["large_above"]:
        price, tier = p["audit_medium"], f"{p['small_below']:,.0f}{DASH}{p['large_above']:,.0f}"
    else:
        price, tier = p["audit_large"], f"over {p['large_above']:,.0f}"
    why = f"{records:,} records ({tier} tier)"
    if crm_count >= 2 and price < p["multi_crm_min"]:
        price = p["multi_crm_min"]
        why += f"; {crm_count} CRMs, so at least {money(price)}"
    return price, why


def cleanup_price(ready: int, decide: int, enrich: int, p: dict) -> tuple[float, str, bool]:
    raw = p["cleanup_base"] + p["per_ready"] * ready + p["per_decide"] * decide + p["per_enrich"] * enrich
    price = min(max(round_to(raw, p["round_to"]), p["cleanup_min"]), p["cleanup_max"])
    why = (f"{money(p['cleanup_base'])} base + {ready:,} fixes ready to load, {decide:,} need a decision, "
           f"{enrich:,} to enrich")
    if round_to(raw, p["round_to"]) < p["cleanup_min"]:
        why += f" (minimum {money(p['cleanup_min'])})"
    elif raw > p["cleanup_max"]:
        why += f" (capped at {money(p['cleanup_max'])})"
    return price, why, raw > p["cleanup_max"]


def retainer(reps: int | None, p: dict) -> dict:
    tiers = p["retainer_tiers"]
    if reps is None:
        lo = min(price for _, price in tiers + [(0, p["retainer_over_price"])])
        hi = max(price for _, price in tiers + [(0, p["retainer_over_price"])])
        return {"amount": None, "low": lo, "high": hi, "display": f"{money(lo)}{DASH}{money(hi)}/month",
                "why": "team size unknown", "note": "Ask how many reps use the CRM to pin this down."}
    prev = 0
    for top, price in tiers:
        if reps <= top:
            return {"amount": price, "display": f"{money(price)}/month",
                    "why": f"{reps:,} reps ({prev + 1:,.0f}{DASH}{top:,.0f} tier)" if prev else
                           f"{reps:,} reps (up to {top:,.0f})", "note": None}
        prev = top
    return {"amount": p["retainer_over_price"], "display": f"{money(p['retainer_over_price'])}/month",
            "why": f"{reps:,} reps (over {prev:,.0f})",
            "note": f"Over {prev:,.0f} reps: custom quote."}


def build_quote(records: int, reps: int | None = None, crm_count: int = 1, cleanup: dict | None = None,
                pilot: bool = False, pricing: dict | None = None) -> dict:
    """cleanup is the cleanup kit summary ({'ready','decide','enrich'}) or None before an audit."""
    p = merged(pricing)
    records, crm_count = int(records), max(1, int(crm_count or 1))
    lines, notes = [], []
    fee, why = audit_price(records, crm_count, p)
    if pilot:
        fee_shown = p["pilot_audit"]
        lines.append({"key": "audit", "label": "Audit (pilot price)", "amount": fee_shown,
                      "display": money(fee_shown), "why": f"flat pilot price; standard fee would be {money(fee)}"})
    else:
        fee_shown = fee
        lines.append({"key": "audit", "label": "Audit", "amount": fee, "display": money(fee), "why": why})
        lines.append({"key": "pilot", "label": p["pilot_label"], "amount": p["pilot_audit"], "alt": True,
                      "display": money(p["pilot_audit"]), "why": "instead of the standard audit fee"})
    cleanup_total = None
    if cleanup is not None:
        c, cwhy, big = cleanup_price(int(cleanup["ready"]), int(cleanup["decide"]), int(cleanup["enrich"]), p)
        cleanup_total = c
        lines.append({"key": "cleanup", "label": "Cleanup project", "amount": c, "display": money(c), "why": cwhy})
        if big:
            notes.append("Large job: consider a custom quote or phasing it.")
    else:
        lines.append({"key": "cleanup", "label": "Cleanup project", "amount": None,
                      "display": f"{money(p['cleanup_min'])}{DASH}{money(p['cleanup_max'])}",
                      "why": "quoted after the audit"})
    credit = round(fee_shown * p["credit_pct"] / 100, 2)
    lines.append({"key": "credit", "label": f"Book the cleanup within {p['credit_days']:g} days",
                  "amount": -credit, "display": f"{DASH}{money(credit)}",
                  "why": f"{p['credit_pct']:g}% of the audit fee credited"})
    if cleanup_total is not None:
        total = fee_shown + cleanup_total - credit
        lines.append({"key": "total", "label": "Audit + cleanup, booked together", "amount": total,
                      "display": money(total), "why": "after the credit"})
    r = retainer(reps, p)
    lines.append({"key": "retainer", "label": "Ongoing retainer", "amount": r["amount"],
                  "display": r["display"], "why": r["why"]})
    if r["note"]:
        notes.append(r["note"])
    return {"lines": lines, "notes": notes, "records": records, "reps": reps, "crm_count": crm_count,
            "pilot": bool(pilot), "standard_audit": fee, "credit_days": p["credit_days"],
            "cleanup_counts": ({k: int(cleanup[k]) for k in ("ready", "decide", "enrich")}
                               if cleanup is not None else None)}


def format_block(q: dict, heading: str = "Suggested quote (for you, not the client)") -> str:
    rows = [(l["label"], l["display"], l["why"]) for l in q["lines"]]
    w1 = max(len(r[0]) for r in rows)
    w2 = max(len(r[1]) for r in rows)
    out = [f" {heading}", " " + "-" * 62]
    out += [f"  {a:<{w1}}  {b:>{w2}}   {c}" for a, b, c in rows]
    out += [f"  Note: {n}" for n in q["notes"]]
    return "\n".join(out)


def quote_text(q: dict, client: str = "", prepared_by: str = "") -> str:
    """Client-facing plain text to paste into an email. Deliberately separate from the internal
    "why" notes: no tiers, base prices, minimums or formulas."""
    by = {l["key"]: l for l in q["lines"]}
    head = f"Uroboric CRM health audit for {client}:" if client else "Uroboric CRM health audit:"
    out = [head]
    a = by["audit"]
    if q["pilot"]:
        out.append(f"- Audit (pilot price): {a['display']} (normally {money(q['standard_audit'])})")
    else:
        out.append(f"- Audit: {a['display']} (fixed price, delivered within 2 business days of "
                   "receiving your exports)")
    c = by["cleanup"]
    cc = q.get("cleanup_counts")
    if c["amount"] is None or not cc:
        out.append(f"- Cleanup project: quoted after the audit ({c['display']})")
    else:
        out.append(f"- Cleanup project: {c['display']} (fixed price; covers {cc['ready']:,} fixes ready to "
                   f"load, {cc['decide']:,} records needing a decision and {cc['enrich']:,} records to enrich)")
    cr = by["credit"]
    out.append(f"- Book the cleanup within {q['credit_days']:g} days and {money(-cr['amount'])} of the audit "
               "fee is credited toward it.")
    if "total" in by:
        out.append(f"- Audit + cleanup together: {by['total']['display']}")
    r = by["retainer"]
    if r["amount"] is None:
        out.append(f"- Ongoing data health retainer: {r['display']} depending on team size")
    else:
        out.append(f"- Ongoing data health retainer: {r['display']} (monthly re-audit and progress report "
                   f"for a team of {q['reps']:,} reps)")
    if prepared_by:
        out += ["", f"— {prepared_by}"]
    return chr(10).join(out)
