"""Runs every check in the checklist against the loaded CRM exports."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import pandas as pd
from .fuzzcompat import fuzz

from . import normalize as N
from .checklist import CHECKS, Check, score_value
from .crms import tip
from .loader import Loaded, Table
from .plain import MEASURED_HEADLINE, RATING, money, one_in

FUZZY_BLOCK_LIMIT = 2000  # unique names per company domain compared pairwise
INACTIVE_NAME_RE = re.compile(r"\((deactivated|inactive|disabled)[^)]*\)|deactivated user", re.I)
# HubSpot's "Record source" values, in plain words (integration/import/API ones count as tools).
# Keys are lowercase with spaces and underscores alike ("CRM_UI" and "CRM UI" are the same).
HUBSPOT_SOURCES = {
    # (labels avoid the word "HubSpot": in a Salesforce org that word marks a sync integration)
    "crm_ui": "Entered by hand", "import": "List import", "integration": "An integration",
    "api": "API integration", "form": "Website form", "email": "Email (logged automatically)",
    "sales": "Sales extension", "batch_update": "Bulk update", "mobile_ios": "Mobile app",
    "mobile_android": "Mobile app", "conversations": "Chat or conversations inbox",
    "automation_platform": "Workflow automation", "migration": "Data migration import",
    "crm_setting": "CRM automation", "hubspot_processing": "CRM automation",
}
# Record sources where a person typed the record in: their name is the better answer than the channel
HUBSPOT_MANUAL = {"crm_ui", "sales", "mobile_ios", "mobile_android"}


def _source_key(v) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(v).lower()).strip("_")


INTEGRATION_RE = re.compile(
    r"integration|\bapi\b|sync|zoominfo|hubspot|marketo|pardot|apollo|outreach|salesloft|zapier|"
    r"automated|automation|system user|\bbot\b|connector|data ?loader|import|clearbit|6sense|gong|"
    r"non-interactive|application user", re.I)


@dataclass
class Result:
    check_id: str
    value: float | None = None
    display: str = ""
    score: int | None = None
    status: str = "not scored"  # scored | not scored | needs input | error
    source: str = "automated"   # automated | entered | auditor
    headline: str = ""          # one plain-English sentence with the real numbers
    example: str = ""           # a real record from the CRM that shows the problem
    notes: list[str] = field(default_factory=list)
    details: dict[str, pd.DataFrame] = field(default_factory=dict)
    extras: dict = field(default_factory=dict)
    flagged: dict[str, set] = field(default_factory=dict)  # object -> ids of the records at fault


class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra

    def groups(self):
        out = {}
        for i in range(len(self.parent)):
            out.setdefault(self.find(i), []).append(i)
        return [g for g in out.values() if len(g) > 1]


def pct(n, d):
    return 100.0 * n / d if d else None


def _freq(p, noun):
    f = one_in(p)
    return f" ({f} {noun})" if f else ""


def _biggest(groups):
    return max(groups, key=len) if groups else None


def _later_copies(df, groups) -> set:
    """In each duplicate group the oldest record is the original; the newer ones are the copies."""
    ids = df["id"].tolist()
    created = df["created"].tolist() if "created" in df else [None] * len(ids)
    out = set()
    for g in groups:
        order = sorted(g, key=lambda i: (pd.isna(created[i]), created[i] if not pd.isna(created[i]) else 0))
        out.update(ids[i] for i in order[1:] if isinstance(ids[i], str))
    return out


def _ids(df, mask) -> set:
    return {i for i in df.loc[mask, "id"] if isinstance(i, str)}


def fmt_pct(v):
    return "n/a" if v is None else f"{v:.1f}%"


def _first_id(v):
    """'10;11;12' -> '10' (HubSpot lists every associated record; the first is the primary)."""
    if isinstance(v, str) and (";" in v or "," in v):
        return re.split(r"[;,]", v)[0].strip() or None
    return v


# ---- Bullhorn
# A company typed in only to satisfy a required field (Bullhorn contacts must have a company)
PLACEHOLDER_COMPANY = {"tbd", "to be determined", "unknown"}
# "api" inside a word (rapid, capital) doesn't count; api_user, acme.api, API User do
BULLHORN_API_RE = re.compile(r"(?<![a-z])api(?![a-z])|integration", re.I)
ARCHIVED_RE = re.compile(r"\barchiv", re.I)
# Deal statuses are admin-defined, so they're matched softly on words
BH_WON_RE = re.compile(r"won|filled|placed", re.I)
BH_LOST_RE = re.compile(r"lost|cancel|declin|dead", re.I)
BH_CLOSED_RE = re.compile(r"closed", re.I)


def _is_placeholder_company(v) -> bool:
    return isinstance(v, str) and re.sub(r"[^a-z ]", "", v.lower()).strip() in PLACEHOLDER_COMPANY


def _first_owner(v):
    """'Ann Lee; Bo Cruz' -> 'Ann Lee' (Bullhorn companies can have several owners)."""
    if isinstance(v, str) and re.search(r"[;,|]", v):
        return re.split(r"[;,|]", v)[0].strip() or None
    return v


def _lookup(keys, values):
    return {k: v for k, v in zip(keys, values) if isinstance(k, str)}


class Context:
    """Cleaned-up, joined views of the exports that several checks share."""

    def __init__(self, data: dict[str, Table], cfg: dict):
        self.data = data
        self.cfg = cfg
        ad = cfg.get("audit_date")
        try:
            self.audit_date = pd.Timestamp(str(ad)) if ad else pd.Timestamp.today().normalize()
        except (ValueError, TypeError):
            raise ValueError(f"audit_date = {ad!r} isn't a date. Write it like 2026-11-10, or leave it out to use "
                             "today's date.") from None
        self.region = cfg.get("phone_region", "US")
        from .crms import resolve
        self.crm = resolve(cfg, data)  # salesforce | hubspot | dynamics | bullhorn
        self.archived: dict = {}  # Bullhorn: records left out because they are archived or deleted
        if self.crm == "bullhorn":
            data = self.data = self._without_archived(data)
        # A file with headers but no records (a new org, or an object nobody uses) counts as absent
        self.empty_tables = {name for name, t in data.items() if len(t) == 0}
        has = lambda name: name in data and name not in self.empty_tables  # noqa: E731
        self._users()
        self.accounts = self._accounts() if has("accounts") else None
        self.contacts = self._contacts() if has("contacts") else None
        self.opps = self._opps() if has("opportunities") else None
        self.leads = self._leads() if has("leads") else None
        if self.leads is None and self.contacts is not None and self.crm == "hubspot":
            self.leads = self._hubspot_leads()

    def t(self, name) -> Table | None:
        return self.data.get(name)

    def _without_archived(self, data):
        """Bullhorn marks a record nobody uses with Status "Archive" (or isDeleted). Those aren't part of the
        active CRM, so they're left out of every count, and the report says how many."""
        out = Loaded()
        out.warnings = getattr(data, "warnings", [])
        for name, t in data.items():
            gone = pd.Series(False, index=t.raw.index)
            if name in ("contacts", "accounts", "opportunities", "leads"):
                if t.has("status"):
                    gone |= t.text("status").map(lambda v: isinstance(v, str) and bool(ARCHIVED_RE.search(v)))
                if t.has("is_deleted"):
                    gone |= t.flag("is_deleted")
            if gone.any():
                self.archived[name] = int(gone.sum())
                t = Table(t.name, t.path, t.raw[~gone.values].reset_index(drop=True), t.mapping)
            out[name] = t
        if self.archived:
            from .loader import TABLE_LABELS
            what = ", ".join(f"{n:,} {TABLE_LABELS[k].lower()}" for k, n in self.archived.items())
            msg = (f"Archived or deleted records were left out of the audit, since they aren't part of the active "
                   f"CRM: {what}.")
            if msg not in out.warnings:
                out.warnings.append(msg)
        return out

    def _users(self):
        self.users_loaded = "users" in self.data
        self.inactive_ids, self.inactive_names, self.user_names = set(), set(), {}
        self.integration_ids = set()
        if not self.users_loaded:
            return
        u = self.data["users"]
        ids, names = u.text("id"), u.text("name")
        if not u.has("name"):  # Data Export: build "First Last" (system users often have only a last name)
            names = (u.text("first_name").fillna("") + " " + u.text("last_name").fillna("")).str.strip() \
                .replace("", None)
        profiles, types = u.text("profile"), u.text("user_type")
        active = u.flag("is_active") if u.has("is_active") else pd.Series(True, index=u.raw.index)
        logins = u.text("username")
        if self.crm == "bullhorn":  # enabled = false or isDeleted = true means the person has left
            if u.has("is_deleted"):
                active = active & ~u.flag("is_deleted")
            if not u.has("name") and not u.has("first_name") and u.has("username"):
                names = logins
        for i, n, a, p, ty, lg in zip(ids, names, active, profiles, types, logins):
            if isinstance(i, str) and isinstance(n, str):
                self.user_names[i] = n
            api = self.crm == "bullhorn" and any(isinstance(x, str) and BULLHORN_API_RE.search(x) for x in (ty, lg))
            if isinstance(i, str) and (api or any(isinstance(x, str) and INTEGRATION_RE.search(x)
                                                  for x in (n, p, ty))):
                self.integration_ids.add(i)
            if not a:
                if isinstance(i, str):
                    self.inactive_ids.add(i)
                if isinstance(n, str):
                    self.inactive_names.add(n.lower())

    def add_creator(self, df, t: Table):
        """Who created each record, and whether that 'who' is automated rather than a person."""
        df["created_by_id"] = t.text("created_by_id")
        names = t.text("created_by_name")
        if self.crm == "hubspot":
            # "Created by user ID" holds the creator's name; "Record source" says how the record got in.
            # Imports, integrations and automation are the real creator, whoever clicked the button.
            src = next((c for c in t.raw.columns if re.sub(r"[^a-z]", "", c.lower()) == "recordsource"), None)
            if src is not None:
                def who(name, source):
                    if not isinstance(source, str):
                        return name
                    key = _source_key(source)
                    label = HUBSPOT_SOURCES.get(key, source.strip())
                    return (name if isinstance(name, str) else label) if key in HUBSPOT_MANUAL else label
                names = pd.Series([who(n, v) for n, v in zip(names, t.raw[src])], index=names.index, dtype=object)
        else:
            names = names.map(lambda v: HUBSPOT_SOURCES.get(_source_key(v), v) if isinstance(v, str) else v)
        df["created_by_name"] = names
        df["creator"] = self.owner_label(df["created_by_id"], df["created_by_name"])
        df["creator_is_integration"] = [
            (isinstance(i, str) and i in self.integration_ids) or
            (isinstance(c, str) and bool(INTEGRATION_RE.search(c)))
            for i, c in zip(df["created_by_id"], df["creator"])]

    def owner_label(self, owner_id, owner_name):
        return owner_id.map(lambda i: self.user_names.get(i, i) if isinstance(i, str) else None) \
            .where(owner_id.notna(), owner_name)

    def owner_status(self, owner_id, owner_name):
        def status(i, n):
            if not isinstance(i, str) and not isinstance(n, str):
                return "no owner"
            if (isinstance(i, str) and i in self.inactive_ids) or \
                    (isinstance(n, str) and (n.lower() in self.inactive_names or INACTIVE_NAME_RE.search(n))):
                return "inactive owner"  # HubSpot and Dynamics often label them "(Deactivated)" / "(Disabled)"
            return "ok"
        return pd.Series([status(i, n) for i, n in zip(owner_id, owner_name)], index=owner_id.index)

    def _accounts(self):
        t = self.data["accounts"]
        df = pd.DataFrame({k: t.text(k) for k in
                           ["id", "name", "website", "industry", "employees", "state", "country",
                            "city", "owner_id", "owner_name"]})
        if self.crm == "bullhorn":  # several owners in one cell: the first one is the owner
            df["owner_name"] = df["owner_name"].map(_first_owner)
            df["owner_id"] = df["owner_id"].map(_first_id)
            self._numeric_owner_is_id(df)
        df["domain"] = df["website"].map(N.norm_domain)
        # HubSpot creates companies from email domains with no name: show the domain instead
        df["name"] = df["name"].where(df["name"].notna(), df["domain"].where(df["domain"].notna(), df["website"]))
        df["name_n"] = df["name"].map(N.norm_company)
        df["owner"] = self.owner_label(df["owner_id"], df["owner_name"])
        df["created"] = t.date("created")
        self.add_creator(df, t)
        return df

    @staticmethod
    def _numeric_owner_is_id(df):
        """A bare "owner" column from the API holds the user's id, not the name."""
        digits = df["owner_name"].map(lambda v: isinstance(v, str) and v.strip().isdigit())
        move = df["owner_id"].isna() & digits
        if digits.any() and move.sum() == digits.sum():
            df.loc[move, "owner_id"] = df.loc[move, "owner_name"]
            df.loc[move, "owner_name"] = None

    def _drop_placeholder_company(self, df, id_col="account_id", name_col="account_name"):
        """Bullhorn contacts must have a company, so people type "TBD": that means no company."""
        tbd = df[name_col].map(_is_placeholder_company)
        df.loc[tbd, name_col] = None
        if id_col in df:
            df.loc[tbd, id_col] = None

    def _contacts(self):
        t = self.data["contacts"]
        df = pd.DataFrame({k: t.text(k) for k in
                           ["id", "first_name", "last_name", "email", "phone", "mobile", "title",
                            "account_id", "account_name", "owner_id", "owner_name", "lead_source",
                            "state", "country"]})
        if not t.has("first_name") and not t.has("last_name") and t.has("name"):  # only a full-name column
            parts = t.text("name").map(lambda v: v.strip().split(None, 1) if isinstance(v, str) and v.strip()
                                       else [])
            df["first_name"] = parts.map(lambda p: p[0] if p else None)
            df["last_name"] = parts.map(lambda p: p[1] if len(p) > 1 else None)
        df["account_id"] = df["account_id"].map(_first_id)  # HubSpot can list several: "10;11;12"
        if self.crm == "bullhorn":
            self._numeric_owner_is_id(df)
            self._drop_placeholder_company(df)
            if self.accounts is not None:  # a contact filed under the placeholder company has no real company
                tbd_ids = set(self.accounts.loc[self.accounts["name"].map(_is_placeholder_company), "id"].dropna())
                df.loc[df["account_id"].isin(tbd_ids), "account_id"] = None
        for k in ("last_activity", "last_modified", "created"):
            df[k] = t.date(k)
        df["opted_out"] = t.flag("opted_out")
        df["name"] = (df["first_name"].fillna("") + " " + df["last_name"].fillna("")).str.strip()
        df["email_n"] = df["email"].map(N.norm_email)
        df["person_key"] = [N.person_key(f, l) for f, l in zip(df["first_name"], df["last_name"])]
        df["acct_domain"] = None
        df["account"] = df["account_name"]
        a = self.accounts
        if a is not None:
            if t.has("account_id") and a["id"].notna().any():
                df["acct_domain"] = df["account_id"].map(_lookup(a["id"], a["domain"]))
                df["account"] = df["account_id"].map(_lookup(a["id"], a["name"])) \
                    .where(df["account_id"].notna(), df["account_name"])
            elif t.has("account_name"):
                df["acct_domain"] = df["account_name"].map(N.norm_company) \
                    .map(_lookup(a["name_n"], a["domain"]))
        df["domain_key"] = df["acct_domain"].where(df["acct_domain"].notna(),
                                                   df["email"].map(N.business_domain))
        df["has_account"] = df["account_id"].notna() | df["account_name"].notna()
        df["owner"] = self.owner_label(df["owner_id"], df["owner_name"])
        self.add_creator(df, t)
        return df

    def _opps(self):
        t = self.data["opportunities"]
        df = pd.DataFrame({k: t.text(k) for k in
                           ["id", "name", "account_id", "account_name", "stage", "owner_id",
                            "owner_name", "contact_id", "contact_name", "loss_reason", "probability"]})
        df["account_id"] = df["account_id"].map(_first_id)
        df["contact_id"] = df["contact_id"].map(_first_id)
        if self.crm == "bullhorn":
            self._numeric_owner_is_id(df)
            self._drop_placeholder_company(df)
        df["close_date"] = t.date("close_date")
        df["last_activity"] = t.date("last_activity")
        df["amount"] = t.number("amount")
        stage = df["stage"].fillna("").str.lower()
        status = t.text("status").fillna("").str.strip().str.lower()
        if t.has("is_closed"):
            df["is_closed"] = t.flag("is_closed")
        elif t.has("status") and status.isin(["open", "won", "lost", "0", "1", "2"]).any():
            df["is_closed"] = status.isin(["won", "lost", "1", "2"])  # Dynamics: Open / Won / Lost
        else:
            df["is_closed"] = stage.str.contains("closed")
        if t.has("is_won"):
            df["is_won"] = t.flag("is_won")
        elif t.has("status") and status.isin(["open", "won", "lost", "0", "1", "2"]).any():
            df["is_won"] = status.isin(["won", "1"])
        else:
            df["is_won"] = df["is_closed"] & stage.str.contains("won")
        if self.crm == "bullhorn":
            self._bullhorn_deals(df, t, status)
        df["account_key"] = df["account_id"].where(df["account_id"].notna(),
                                                   df["account_name"].map(N.norm_company))
        acct_names = {}
        if self.accounts is not None:
            acct_names = _lookup(self.accounts["id"], self.accounts["name"])
        df["account"] = df["account_id"].map(acct_names).where(df["account_id"].notna(),
                                                                df["account_name"])
        df["owner"] = self.owner_label(df["owner_id"], df["owner_name"])
        return df

    def _bullhorn_deals(self, df, t: Table, status: pd.Series):
        """Open, won and lost for Bullhorn Opportunities (or the job orders standing in for them). Statuses are
        admin-defined, so they're matched on words: won = Closed-Won / Filled / Placed; lost = Lost / Closed-Lost /
        Cancelled; any other 'closed' status is closed too. isOpen decides open vs closed when the export has it."""
        won = status.map(lambda v: bool(BH_WON_RE.search(v)))
        lost = status.map(lambda v: bool(BH_LOST_RE.search(v)))
        if t.has("is_open"):
            closed = ~t.flag("is_open")
        else:
            closed = won | lost | status.map(lambda v: bool(BH_CLOSED_RE.search(v)))
        df["is_closed"] = closed
        df["is_won"] = won & closed
        if not t.has("stage"):  # the status is the closest thing to a stage
            df["stage"] = t.text("status")
        expected, actual = t.date("expected_close"), t.date("actual_close")  # expected while open, actual once closed
        df["close_date"] = actual.where(closed & actual.notna(), expected.where(expected.notna(), actual))

    def _leads(self):
        t = self.data["leads"]
        df = pd.DataFrame({k: t.text(k) for k in ["id", "email", "status", "owner_id", "owner_name",
                                                  "first_name", "last_name", "company", "lead_source"]})
        df["created"] = t.date("created")
        df["last_activity"] = t.date("last_activity")
        if self.crm == "bullhorn":
            self._numeric_owner_is_id(df)
            self._drop_placeholder_company(df, "company_id", "company")
        if t.has("is_converted"):
            df["is_converted"] = t.flag("is_converted")
        else:  # Dynamics marks converted leads with Status "Qualified"
            df["is_converted"] = df["status"].fillna("").str.strip().str.lower().isin(
                ["qualified", "converted", "closed - converted"])
        df["owner"] = self.owner_label(df["owner_id"], df["owner_name"])
        df["name"] = (df["first_name"].fillna("") + " " + df["last_name"].fillna("")).str.strip()
        df["email_n"] = df["email"].map(N.norm_email)
        self.add_creator(df, t)
        return df

    def _hubspot_leads(self):
        """HubSpot has no separate lead record: leads are contacts in an early lifecycle stage."""
        t = self.data["contacts"]
        stage = t.text("lifecycle_stage").fillna("").map(lambda v: re.sub(r"[^a-z]", "", v.lower()))
        early = stage.isin(["subscriber", "lead", "marketingqualifiedlead", "salesqualifiedlead", "mql", "sql"])
        if not t.has("lifecycle_stage") or not early.any():
            return None
        C = self.contacts
        df = C.loc[early.values, ["id", "email", "owner_id", "owner_name", "first_name", "last_name", "account",
                                  "lead_source", "created", "last_activity", "owner", "name", "email_n",
                                  "created_by_id", "created_by_name", "creator", "creator_is_integration"]].copy()
        df = df.rename(columns={"account": "company"})
        df["status"] = t.text("lifecycle_stage")[early.values].values
        df["is_converted"] = False
        return df.reset_index(drop=True)


def _missing(chk: Check, what: str) -> Result:
    return Result(chk.id, display=f"Needs {what} export",
                  notes=[f"No {what} file was found in the data folder, so this wasn't measured."])


def _cap(df: pd.DataFrame, n=20000):
    return df.head(n)


def _owners_split(groups, owner_series) -> int:
    own = owner_series.tolist()
    return sum(1 for g in groups if len({own[i] for i in g if isinstance(own[i], str)}) > 1)


def _group_table(df: pd.DataFrame, groups, cols: dict[str, str]) -> pd.DataFrame:
    groups = sorted(groups, key=len, reverse=True)
    if not groups:
        return pd.DataFrame(columns=["Group", "Group size"] + list(cols.values()))
    rows = [i for g in groups for i in g]  # one lookup for every group, not one per group
    out = df.iloc[rows][list(cols)].rename(columns=cols).reset_index(drop=True)
    out.insert(0, "Group size", [len(g) for g in groups for _ in g])
    out.insert(0, "Group", [n for n, g in enumerate(groups, 1) for _ in g])
    return out


CONTACT_COLS = {"id": "Contact ID", "name": "Name", "email": "Email", "account": "Account",
                "owner": "Owner", "created": "Created", "last_activity": "Last activity"}


# ---------------------------------------------------------------- 1. Duplicates

def c_1_1(ctx: Context, chk: Check) -> Result:
    C = ctx.contacts
    if C is None:
        return _missing(chk, "contacts")
    real_email = C["email_n"].where(~C["email_n"].map(N.is_placeholder_email))
    counts = real_email.value_counts()
    dup = counts[counts > 1]
    extra = int((dup - 1).sum())
    r = Result(chk.id, value=pct(extra, len(C)))
    r.display = f"{fmt_pct(r.value)} ({extra:,} extra records in {len(dup):,} groups, of {len(C):,} contacts)"
    pos = pd.Series(range(len(C)), index=C.index)
    in_dup = C[real_email.isin(dup.index)]
    groups = [pos[idx].tolist() for idx in in_dup.groupby(real_email[in_dup.index]).groups.values()]
    split = _owners_split(groups, C["owner"])
    if groups:
        r.notes.append(f"{split:,} of {len(groups):,} duplicate groups have records owned by different reps.")
        r.notes.append("Groups are sorted largest first; the top 5 are your 'worst examples' for the readout.")
    r.details["Dup contacts (email)"] = _cap(_group_table(C, groups, CONTACT_COLS))
    r.extras = {"groups": len(groups), "owners_split": split}
    r.flagged = {"contacts": _later_copies(C, groups)}
    if extra:
        r.headline = f"{extra:,} contacts are extra copies of someone already in the CRM" + _freq(r.value, "contacts")
        real = [x for x in groups if not N.is_junk(C["first_name"].iloc[x[0]])
                and N.email_domain(C["email_n"].iloc[x[0]]) not in {"test.com", "example.com"}]
        g = _biggest(real or groups)
        row = C.iloc[g[0]]
        owners = C["owner"].iloc[g].dropna().nunique()
        r.example = f'"{row["name"]}" ({row["email_n"]}) is in the CRM {len(g)} times' + \
            (f", owned by {owners} different reps" if owners > 1 else "")
    else:
        r.headline = "No two contacts share an email address"
    return r


def _similar_people(a: str, b: str) -> bool:
    if a == b:
        return True
    fa, la = a.split(" ", 1)
    fb, lb = b.split(" ", 1)
    if la == lb and (fa[0] == fb[0]) and (len(fa) == 1 or len(fb) == 1):
        return True  # 'j smith' vs 'john smith'
    return fuzz.ratio(a, b) >= 90 and (la == lb or fa == fb)


def c_1_2(ctx: Context, chk: Check) -> Result:
    C = ctx.contacts
    if C is None:
        return _missing(chk, "contacts")
    sub = C[C["person_key"].notna() & C["domain_key"].notna()]
    pos = {idx: i for i, idx in enumerate(C.index)}
    uf = UnionFind(len(C))
    blocks: dict[str, dict[str, list[int]]] = {}  # company domain -> person key -> row positions
    for idx, dom, key in zip(sub.index, sub["domain_key"], sub["person_key"]):
        blocks.setdefault(dom, {}).setdefault(key, []).append(pos[idx])
    for by_key in blocks.values():
        for members in by_key.values():  # the same name at the same company
            for m in members[1:]:
                uf.union(members[0], m)
        if len(by_key) < 2:
            continue
        # Every pair _similar_people accepts shares a first or a last name, so only compare names
        # inside those groups (comparing every pair is slow for large companies).
        by_first: dict[str, list[str]] = {}
        by_last: dict[str, list[str]] = {}
        for k in by_key:
            f, l = k.split(" ", 1)
            by_first.setdefault(f, []).append(k)
            by_last.setdefault(l, []).append(k)
        for group in (*by_first.values(), *by_last.values()):
            if 1 < len(group) <= FUZZY_BLOCK_LIMIT:
                for i in range(len(group)):
                    for j in range(i + 1, len(group)):
                        if _similar_people(group[i], group[j]):
                            uf.union(by_key[group[i]][0], by_key[group[j]][0])
    groups, extra = [], 0
    email_list = C["email_n"].tolist()
    for g in uf.groups():
        vals = [email_list[i] for i in g]
        distinct = len({v for v in vals if isinstance(v, str)}) + sum(1 for v in vals if not isinstance(v, str))
        if distinct > 1:
            groups.append(g)
            extra += distinct - 1
    r = Result(chk.id, value=pct(extra, len(C)))
    r.display = f"{fmt_pct(r.value)} ({extra:,} likely duplicates in {len(groups):,} groups)"
    if sub.shape[0] < len(C):
        r.notes.append(f"{len(C) - sub.shape[0]:,} contacts had no company domain (no account website "
                       "and a personal email), so they couldn't be compared.")
    split = _owners_split(groups, C["owner"])
    if groups:
        r.notes.append(f"{split:,} groups have records owned by different reps.")
    cols = dict(CONTACT_COLS)
    cols["domain_key"] = "Company domain"
    r.details["Dup contacts (fuzzy)"] = _cap(_group_table(C, groups, cols))
    r.extras = {"groups": len(groups), "owners_split": split}
    r.flagged = {"contacts": _later_copies(C, groups)}
    if extra:
        r.headline = f"{extra:,} contacts look like the same person entered with a different email" + \
            _freq(r.value, "contacts")
        g = _biggest(groups)
        people = " and ".join(f'"{C["name"].iloc[i]}" ({C["email"].iloc[i] or "no email"})' for i in g[:2])
        r.example = f"{people} at {C['domain_key'].iloc[g[0]]}"
    else:
        r.headline = "No likely duplicates found under different emails"
    return r


def c_1_3(ctx: Context, chk: Check) -> Result:
    A = ctx.accounts
    if A is None:
        return _missing(chk, "accounts")
    uf = UnionFind(len(A))
    for key in ("domain", "name_n"):
        firsts = {}
        for i, v in enumerate(A[key]):
            if isinstance(v, str):
                if v in firsts:
                    uf.union(firsts[v], i)
                else:
                    firsts[v] = i
    groups = uf.groups()
    extra = sum(len(g) - 1 for g in groups)
    r = Result(chk.id, value=pct(extra, len(A)))
    r.display = f"{fmt_pct(r.value)} ({extra:,} extra accounts in {len(groups):,} groups, of {len(A):,})"
    split = _owners_split(groups, A["owner"])
    if groups:
        r.notes.append(f"{split:,} groups have accounts owned by different reps.")
    cols = {"id": "Account ID", "name": "Account name", "website": "Website", "domain": "Domain",
            "owner": "Owner"}
    r.details["Dup accounts"] = _cap(_group_table(A, groups, cols))
    r.extras = {"groups": len(groups), "owners_split": split}
    r.flagged = {"accounts": _later_copies(A, groups)}
    if extra:
        r.headline = f"{extra:,} companies are duplicates of another company record" + _freq(r.value, "companies")
        g = _biggest(groups)
        names = " and ".join(f'"{A["name"].iloc[i]}"' for i in g[:3])
        owners = A["owner"].iloc[g].dropna().nunique()
        r.example = f"{names} are the same company" + (f", owned by {owners} different reps" if owners > 1 else "")
    else:
        r.headline = "No duplicate companies found"
    return r


def _deal_core(name, account):
    n = N.canon_text(name) or ""
    acct = set((N.norm_company(account) or "").split())
    return " ".join(t for t in n.split() if t not in acct and t not in {"opportunity", "deal", "opp"})


def c_1_4(ctx: Context, chk: Check) -> Result:
    O = ctx.opps
    if O is None:
        return _missing(chk, "opportunities")
    open_ = O[~O["is_closed"] & O["account_key"].notna()]
    per_account = open_["account_key"].value_counts()  # only accounts with 2+ open deals can hold a duplicate
    open_ = open_[open_["account_key"].isin(per_account[per_account > 1].index)]
    pos = {idx: i for i, idx in enumerate(O.index)}
    uf = UnionFind(len(O))
    for _, block in open_.groupby("account_key"):
        cores = [(pos[i], _deal_core(n, a)) for i, n, a in zip(block.index, block["name"], block["account"])]
        for x in range(len(cores)):
            for y in range(x + 1, len(cores)):
                a, b = cores[x][1], cores[y][1]
                if a == b or (a and b and fuzz.token_sort_ratio(a, b) >= 85):
                    uf.union(cores[x][0], cores[y][0])
    groups = uf.groups()
    extra = sum(len(g) - 1 for g in groups)
    n_open = int((~O["is_closed"]).sum())
    r = Result(chk.id, value=pct(extra, n_open) if n_open else 0.0)
    r.display = f"{extra:,} duplicate open deals in {len(groups):,} groups ({fmt_pct(r.value)} of {n_open:,} open)"
    cols = {"id": "Opportunity ID", "name": "Opportunity", "account": "Account", "stage": "Stage",
            "amount": "Amount", "close_date": "Close date", "owner": "Owner"}
    r.details["Dup open deals"] = _cap(_group_table(O, groups, cols))
    r.extras = {"count": extra, "amount": float(O.iloc[[i for g in groups for i in g[1:]]]["amount"].sum()) if groups else 0.0}
    if groups:
        r.notes.append(f"About ${r.extras['amount']:,.0f} of pipeline is counted twice.")
        r.headline = f"{extra:,} open deals appear to be entered twice, worth {money(r.extras['amount'])}"
        g = _biggest(groups)
        r.example = f'"{O["name"].iloc[g[0]]}" ({O["account"].iloc[g[0]] or "no account"}) is open {len(g)} times'
    else:
        r.headline = "No duplicate open deals found"
    return r


# ------------------------------------------------- 2. Contact accuracy and decay

def c_2_4(ctx: Context, chk: Check) -> Result:
    C, t = ctx.contacts, ctx.t("contacts")
    if C is None:
        return _missing(chk, "contacts")
    if not (t.has("phone") or t.has("mobile")):
        return Result(chk.id, display="No phone columns in export",
                      notes=["Add Phone and MobilePhone to the contacts export."])
    ok = C["phone"].map(lambda v: N.phone_valid(v, ctx.region)) | \
        C["mobile"].map(lambda v: N.phone_valid(v, ctx.region))
    missing = C["phone"].isna() & C["mobile"].isna()
    invalid = ~ok & ~missing
    bad = int((~ok).sum())
    r = Result(chk.id, value=pct(bad, len(C)))
    r.display = f"{fmt_pct(r.value)} bad or missing ({int(missing.sum()):,} missing, {int(invalid.sum()):,} invalid)"
    r.notes.append("Line type and wrong-number rates still need a sample call-through or a rep interview.")
    cols = {"id": "Contact ID", "name": "Name", "phone": "Phone", "mobile": "Mobile",
            "account": "Account", "owner": "Owner"}
    r.details["Invalid phones"] = _cap(C[invalid][list(cols)].rename(columns=cols))
    r.flagged = {"contacts": _ids(C, ~ok)}
    r.headline = f"{bad:,} contacts have no working phone number" + _freq(r.value, "contacts")
    if invalid.any():
        row = C[invalid].iloc[0]
        r.example = f'{row["name"]}\'s number is listed as "{row["phone"] or row["mobile"]}"'
    return r


def c_2_5(ctx: Context, chk: Check) -> Result:
    C, t = ctx.contacts, ctx.t("contacts")
    if C is None:
        return _missing(chk, "contacts")
    if not (t.has("last_activity") or t.has("last_modified")):
        return Result(chk.id, display="No activity/modified dates in export",
                      notes=["Add LastActivityDate and LastModifiedDate to the contacts export."])
    cutoff = ctx.audit_date - pd.DateOffset(months=12)
    no_act = (C["last_activity"].isna() | (C["last_activity"] < cutoff)) if t.has("last_activity") else True
    no_mod = (C["last_modified"].isna() | (C["last_modified"] < cutoff)) if t.has("last_modified") else True
    stale = no_act & no_mod
    if isinstance(stale, bool):
        stale = pd.Series(stale, index=C.index)
    n = int(stale.sum())
    r = Result(chk.id, value=pct(n, len(C)))
    r.display = f"{fmt_pct(r.value)} ({n:,} of {len(C):,} contacts untouched since {cutoff:%b %Y})"
    if not t.has("last_modified"):
        r.notes.append("No LastModifiedDate column, so this is based on activity only.")
    if not t.has("last_activity"):
        r.notes.append("No LastActivityDate column, so this is based on last-modified date only.")
    r.extras = {"count": n}
    cols = {"id": "Contact ID", "name": "Name", "email": "Email", "account": "Account",
            "owner": "Owner", "last_activity": "Last activity", "last_modified": "Last modified"}
    r.details["Stale contacts"] = _cap(C[stale][list(cols)].rename(columns=cols))
    r.headline = f"{n:,} contacts haven't been touched or updated in over a year" + _freq(r.value, "contacts")
    return r


# ------------------------------------- 3. Field completeness and standardization

def _fill_table(rows):
    return pd.DataFrame(rows, columns=["Field", "Records filled", "Fill rate"])


def c_3_1(ctx: Context, chk: Check) -> Result:
    C, t = ctx.contacts, ctx.t("contacts")
    if C is None:
        return _missing(chk, "contacts")
    parts = {
        "Email": C["email"].notna(),
        "Phone (or mobile)": C["phone"].notna() | C["mobile"].notna(),
        "Job title": C["title"].notna(),
        "Account": C["has_account"],
    }
    allf = pd.concat(parts.values(), axis=1).all(axis=1)
    r = Result(chk.id, value=pct(int(allf.sum()), len(C)))
    r.display = f"{fmt_pct(r.value)} of contacts have all four"
    r.notes.append("By field: " + ", ".join(f"{k} {pct(int(v.sum()), len(C)):.0f}%" for k, v in parts.items()))
    for f, label in (("email", "Email"), ("title", "Title")):
        if not t.has(f):
            r.notes.append(f"No {label} column in the export, so it counts as empty.")
    r.details["Core field fill (contacts)"] = _fill_table(
        [(k, int(v.sum()), round(pct(int(v.sum()), len(C)), 1)) for k, v in parts.items()])
    _gap_headline(r, parts, len(C), "contacts", "an email, phone, job title or company")
    r.flagged = {"contacts": _ids(C, ~allf)}
    return r


def _gap_headline(r, parts, total, noun, what):
    missing = total - int(pd.concat(parts.values(), axis=1).all(axis=1).sum())
    if not missing:
        r.headline = f"Every one of the {noun} has {what.replace(' or ', ' and ')}"
        return
    r.headline = f"{missing:,} {noun} are missing {what}" + _freq(pct(missing, total), noun)
    worst, mask = min(parts.items(), key=lambda kv: kv[1].sum())
    r.example = f"{worst} is blank on {total - int(mask.sum()):,} {noun}"


def c_3_2(ctx: Context, chk: Check) -> Result:
    A = ctx.accounts
    if A is None:
        return _missing(chk, "accounts")
    parts = {
        "Industry": A["industry"].notna(),
        "Employee count": A["employees"].notna(),
        "Location (city/state/country)": A["state"].notna() | A["city"].notna() | A["country"].notna(),
        "Website": A["website"].notna(),
    }
    allf = pd.concat(parts.values(), axis=1).all(axis=1)
    r = Result(chk.id, value=pct(int(allf.sum()), len(A)))
    r.display = f"{fmt_pct(r.value)} of accounts have all four"
    r.notes.append("By field: " + ", ".join(f"{k} {pct(int(v.sum()), len(A)):.0f}%" for k, v in parts.items()))
    r.details["Core field fill (accounts)"] = _fill_table(
        [(k, int(v.sum()), round(pct(int(v.sum()), len(A)), 1)) for k, v in parts.items()])
    _gap_headline(r, parts, len(A), "companies", "an industry, size, location or website")
    r.flagged = {"accounts": _ids(A, ~allf)}
    return r


def c_3_3(ctx: Context, chk: Check) -> Result:
    fields = []
    if ctx.contacts is not None:
        fields += [("Contact mailing state", ctx.contacts["state"], N.canon_state),
                   ("Contact mailing country", ctx.contacts["country"], N.canon_country)]
    if ctx.accounts is not None:
        fields += [("Account billing state", ctx.accounts["state"], N.canon_state),
                   ("Account billing country", ctx.accounts["country"], N.canon_country),
                   ("Account industry", ctx.accounts["industry"], N.canon_text)]
    if not fields:
        return _missing(chk, "contacts or accounts")
    rows, total, off = [], 0, 0
    for label, s, canon in fields:
        vals = s.dropna()
        if vals.empty:
            continue
        total += len(vals)
        df = pd.DataFrame({"raw": vals, "key": vals.map(canon)}).dropna(subset=["key"])
        for key, grp in df.groupby("key"):
            vc = grp["raw"].value_counts()
            if len(vc) > 1:
                n_off = int(vc.iloc[1:].sum())
                off += n_off
                rows.append({"Field": label, "Most common spelling": vc.index[0],
                             "Variants found": ", ".join(f'"{v}" ({c})' for v, c in vc.iloc[1:].items()),
                             "Records using a variant": n_off})
    if not total:
        return Result(chk.id, display="State, country and industry are empty",
                      notes=["No values to compare; see 3.1/3.2 for fill rates."])
    r = Result(chk.id, value=pct(off, total))
    r.display = (f"{fmt_pct(r.value)} of values are non-standard spellings "
                 f"({off:,} records, {len(rows):,} values with variants)")
    if rows:
        r.notes.append("Variants usually mean free-text fields. " + tip("3.3", ctx.crm))
    r.details["Picklist variants"] = pd.DataFrame(
        rows, columns=["Field", "Most common spelling", "Variants found", "Records using a variant"]) \
        .sort_values("Records using a variant", ascending=False)
    if rows:
        r.headline = f"{off:,} records spell a state, country or industry differently from everyone else"
        top = max(rows, key=lambda x: x["Records using a variant"])
        r.example = f'"{top["Most common spelling"]}" is also written as {top["Variants found"]}'
    else:
        r.headline = "States, countries and industries are spelled consistently"
    return r


def c_3_4(ctx: Context, chk: Check) -> Result:
    C, t = ctx.contacts, ctx.t("contacts")
    if C is None:
        return _missing(chk, "contacts")
    preview = C["title"].map(N.seniority_from_title).value_counts(dropna=False).rename_axis("Seniority from title") \
        .reset_index(name="Contacts")
    preview["Seniority from title"] = preview["Seniority from title"].fillna("(no title)")
    if not t.has("seniority"):
        r = Result(chk.id, value=0.0, score=0, status="scored",
                   display="No seniority or persona field found")
        r.notes.append("No column like Seniority__c or Persona__c in the export. The preview sheet "
                       "shows what a title-based seniority field would look like.")
    else:
        col = t.mapping["seniority"]
        filled = int(t.text("seniority").notna().sum())
        r = Result(chk.id, value=pct(filled, len(C)))
        r.display = f"'{col}' is {fmt_pct(r.value)} filled"
    if t.has("seniority"):
        r.headline = f"Seniority is filled in on only {r.value:.0f}% of contacts" if r.value < 100 else \
            "Seniority is filled in on every contact"
    else:
        r.headline = "There's no seniority field, so there's no easy way to filter for decision-makers"
    r.details["Seniority preview"] = preview
    return r


def c_3_5(ctx: Context, chk: Check) -> Result:
    C = ctx.contacts
    if C is None:
        return _missing(chk, "contacts")
    patterns = C["phone"].map(N.phone_pattern)
    main_pattern = patterns.value_counts().index[0] if patterns.notna().any() else None
    issue_counts: dict[str, int] = {}
    issues_col = []
    for first, last, email, acct, pat in zip(C["first_name"], C["last_name"], C["email"],
                                             C["account"], patterns):
        issues = []
        for v in (first, last):
            if isinstance(v, str) and sum(ch.isalpha() for ch in v) >= 3:
                if v.isupper():
                    issues.append("ALL CAPS name")
                elif v.islower():
                    issues.append("lowercase name")
        local = email.split("@")[0] if isinstance(email, str) else None
        if any(N.is_junk(v) for v in (first, last, local, acct)) or \
                (isinstance(email, str) and N.email_domain(email) in {"test.com", "example.com", "asdf.com"}):
            issues.append("junk value")
        if isinstance(email, str) and not N.email_syntax_ok(email):
            issues.append("broken email")
        if isinstance(pat, str) and main_pattern is not None and pat != main_pattern:
            issues.append("phone not in main format")
        issues = list(dict.fromkeys(issues))
        for i in issues:
            issue_counts[i] = issue_counts.get(i, 0) + 1
        issues_col.append(", ".join(issues) or None)
    bad_mask = pd.Series([i is not None for i in issues_col], index=C.index)
    n = int(bad_mask.sum())
    r = Result(chk.id, value=pct(n, len(C)))
    r.display = f"{fmt_pct(r.value)} of contacts ({n:,}) have a formatting problem"
    if issue_counts:
        r.notes.append("By issue: " + ", ".join(f"{k} {v:,}" for k, v in
                                                sorted(issue_counts.items(), key=lambda kv: -kv[1])))
    if main_pattern:
        r.notes.append(f"Main phone format is {main_pattern.replace('9', '#')}.")
    out = C[bad_mask][["id", "first_name", "last_name", "email", "phone", "account"]].copy()
    out.insert(0, "Issues", [i for i in issues_col if i is not None])
    r.details["Formatting issues"] = _cap(out.rename(columns={
        "id": "Contact ID", "first_name": "First name", "last_name": "Last name", "email": "Email",
        "phone": "Phone", "account": "Account"}))
    r.extras = {"by_issue": issue_counts}
    # For tracing where bad data comes from, a phone in a different format alone isn't someone's fault
    entry_errors = pd.Series([i is not None and i != "phone not in main format" for i in issues_col], index=C.index)
    r.flagged = {"contacts": _ids(C, entry_errors)}
    r.headline = f"{n:,} contacts have formatting problems" + _freq(r.value, "contacts") if n else \
        "Names, emails and phone numbers are formatted consistently"
    if issue_counts:
        plain = {"phone not in main format": "phone numbers written in a different format from the rest",
                 "lowercase name": "names in all lowercase", "ALL CAPS name": "names in ALL CAPS",
                 "junk value": "junk entries like 'test' or 'asdf'", "broken email": "email addresses with typos"}
        r.example = ", ".join(f"{v:,} {plain.get(k, k)}" for k, v in
                              sorted(issue_counts.items(), key=lambda kv: -kv[1])[:3])
    return r


def c_3_6(ctx: Context, chk: Check) -> Result:
    rows = []
    for name, t in ctx.data.items():
        if name in ("users", "tasks", "contact_roles", "opportunity_history") or len(t) == 0:
            continue  # an empty file says nothing about which fields people use
        for c in t.raw.columns:
            if c.lower().endswith("__c"):
                filled = int(t.raw[c].notna().sum())
                rows.append({"Object": name.title(), "Field": c, "Records filled": filled,
                             "Fill rate": round(pct(filled, len(t)) or 0.0, 1)})
    if not rows:
        return Result(chk.id, display="No custom fields in export",
                      notes=["The exports have no __c columns. Export with all fields (Data Loader "
                             "'Select all fields' or Data Export) to measure this."])
    df = pd.DataFrame(rows).sort_values("Fill rate")
    unused = df[df["Fill rate"] < 5]
    r = Result(chk.id, value=float(len(unused)))
    r.display = f"{len(unused):,} of {len(df):,} custom fields are under 5% filled"
    r.details["Custom field usage"] = df
    r.headline = f"{len(unused):,} of {len(df):,} custom fields are almost never filled in"
    if len(unused):
        r.example = ", ".join(unused["Field"].head(4)) + (" and others" if len(unused) > 4 else "")
    return r


# -------------------------------------------- 4. Ownership, lifecycle, pipeline

def c_4_1(ctx: Context, chk: Check) -> Result:
    frames = []
    for label, df, t in (("Contact", ctx.contacts, ctx.t("contacts")),
                         ("Account", ctx.accounts, ctx.t("accounts"))):
        if df is None or not (t.has("owner_id") or t.has("owner_name")):
            continue
        st = ctx.owner_status(df["owner_id"], df["owner_name"])
        name = df["name"]
        frames.append(pd.DataFrame({"Object": label, "Record ID": df["id"], "Name": name,
                                    "Owner": df["owner"], "Problem": st}))
    if not frames:
        return Result(chk.id, display="No owner columns in export",
                      notes=["Add OwnerId to the contacts and accounts exports. (Owner columns that are empty in "
                             "every row count as missing.)"])
    allr = pd.concat(frames, ignore_index=True)
    bad = allr[allr["Problem"] != "ok"]
    r = Result(chk.id, value=pct(len(bad), len(allr)))
    by = bad["Problem"].value_counts()
    r.display = f"{fmt_pct(r.value)} ({len(bad):,} of {len(allr):,} contacts and accounts)"
    if len(by):
        r.notes.append("By problem: " + ", ".join(f"{k} {v:,}" for k, v in by.items()))
    if not ctx.users_loaded:
        r.notes.append("No users export, so only blank owners were counted. Add users.csv "
                       "(Id, Name, IsActive) to catch records owned by deactivated reps.")
    r.details["Orphaned records"] = _cap(bad)
    r.extras = {"count": len(bad)}
    if len(bad):
        r.headline = f"{len(bad):,} contacts and companies belong to former employees or to no one"
        gone = bad[bad["Problem"] == "inactive owner"]["Owner"].value_counts()
        if len(gone):
            r.example = f"{gone.index[0]} no longer works here but still owns {gone.iloc[0]:,} records"
    else:
        r.headline = "Every contact and company has a current owner"
    return r


def c_4_2(ctx: Context, chk: Check) -> Result:
    L = ctx.leads
    if L is None:
        return _missing(chk, "leads")
    if L["created"].isna().all():
        return Result(chk.id, display="No CreatedDate in leads export",
                      notes=["Add CreatedDate to the leads export."])
    start, end = ctx.audit_date - pd.Timedelta(days=90), ctx.audit_date - pd.Timedelta(hours=48)
    recent = L[(L["created"] >= start) & (L["created"] <= end)].copy()
    if recent.empty:
        return Result(chk.id, value=0.0, display="No leads created in the last 90 days")
    tasks = ctx.t("tasks")
    first_touch = None
    if tasks is not None and tasks.has("who_id") and tasks.has("created"):
        first = pd.DataFrame({"who": tasks.text("who_id"), "at": tasks.date("created")}) \
            .dropna().groupby("who")["at"].min()
        first_touch = recent["id"].map(first)
        worked = first_touch.notna() & (first_touch <= recent["created"] + pd.Timedelta(hours=48))
        method = "Measured from the first task logged on each lead."
    else:
        if recent["last_activity"].isna().all():
            return Result(chk.id, display="No activity dates in the leads export",
                          notes=["The leads export has no activity date and there's no activities export, so "
                                 "response time can't be measured. Add an activities/tasks export."])
        worked = recent["last_activity"].notna()
        method = ("No tasks export, so a lead counts as worked if it has any activity at all. The real "
                  "48-hour number is likely worse; add tasks.csv (WhoId, CreatedDate) for the exact figure.")
    worked = worked | recent["is_converted"]
    un = recent[~worked]
    r = Result(chk.id, value=pct(len(un), len(recent)))
    r.display = f"{fmt_pct(r.value)} ({len(un):,} of {len(recent):,} recent leads)"
    r.notes.append(method)
    cols = {"id": "Lead ID", "email": "Email", "status": "Status", "owner": "Owner", "created": "Created"}
    r.details["Unworked leads"] = _cap(un[list(cols)].rename(columns=cols))
    r.extras = {"unworked_count": len(un), "recent_leads": len(recent)}
    r.headline = (f"{len(un):,} of {len(recent):,} new leads from the last 90 days waited more than 2 days "
                  f"for a first contact, or never got one" + _freq(r.value, "leads")) if len(un) else \
        "Every new lead got a first contact within 2 days"
    never = int(first_touch[~worked].isna().sum()) if first_touch is not None else None
    if never:
        r.example = f"{never:,} of them have never been contacted at all"
    return r


def c_4_4(ctx: Context, chk: Check) -> Result:
    O, t = ctx.opps, ctx.t("opportunities")
    if O is None:
        return _missing(chk, "opportunities")
    won_amounts = O.loc[O["is_won"], "amount"].dropna()
    extras = {"avg_won_amount": float(won_amounts.mean()) if len(won_amounts) else None}
    op = O[~O["is_closed"]]
    if op.empty:
        return Result(chk.id, value=0.0, display="No open opportunities", extras=extras)
    past = op["close_date"] < ctx.audit_date.normalize()
    if t.has("last_activity"):
        quiet = op["last_activity"].isna() | (op["last_activity"] < ctx.audit_date - pd.Timedelta(days=30))
    else:
        quiet = pd.Series(False, index=op.index)
    stale = past | quiet
    amt_total = op["amount"].sum()
    amt_stale = float(op.loc[stale, "amount"].sum())
    if amt_total > 0:
        value, basis = 100 * amt_stale / amt_total, "of open pipeline value"
    else:
        value, basis = pct(int(stale.sum()), len(op)), "of open deals (no amounts in export)"
    r = Result(chk.id, value=value, extras=extras)
    r.display = (f"{fmt_pct(value)} {basis}: {int(stale.sum()):,} of {len(op):,} open deals, "
                 f"${amt_stale:,.0f}")
    if t.has("last_activity"):
        r.notes.append(f"{int(past.sum()):,} have a close date in the past; {int(quiet.sum()):,} have no "
                       "activity in 30+ days.")
    else:
        r.notes.append(f"{int(past.sum()):,} have a close date in the past. No LastActivityDate column (or it is "
                       "empty in every row), so quiet deals weren't counted.")
    extras.update(stale_amount=amt_stale, stale_count=int(stale.sum()))
    out = op[stale].copy()
    out["why"] = [", ".join(x for x, f in (("close date passed", p), ("no activity 30+ days", q)) if f)
                  for p, q in zip(past[stale], quiet[stale])]
    cols = {"id": "Opportunity ID", "name": "Opportunity", "account": "Account", "stage": "Stage",
            "amount": "Amount", "close_date": "Close date", "last_activity": "Last activity",
            "owner": "Owner", "why": "Why it's stale"}
    r.details["Stale open deals"] = _cap(out[list(cols)].rename(columns=cols).sort_values("Amount", ascending=False))
    if stale.any():
        r.headline = (f"{money(amt_stale)} of open deals ({value:.0f}% of the pipeline) are past their close "
                      "date or have gone quiet")
        big = out.sort_values("amount", ascending=False).iloc[0]
        cd = big["close_date"]
        when = f", close date {cd:%b} {cd.day}, {cd.year}" if pd.notna(cd) else ""
        r.example = f'"{big["name"]}" ({money(big["amount"]) if pd.notna(big["amount"]) else "no amount"}{when}): {big["why"]}'
    else:
        r.headline = "Every open deal is current and active"
    return r


def c_4_6(ctx: Context, chk: Check) -> Result:
    O, t = ctx.opps, ctx.t("opportunities")
    if O is None:
        return _missing(chk, "opportunities")
    has_acct = O["account_id"].notna() | O["account_name"].notna()
    roles = ctx.t("contact_roles")
    has_contact, note = None, None
    if roles is not None and roles.has("opportunity_id"):
        linked = set(roles.text("opportunity_id").dropna())
        has_contact = O["id"].isin(linked) | O["contact_id"].notna()
        note = "Contacts counted from Opportunity Contact Roles and the primary contact field."
    elif t.has("contact_id") or t.has("contact_name"):
        has_contact = O["contact_id"].notna() | O["contact_name"].notna()
        note = ("Contacts counted from the opportunity's primary contact field. Add "
                "opportunity_contact_roles.csv for a complete count.")
    if has_contact is None:
        ok = has_acct
        note = ("No contact information in the export, so only the account link was checked. Add "
                "opportunity_contact_roles.csv (OpportunityId, ContactId).")
    else:
        ok = has_acct & has_contact
    r = Result(chk.id, value=pct(int(ok.sum()), len(O)))
    r.display = f"{fmt_pct(r.value)} of {len(O):,} opportunities are fully linked"
    r.notes.append(note)
    out = O[~ok].copy()
    hc = has_contact if has_contact is not None else pd.Series(True, index=O.index)
    out["missing"] = [", ".join(x for x, f in (("account", not a), ("contact", not c)) if f)
                      for a, c in zip(has_acct[~ok], hc[~ok])]
    cols = {"id": "Opportunity ID", "name": "Opportunity", "account": "Account", "owner": "Owner",
            "missing": "Missing"}
    r.details["Unlinked deals"] = _cap(out[list(cols)].rename(columns=cols))
    n_bad = int((~ok).sum())
    r.headline = f"{n_bad:,} deals aren't linked to both a company and a contact" + _freq(pct(n_bad, len(O)), "deals") \
        if n_bad else "Every deal is linked to a company and a contact"
    return r


def c_4_7(ctx: Context, chk: Check) -> Result:
    O, t = ctx.opps, ctx.t("opportunities")
    if O is None:
        return _missing(chk, "opportunities")
    lost = O[O["is_closed"] & ~O["is_won"]]
    if not t.has("loss_reason"):
        return Result(chk.id, display="No loss-reason field found",
                      notes=["No column like Loss_Reason__c in the export. If the org has one, set it "
                             "under [columns.opportunities] loss_reason in audit.toml. If it has none, "
                             "score this 0 under [manual_scores]."])
    if lost.empty:
        return Result(chk.id, display="No closed-lost opportunities")
    filled = int(lost["loss_reason"].notna().sum())
    r = Result(chk.id, value=pct(filled, len(lost)))
    r.display = f"{fmt_pct(r.value)} of {len(lost):,} lost deals have a reason ('{t.mapping['loss_reason']}')"
    vc = lost["loss_reason"].value_counts()
    if len(vc):
        r.notes.append("Top reasons: " + ", ".join(f"{k} ({v})" for k, v in vc.head(5).items()))
        r.example = f'When a reason is given, the most common is "{vc.index[0]}"'
    r.headline = f"{len(lost) - filled:,} of {len(lost):,} lost deals have no reason recorded"
    return r


# --------------------------------------------- 5. Lists, imports, integrations

def c_5_2(ctx: Context, chk: Check) -> Result:
    C, t = ctx.contacts, ctx.t("contacts")
    if C is None:
        return _missing(chk, "contacts")
    if not t.has("lead_source"):
        L, tl = ctx.leads, ctx.t("leads")
        if L is not None and tl is not None and tl.has("lead_source"):
            # Dynamics keeps the source on the lead, not the contact
            filled = int(L["lead_source"].notna().sum())
            r = Result(chk.id, value=pct(filled, len(L)))
            r.display = f"{fmt_pct(r.value)} of leads have a lead source"
            r.notes.append("Contacts have no lead source field in this CRM, so leads were measured instead.")
            miss = len(L) - filled
            r.headline = (f"{miss:,} leads have no record of where they came from" + _freq(pct(miss, len(L)), "leads")
                          if miss else "Every lead has a lead source")
            return r
        if ctx.crm == "hubspot":
            return Result(chk.id, display="No 'Lead source' property in export",
                          notes=["HubSpot fills in Original Source by itself (imports are all 'Offline Sources'), so "
                                 "it can't show whether reps record where a lead came from. " + tip("5.2", ctx.crm)])
        return Result(chk.id, display="No LeadSource column in export",
                      notes=["Add LeadSource to the contacts export (or set the field under "
                             "[columns.contacts] lead_source)."])
    filled = int(C["lead_source"].notna().sum())
    r = Result(chk.id, value=pct(filled, len(C)))
    r.display = f"{fmt_pct(r.value)} of contacts have a lead source"
    vc = C["lead_source"].value_counts()
    if len(vc):
        r.notes.append("Sources: " + ", ".join(f"{k} ({v:,})" for k, v in vc.head(8).items()))
    miss = len(C) - filled
    r.flagged = {"contacts": _ids(C, C["lead_source"].isna())}
    r.headline = f"{miss:,} contacts have no record of where they came from" + _freq(pct(miss, len(C)), "contacts") \
        if miss else "Every contact has a lead source"
    return r


AUTO = {
    "1.1": c_1_1, "1.2": c_1_2, "1.3": c_1_3, "1.4": c_1_4,
    "2.4": c_2_4, "2.5": c_2_5,
    "3.1": c_3_1, "3.2": c_3_2, "3.3": c_3_3, "3.4": c_3_4, "3.5": c_3_5, "3.6": c_3_6,
    "4.1": c_4_1, "4.2": c_4_2, "4.4": c_4_4, "4.6": c_4_6, "4.7": c_4_7,
    "5.2": c_5_2,
}

from .checks_extra import EXTRA_AUTO  # noqa: E402  (new checks live in their own module)

AUTO.update(EXTRA_AUTO)


def _unit(chk, v):
    if chk.unit == "%":
        return f"{v:g}%"
    return f"{v:g} {chk.unit}"


def run_checks(data: dict[str, Table], cfg: dict):
    ctx = Context(data, cfg)
    measured = {str(k): v for k, v in cfg.get("measured", {}).items()}
    manual = {str(k): v for k, v in cfg.get("manual_scores", {}).items()}
    results: dict[str, Result] = {}
    from .crms import NOT_APPLICABLE
    na = NOT_APPLICABLE.get(ctx.crm, {})
    for chk in CHECKS:
        if chk.id in na and not (chk.id == "4.8" and ctx.t("opportunity_history") is not None):
            results[chk.id] = Result(chk.id, status="not applicable", source="automated",
                                     display="Not applicable to this CRM", headline="Doesn't apply to this CRM",
                                     notes=[na[chk.id]])
            continue
        if chk.mode == "auto":
            try:
                r = AUTO[chk.id](ctx, chk)
            except Exception as e:  # one bad column shouldn't sink the whole audit
                r = Result(chk.id, status="error", display="Check failed",
                           notes=[f"{type(e).__name__}: {e}"])
            if r.value is not None and r.score is None:
                r.score = score_value(chk.rule, r.value)
            if r.score is not None:
                r.status = "scored"
        elif chk.mode == "measured":
            v = measured.get(chk.id)
            if v is None:
                r = Result(chk.id, status="needs input", source="entered", display="Needs your input")
            else:
                try:
                    num = float(v)
                except (TypeError, ValueError):
                    raise ValueError(f'[measured] "{chk.id}" = {v!r} isn\'t a number. Enter it as a plain number '
                                     f"({chk.unit}), like 3.5.") from None
                r = Result(chk.id, value=num, source="entered", display=f"{_unit(chk, num)} (entered)")
                r.score, r.status = score_value(chk.rule, num), "scored"
        else:
            r = Result(chk.id, status="needs input", source="auditor", display="Needs your input")
        for tbl in ctx.empty_tables:  # say "no records" rather than "needs an export" for empty files
            if r.display == f"Needs {tbl} export":
                r.display = f"No {tbl} in the export"
                r.notes = [f"The {tbl} file was found but has no records, so this wasn't measured."]
        ov = manual.get(chk.id)
        if ov is not None:
            if ov not in (0, 1, 2):
                r.notes.append(f"Ignored manual score {ov!r}: use 0, 1 or 2.")
            else:
                if chk.mode != "manual" and r.score is not None:
                    r.notes.append(f"Score set by auditor in audit.toml (the measured score was {r.score}).")
                if chk.mode == "manual":
                    r.display = {2: "Healthy", 1: "Needs attention", 0: "Critical"}[ov] + " (auditor)"
                r.score, r.status, r.source = int(ov), "scored", ("auditor" if chk.mode == "manual" else r.source)
        if not r.headline:
            if chk.mode == "measured" and r.value is not None:
                r.headline = MEASURED_HEADLINE[chk.id].format(v=r.value)
            elif r.score is not None:
                r.headline = {2: "In place and working", 1: "Partly in place",
                              0: "Not in place, or nobody could say"}[r.score]
            elif r.status == "error":
                r.headline = "This check couldn't run on the export (see the detail workbook)"
            elif r.status == "needs input":
                r.headline = "Not checked yet"
            else:
                r.headline = r.display
        results[chk.id] = r
    return ctx, results
