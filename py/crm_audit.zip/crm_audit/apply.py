"""apply-review: turns the client's reviewed Cleanup_review.xlsx into a small "ready to load" folder.

  python -m crm_audit apply-review <reviewed workbook> [--out <folder>] [--fresh <folder of new exports>]

Nothing here touches the CRM. Only rows the client approved are used; blank decisions are left alone.
The returned workbook is checked against the kit's own record of what it proposed (manifest.py): rows that
were altered, are not in that record, or hold a formula are skipped.
The folder holds:
  1_update_<object>.csv      one row per record, one column per field changed (blank = no change)
  1_undo_<object>.csv        the same rows with the old values, in case anything looks wrong
  1_undo_clear_*.csv         fields that were empty before (a blank cell can't restore them)
  2_clear_<object>_<field>.csv   values to empty
  3_merge_*.csv, 3_convert_leads.csv, 3_delete.csv   hands-on lists (approved rows only)
  4_reps/<rep>.csv, 4_enrich_*.csv   hand-offs
  5_held_back.csv            (with --fresh) approved changes whose CRM value moved since the audit
  CHECKLIST.txt              one page, four phases
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import re
import textwrap
from pathlib import Path

from . import manifest as M
from .cleanup import HOW, KIT_VERSION, _long_path
from .crms import NAMES
from .plain import nice_date

YES = {"yes", "y", "true", "1", "approve", "approved", "ok"}
NO = {"no", "n", "false", "0", "decline", "declined", "reject"}
OBJECT_KEY = {"contact": "contacts", "account": "accounts", "company": "accounts", "opportunity": "opportunities",
              "deal": "opportunities", "lead": "leads"}
ORDER = ["contacts", "accounts", "opportunities", "leads"]
# Ask-for wording in each CRM's own how-to text ("{obj}s" in HubSpot's text needs "Companie" for companies)
HOW_OBJ = {"salesforce": {"contacts": "Contact", "accounts": "Account", "opportunities": "Opportunity", "leads": "Lead"},
           "hubspot": {"contacts": "Contact", "accounts": "Companie", "opportunities": "Deal"},
           "dynamics": {"contacts": "Contact", "accounts": "Account", "opportunities": "Opportunity", "leads": "Lead"},
           "bullhorn": {"contacts": "Contact", "accounts": "Company", "opportunities": "Opportunity", "leads": "Lead"}}


# Where each update file goes, one line per file; the shared notes are printed once
UPDATE_WHERE = {
    "salesforce": lambda o: f"Data Loader > Update > {o}",
    "hubspot": lambda o: f"Import > One object > {o}s",
    "dynamics": lambda o: f"your Excel export of {o}s > Import from Excel",
    # Custom Import only takes contacts and leads; companies and opportunities are updated another way
    "bullhorn": lambda o: (f"Menu > Tools > Custom Import > {o}s" if o in ("Contact", "Lead") else
                           f"{'Companies' if o == 'Company' else o + 's'} can't use Custom Import: update by hand, or ask Bullhorn Support or a "
                           "data-loader partner"),
}
UPDATE_NOTE = {
    "salesforce": "Map Id and each column (Auto-Match). Check the error file after each load.",
    "hubspot": "Choose 'Update existing records', matched on Record ID; headers are your property names, blanks are skipped.",
    "dynamics": "Paste the new values on the rows with the same hidden '(Do Not Modify)' ID; leave hidden columns alone.",
    "bullhorn": "Custom Import: 'Create new records and update existing ones', up to 1,000 rows a batch. Headers are "
                "Bullhorn API field names. How existing rows are matched, and whether blank cells overwrite values, "
                "isn't documented: load 5 rows and check them before the full batch. The owner column is for "
                "reference: change owners from a list view (500 at a time).",
}


class ApplyError(ValueError):
    """A problem the person can fix; the message is plain English."""


# ------------------------------------------------------------------ reading the workbook

_s = M.norm   # a cell as clean text (Excel turns IDs such as 5001 into numbers; they come back as text)


def _v(v) -> str:
    """A value column (Current value, New value): text is kept exactly as stored."""
    return v if isinstance(v, str) else _s(v)


def _decision(v, where: str, warnings: list):
    """True = Yes, False = No, None = left blank (or not understood)."""
    t = _s(v).lower()
    if not t:
        return None
    if t in YES:
        return True
    if t in NO:
        return False
    warnings.append(f"{where}: Approve says \"{_s(v)}\", which isn't Yes or No, so it was left alone.")
    return None


def _table(ws) -> list[dict]:
    """The sheet's rows as dicts. "_row" is the Excel row number; "_formulas" names the columns whose cell
    holds a real formula (text that merely starts with "=" is a text cell and is not a formula)."""
    rows = ws.iter_rows()
    try:
        header = [_s(c.value) for c in next(rows)]
    except StopIteration:
        return []
    out = []
    for n, row in enumerate(rows, 2):
        if all(c.value is None or _s(c.value) == "" for c in row):
            continue
        d = {h: row[i].value if i < len(row) else None for i, h in enumerate(header) if h}
        d["_row"] = n
        d["_formulas"] = {h for i, h in enumerate(header) if h and i < len(row) and row[i].data_type == "f"}
        out.append(d)
    return out


def _need(rows: list[dict], sheet: str, *cols):
    if rows:
        for c in cols:
            if c not in rows[0]:
                raise ApplyError(f"The '{sheet}' tab is missing its '{c}' column. Ask for the original file again, "
                                 "or re-run the audit to make a new one.")


def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(name)).strip("_") or "x"


def file_object(crm: str, key: str) -> str:
    """The object's name as used in the output file names."""
    names = {"contacts": "contacts", "accounts": "companies" if crm in ("hubspot", "bullhorn") else "accounts",
             "opportunities": "deals" if crm == "hubspot" else "opportunities", "deals": "deals", "leads": "leads"}
    return names[key]


def _write_csv(path: Path, header: list, rows: list):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


# ------------------------------------------------------------------ what may change, and what is checked
# Every column that reaches an output file is either an editable (yellow) cell that apply validates, or a locked
# column that is compared with the kit's manifest. tests/test_audit.py walks these tables.
EDITABLE_COLUMNS = {
    "Field fixes": ["Approve", "New value"],            # New value: any non-empty text
    "Values to clear": ["Approve"],
    "Owners": ["Approve", "New owner"],                 # a label from the Lists sheet
    "Merges": ["Approve", "Keep ID"],                   # one of the group's own ids
    "Leads to convert": ["Approve"],
    "Delete": ["Approve"],
}
CHECKED_COLUMNS = {
    "Field fixes": ["Object", "Record ID", "Field", "Current value", "Kind", "Merge key"],
    "Values to clear": ["Object", "Record ID", "Field", "Current value"],
    "Owners": ["Object", "Record ID", "Current owner", "Current owner ID"],
    "Merges": ["Object", "Merge IDs"],
    "Leads to convert": ["Lead ID", "Lead name", "Lead email", "Existing contact ID", "Existing contact",
                         "Existing account ID"],
    "Delete": ["Object", "Record ID", "Name", "Email", "Why"],
    "Rep to-do": None,                                  # None: the whole sheet is hashed
    "Enrich": None,
}
# every column the code reads on a decision sheet: a missing or renamed header is a plain-English error
REQUIRED_COLUMNS = {name: sorted(set(EDITABLE_COLUMNS[name]) | set(cols) | ({"Merge key"} if name == "Merges" else {"Change ID"}))
                    for name, cols in CHECKED_COLUMNS.items() if cols is not None}
REQUIRED_COLUMNS["_groups"] = ["Merge key", "Object", "ID", "Name", "Suggested keep", "Same person", "Fill values"]

# columns that are shown to the client but never reach an output file
UNUSED_COLUMNS = {
    "Field fixes": ["Name", "Why", "Change ID"],
    "Values to clear": ["Name", "Why", "Change ID"],
    "Owners": ["Name", "Problem", "Change ID"],
    "Merges": ["Keep name", "Merge names", "Why this one is kept", "Check first", "Merge key"],
    "Leads to convert": ["Change ID"],
    "Delete": ["Change ID"],
}


# ------------------------------------------------------------------ the integrity record

def _load_manifest(wb, info, xlsx: Path, client: str, audit_date: str) -> dict:
    """The kit's manifest from the workbook's hidden sheet, checked against the side-car file if there is one."""
    chunks = []
    if "_manifest" in wb.sheetnames:
        rows = [r for r in wb["_manifest"].iter_rows(values_only=True) if r and r[0] is not None]
        try:
            rows.sort(key=lambda r: int(float(_s(r[0]))))
        except ValueError:
            rows = []
        chunks = [_s(r[1]) for r in rows]
    missing = ApplyError("This review workbook has no integrity record (its hidden \"_manifest\" sheet is missing "
                         "or damaged), so I can't check that it matches the audit. Use the original "
                         "Cleanup_review.xlsx made by the audit, and don't copy it into another program.")
    if not chunks or M.digest(chunks) != _s(info.get("manifest_sha")):
        raise missing
    try:
        man = M.unpack(chunks)
    except Exception as e:
        raise missing from e
    if _s(man.get("kit_id")) != _s(info.get("kit_id")) or not isinstance(man.get("entries"), dict):
        raise missing
    slug = _safe(client)
    names = [xlsx.with_name(xlsx.stem + ".manifest.json"),
             xlsx.parent.with_name(xlsx.parent.name + ".manifest.json"),
             xlsx.parent / f"{slug}_cleanup_{audit_date}.manifest.json",
             xlsx.parent.parent / f"{slug}_cleanup_{audit_date}.manifest.json"]
    for side in dict.fromkeys(names):
        if not side.is_file():
            continue
        try:
            other = json.loads(side.read_text(encoding="utf-8"))
            same_kit = _s(other.get("kit_id")) == _s(man["kit_id"])
        except (ValueError, AttributeError, OSError):
            other, same_kit = None, False
        if not same_kit:
            raise ApplyError(f"This workbook doesn't belong to the kit saved in \"{side.name}\" (the kit ids don't "
                             "match). Use the Cleanup_review.xlsx from that kit, or move the other manifest file away.")
        if M.canonical(other) != M.canonical(man):
            raise ApplyError(f"The workbook's hidden record doesn't match \"{side.name}\", so the workbook may have "
                             "been altered. Ask for a clean copy of Cleanup_review.xlsx.")
        break
    return man


# ------------------------------------------------------------------ the freshness check

class _Fresh:
    """Today's values from a new set of exports, to compare with the values at the time of the audit.
    Anything that can't be looked up is reported as "unverifiable" with a reason: it is held back, never passed."""
    OBJECTS = {"contacts": "contacts", "accounts": "accounts", "deals": "opportunities", "opportunities": "opportunities",
               "leads": "leads"}

    def __init__(self, folder, crm):
        from .cleanup import API, BULLHORN_API
        from .config import load_config
        from .loader import load_folder
        folder = Path(folder)
        cfgp = folder / "audit.toml"
        try:
            self.data = load_folder(folder, load_config(cfgp if cfgp.exists() else None))
        except FileNotFoundError as e:
            raise ApplyError(f"I couldn't read the new exports in {folder}: {e}") from e
        self.crm, self.api = crm, {"salesforce": API, "bullhorn": BULLHORN_API}.get(crm)
        self.idx: dict = {}

    def _column(self, t, obj, field, owner):
        if owner:
            for logical in (("owner_id", "owner_name") if self.crm == "salesforce" else ("owner_name", "owner_id")):
                if t.has(logical):
                    return t.mapping[logical]
            return None
        if self.api is not None:
            for logical, name in self.api.get(obj, {}).items():
                if name == field and t.has(logical):
                    return t.mapping[logical]
            return None
        return field if field in t.raw.columns else None

    def _row(self, obj, rid):
        """('ok', table, row position) | ('missing', ...) | ('unverifiable', reason)"""
        obj = self.OBJECTS.get(obj, obj)
        t = self.data.get(obj)
        if t is None:
            return "unverifiable", f"{obj} missing from the new export"
        if not t.has("id"):
            return "unverifiable", f"the ID column of {obj} missing from the new export"
        if obj not in self.idx:
            self.idx[obj] = {}
            for i, v in enumerate(t.text("id")):
                self.idx[obj].setdefault(_s(v), i)
        i = self.idx[obj].get(_s(rid))
        if i is None:
            return "missing", "record not in the new export"
        if t.has("is_deleted") and bool(t.flag("is_deleted").iloc[i]):
            return "missing", "record is deleted in the new export"
        return "ok", (t, i)

    def value(self, obj, rid, field, owner=False):
        """('ok', text) | ('missing', why) | ('unverifiable', why)"""
        st, got = self._row(obj, rid)
        if st != "ok":
            return st, got
        t, i = got
        col = self._column(t, self.OBJECTS.get(obj, obj), field, owner)
        if col is None:
            return "unverifiable", f"{field} missing from the new {self.OBJECTS.get(obj, obj)} export"
        return "ok", _s(t.raw[col].iloc[i])

    def exists(self, obj, rid):
        st, got = self._row(obj, rid)
        return (st, got if st != "ok" else "")

    def lead_state(self, rid):
        """('ok', 'open'|'converted') | ('missing', why) | ('unverifiable', why)"""
        st, got = self._row("leads", rid)
        if st != "ok":
            return st, got
        t, i = got
        if not t.has("is_converted"):
            return "unverifiable", "the converted flag of leads missing from the new export"
        return "ok", "converted" if bool(t.flag("is_converted").iloc[i]) else "open"

    def person(self, rid):
        """('ok', 'name|email' text) for a contact, or why not."""
        st, got = self._row("contacts", rid)
        if st != "ok":
            return st, got
        t, i = got
        if not (t.has("email") and (t.has("first_name") or t.has("last_name"))):
            return "unverifiable", "name or email of contacts missing from the new export"
        f = t.text("first_name").iloc[i] if t.has("first_name") else None
        l = t.text("last_name").iloc[i] if t.has("last_name") else None
        name = f"{_s(f)} {_s(l)}".strip()
        return "ok", f"{name}|{_s(t.text('email').iloc[i])}"


# ------------------------------------------------------------------ apply

def _age_days(audit_date: str, today=None):
    try:
        return ((today or dt.date.today()) - dt.date.fromisoformat(audit_date)).days
    except ValueError:
        return None


def approval_lines(sm: dict) -> list[str]:
    """The "What will change" block shown before anything is loaded (printed, in CHECKLIST.txt, and in the app)."""
    w = sm["will_change"]
    lines = ["WHAT WILL CHANGE (approved rows only)",
             f"  {w['format']:,} format fixes (capitalisation, phone and email format, spelling)",
             f"  {w['fills']:,} values copied onto the record being kept, before merges",
             f"  {w['cleared']:,} fields cleared",
             f"  {w['owners']:,} owner changes",
             f"  {w['merges']:,} merges",
             f"  {w['conversions']:,} lead conversions",
             f"  {w['deletions']:,} deletions"]
    left = [f"{k} {v['undecided']:,}" for k, v in sm["sheets"].items() if v["undecided"]]
    lines.append("Left undecided (not applied): " + (", ".join(left) if left else "nothing"))
    if sm["different_keep"]:
        n = sm["different_keep"]
        lines.append(f"{n:,} merge{'s' if n != 1 else ''} use a different record to keep than proposed: check its blank "
                     "fields by hand before merging (no values were copied automatically)")
    if sm["dup_tasks_left_out"]:
        n = sm["dup_tasks_left_out"]
        lines.append(f"{n:,} duplicate-deal task{'s' if n != 1 else ''} left out of the rep files because their merge "
                     "wasn't approved")
    extra = []
    if sm["owner_blank"]:
        extra.append(f"{sm['owner_blank']:,} owners chosen but Approve is blank (not applied)")
    if sm["waiting"]:
        extra.append(f"{sm['waiting']:,} fill-before-merge values waiting for an approved merge")
    if sm["held_back"]:
        why = ", ".join(f"{c:,} {r}" for r, c in sm["held_reasons"].items())
        extra.append(f"{sm['held_back']:,} held back by --fresh ({why}); see 5_held_back.csv")
    if sm["skipped"]:
        extra.append(f"{sm['skipped']:,} row{'s' if sm['skipped'] != 1 else ''} skipped (see Heads up)")
    if extra:
        lines.append("Also: " + "; ".join(extra))
    return lines


def apply_review(xlsx, out=None, fresh=None, today=None) -> dict:
    import openpyxl
    xlsx = Path(xlsx)
    if not xlsx.exists():
        raise ApplyError(f"I couldn't find {xlsx}.")
    try:
        wb = openpyxl.load_workbook(xlsx, data_only=False)   # formulas must be seen, not their results
    except Exception as e:  # not a workbook, damaged, or an old .xls
        raise ApplyError("That file couldn't be opened as an Excel workbook. Send back the .xlsx file "
                         "(Cleanup_review.xlsx), saved as an Excel Workbook.") from e
    if "_kit" not in wb.sheetnames:
        raise ApplyError("This doesn't look like a Uroboric review workbook: its hidden \"_kit\" sheet is missing. "
                         "Use the Cleanup_review.xlsx made by the audit (not a copy exported to CSV or another program).")
    info = {_s(r[0]): r[1] for r in wb["_kit"].iter_rows(values_only=True) if r and r[0] is not None}
    try:
        version = int(float(_s(info.get("kit_version"))))
    except ValueError:
        version = None
    if version != KIT_VERSION:
        raise ApplyError(f"This review workbook is version {version or 'unknown'}, which this program can't read "
                         f"(it reads version {KIT_VERSION}). Re-run the audit to make a new workbook.")
    crm = _s(info.get("crm"))
    if crm not in HOW:
        raise ApplyError("The review workbook doesn't say which CRM it is for. Re-run the audit to make a new one.")
    client, audit_date = _s(info.get("client")) or "client", _s(info.get("audit_date"))
    manifest = _load_manifest(wb, info, xlsx, client, audit_date)
    ENT = manifest["entries"]
    if (_s(manifest.get("crm")), _s(manifest.get("client")) or "client", _s(manifest.get("audit_date"))) != \
            (crm, client, audit_date):
        raise ApplyError("The workbook's hidden settings (CRM, client or audit date) don't match the kit's record, so "
                         "it may have been altered. Ask for a clean copy of Cleanup_review.xlsx.")
    meta = manifest.get("meta") or {}   # id / owner column headers come from the manifest, not the hidden sheet
    how = HOW[crm]
    warnings: list[str] = []
    stats = {}
    counts = {"formula": 0, "tampered": 0, "ignored": 0, "owner_blank": 0, "different_keep": 0, "table": 0}
    age = _age_days(audit_date, today)
    if age is not None and age > 7:
        warnings.append(f"This review is {age} days old (audit date {audit_date}). The CRM may have changed since: "
                        "run apply-review again with --fresh <folder of new exports> to hold back anything that has.")

    def stat(sheet):
        return stats.setdefault(sheet, {"approved": 0, "declined": 0, "undecided": 0, "skipped": 0, "waiting": 0})

    def sheet(name):
        rows = _table(wb[name]) if name in wb.sheetnames else []
        if name in REQUIRED_COLUMNS:
            _need(rows, name, *REQUIRED_COLUMNS[name])
        return rows

    seen: set = set()

    def usable(name, r, key, pairs=()):
        """False (with a warning) if the row has a formula, isn't in the manifest, or had a locked column changed.
        Returns the manifest entry for a good row."""
        st = stat(name)
        if r["_formulas"]:
            warnings.append(f"Row {r['_row']} on '{name}' contains a formula and was skipped.")
            st["skipped"] += 1
            counts["formula"] += 1
            return None
        ent = ENT.get(key)
        if ent is None or ent.get("s") != name:
            warnings.append(f"Row {r['_row']} on '{name}' isn't part of the original review, so it was ignored.")
            st["skipped"] += 1
            counts["ignored"] += 1
            return None
        for label, fld, actual in pairs:
            want = ent.get("x", {}).get(fld[2:], "") if fld.startswith("x:") else ent.get(fld, "")
            if want != actual:
                warnings.append(f"Row {r['_row']} was changed in a way that isn't allowed ({label} edited) and was "
                                f"skipped (sheet '{name}').")
                st["skipped"] += 1
                counts["tampered"] += 1
                return None
        if (name, key) in seen:
            warnings.append(f"Row {r['_row']} on '{name}' repeats a change already listed, so the repeat was ignored.")
            st["skipped"] += 1
            counts["ignored"] += 1
            return None
        seen.add((name, key))
        return ent

    def table_ok(name, rows):
        """Rep to-do and Enrich have no editable cells: the whole sheet must match what the kit wrote."""
        if not rows:
            return True
        want = manifest.get("tables", {}).get(name)
        cols = [c for c in rows[0] if c not in ("_row", "_formulas")]
        got = M.table_hash(cols, [[_s(r.get(c)) for c in cols] for r in rows])
        if want != got or any(r["_formulas"] for r in rows):
            warnings.append(f"The '{name}' sheet was changed after the kit was made, so its files were not written.")
            counts["table"] += 1
            return False
        return True

    def locked(r):
        return [("Object", "o", _s(r.get("Object"))), ("Record ID", "r", _s(r.get("Record ID"))),
                ("Field", "f", _s(r.get("Field"))), ("Current value", "c", M.h(r.get("Current value")))]

    # people who can take ownership: label -> (label, id), from the manifest only. The hidden Lists sheet only feeds
    # the dropdown; sorting or pasting in it changes nothing here.
    users, ambiguous = {}, set()
    for label, uid in manifest.get("users") or []:
        k = re.sub(r"\s+", " ", _s(label)).lower()
        if k in users and users[k][1] != _s(uid):
            ambiguous.add(k)
        users[k] = (_s(label), _s(uid) or _s(label))

    def excel_text(n, what):
        warnings.append("Row {n}: Excel changed the {what} into a number or date. Type it again starting with an apostrophe (') so it stays as text, or leave the suggested value.".format(n=n, what=what))
    # duplicate groups
    groups: dict = {}
    for r in sheet("_groups"):
        g = groups.setdefault(_s(r["Merge key"]), {"object": _s(r["Object"]), "ids": [], "names": {}, "keep": "",
                                                    "same": {}, "fill": {}})
        i = _s(r["ID"])
        g["ids"].append(i)
        g["names"][i] = _s(r["Name"])
        g["same"][i] = _s(r["Same person"]) == "Yes"
        g["fill"][i] = json.loads(_s(r["Fill values"]) or "{}")
        if _s(r["Suggested keep"]) == "Yes":
            g["keep"] = i

    fixes: dict = {}   # (object, id, field) -> change
    pending: dict = {}  # merge key -> fill-before-merge rows waiting for their merge to be approved

    def add(fix, where):
        key = (fix["obj"], fix["id"], fix["field"])
        if key in fixes:
            warnings.append(f"{where}: {fix['field']} on record {fix['id']} was already being changed "
                            "(two rows for the same field), so the first change was kept.")
            return False
        fixes[key] = fix
        return True

    # ---- Field fixes (formatting is pre-approved; fill-before-merge values follow their merge)
    rows = sheet("Field fixes")
    _need(rows, "Field fixes", "Approve", "Record ID", "Field", "New value")
    for r in rows:
        st, where = stat("Field fixes"), f"Field fixes row {r['_row']}"
        if r["_formulas"]:
            usable("Field fixes", r, "")
            continue
        yes = _decision(r["Approve"], where, warnings)
        ent = ENT.get(_s(r.get("Change ID")))
        follows_merge = (yes is None and not _s(r["Approve"]) and ent is not None and ent.get("k") == "fill"
                         and ent.get("m"))
        if yes is None and not follows_merge:
            st["undecided"] += 1
            continue
        if yes is False:
            st["declined"] += 1
            continue
        ent = usable("Field fixes", r, _s(r.get("Change ID")),
                     locked(r) + [("Kind", "k", _s(r.get("Kind"))), ("Merge key", "m", _s(r.get("Merge key")))])
        if ent is None:
            continue
        obj = OBJECT_KEY.get(_s(r.get("Object")).lower())
        if obj is None:
            warnings.append(f"{where}: I don't know what \"{_s(r.get('Object'))}\" is, so the row was skipped.")
            st["skipped"] += 1
            continue
        nv = r["New value"]
        if not _s(nv):
            warnings.append(f"Row {r['_row']}: the new value was emptied, so the fix was skipped. "
                            "To clear a value, approve it on 'Values to clear'.")
            st["skipped"] += 1
            continue
        if not isinstance(nv, str):
            if M.h(nv) != ent["p"]:   # Excel turned typed or pasted text into a number, date or true/false
                excel_text(r["_row"], "new value")
                st["skipped"] += 1
                continue
            nv = _s(nv)               # the proposed value itself, re-typed by Excel on open
        fix = {"obj": obj, "id": _s(r["Record ID"]), "field": _s(r["Field"]), "cur": _v(r.get("Current value")),
               "new": nv, "kind": ent["k"], "sheet": "Field fixes", "mkey": ent.get("m", ""),
               "donor": ((ent["d"], ent["dv"]) if ent.get("d") else None)}
        if fix["kind"] == "fill" and ent.get("m"):
            pending.setdefault(ent["m"], []).append((fix, where))
        elif add(fix, where):
            st["approved"] += 1
        else:
            st["skipped"] += 1

    # ---- Values to clear (nothing is cleared unless the client said Yes)
    for r in sheet("Values to clear"):
        st, where = stat("Values to clear"), f"Values to clear row {r['_row']}"
        if r["_formulas"]:
            usable("Values to clear", r, "")
            continue
        yes = _decision(r["Approve"], where, warnings)
        if yes is None:
            st["undecided"] += 1
            continue
        if not yes:
            st["declined"] += 1
            continue
        ent = usable("Values to clear", r, _s(r.get("Change ID")), locked(r))
        if ent is None:
            continue
        obj = OBJECT_KEY.get(_s(r.get("Object")).lower())
        if obj is None:
            warnings.append(f"{where}: I don't know what \"{_s(r.get('Object'))}\" is, so the row was skipped.")
            st["skipped"] += 1
            continue
        fix = {"obj": obj, "id": _s(r["Record ID"]), "field": _s(r["Field"]), "cur": _v(r.get("Current value")),
               "new": "", "kind": "clear", "sheet": "Values to clear"}
        if add(fix, where):
            st["approved"] += 1
        else:
            st["skipped"] += 1

    # ---- Merges (and the fill-before-merge values that go with an approved one)
    merges = []
    for r in sheet("Merges"):
        st, where = stat("Merges"), f"Merges row {r['_row']}"
        if r["_formulas"]:
            usable("Merges", r, "")
            continue
        yes = _decision(r["Approve"], where, warnings)
        if yes is None:
            st["undecided"] += 1
            continue
        if not yes:
            st["declined"] += 1
            continue
        g = groups.get(_s(r.get("Merge key")))
        keep = _s(r.get("Keep ID"))
        if g is None:
            warnings.append(f"{where}: this merge group isn't in the workbook's records, so it was skipped.")
            st["skipped"] += 1
            continue
        rk = r.get("Keep ID")
        if rk is not None and not isinstance(rk, str) and not (
                isinstance(rk, (int, float)) and not isinstance(rk, bool) and keep in g["ids"]):
            excel_text(r["_row"], "Keep ID")
            st["skipped"] += 1
            continue
        ent = usable("Merges", r, _s(r.get("Merge key")),
                     [("Object", "o", _s(r.get("Object"))), ("Merge IDs", "p", M.h(r.get("Merge IDs"))),
                      ("hidden group list", "c", M.group_hash(g["ids"], g["names"], g["same"], g["fill"], g["keep"]))])
        if ent is None:
            continue
        if keep not in g["ids"]:
            warnings.append(f"{where}: Keep ID \"{keep}\" isn't one of the records in this group "
                            f"({', '.join(g['ids'])}), so the merge was NOT applied. Pick one of those IDs.")
            st["skipped"] += 1
            continue
        st["approved"] += 1
        others = [i for i in g["ids"] if i != keep]
        merges.append({"object": g["object"], "keep": keep, "merge": others,
                       "keep_name": g["names"][keep], "merge_names": [g["names"][i] for i in others]})
        obj = {"contacts": "contacts", "accounts": "accounts"}.get(g["object"])
        mkey = _s(r["Merge key"])
        merges[-1]["key"] = mkey
        if keep == g["keep"]:
            for fix, w in pending.pop(mkey, []):
                if add(fix, w):
                    stat("Field fixes")["approved"] += 1
        else:
            # the client chose another record to keep: nothing is copied automatically (the proposed fills were
            # worked out for the proposed record, and the client may have declined some of them)
            pending.pop(mkey, None)
            counts["different_keep"] += 1
            merges[-1]["different_keep"] = True
    for mkey, items in pending.items():  # fills whose merge wasn't approved: held back
        stat("Field fixes")["waiting"] += len(items)

    # ---- Owners: a suggested owner is only a suggestion; applying one needs an explicit Yes
    for r in sheet("Owners"):
        st, where = stat("Owners"), f"Owners row {r['_row']}"
        if r["_formulas"]:
            usable("Owners", r, "")
            continue
        yes = _decision(r["Approve"], where, warnings)
        who = re.sub(r"\s+", " ", _s(r.get("New owner")))
        if yes is None:
            ent = ENT.get(_s(r.get("Change ID")))
            if who and not _s(r.get("Approve")) and ent is not None and ent.get("p") != M.h(who):
                counts["owner_blank"] += 1   # a New owner the client chose (not the kit's own suggestion), Approve blank
            st["undecided"] += 1
            continue
        if not yes:
            st["declined"] += 1
            continue
        if not who:
            warnings.append(f"{where}: Approve is Yes but no New owner was chosen, so it was left alone.")
            st["undecided"] += 1
            continue
        if not isinstance(r.get("New owner"), str):
            excel_text(r["_row"], "new owner")
            st["skipped"] += 1
            continue
        ent = usable("Owners", r, _s(r.get("Change ID")),
                     [("Object", "o", _s(r.get("Object"))), ("Record ID", "r", _s(r.get("Record ID"))),
                      ("Current owner", "c", M.h(f"{_s(r.get('Current owner ID'))}|{_s(r.get('Current owner'))}"))])
        if ent is None:
            continue
        obj = OBJECT_KEY.get(_s(r.get("Object")).lower())
        cols = meta.get(obj or "", {})
        if not cols.get("owner") or not cols.get("id"):
            warnings.append(f"{where}: this CRM export has no owner column for {_s(r.get('Object'))} records, so it was skipped.")
            st["skipped"] += 1
            continue
        if users:
            if who.lower() in ambiguous:
                warnings.append(f"{where}: \"{who}\" is listed for two different people, so it was skipped.")
                st["skipped"] += 1
                continue
            if who.lower() not in users:
                warnings.append(f"{where}: \"{who}\" isn't in the list of active users, so it was skipped. "
                                "Pick a name from the dropdown.")
                st["skipped"] += 1
                continue
            name, uid = users[who.lower()]
        else:
            if crm == "salesforce":
                warnings.append(f"{where}: no list of users came with this workbook, so the owner can't be matched to an ID.")
                st["skipped"] += 1
                continue
            name = uid = who
        cur = _s(r.get("Current owner ID")) if crm == "salesforce" else _s(r.get("Current owner"))
        fix = {"obj": obj, "id": _s(r["Record ID"]), "field": cols["owner"], "cur": cur,
               "new": uid if crm == "salesforce" else name, "kind": "owner", "sheet": "Owners"}
        if add(fix, where):
            st["approved"] += 1
        else:
            st["skipped"] += 1
    if counts["owner_blank"]:
        warnings.append(f"New owner chosen but Approve is blank on {counts['owner_blank']:,} "
                        f"record{'s' if counts['owner_blank'] != 1 else ''}: they were NOT applied. "
                        "Set Approve to Yes on the rows you want.")

    # ---- the simple approve/decline lists
    def approved_rows(name, label_cols, pairs):
        keep = []
        for r in sheet(name):
            st = stat(name)
            if r["_formulas"]:
                usable(name, r, "")
                continue
            yes = _decision(r["Approve"], f"{name} row {r['_row']}", warnings)
            if yes is None:
                st["undecided"] += 1
            elif not yes:
                st["declined"] += 1
            elif usable(name, r, _s(r.get("Change ID")), pairs(r)) is not None:
                st["approved"] += 1
                keep.append([_v(r.get(c)) for c in label_cols])
        return keep

    convert = approved_rows("Leads to convert", ["Lead ID", "Lead name", "Lead email", "Existing contact ID",
                                                 "Existing contact", "Existing account ID"],
                            lambda r: [("Lead ID", "r", _s(r.get("Lead ID"))),
                                       ("Existing contact ID", "c", M.h(r.get("Existing contact ID")))]
                            + [(c, "x:" + c, M.h(r.get(c))) for c in
                               ("Lead name", "Lead email", "Existing contact", "Existing account ID")])
    delete = approved_rows("Delete", ["Object", "Record ID", "Name", "Email", "Why"],
                           lambda r: [("Object", "o", _s(r.get("Object"))), ("Record ID", "r", _s(r.get("Record ID"))),
                                      ("Name or Email", "c", M.h(f"{_s(r.get('Name'))}|{_s(r.get('Email'))}")),
                                      ("Why", "x:Why", M.h(r.get("Why")))])

    # ---- freshness (--fresh): hold back anything that can't be shown to still match the CRM
    held: list = []
    held_reasons: dict = {}
    held_fill_keys: set = set()

    def hold(obj, rid, field, was, now, proposed, sheet_name, reason):
        held.append([obj, rid, field, was, now, proposed, sheet_name, reason])
        key = "couldn't be checked" if reason.startswith("couldn't be checked") else reason.split(":")[0]
        held_reasons[key] = held_reasons.get(key, 0) + 1
        st = stat(sheet_name)
        st["approved"] = max(0, st["approved"] - 1)
        st["skipped"] += 1

    if fresh is not None:
        fr = _Fresh(fresh, crm)

        def verdict(res):
            """None if fine, else the reason text."""
            if res[0] == "unverifiable":
                return f"couldn't be checked: {res[1]}"
            if res[0] == "missing":
                return res[1]
            return None

        for key, f in list(fixes.items()):
            res = fr.value(f["obj"], f["id"], f["field"], owner=f["kind"] == "owner")
            why = verdict(res)
            if why is None and res[1] != _s(f["cur"]):
                why = "value changed in the CRM since the audit"
            if why is None and f.get("donor"):
                did, dhash = f["donor"]
                dres = fr.value(f["obj"], did, f["field"])
                dwhy = verdict(dres)
                if dwhy is None and M.h(dres[1]) != dhash:
                    dwhy = "the value copied from the duplicate changed in the CRM"
                elif dwhy is not None:
                    dwhy = "donor record: " + dwhy
                why = dwhy
            if why is not None:
                hold(f["obj"], f["id"], f["field"], f["cur"], res[1] if res[0] == "ok" else "", f["new"], f["sheet"], why)
                del fixes[key]
                if f["kind"] == "fill" and f.get("mkey"):
                    held_fill_keys.add(f["mkey"])
        for m in list(merges):
            problem = None
            if m.get("key") in held_fill_keys:
                problem = "a value to keep changed since the audit: review this merge again"
            for rid in ([] if problem else [m["keep"]] + m["merge"]):
                res = fr.exists(m["object"], rid)
                problem = verdict(res)
                if problem:
                    problem = f"merge member {rid}: {problem}"
                    break
            if problem:
                hold(m["object"], m["keep"], "merge", "", "", ";".join(m["merge"]), "Merges", problem)
                merges.remove(m)
                for key, f in list(fixes.items()):   # the values copied for that merge go with it
                    if f.get("mkey") == m.get("key"):
                        del fixes[key]
        keep_rows = []
        for row in convert:
            lead, contact = row[0], row[3]
            problem = verdict(fr.lead_state(lead))
            if problem is None:
                state = fr.lead_state(lead)[1]
                problem = "lead is already converted" if state == "converted" else None
            if problem is None:
                problem = verdict(fr.exists("contacts", contact))
                problem = f"existing contact {contact}: {problem}" if problem else None
            if problem:
                hold("Lead", lead, "convert", "", "", contact, "Leads to convert", problem)
            else:
                keep_rows.append(row)
        convert = keep_rows
        keep_rows = []
        for row in delete:
            obj, rid, name, email = row[0], row[1], row[2], row[3]
            if _s(obj).lower() == "contact":
                res = fr.person(rid)
                problem = verdict(res)
                if problem is None and res[1] != f"{_s(name)}|{_s(email)}":
                    problem = "name or email changed in the CRM since the audit"
            else:
                problem = verdict(fr.exists(OBJECT_KEY.get(_s(obj).lower(), "accounts"), rid))
            if problem:
                hold(obj, rid, "delete", f"{name}|{email}", "", "", "Delete", problem)
            else:
                keep_rows.append(row)
        delete = keep_rows
        if held:
            warnings.append(f"{len(held):,} approved row{'s' if len(held) != 1 else ''} held back by --fresh "
                            "(changed in the CRM since the audit, or couldn't be checked): see 5_held_back.csv.")

    # ---- write the folder
    slug = _safe(client)
    folder = Path(out) if out else xlsx.resolve().parent / f"{slug}_ready_to_load_{audit_date}"
    shown, folder = folder, _long_path(folder)
    _clean_folder(folder)
    folder.mkdir(parents=True, exist_ok=True)
    files: list[dict] = []   # {"name", "rows", "kind"}

    def out_csv(name, header, rows, kind):
        _write_csv(folder / name, header, rows)
        files.append({"name": name, "rows": len(rows), "kind": kind})

    will = {"format": 0, "fills": 0, "cleared": 0, "owners": 0, "merges": len(merges),
            "conversions": len(convert), "deletions": len(delete)}
    by_obj: dict = {}
    for f in fixes.values():
        by_obj.setdefault(f["obj"], []).append(f)
    for obj in [o for o in ORDER if o in by_obj] + [o for o in by_obj if o not in ORDER]:
        idh = meta.get(obj, {}).get("id") or "Record ID"
        fo = file_object(crm, obj)
        recs: dict = {}  # id -> {field: fix}
        for f in by_obj[obj]:
            recs.setdefault(f["id"], {})[f["field"]] = f
        for rid in list(recs):   # a change to the value it already has is dropped
            for fld in list(recs[rid]):
                if recs[rid][fld]["new"] == recs[rid][fld]["cur"]:
                    del recs[rid][fld]
            if not recs[rid]:
                del recs[rid]
        for r in recs.values():
            for f in r.values():
                if f["new"] == "":
                    will["cleared"] += 1
                elif f["kind"] == "owner":
                    will["owners"] += 1
                elif f["kind"] == "fill":
                    will["fills"] += 1
                else:
                    will["format"] += 1
        all_fields = list(dict.fromkeys(h for r in recs.values() for h in r))
        upd_fields = [h for h in all_fields if any(h in r and r[h]["new"] != "" for r in recs.values())]
        rows = [[rid] + [r[h]["new"] if h in r and r[h]["new"] != "" else "" for h in upd_fields]
                for rid, r in recs.items() if any(h in r and r[h]["new"] != "" for h in upd_fields)]
        if rows:
            out_csv(f"1_update_{fo}.csv", [idh] + upd_fields, rows, "update")
        undo = [[rid] + [r[h]["cur"] if h in r else "" for h in all_fields] for rid, r in recs.items()]
        undo = [row for row in undo if any(row[1:])]
        if undo:
            out_csv(f"1_undo_{fo}.csv", [idh] + all_fields, undo, "undo")
        for h in all_fields:  # fields that were empty can only be put back by clearing them
            ids = [rid for rid, r in recs.items() if h in r and r[h]["cur"] == "" and r[h]["new"] != ""]
            if ids:
                out_csv(f"1_undo_clear_{fo}_{_safe(h)}.csv", [idh, h], [[i, ""] for i in ids], "undo_clear")
        for h in all_fields:
            ids = [rid for rid, r in recs.items() if h in r and r[h]["new"] == "" and r[h]["cur"] != ""]
            if ids:
                out_csv(f"2_clear_{fo}_{_safe(h)}.csv", [idh, h], [[i, ""] for i in ids], "clear")

    for key in ("contacts", "accounts", "deals"):
        ms = [m for m in merges if m["object"] == key]
        if ms:
            out_csv(f"3_merge_{file_object(crm, key)}.csv", ["Keep ID", "Merge IDs", "Keep name", "Merge names"],
                    [[m["keep"], ";".join(m["merge"]), m["keep_name"], "; ".join(m["merge_names"])] for m in ms], "merge")
    if convert:
        out_csv("3_convert_leads.csv", ["Lead ID", "Lead name", "Lead email", "Existing contact ID",
                                        "Existing contact", "Existing account ID"], convert, "convert")
    if delete:
        out_csv("3_delete.csv", ["Object", "Record ID", "Name", "Email", "Why"], delete, "delete")
    if held:
        out_csv("5_held_back.csv", ["Object", "Record ID", "Field", "Value at audit", "Value now", "Proposed value",
                                    "Sheet", "Reason"], held, "held")

    reps = sheet("Rep to-do")
    if not table_ok("Rep to-do", reps):
        reps = []
    rep_files = {}
    left_out = 0
    if reps:
        cols = [c for c in reps[0] if c not in ("_row", "_formulas", "Merge key", "Conditional task")]
        by_rep: dict = {}
        approved_deal_merges = {m["key"]: m for m in merges
                                if m["object"] == "deals" and not m.get("different_keep") and m.get("key")}
        for r in reps:
            vals = {c: _v(r.get(c)) for c in cols}
            cond = _s(r.get("Conditional task"))
            if cond:   # "close this duplicate deal" only goes to the rep if its merge is approved and still valid
                m = approved_deal_merges.get(_s(r.get("Merge key")))
                if not (m and _s(r.get("Deal ID")) in m["merge"]):
                    left_out += 1
                    vals["To do"] = "; ".join(x for x in _s(r.get("To do")).split("; ") if x and x != cond)
                    if not vals["To do"]:
                        continue
            by_rep.setdefault(_s(r.get("Rep")) or "(no owner)", []).append([vals[c] for c in cols])
        used = set()
        for rep, rows in by_rep.items():
            base, n = _safe(rep), 2
            name = base
            while name.lower() in used:
                name, n = f"{base}_{n}", n + 1
            used.add(name.lower())
            _write_csv(folder / "4_reps" / f"{name}.csv", cols, rows)
            rep_files[rep] = len(rows)
            files.append({"name": f"4_reps/{name}.csv", "rows": len(rows), "kind": "rep"})
    enrich = sheet("Enrich")
    if not table_ok("Enrich", enrich):
        enrich = []
    if enrich:
        spec = {"Contact": ("contacts", ["Id", "FirstName", "LastName", "Email", "Company", "Company domain", "Needs"]),
                "Account": ("accounts", ["Id", "Name", "Website", "Needs"])}
        for label, (key, cols) in spec.items():
            rows = [[_v(r.get(c)) for c in cols] for r in enrich if _s(r.get("Object")) == label]
            if rows:
                out_csv(f"4_enrich_{file_object(crm, key)}.csv", cols, rows, "enrich")

    totals = {k: sum(s[k] for s in stats.values()) for k in ("approved", "declined", "undecided", "skipped", "waiting")}
    summary = {"folder": str(shown), "client": client, "crm": crm, "audit_date": audit_date, **totals,
               "sheets": stats, "files": [f["name"] for f in files] + ["CHECKLIST.txt"], "warnings": warnings,
               "records_updated": {o: len({f["id"] for f in fs}) for o, fs in by_obj.items()},
               "reps": rep_files, "will_change": will, "owner_blank": counts["owner_blank"],
               "formula_skipped": counts["formula"], "tampered": counts["tampered"], "ignored": counts["ignored"],
               "held_back": len(held), "held_reasons": held_reasons, "different_keep": counts["different_keep"], "dup_tasks_left_out": left_out,
               "age_days": age, "kit_id": _s(manifest.get("kit_id"))}
    summary["approval"] = approval_lines(summary)
    (folder / "CHECKLIST.txt").write_text(_checklist(summary, files, info, how, crm), encoding="utf-8")
    return summary


def _clean_folder(folder: Path):
    """Re-running on the same workbook replaces the earlier output; anything else in the folder is left alone."""
    import shutil
    if not folder.exists():
        return
    for p in folder.iterdir():
        if p.is_file() and (re.match(r"[1-5]_", p.name) or p.name == "CHECKLIST.txt"):
            p.unlink()
        elif p.is_dir() and p.name == "4_reps":
            shutil.rmtree(p)


# ------------------------------------------------------------------ the checklist

def _wrap(text: str, indent=6) -> list[str]:
    pad = " " * indent
    return textwrap.wrap(text, width=78, initial_indent=pad, subsequent_indent=pad) if text else []


def _item(text: str) -> list[str]:
    return textwrap.wrap(text, width=78, initial_indent="  [ ] ", subsequent_indent="      ")


def _checklist(sm, files, info, how, crm) -> str:
    by_kind: dict = {}
    for f in files:
        by_kind.setdefault(f["kind"], []).append(f)

    def names(kind):
        return ", ".join(f["name"] for f in by_kind.get(kind, []))

    def count(kind):
        return sum(f["rows"] for f in by_kind.get(kind, []))

    head = f"UROBORIC READY-TO-LOAD CHECKLIST  -  {sm['client']}  -  {nice_date(dt.date.fromisoformat(sm['audit_date'])) if sm['audit_date'] else ''}"
    white = _s(info.get("white_label"))
    if white:
        head = head.replace("UROBORIC READY-TO-LOAD", "READY-TO-LOAD", 1)
    out = [head, "=" * 78]
    if _s(info.get("prepared_by")):
        out.append(f"Prepared by {_s(info['prepared_by'])}")
    if _s(info.get("contact")):
        out.append(f"Questions? {_s(info['contact'])}")
    out += [""] + sm["approval"] + [""]
    out.append(f"Reviewed: {sm['approved']:,} approved, {sm['declined']:,} declined, {sm['undecided']:,} left undecided "
               f"(not applied)" + (f", {sm['skipped']:,} skipped (see below)" if sm["skipped"] else "") + ".")
    if sm["undecided"]:
        out.append("Ask the client if the undecided items should be done.")
    if sm["age_days"] is not None and sm["age_days"] > 7:
        out += _wrap(f"! This review is {sm['age_days']} days old. Re-run apply-review with --fresh <folder of new "
                     "exports> so anything changed in the CRM since the audit is held back (5_held_back.csv).", 2)
    for w in sm["warnings"][:6]:
        out += _wrap("! " + w, 2)
    if len(sm["warnings"]) > 6:
        out.append(f"  ! ...and {len(sm['warnings']) - 6} more (shown when you ran apply-review).")

    out += ["", "PHASE 1 - BACK UP"] + _item(how["backup"])

    out += ["", "PHASE 2 - LOAD THE UPDATE FILES"]
    ups = by_kind.get("update", [])
    if ups:
        for f in ups:
            key = next((o for o in ORDER if f["name"] == f"1_update_{file_object(crm, o)}.csv"), "contacts")
            out += _item(f"{f['name']} ({f['rows']:,}) -> {UPDATE_WHERE[crm](HOW_OBJ[crm].get(key, 'Contact'))}")
        out += _wrap(UPDATE_NOTE[crm])
        if crm == "salesforce":
            out += _wrap("Leave 'Insert null values' OFF for these files: blank cells mean no change.")
        out += _wrap("If anything looks wrong, load the matching 1_undo file: "
                     + names("undo") + ".")
        if by_kind.get("undo_clear"):
            out += _wrap(f"{len(by_kind['undo_clear'])} undo file(s) named 1_undo_clear_* put back fields that were "
                         "empty before; load them (as in phase 3, clearing) only if you need to undo.")
    else:
        out.append("  Nothing to load.")
    out += _wrap("Don't open the load files in Excel and re-save them; load them as they are.", 2)

    if by_kind.get("held"):
        out += _item(f"Held back: 5_held_back.csv ({count('held'):,} rows) changed in the CRM since the audit. "
                     "Check them with the client; they are not in the files above.")
    out += ["", "PHASE 3 - HANDS-ON IN THE CRM"]
    any3 = False
    if by_kind.get("clear"):
        any3 = True
        out += _item(f"Clear made-up values: {len(by_kind['clear'])} file(s), {count('clear'):,} records "
                     "(2_clear_*.csv)")
        out += _wrap(how["clear"])
    if by_kind.get("merge"):
        any3 = True
        out += _item(f"Merge duplicates: {names('merge')} ({count('merge'):,} groups)")
        n = sm["will_change"]["fills"]
        if n and not (sm["held_back"] or sm["different_keep"] or sm["skipped"] or sm["waiting"]):
            tail = f" The update files already carry over {n:,} detail{'s' if n != 1 else ''} worth keeping."
        elif n:
            tail = (f" The update files carry over {n:,} detail{'s' if n != 1 else ''}; other blank fields on the kept "
                    "record were not copied (declined, skipped, held back or not proposed): check them by hand before merging.")
        else:
            tail = " No details were copied into the kept record automatically: check its blank fields by hand before merging."
        out += _wrap(how["merge"] + tail)
    if by_kind.get("convert"):
        any3 = True
        out += _item(f"Convert leads: 3_convert_leads.csv ({count('convert'):,})")
        out += _wrap(how["convert"])
    if by_kind.get("delete"):
        any3 = True
        out += _item(f"Delete test/junk records: 3_delete.csv ({count('delete'):,})")
        out += _wrap(how["delete"])
    if not any3:
        out.append("  Nothing to do by hand.")

    out += ["", "PHASE 4 - HAND OFF"]
    any4 = False
    if by_kind.get("rep"):
        any4 = True
        out += _item("These are suggestions for each rep to review, not approved changes. "
                     f"Give each rep their file in 4_reps/ ({len(by_kind['rep'])} rep file{'s' if len(by_kind['rep']) != 1 else ''}, {count('rep'):,} deals); "
                     "go through them in the next pipeline meeting.")
    if by_kind.get("enrich"):
        any4 = True
        out += _item(f"Enrichment lists: {names('enrich')} ({count('enrich'):,} records). Send to a data "
                     "provider ONLY with the client's written approval.")
    if not any4:
        out.append("  Nothing to hand off.")
    from .versions import stamp
    out += ["", stamp(bool(white))]
    return "\n".join(out) + "\n"
