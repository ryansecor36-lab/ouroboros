"""apply-review: turns the client's reviewed Cleanup_review.xlsx into a small "ready to load" folder.

  python -m crm_audit apply-review <reviewed workbook> [--out <folder>]

Nothing here touches the CRM. Only rows the client approved are used; blank decisions are left alone.
The folder holds:
  1_update_<object>.csv      one row per record, one column per field changed (blank = no change)
  1_undo_<object>.csv        the same rows with the old values, in case anything looks wrong
  1_undo_clear_*.csv         fields that were empty before (a blank cell can't restore them)
  2_clear_<object>_<field>.csv   values to empty
  3_merge_*.csv, 3_convert_leads.csv, 3_delete.csv   hands-on lists (approved rows only)
  4_reps/<rep>.csv, 4_enrich_*.csv   hand-offs
  CHECKLIST.txt              one page, four phases
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import re
import textwrap
from pathlib import Path

from .cleanup import HOW, KIT_VERSION, _long_path
from .crms import NAMES
from .plain import nice_date

YES = {"yes", "y", "true", "1", "approve", "approved", "ok"}
NO = {"no", "n", "false", "0", "decline", "declined", "reject"}
OBJECT_KEY = {"contact": "contacts", "account": "accounts", "company": "accounts", "opportunity": "opportunities",
              "deal": "opportunities", "lead": "leads"}
ORDER = ["contacts", "accounts", "opportunities", "leads"]
# Ask-for wording in each CRM's own how-to text ("{obj}s" in HubSpot's text needs "Companie" for companies)
HOW_OBJ = {"salesforce": {"contacts": "Contact", "accounts": "Account", "opportunities": "Opportunity", "leads": "Lead"},
           "hubspot": {"contacts": "Contact", "accounts": "Companie", "opportunities": "Deal"},
           "dynamics": {"contacts": "Contact", "accounts": "Account", "opportunities": "Opportunity", "leads": "Lead"},
           "bullhorn": {"contacts": "Contact", "accounts": "Company", "opportunities": "Opportunity", "leads": "Lead"}}


# Where each update file goes, one line per file; the shared notes are printed once
UPDATE_WHERE = {
    "salesforce": lambda o: f"Data Loader > Update > {o}",
    "hubspot": lambda o: f"Import > One object > {o}s",
    "dynamics": lambda o: f"your Excel export of {o}s > Import from Excel",
    # Custom Import only takes contacts and leads; companies and opportunities are updated another way
    "bullhorn": lambda o: (f"Menu > Tools > Custom Import > {o}s" if o in ("Contact", "Lead") else
                           f"{'Companies' if o == 'Company' else o + 's'} can't use Custom Import: update by hand, or ask Bullhorn Support or a "
                           "data-loader partner"),
}
UPDATE_NOTE = {
    "salesforce": "Map Id and each column (Auto-Match). Check the error file after each load.",
    "hubspot": "Choose 'Update existing records', matched on Record ID; headers are your property names, blanks are skipped.",
    "dynamics": "Paste the new values on the rows with the same hidden '(Do Not Modify)' ID; leave hidden columns alone.",
    "bullhorn": "Custom Import: 'Create new records and update existing ones', up to 1,000 rows a batch. Headers are "
                "Bullhorn API field names. How existing rows are matched, and whether blank cells overwrite values, "
                "isn't documented: load 5 rows and check them before the full batch. The owner column is for "
                "reference: change owners from a list view (500 at a time).",
}


class ApplyError(ValueError):
    """A problem the person can fix; the message is plain English."""


# ------------------------------------------------------------------ reading the workbook

def _s(v) -> str:
    """A cell as clean text. Excel turns IDs such as 0031234 or 5001 into numbers; they come back as text."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "Yes" if v else "No"
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, dt.date):
        return v.isoformat()
    return re.sub(r"[ \t\r\n]+$", "", str(v)).lstrip()


def _decision(v, where: str, warnings: list):
    """True = Yes, False = No, None = left blank (or not understood)."""
    t = _s(v).lower()
    if not t:
        return None
    if t in YES:
        return True
    if t in NO:
        return False
    warnings.append(f"{where}: Approve says \"{_s(v)}\", which isn't Yes or No, so it was left alone.")
    return None


def _table(ws) -> list[dict]:
    rows = ws.iter_rows(values_only=True)
    try:
        header = [_s(c) for c in next(rows)]
    except StopIteration:
        return []
    out = []
    for n, row in enumerate(rows, 2):
        if all(c is None or _s(c) == "" for c in row):
            continue
        d = {h: row[i] if i < len(row) else None for i, h in enumerate(header) if h}
        d["_row"] = n
        out.append(d)
    return out


def _need(rows: list[dict], sheet: str, *cols):
    if rows:
        for c in cols:
            if c not in rows[0]:
                raise ApplyError(f"The \"{sheet}\" sheet is missing its \"{c}\" column. "
                                 "Use the original Cleanup_review.xlsx and don't delete or rename columns.")


def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(name)).strip("_") or "x"


def file_object(crm: str, key: str) -> str:
    """The object's name as used in the output file names."""
    names = {"contacts": "contacts", "accounts": "companies" if crm in ("hubspot", "bullhorn") else "accounts",
             "opportunities": "deals" if crm == "hubspot" else "opportunities", "deals": "deals", "leads": "leads"}
    return names[key]


def _write_csv(path: Path, header: list, rows: list):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


# ------------------------------------------------------------------ apply

def apply_review(xlsx, out=None) -> dict:
    import openpyxl
    xlsx = Path(xlsx)
    if not xlsx.exists():
        raise ApplyError(f"I couldn't find {xlsx}.")
    try:
        wb = openpyxl.load_workbook(xlsx, data_only=True)
    except Exception as e:  # not a workbook, damaged, or an old .xls
        raise ApplyError("That file couldn't be opened as an Excel workbook. Send back the .xlsx file "
                         "(Cleanup_review.xlsx), saved as an Excel Workbook.") from e
    if "_kit" not in wb.sheetnames:
        raise ApplyError("This doesn't look like a Uroboric review workbook: its hidden \"_kit\" sheet is missing. "
                         "Use the Cleanup_review.xlsx made by the audit (not a copy exported to CSV or another program).")
    info = {_s(r[0]): r[1] for r in wb["_kit"].iter_rows(values_only=True) if r and r[0] is not None}
    try:
        version = int(float(_s(info.get("kit_version"))))
    except ValueError:
        version = None
    if version != KIT_VERSION:
        raise ApplyError(f"This review workbook is version {version or 'unknown'}, which this program can't read "
                         f"(it reads version {KIT_VERSION}). Re-run the audit to make a new workbook.")
    crm = _s(info.get("crm"))
    if crm not in HOW:
        raise ApplyError("The review workbook doesn't say which CRM it is for. Re-run the audit to make a new one.")
    client, audit_date = _s(info.get("client")) or "client", _s(info.get("audit_date"))
    meta = json.loads(_s(info.get("meta")) or "{}")
    how = HOW[crm]
    warnings: list[str] = []
    stats = {}

    def stat(sheet):
        return stats.setdefault(sheet, {"approved": 0, "declined": 0, "undecided": 0, "skipped": 0, "waiting": 0})

    def sheet(name):
        return _table(wb[name]) if name in wb.sheetnames else []

    # people who can take ownership: name -> (name, id)
    users = {}
    if "Lists" in wb.sheetnames:
        for r in _table(wb["Lists"]):
            if _s(r.get("Name")):
                users[re.sub(r"\s+", " ", _s(r["Name"])).lower()] = (_s(r["Name"]), _s(r.get("ID")) or _s(r["Name"]))
    # duplicate groups
    groups: dict = {}
    for r in sheet("_groups"):
        g = groups.setdefault(_s(r["Merge key"]), {"object": _s(r["Object"]), "ids": [], "names": {}, "keep": "",
                                                    "same": {}, "fill": {}})
        i = _s(r["ID"])
        g["ids"].append(i)
        g["names"][i] = _s(r["Name"])
        g["same"][i] = _s(r["Same person"]) == "Yes"
        g["fill"][i] = json.loads(_s(r["Fill values"]) or "{}")
        if _s(r["Suggested keep"]) == "Yes":
            g["keep"] = i

    fixes: dict = {}   # (object, id, field) -> change
    pending: dict = {}  # merge key -> fill-before-merge rows waiting for their merge to be approved

    def add(fix, where):
        key = (fix["obj"], fix["id"], fix["field"])
        if key in fixes:
            warnings.append(f"{where}: {fix['field']} on record {fix['id']} was already being changed "
                            "(two rows for the same field), so the first change was kept.")
            return False
        fixes[key] = fix
        return True

    # ---- Field fixes
    rows = sheet("Field fixes")
    _need(rows, "Field fixes", "Approve", "Record ID", "Field", "New value")
    for r in rows:
        st, where = stat("Field fixes"), f"Field fixes row {r['_row']}"
        yes = _decision(r["Approve"], where, warnings)
        if yes is None:
            st["undecided"] += 1
            continue
        if not yes:
            st["declined"] += 1
            continue
        obj = OBJECT_KEY.get(_s(r.get("Object")).lower())
        if obj is None:
            warnings.append(f"{where}: I don't know what \"{_s(r.get('Object'))}\" is, so the row was skipped.")
            st["skipped"] += 1
            continue
        fix = {"obj": obj, "id": _s(r["Record ID"]), "field": _s(r["Field"]), "cur": _s(r.get("Current value")),
               "new": _s(r["New value"]), "kind": _s(r.get("Kind"))}
        if fix["kind"] == "fill" and _s(r.get("Merge key")):
            pending.setdefault(_s(r["Merge key"]), []).append((fix, where))
        elif add(fix, where):
            st["approved"] += 1
        else:
            st["skipped"] += 1

    # ---- Merges (and the fill-before-merge values that go with an approved one)
    merges = []
    for r in sheet("Merges"):
        st, where = stat("Merges"), f"Merges row {r['_row']}"
        yes = _decision(r["Approve"], where, warnings)
        if yes is None:
            st["undecided"] += 1
            continue
        if not yes:
            st["declined"] += 1
            continue
        g = groups.get(_s(r.get("Merge key")))
        keep = _s(r.get("Keep ID"))
        if g is None:
            warnings.append(f"{where}: this merge group isn't in the workbook's records, so it was skipped.")
            st["skipped"] += 1
            continue
        if keep not in g["ids"]:
            warnings.append(f"{where}: Keep ID \"{keep}\" isn't one of the records in this group "
                            f"({', '.join(g['ids'])}), so the merge was NOT applied. Pick one of those IDs.")
            st["skipped"] += 1
            continue
        st["approved"] += 1
        others = [i for i in g["ids"] if i != keep]
        merges.append({"object": g["object"], "keep": keep, "merge": others,
                       "keep_name": g["names"][keep], "merge_names": [g["names"][i] for i in others]})
        obj = {"contacts": "contacts", "accounts": "accounts"}.get(g["object"])
        mkey = _s(r["Merge key"])
        if keep == g["keep"]:
            for fix, w in pending.pop(mkey, []):
                if add(fix, w):
                    stat("Field fixes")["approved"] += 1
        elif obj:
            n = len(pending.pop(mkey, []))
            filled = 0
            blanks = g["fill"].get(keep, {})
            for h in dict.fromkeys(h for i in g["ids"] for h in g["fill"].get(i, {})):
                if h in blanks:
                    continue
                donor = next((g["fill"][i][h] for i in g["ids"] if i != keep and g["same"].get(i) and h in g["fill"][i]), None)
                if donor is not None and add({"obj": obj, "id": keep, "field": h, "cur": "", "new": donor,
                                              "kind": "fill"}, where):
                    filled += 1
            if n:
                warnings.append(f"{where}: you chose a different record to keep, so the \"fill before merge\" values "
                                f"were worked out again for it ({filled} field{'s' if filled != 1 else ''}).")
    for mkey, items in pending.items():  # fills whose merge wasn't approved: held back
        stat("Field fixes")["waiting"] += len(items)

    # ---- Owners
    for r in sheet("Owners"):
        st, where = stat("Owners"), f"Owners row {r['_row']}"
        yes = _decision(r["Approve"], where, warnings)
        who = re.sub(r"\s+", " ", _s(r.get("New owner")))
        if yes is None and who and not _s(r.get("Approve")):
            yes = True   # picking a new owner is the decision
        if yes is None:
            st["undecided"] += 1
            continue
        if not yes:
            st["declined"] += 1
            continue
        if not who:
            warnings.append(f"{where}: Approve is Yes but no New owner was chosen, so it was left alone.")
            st["undecided"] += 1
            continue
        obj = OBJECT_KEY.get(_s(r.get("Object")).lower())
        cols = meta.get(obj or "", {})
        if not cols.get("owner") or not cols.get("id"):
            warnings.append(f"{where}: this CRM export has no owner column for {_s(r.get('Object'))} records, so it was skipped.")
            st["skipped"] += 1
            continue
        if users:
            if who.lower() not in users:
                warnings.append(f"{where}: \"{who}\" isn't in the list of active users, so it was skipped. "
                                "Pick a name from the dropdown.")
                st["skipped"] += 1
                continue
            name, uid = users[who.lower()]
        else:
            if crm == "salesforce":
                warnings.append(f"{where}: no list of users came with this workbook, so the owner can't be matched to an ID.")
                st["skipped"] += 1
                continue
            name = uid = who
        cur = _s(r.get("Current owner ID")) if crm == "salesforce" else _s(r.get("Current owner"))
        fix = {"obj": obj, "id": _s(r["Record ID"]), "field": cols["owner"], "cur": cur,
               "new": uid if crm == "salesforce" else name, "kind": "owner"}
        if add(fix, where):
            st["approved"] += 1
        else:
            st["skipped"] += 1

    # ---- the simple approve/decline lists
    def approved_rows(name, label_cols):
        keep = []
        for r in sheet(name):
            st = stat(name)
            yes = _decision(r["Approve"], f"{name} row {r['_row']}", warnings)
            if yes is None:
                st["undecided"] += 1
            elif not yes:
                st["declined"] += 1
            else:
                st["approved"] += 1
                keep.append([_s(r.get(c)) for c in label_cols])
        return keep

    convert = approved_rows("Leads to convert", ["Lead ID", "Lead name", "Lead email", "Existing contact ID",
                                                 "Existing contact", "Existing account ID"])
    delete = approved_rows("Delete", ["Object", "Record ID", "Name", "Email", "Why"])

    # ---- write the folder
    slug = _safe(client)
    folder = Path(out) if out else xlsx.resolve().parent / f"{slug}_ready_to_load_{audit_date}"
    shown, folder = folder, _long_path(folder)
    _clean_folder(folder)
    folder.mkdir(parents=True, exist_ok=True)
    files: list[dict] = []   # {"name", "rows", "kind"}

    def out_csv(name, header, rows, kind):
        _write_csv(folder / name, header, rows)
        files.append({"name": name, "rows": len(rows), "kind": kind})

    by_obj: dict = {}
    for f in fixes.values():
        by_obj.setdefault(f["obj"], []).append(f)
    for obj in [o for o in ORDER if o in by_obj] + [o for o in by_obj if o not in ORDER]:
        idh = meta.get(obj, {}).get("id") or "Record ID"
        fo = file_object(crm, obj)
        recs: dict = {}  # id -> {field: fix}
        for f in by_obj[obj]:
            recs.setdefault(f["id"], {})[f["field"]] = f
        for rid in list(recs):   # a change to the value it already has is dropped
            for fld in list(recs[rid]):
                if recs[rid][fld]["new"] == recs[rid][fld]["cur"]:
                    del recs[rid][fld]
            if not recs[rid]:
                del recs[rid]
        all_fields = list(dict.fromkeys(h for r in recs.values() for h in r))
        upd_fields = [h for h in all_fields if any(h in r and r[h]["new"] != "" for r in recs.values())]
        rows = [[rid] + [r[h]["new"] if h in r and r[h]["new"] != "" else "" for h in upd_fields]
                for rid, r in recs.items() if any(h in r and r[h]["new"] != "" for h in upd_fields)]
        if rows:
            out_csv(f"1_update_{fo}.csv", [idh] + upd_fields, rows, "update")
        undo = [[rid] + [r[h]["cur"] if h in r else "" for h in all_fields] for rid, r in recs.items()]
        undo = [row for row in undo if any(row[1:])]
        if undo:
            out_csv(f"1_undo_{fo}.csv", [idh] + all_fields, undo, "undo")
        for h in all_fields:  # fields that were empty can only be put back by clearing them
            ids = [rid for rid, r in recs.items() if h in r and r[h]["cur"] == "" and r[h]["new"] != ""]
            if ids:
                out_csv(f"1_undo_clear_{fo}_{_safe(h)}.csv", [idh, h], [[i, ""] for i in ids], "undo_clear")
        for h in all_fields:
            ids = [rid for rid, r in recs.items() if h in r and r[h]["new"] == "" and r[h]["cur"] != ""]
            if ids:
                out_csv(f"2_clear_{fo}_{_safe(h)}.csv", [idh, h], [[i, ""] for i in ids], "clear")

    for key in ("contacts", "accounts", "deals"):
        ms = [m for m in merges if m["object"] == key]
        if ms:
            out_csv(f"3_merge_{file_object(crm, key)}.csv", ["Keep ID", "Merge IDs", "Keep name", "Merge names"],
                    [[m["keep"], ";".join(m["merge"]), m["keep_name"], "; ".join(m["merge_names"])] for m in ms], "merge")
    if convert:
        out_csv("3_convert_leads.csv", ["Lead ID", "Lead name", "Lead email", "Existing contact ID",
                                        "Existing contact", "Existing account ID"], convert, "convert")
    if delete:
        out_csv("3_delete.csv", ["Object", "Record ID", "Name", "Email", "Why"], delete, "delete")

    reps = sheet("Rep to-do")
    rep_files = {}
    if reps:
        cols = [c for c in reps[0] if c != "_row"]
        by_rep: dict = {}
        for r in reps:
            by_rep.setdefault(_s(r.get("Rep")) or "(no owner)", []).append([_s(r.get(c)) for c in cols])
        used = set()
        for rep, rows in by_rep.items():
            base, n = _safe(rep), 2
            name = base
            while name.lower() in used:
                name, n = f"{base}_{n}", n + 1
            used.add(name.lower())
            _write_csv(folder / "4_reps" / f"{name}.csv", cols, rows)
            rep_files[rep] = len(rows)
            files.append({"name": f"4_reps/{name}.csv", "rows": len(rows), "kind": "rep"})
    enrich = sheet("Enrich")
    if enrich:
        spec = {"Contact": ("contacts", ["Id", "FirstName", "LastName", "Email", "Company", "Company domain", "Needs"]),
                "Account": ("accounts", ["Id", "Name", "Website", "Needs"])}
        for label, (key, cols) in spec.items():
            rows = [[_s(r.get(c)) for c in cols] for r in enrich if _s(r.get("Object")) == label]
            if rows:
                out_csv(f"4_enrich_{file_object(crm, key)}.csv", cols, rows, "enrich")

    totals = {k: sum(s[k] for s in stats.values()) for k in ("approved", "declined", "undecided", "skipped", "waiting")}
    summary = {"folder": str(shown), "client": client, "crm": crm, "audit_date": audit_date, **totals,
               "sheets": stats, "files": [f["name"] for f in files] + ["CHECKLIST.txt"], "warnings": warnings,
               "records_updated": {o: len({f["id"] for f in fs}) for o, fs in by_obj.items()},
               "reps": rep_files}
    (folder / "CHECKLIST.txt").write_text(_checklist(summary, files, info, how, crm), encoding="utf-8")
    return summary


def _clean_folder(folder: Path):
    """Re-running on the same workbook replaces the earlier output; anything else in the folder is left alone."""
    import shutil
    if not folder.exists():
        return
    for p in folder.iterdir():
        if p.is_file() and (re.match(r"[1-4]_", p.name) or p.name == "CHECKLIST.txt"):
            p.unlink()
        elif p.is_dir() and p.name == "4_reps":
            shutil.rmtree(p)


# ------------------------------------------------------------------ the checklist

def _wrap(text: str, indent=6) -> list[str]:
    pad = " " * indent
    return textwrap.wrap(text, width=78, initial_indent=pad, subsequent_indent=pad) if text else []


def _item(text: str) -> list[str]:
    return textwrap.wrap(text, width=78, initial_indent="  [ ] ", subsequent_indent="      ")


def _checklist(sm, files, info, how, crm) -> str:
    by_kind: dict = {}
    for f in files:
        by_kind.setdefault(f["kind"], []).append(f)

    def names(kind):
        return ", ".join(f["name"] for f in by_kind.get(kind, []))

    def count(kind):
        return sum(f["rows"] for f in by_kind.get(kind, []))

    head = f"UROBORIC READY-TO-LOAD CHECKLIST  -  {sm['client']}  -  {nice_date(dt.date.fromisoformat(sm['audit_date'])) if sm['audit_date'] else ''}"
    white = _s(info.get("white_label"))
    if white:
        head = head.replace("UROBORIC READY-TO-LOAD", "READY-TO-LOAD", 1)
    out = [head, "=" * 78]
    if _s(info.get("prepared_by")):
        out.append(f"Prepared by {_s(info['prepared_by'])}")
    if _s(info.get("contact")):
        out.append(f"Questions? {_s(info['contact'])}")
    out.append(f"Reviewed: {sm['approved']:,} approved, {sm['declined']:,} declined, {sm['undecided']:,} left undecided "
               f"(not applied)" + (f", {sm['skipped']:,} skipped (see below)" if sm["skipped"] else "") + ".")
    if sm["waiting"]:
        out += _wrap(f"{sm['waiting']:,} fill-before-merge values were held back because their merge isn't approved.", 0)
    left = [f"{k} {v['undecided']}" for k, v in sm["sheets"].items() if v["undecided"]]
    if left:
        out.append("Undecided by sheet: " + ", ".join(left) + ". Ask the client if these should be done.")
    for w in sm["warnings"][:6]:
        out += _wrap("! " + w, 2)
    if len(sm["warnings"]) > 6:
        out.append(f"  ! ...and {len(sm['warnings']) - 6} more (shown when you ran apply-review).")

    out += ["", "PHASE 1 - BACK UP"] + _item(how["backup"])

    out += ["", "PHASE 2 - LOAD THE UPDATE FILES"]
    ups = by_kind.get("update", [])
    if ups:
        for f in ups:
            key = next((o for o in ORDER if f["name"] == f"1_update_{file_object(crm, o)}.csv"), "contacts")
            out += _item(f"{f['name']} ({f['rows']:,}) -> {UPDATE_WHERE[crm](HOW_OBJ[crm].get(key, 'Contact'))}")
        out += _wrap(UPDATE_NOTE[crm])
        if crm == "salesforce":
            out += _wrap("Leave 'Insert null values' OFF for these files: blank cells mean no change.")
        out += _wrap("If anything looks wrong, load the matching 1_undo file: "
                     + names("undo") + ".")
        if by_kind.get("undo_clear"):
            out += _wrap(f"{len(by_kind['undo_clear'])} undo file(s) named 1_undo_clear_* put back fields that were "
                         "empty before; load them (as in phase 3, clearing) only if you need to undo.")
    else:
        out.append("  Nothing to load.")

    out += ["", "PHASE 3 - HANDS-ON IN THE CRM"]
    any3 = False
    if by_kind.get("clear"):
        any3 = True
        out += _item(f"Clear made-up values: {len(by_kind['clear'])} file(s), {count('clear'):,} records "
                     "(2_clear_*.csv)")
        out += _wrap(how["clear"])
    if by_kind.get("merge"):
        any3 = True
        out += _item(f"Merge duplicates: {names('merge')} ({count('merge'):,} groups)")
        out += _wrap(how["merge"] + " The update files already carry over details worth keeping.")
    if by_kind.get("convert"):
        any3 = True
        out += _item(f"Convert leads: 3_convert_leads.csv ({count('convert'):,})")
        out += _wrap(how["convert"])
    if by_kind.get("delete"):
        any3 = True
        out += _item(f"Delete test/junk records: 3_delete.csv ({count('delete'):,})")
        out += _wrap(how["delete"])
    if not any3:
        out.append("  Nothing to do by hand.")

    out += ["", "PHASE 4 - HAND OFF"]
    any4 = False
    if by_kind.get("rep"):
        any4 = True
        out += _item(f"Give each rep their file in 4_reps/ ({len(by_kind['rep'])} rep file{'s' if len(by_kind['rep']) != 1 else ''}, {count('rep'):,} deals); "
                     "go through them in the next pipeline meeting.")
    if by_kind.get("enrich"):
        any4 = True
        out += _item(f"Enrichment lists: {names('enrich')} ({count('enrich'):,} records). Send to a data "
                     "provider ONLY with the client's written approval.")
    if not any4:
        out.append("  Nothing to hand off.")
    return "\n".join(out) + "\n"
