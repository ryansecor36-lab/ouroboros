"""Fuzzy string matching. Uses rapidfuzz when it's installed (desktop). In the iPad/browser app
rapidfuzz isn't available, so this falls back to Python's built-in difflib, which gives very
close scores and is fast enough for the database sizes this tool targets."""
from __future__ import annotations

try:
    from rapidfuzz import fuzz  # noqa: F401
except ImportError:  # pragma: no cover - exercised in the browser build
    from difflib import SequenceMatcher

    class _Fuzz:
        @staticmethod
        def ratio(a: str, b: str) -> float:
            if not a and not b:
                return 100.0
            return 100.0 * SequenceMatcher(None, a, b).ratio()

        @staticmethod
        def token_sort_ratio(a: str, b: str) -> float:
            return _Fuzz.ratio(" ".join(sorted(a.split())), " ".join(sorted(b.split())))

    fuzz = _Fuzz()
