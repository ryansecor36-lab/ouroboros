"""The question-and-answer versions of New audit, Run audit and Apply review, used by the double-click
launchers. They use plain input() prompts so they also work (and are tested) with typed-in answers.

Folders are relative to where the program is started (the Uroboric folder, which audit.ps1 switches to)."""
from __future__ import annotations

import datetime as dt
import os
import re
import subprocess
import sys
from pathlib import Path

from .config import CRM_CHOICES, starter_settings

CLIENTS = "clients"
_RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


def _open_path(path: Path) -> None:
    """Show a folder in Explorer (or a file in its program). Quietly does nothing if that isn't possible."""
    if os.environ.get("UROBORIC_NO_OPEN"):
        return
    try:
        os.startfile(str(path))  # Windows only
    except (AttributeError, OSError):
        pass


def safe_folder_name(name: str) -> str:
    """The client's name made safe as a Windows folder name (O'Brien & Sons is fine; A/B: C? is not)."""
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "-", str(name))
    s = re.sub(r"\s+", " ", s).strip(" .-") or "Client"
    s = s[:80].strip(" .")
    if s.lower().split(".")[0] in _RESERVED:
        s += "_"
    return s or "Client"


def clean_path(text) -> str:
    """A path typed or dropped onto a window: remove the quotes Windows may put around it."""
    s = str(text or "").strip().strip('"')
    if len(s) >= 2 and s[0] == s[-1] == "'":
        s = s[1:-1]
    return s.strip()


def _ask(prompt: str) -> str:
    try:
        return input(prompt).replace("﻿", "")  # piped-in text can start with an invisible marker
    except EOFError:
        return ""


def choose_crm() -> str:
    print("Which CRM does the client use?")
    for n, label in CRM_CHOICES.items():
        print(f"  {n}  {label}" + (" (pilot)" if label == "Bullhorn" else ""))
    for attempt in range(2):
        a = _ask("Type a number, or press Enter to detect it automatically: ").strip()
        if not a:
            return ""
        if a in CRM_CHOICES:
            return CRM_CHOICES[a]
        for label in CRM_CHOICES.values():
            if a.lower() == label.lower() or a.lower() == label.split()[0].lower():
                return label
        print("  That wasn't one of the choices." + (" Try again." if attempt == 0 else " I'll detect it automatically."))
    return ""


def new_client(root: Path | None = None) -> Path | None:
    root = Path(root) if root else Path.cwd()
    name = ""
    for _ in range(3):
        name = _ask("Client name: ").strip()
        if name:
            break
        print("  Please type the client's name.")
    if not name:
        print("No name given, so nothing was created.")
        return None
    crm = choose_crm()
    folder = root / CLIENTS / safe_folder_name(name)
    settings = folder / "audit.toml"
    if settings.exists():
        print(f"\nThere's already a folder for this client: {folder}")
        print("It was left as it is (nothing was overwritten).")
    else:
        folder.mkdir(parents=True, exist_ok=True)
        settings.write_text(starter_settings(name, crm, dt.date.today()), encoding="utf-8")
        print(f"\nCreated {folder}")
    _open_path(folder)
    print("Put the CRM export files in this folder, then double-click Run audit (or drag the folder onto it).")
    return folder


def _recent_clients(root: Path) -> list[Path]:
    base = root / CLIENTS
    if not base.is_dir():
        return []
    return sorted((p for p in base.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)


def pick_client(root: Path) -> Path | None:
    clients = _recent_clients(root)
    if not clients:
        print("There are no client folders yet. Double-click 'New audit' to make one first.")
        return None
    print("Which client? (newest first)\n")
    for i, p in enumerate(clients, 1):
        when = dt.datetime.fromtimestamp(p.stat().st_mtime)
        print(f"  {i:>2}  {p.name}   (changed {when:%b} {when.day})")
    for attempt in range(3):
        a = _ask("\nType the number [Enter = 1]: ").strip() or "1"
        if a.isdigit() and 1 <= int(a) <= len(clients):
            return clients[int(a) - 1]
        print(f"  Please type a number from 1 to {len(clients)}.")
    print("No client chosen.")
    return None


def run_client(folder: str | None = None, root: Path | None = None) -> None:
    root = Path(root) if root else Path.cwd()
    chosen = Path(clean_path(folder)) if clean_path(folder) else None
    if chosen is not None and chosen.is_file():
        chosen = chosen.parent  # a file dropped from inside the client's folder
    if chosen is None:
        chosen = pick_client(root)
        if chosen is None:
            return
    if not chosen.is_dir():
        sys.exit(f"Error: I couldn't find the folder {chosen}.")
    from .__main__ import main
    print(f"\nRunning the audit for {chosen.name} ...\n")
    main(["run", str(chosen)] + (["--no-open"] if os.environ.get("UROBORIC_NO_OPEN") else []))
    _open_path(Path("reports").resolve())


def pick_file(start: Path) -> str:
    """A Windows 'open file' window for .xlsx files. Returns the path, or '' if cancelled or unavailable."""
    if os.environ.get("UROBORIC_NO_OPEN"):
        return ""  # automated runs never show a window
    script = (
        "Add-Type -AssemblyName System.Windows.Forms; "
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
        "$owner = New-Object System.Windows.Forms.Form -Property @{TopMost=$true; ShowInTaskbar=$false}; "
        "$d = New-Object System.Windows.Forms.OpenFileDialog; "
        "$d.Title = 'Choose the reviewed Cleanup_review.xlsx'; "
        "$d.Filter = 'Excel workbooks (*.xlsx)|*.xlsx'; "
        "$d.InitialDirectory = $env:URO_START; "
        "if ($d.ShowDialog($owner) -eq 'OK') { Write-Output $d.FileName }")
    env = {**os.environ, "URO_START": str(start)}
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", script],
                           capture_output=True, env=env, timeout=600)
    except (OSError, subprocess.SubprocessError):
        return ""
    return r.stdout.decode("utf-8", "replace").strip() if r.returncode == 0 else ""


def review_audit_date(workbook: Path):
    """The audit date stored inside a review workbook, or None if it can't be read."""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(workbook, read_only=True, data_only=True)
        try:
            for row in wb["_kit"].iter_rows(values_only=True):
                if row and str(row[0]).strip() == "audit_date" and len(row) > 1 and row[1] is not None:
                    return str(row[1]).strip()
        finally:
            wb.close()
    except Exception:  # noqa: BLE001 - a workbook that can't be read is reported properly by apply-review
        pass
    return None


def apply_client(workbook: str | None = None, root: Path | None = None, today: dt.date | None = None) -> None:
    root = Path(root) if root else Path.cwd()
    path = clean_path(workbook)
    if not path:
        start = root / "reports"
        print("A window will open: choose the Cleanup_review.xlsx the client sent back.")
        path = pick_file(start if start.is_dir() else root)
        if not path:
            print("The window didn't give me a file.")
            path = clean_path(_ask("Drag the Cleanup_review.xlsx here and press Enter (or just press Enter to stop): "))
        if not path:
            print("No file chosen, so nothing was done.")
            return
    wb = Path(path)
    if not wb.is_file():
        sys.exit(f"Error: I couldn't find {wb}.")
    if wb.suffix.lower() != ".xlsx":
        sys.exit(f"Error: {wb.name} isn't an Excel (.xlsx) file. Choose the client's reviewed Cleanup_review.xlsx.")
    fresh = None
    from .apply import _age_days
    stamp = review_audit_date(wb)
    age = _age_days(stamp, today) if stamp else None
    if age is not None and age > 7:
        print(f"\nThis review is {age} days old (audit date {stamp}); the CRM may have changed since.")
        for _ in range(2):
            fresh = clean_path(_ask("Do you have fresh exports to check against? "
                                    "Drag the folder here or press Enter to skip: "))
            if not fresh:
                fresh = None
                break
            if Path(fresh).is_dir():
                break
            print(f"  I couldn't find the folder {fresh}.")
            fresh = None
    from argparse import Namespace
    from .__main__ import cmd_apply_review
    try:
        sm = cmd_apply_review(Namespace(workbook=str(wb), out=None, fresh=fresh))
    except (FileNotFoundError, ValueError) as e:
        sys.exit(f"Error: {e}")
    _open_path(Path(sm["folder"]))
