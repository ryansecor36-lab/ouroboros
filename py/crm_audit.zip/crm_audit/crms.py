"""What differs between Salesforce, HubSpot, Microsoft Dynamics 365 and Bullhorn: how to recognize their
exports, what they call things, and the CRM-specific way to carry out each fix."""
from __future__ import annotations

from .loader import norm_header

NAMES = {"salesforce": "Salesforce", "hubspot": "HubSpot", "dynamics": "Dynamics 365", "bullhorn": "Bullhorn"}

# CRMs whose support has NOT yet been checked against a real export. The consultant is told (CLI output and
# the app's status line, never the client's report). Delete the entry once a real Bullhorn export has been tried.
VERIFIED = {"bullhorn": False}
UNVERIFIED_NOTE = {
    "bullhorn": "Bullhorn support is built from Bullhorn's documentation and hasn't yet been checked against a real "
                "export - compare a few numbers by hand on the first client.",
}


def consultant_note(crm) -> str:
    """A heads-up for the consultant only, or an empty string."""
    return UNVERIFIED_NOTE.get(crm, "") if VERIFIED.get(crm, True) is False else ""


# Column headers that only one CRM's exports have (compared after norm_header)
_SIGNS = {
    # ("Contact owner" is left out: Salesforce report exports use the same label)
    "hubspot": ["recordid", "lifecyclestage", "associatedcompany", "associatedcompanyidsprimary",
                "dealowner", "dealstage", "companyowner", "companydomainname", "recordsource", "createdate",
                "phonenumber", "staterregion", "stateregion", "countryregion", "originalsource"],
    "dynamics": ["donotmodifycontact", "donotmodifyaccount", "donotmodifyopportunity", "donotmodifylead",
                 "donotmodifyrowchecksum", "createdon", "modifiedon", "estclosedate", "estrevenue",
                 "potentialcustomer", "emailaddress1", "address1stateorprovince"],
    # Bullhorn labels and API names (compared after norm_header, so "Date Added" and dateAdded are one sign).
    # Words other CRMs also use (Owner, Status, Email, Title, Source) are left out; at least two signs are needed.
    "bullhorn": ["dateadded", "occupation", "clientcorporation", "clientcorporationid", "clientcorporationname",
                 "businesssector", "businesssectorlist", "industrylist", "reasonclosed", "datelastvisit",
                 "companyurl", "atsid", "datelastmodified", "winprobability", "winprobabilitypercent",
                 "numemployees", "dealvalue", "clientcontact"],
    "salesforce": ["ownerid", "accountid", "createdbyid", "lastmodifieddate", "stagename", "isclosed",
                   "hasoptedoutofemail", "mailingstate", "billingstate", "leadsource",
                   # labels in Salesforce report exports
                   "mailingstateprovince", "billingstateprovince", "accountowner", "opportunityowner",
                   "leadowner", "lastactivity", "emailoptout", "accountname", "opportunityname"],
}


def bullhorn_score(columns) -> int:
    """How many Bullhorn-only column names are in these headers."""
    cols = {norm_header(c) for c in columns}
    return sum(1 for s in _SIGNS["bullhorn"] if s in cols)


def detect(data) -> str:
    """Which CRM the exports came from, by the column headers they use."""
    score = {k: 0 for k in _SIGNS}
    for t in data.values():
        cols = {norm_header(c) for c in t.raw.columns}
        for crm, signs in _SIGNS.items():
            score[crm] += sum(1 for s in signs if s in cols)
    if score["bullhorn"] < 2:  # its words are shared with others, so a lone match proves nothing
        score["bullhorn"] = 0
    best = max(score, key=score.get)
    return best if score[best] else "salesforce"


def resolve(cfg, data) -> str:
    """The CRM named in audit.toml wins; otherwise it's detected from the files."""
    named = str(cfg.get("crm") or "").strip().lower()
    for key, label in NAMES.items():
        if named and (named == key or named == label.lower() or named.startswith(key[:4])):
            return key
    return detect(data)


# How to carry out each fix in each CRM. Appended to the plain-English "How to fix it".
TIPS = {
    "salesforce": {
        "1.1": "In Salesforce, turn on duplicate and matching rules so new copies get flagged.",
        "1.3": "Merge Accounts in Salesforce keeps every contact and deal from both copies.",
        "1.5": "Setup > Duplicate Rules and Matching Rules.",
        "1.6": "Convert each lead and attach it to the existing contact instead of creating a new one.",
        "3.3": "Turning on State and Country/Territory Picklists in Setup fixes state and country for good.",
        "3.7": "Use validation rules or required fields on the page layout.",
        "4.1": "Salesforce's Mass Transfer Records tool does this in minutes.",
        "4.7": "A validation rule can require it when a deal is marked Closed Lost.",
    },
    "hubspot": {
        "1.1": "HubSpot's Manage duplicates tool (Contacts > Actions) suggests pairs to merge.",
        "1.2": "Merge them in HubSpot, keeping the work email as the primary email.",
        "1.3": "Merge the companies in HubSpot; associated contacts and deals move to the one kept.",
        "1.5": "Review HubSpot's Manage duplicates suggestions every month.",
        "3.3": "In HubSpot, change these properties to dropdown selects so values can't vary.",
        "3.7": "Make key properties required on create forms and on deal-stage changes.",
        "4.1": "In HubSpot, filter the list by owner, select all, and edit the owner in bulk.",
        "5.2": "Create a required 'Lead source' dropdown property in HubSpot and add it to your create forms.",
        "4.7": "Make 'Closed lost reason' required in the deal pipeline settings.",
    },
    "dynamics": {
        "1.1": "In Dynamics 365, turn on duplicate detection rules for contacts.",
        "1.3": "Use Merge on the account records; related contacts and opportunities move over.",
        "1.5": "Settings > Data Management > Duplicate Detection Rules.",
        "1.6": "Qualify each lead and choose the existing contact and account.",
        "3.3": "In Dynamics 365, use choice (option set) columns instead of free text.",
        "3.7": "Make columns Business Required, or add business rules.",
        "4.1": "In Dynamics 365, select the records in a view and click Assign.",
        "4.7": "Use the Close Opportunity dialog's reason, and require it with a business rule.",
    },
    "bullhorn": {
        "1.1": "Ask your Bullhorn admin whether duplicate checking can be turned on for new contacts.",
        "1.3": "Merge the companies in Bullhorn (Actions > Merge Records). Copy address and custom fields to the "
               "one you keep first.",
        "1.5": "Ask your Bullhorn admin about duplicate checking, and merge a few pairs every month.",
        "1.6": "Convert each lead onto the existing company and contact (Lead > Convert). Conversion can't be undone.",
        "3.3": "Ask your Bullhorn admin to turn these fields into dropdown lists so values can't vary.",
        "3.7": "Ask your Bullhorn admin to make the key fields required.",
        "4.1": "In a Bullhorn list view, select up to 500 records at a time and change the owner in bulk.",
        "4.7": "Ask your Bullhorn admin to make Reason Closed required when an opportunity is closed.",
    },
}

# Quick-win wording that names a CRM tool
QUICK_TIPS = {
    "4.1": {"salesforce": "Salesforce's Mass Transfer Records tool moves them to a current rep in a few minutes.",
            "hubspot": "Filter by owner in HubSpot, select all, and edit the owner in one step.",
            "dynamics": "Select them in a Dynamics 365 view and click Assign.",
            "bullhorn": "In a Bullhorn list view, select up to 500 at a time and change the owner in bulk."},
    "3.3": {"salesforce": "A single admin setting in Salesforce that ends spelling variants for good.",
            "hubspot": "Change the State/Region and Country properties to dropdowns.",
            "dynamics": "Switch these columns to choice (option set) columns.",
            "bullhorn": "Ask your Bullhorn admin to turn these fields into dropdown lists."},
    "4.7": {"salesforce": "One validation rule. From then on, every lost deal says why it was lost.",
            "hubspot": "One pipeline setting. From then on, every lost deal says why it was lost.",
            "dynamics": "One business rule. From then on, every lost deal says why it was lost.",
            "bullhorn": "One field setting. From then on, every lost deal says why it was lost."},
    "1.6": {"salesforce": "Salesforce's 'Convert' button can attach a lead to an existing contact instead of creating a new one.",
            "dynamics": "Qualify each lead onto the existing contact instead of creating a new one.",
            "hubspot": "",
            "bullhorn": "Convert each lead onto the existing company and contact instead of creating new ones."},
}
QUICK_TITLES = {
    "3.3": {"salesforce": "Turn on State and Country picklists", "hubspot": "Make state and country dropdowns",
            "dynamics": "Make state and country choice columns", "bullhorn": "Make state and country dropdowns"},
}

# Checks that a CRM's standard exports can't support
_CUSTOM = ("exports don't mark which fields are custom, so unused custom fields can't be counted. Review "
           "the Fill rates sheet for fields that are almost never filled in.")
NOT_APPLICABLE = {
    "hubspot": {"1.6": "In HubSpot, leads are contacts with a Lead lifecycle stage, so there's no separate lead "
                       "record that can duplicate a contact.",
                "3.6": "HubSpot " + _CUSTOM,
                "4.8": "HubSpot's deal exports don't include close-date history, so pushes can't be counted."},
    "dynamics": {"3.6": "Dynamics 365 " + _CUSTOM,
                 "4.8": "Dynamics 365 exports don't include close-date history unless auditing is turned on, so "
                        "pushes can't be counted."},
    # Bullhorn: every check is applicable except these two. Leads (Lead), opportunities (or job orders), owners,
    # users and lead source all exist in its exports. Custom fields are customText1... with no marker, and its
    # list exports carry no close-date history.
    "bullhorn": {"3.6": "Bullhorn " + _CUSTOM,
                 "4.8": "Bullhorn's list exports don't include close-date history, so pushes can't be counted."},
}


def tip(cid, crm) -> str:
    return TIPS.get(crm, {}).get(cid, "")


def quick_detail(cid, crm, default):
    return QUICK_TIPS.get(cid, {}).get(crm) or default


def quick_title(cid, crm, default):
    return QUICK_TITLES.get(cid, {}).get(crm) or default
