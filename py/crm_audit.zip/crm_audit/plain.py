"""Everyday-language wording for the report: plain titles, why each check matters, how to fix it,
number formatting non-experts can read at a glance, and picking the top problems and quick wins."""
from __future__ import annotations

from .checklist import CATEGORIES, CHECKS, CHECKS_BY_ID

RATING = {2: "Good", 1: "Needs work", 0: "Problem", None: "Not checked yet"}
RATING_ICON = {2: "✓", 1: "!", 0: "✕", None: "–"}

AREAS = {
    1: ("Duplicate records", "The same person, company or deal entered more than once."),
    2: ("Wrong or outdated contact info", "Bounced emails, bad phone numbers, and people who have left."),
    3: ("Missing or messy fields", "Blank fields and the same thing spelled different ways."),
    4: ("Leads and deals slipping through the cracks", "Who owns what, and whether the pipeline is real."),
    5: ("How new data gets in", "List uploads and the other tools connected to the CRM."),
    6: ("Habits that keep it clean", "Who is in charge of data quality, and the rules the team follows."),
}

GRADE_PLAIN = {
    "A": "In good shape. Light, regular upkeep will keep it that way.",
    "B": "Mostly fine, but bad data is costing reps time in a couple of areas.",
    "C": "Bad data is slowing reps down and making the forecast unreliable.",
    "D": "The team can't trust what's in the CRM. It needs a full cleanup and new habits.",
}

# id: (plain title, why it matters, how to fix)
PLAIN = {
    "1.1": ("The same contact entered more than once",
            "Reps may contact the same person twice, and the history ends up split across copies, so nobody sees the full picture.",
            "Merge the duplicates (the detail workbook lists every one), then turn on Salesforce duplicate rules."),
    "1.2": ("The same person under two different emails",
            "Usually a work email and a personal one. Reps can't tell which record is current.",
            "Review each pair and merge them, keeping the work email."),
    "1.3": ("Companies entered more than once",
            "Contacts and deals get split between the copies, and two reps can end up working the same company without knowing.",
            "Merge the duplicate companies, give each one a single owner, and turn on duplicate rules for accounts."),
    "1.4": ("Deals entered twice",
            "Duplicate deals make the pipeline and the forecast look bigger than they really are.",
            "Close or merge the duplicate deals."),
    "1.5": ("A tool or rule that blocks duplicates",
            "Without one, duplicates come right back after a cleanup.",
            "Turn on Salesforce duplicate and matching rules and review them every month."),
    "1.6": ("New leads who are already contacts",
            "The same person gets worked twice, often by two different reps, and the lead's activity never reaches the real contact record.",
            "Merge each of these leads into the existing contact, and send leads from existing companies to the account owner."),
    "2.1": ("Emails that bounce",
            "Every bounce is a wasted touch, and a high bounce rate can send the whole company's email to spam.",
            "Remove or re-check the addresses that bounced."),
    "2.2": ("Email addresses that don't work",
            "Sending to dead addresses wastes rep time and hurts email delivery.",
            "Run the whole database through an email checker."),
    "2.3": ("Contacts who have changed jobs",
            "Reps keep reaching out to people who have left. Their replacement, a fresh opportunity, gets missed.",
            "Use a job-change alert tool, or recheck key contacts every quarter."),
    "2.4": ("Phone numbers that are wrong or missing",
            "Reps waste dials on numbers that don't work, or have no number to call.",
            "Fix the invalid numbers and fill in missing ones from a data provider."),
    "2.5": ("Contacts nobody has touched in over a year",
            "Old records clutter lists and reports, and much of their information is probably out of date.",
            "Re-check them, or archive the ones that no longer matter."),
    "2.6": ("How recently the data was refreshed",
            "Business contact details go out of date constantly as people change jobs, titles and phone numbers.",
            "Refresh (enrich) the database at least twice a year."),
    "2.7": ("Unsubscribes being respected",
            "Emailing people who opted out invites complaints and breaks anti-spam rules.",
            "Make sure opted-out contacts can't be added to email sequences."),
    "3.1": ("Contacts missing basic details",
            "Without an email, phone, job title and company, a rep can't work the contact or put it on the right list.",
            "Fill the gaps from a data provider and make the key fields required."),
    "3.2": ("Companies missing basic details",
            "You can't target companies by industry, size or location when those fields are blank.",
            "Fill in company details from a data provider."),
    "3.3": ("The same value spelled different ways",
            "To a report, 'NJ', 'New Jersey' and 'N.J.' are three different places, so filters and territory rules miss records.",
            "Standardize the spellings and turn these fields into dropdowns."),
    "3.4": ("Seniority on each contact",
            "Without it, there's no easy way to find the decision-makers.",
            "Add a seniority field that fills in automatically from the job title."),
    "3.5": ("Sloppy formatting",
            "ALL CAPS names, 'test' records and mixed phone formats look careless in emails and make searching harder.",
            "Clean up formatting in bulk and delete the junk records."),
    "3.6": ("Custom fields nobody uses",
            "Unused fields clutter every screen and slow reps down.",
            "Hide or delete fields that are almost never filled in."),
    "3.7": ("Key fields required when entering data",
            "If nothing is required, records get saved half-empty.",
            "Require the key fields when records are created and when deals move to a new stage."),
    "3.8": ("Made-up values that get past required fields",
            "When a field is required, people type whatever lets them save: a $1 deal, a 2099 close date, 'TBD' as a title. Reports then count these fake values as real.",
            "Fix the records listed, and change required fields so they offer real choices (a dropdown) instead of a blank box."),
    "4.1": ("Records owned by people who left, or by no one",
            "Nobody is following up with these customers and prospects.",
            "Reassign them to current reps (Salesforce's Mass Transfer tool does this in minutes)."),
    "4.2": ("New leads not contacted within 2 days",
            "Leads go cold fast. Slow follow-up means lost deals.",
            "Set up automatic lead assignment and alerts, and track how fast leads get a first contact."),
    "4.3": ("Lead and customer stages that are correct",
            "When stages are wrong, every funnel report is wrong.",
            "Fix the stages and write down when each one applies."),
    "4.4": ("Deals that have gone quiet or are past their close date",
            "These make the forecast look bigger than it really is.",
            "Have each rep update or close their stale deals."),
    "4.5": ("Clear rules for each deal stage",
            "Without them, one rep's 'Proposal' is another rep's 'Negotiation', so forecasts can't be compared.",
            "Write down what has to be true for a deal to enter and leave each stage."),
    "4.6": ("Deals linked to a company and a person",
            "Unlinked deals don't appear in the company's history, and nobody can see who the buyer is.",
            "Link every open deal to its company and main contact."),
    "4.7": ("A reason recorded for every lost deal",
            "Without reasons, the team can't learn why it loses.",
            "Make the loss reason required when a deal is marked lost."),
    "4.8": ("Deals whose close date keeps slipping",
            "A deal pushed back three or more times usually isn't really going to close. These deals make the forecast look better than it is, quarter after quarter.",
            "Review each one with its rep: set a real date with a reason, or close it as lost."),
    "5.1": ("A clear process for uploading lists",
            "Most bad data enters through list uploads.",
            "Limit who can upload, and use a checklist: verify, remove duplicates, map fields, tag the source."),
    "5.2": ("Knowing where each contact came from",
            "Without a source, there's no way to tell which marketing and lists actually pay off.",
            "Make Lead Source required and fill it in where it's known."),
    "5.3": ("Checking purchased lists before upload",
            "Unchecked lists bring in bad emails and duplicates.",
            "Verify every purchased or scraped list before it goes in."),
    "5.4": ("Other tools overwriting good data",
            "Connected tools can quietly create duplicates or replace correct details with wrong ones.",
            "Review every tool that writes to the CRM and decide which source wins."),
    "5.5": ("Old, unused lists and reports",
            "Clutter makes it hard to find the lists that matter.",
            "Archive old list views, reports and campaigns."),
    "5.6": ("How fast a targeted list can be built",
            "If a list takes hours to build, campaigns don't happen.",
            "Clean the fields lists are built from: industry, size, location, seniority."),
    "6.1": ("One person in charge of data quality",
            "When everyone owns data quality, nobody does.",
            "Name an owner and give them time each week for it."),
    "6.2": ("Written rules for entering data",
            "Without them, every rep enters data their own way.",
            "Write a one-page guide and share it with the team."),
    "6.3": ("Limits on who can delete or mass-edit",
            "One wrong bulk edit can damage thousands of records.",
            "Limit those permissions to one to three admins."),
    "6.4": ("Regular cleanup on a schedule",
            "Data decays every month, so one-time cleanups don't last.",
            "Schedule a weekly duplicate check and a quarterly data refresh."),
    "6.5": ("Reps trusting the CRM",
            "If reps don't trust it, they keep their own spreadsheets and the CRM gets worse.",
            "Fix the top problems in this report and tell the team what changed."),
    "6.6": ("Customer data kept secure",
            "Data copied into personal spreadsheets or unapproved AI tools is a security and privacy risk.",
            "Set a clear policy and keep data inside approved tools."),
}

MEASURED_HEADLINE = {
    "2.1": "{v:g}% of emails bounced in the last 90 days",
    "2.2": "{v:g}% of the email addresses tested don't work",
    "2.3": "{v:g}% of the key contacts checked have left their company",
    "2.6": "The data was last refreshed {v:g} months ago",
    "6.5": "Reps rate their trust in the CRM {v:g} out of 10",
}

# Things a team can fix on its own within a week: (id, title, detail). {n} etc. come from extras.
QUICK_WINS = [
    ("4.1", "Reassign {count:,} records owned by former employees or no one",
     "Salesforce's Mass Transfer Records tool moves them to a current rep in a few minutes."),
    ("4.4", "Ask reps to update or close {stale_count:,} stale deals",
     "Fix past-due close dates and close dead deals. The forecast becomes believable right away."),
    ("1.4", "Close or merge {count:,} duplicate open deals",
     "Stops the same deal being counted twice in the forecast."),
    ("4.8", "Review the {count:,} deals pushed back 3 or more times",
     "In the next pipeline meeting, each rep gives every one a real date or closes it as lost."),
    ("1.6", "Merge {count:,} leads into the contacts they duplicate",
     "Salesforce's 'Convert' button can attach a lead to an existing contact instead of creating a new one."),
    ("3.8", "Fix {count:,} made-up values like $1 deals and 'TBD' titles",
     "The detail workbook lists each one with the field and value."),
    ("3.3", "Turn on State and Country picklists",
     "A single admin setting in Salesforce that ends spelling variants for good."),
    ("4.7", "Make 'loss reason' required on lost deals",
     "One validation rule. From then on, every lost deal says why it was lost."),
    ("1.1", "Merge {groups:,} sets of contacts that share an email",
     "The detail workbook lists every set, largest first."),
    ("3.6", "Hide unused custom fields from page layouts",
     "Cleaner screens for reps, and nothing is deleted."),
]


def one_in(p) -> str | None:
    """12.5 -> 'about 1 in 8'; 60 -> 'about 6 in 10'."""
    if p is None or p <= 0:
        return None
    if p >= 95:
        return "nearly all"
    if p >= 45:
        return f"about {round(p / 10)} in 10"
    if p >= 1:
        return f"about 1 in {round(100 / p)}"
    return "fewer than 1 in 100"


def nice_date(d) -> str:
    """November 1, 2026 (no leading zero on the day)."""
    return f"{d:%B} {d.day}, {d.year}"


def money(v) -> str:
    if v is None:
        return "-"
    if abs(v) >= 1_000_000:
        return f"${v / 1_000_000:.1f}M"
    if abs(v) >= 100_000:
        return f"${v / 1000:.0f}K"
    return f"${v:,.0f}"


def plain_title(cid):
    return PLAIN[cid][0]


def _miss(rule, value):
    """How many times worse than the target a value is (1 = right at the target), capped at 5."""
    kind, t = rule
    if kind in ("max", "within"):
        m = value / t if t else 5
    elif kind == "min":
        m = (100 - value) / (100 - t) if t < 100 else 5
    elif kind == "min_value":
        m = t / value if value else 5
    else:  # zero
        m = 1 + value / t if t else 5
    return max(1.0, min(m, 5.0))


def top_problems(results, weights, n=3):
    """The checks hurting the team most. Ranked by how far off target they are and how much their
    area counts. Problems measured in the CRM (which come with real examples) go first, and the
    list is spread across different areas."""
    cands = []
    for c in CHECKS:
        r = results[c.id]
        if r.score is None or r.score == 2 or c.mode == "manual" or r.value is None:
            continue
        sev = (2 - r.score) * weights.get(c.category, 0) * _miss(c.rule, r.value)
        cands.append((c.mode != "auto", -sev, c.id, c.category))
    cands.sort()
    picked, areas = [], set()
    for _, _, cid, cat in cands:
        if cat not in areas:
            picked.append(cid)
            areas.add(cat)
        if len(picked) == n:
            return picked
    for _, _, cid, _ in cands:
        if cid not in picked:
            picked.append(cid)
        if len(picked) == n:
            break
    return picked


def quick_wins(results, exclude=(), n=3, sources=None):
    out = []
    if sources and sources["top_share"] >= 30 and sources["top_creator"] != "(unknown)":
        who = sources["top_creator"]
        if sources["top_is_integration"]:
            out.append(("src", f"Check the settings of {who}",
                        f"It created {sources['top_share']:.0f}% of the problem records. Turn on duplicate matching "
                        "for it, or stop it from creating new records, so the mess stops coming back."))
        else:
            out.append(("src", f"Show {who} the data-entry basics",
                        f"{who} created {sources['top_share']:.0f}% of the problem records. Fifteen minutes on "
                        "how to search before creating a record will prevent most of them."))
    for cid, title, detail in QUICK_WINS:
        r = results[cid]
        if r.score is None or r.score == 2 or cid in exclude:
            continue
        try:
            out.append((cid, title.format(**r.extras), detail))
        except (KeyError, ValueError):
            continue
        if len(out) == n:
            break
    return out


def area_name(num):
    return AREAS[num][0]


__all__ = ["RATING", "RATING_ICON", "AREAS", "GRADE_PLAIN", "PLAIN", "MEASURED_HEADLINE", "one_in",
           "money", "top_problems", "quick_wins", "plain_title", "area_name", "CATEGORIES", "CHECKS_BY_ID"]
