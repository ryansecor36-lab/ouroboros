"""Writes the audit workbook: scorecard, all checks, impact, to-do list and evidence sheets."""
from __future__ import annotations

import datetime as dt
import math
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .checklist import CATEGORIES, CHECKS, GRADES
from .loader import ALIASES, PATTERNS, TABLE_LABELS
from .plain import fix_text, nice_date, AREAS, GRADE_PLAIN, PLAIN, RATING, RATING_ICON, top_problems

NAVY = "1F3A5F"
HEADER_FILL = PatternFill("solid", fgColor=NAVY)
HEADER_FONT = Font(bold=True, color="FFFFFF")
SCORE_FILL = {2: PatternFill("solid", fgColor="C6EFCE"), 1: PatternFill("solid", fgColor="FFEB9C"),
              0: PatternFill("solid", fgColor="FFC7CE")}
GREY_FILL = PatternFill("solid", fgColor="EDEDED")
GRADE_FILL = {"A": "C6EFCE", "B": "E2F0D9", "C": "FFEB9C", "D": "FFC7CE"}
THIN = Border(bottom=Side(style="thin", color="D0D0D0"))
WRAP = Alignment(wrap_text=True, vertical="top")
MONEY = '"$"#,##0'


def _clean(v):
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    if v is pd.NaT or (not isinstance(v, (list, dict)) and pd.isna(v) is True):
        return None
    if isinstance(v, pd.Timestamp):
        return v.to_pydatetime()
    if hasattr(v, "item") and not isinstance(v, str):
        try:
            return v.item()
        except (ValueError, AttributeError):
            pass
    if isinstance(v, str):
        return ILLEGAL_CHARACTERS_RE.sub("", v)
    return v


def _header(ws, row, values, col=1):
    for j, v in enumerate(values):
        c = ws.cell(row, col + j, v)
        c.fill, c.font = HEADER_FILL, HEADER_FONT
        c.alignment = Alignment(vertical="center", wrap_text=True)


def write_df(ws, df: pd.DataFrame, row=1, col=1):
    _header(ws, row, [str(c) for c in df.columns], col)
    for i, rec in enumerate(df.itertuples(index=False), start=row + 1):
        for j, v in enumerate(rec):
            cell = ws.cell(i, col + j, _clean(v))
            if isinstance(cell.value, dt.datetime):
                cell.number_format = "yyyy-mm-dd"
            elif isinstance(cell.value, float) and str(df.columns[j]).lower() in ("amount",):
                cell.number_format = MONEY
    return row + len(df)


def autosize(ws, max_width=60, min_width=8):
    widths = {}
    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 300)):
        for c in row:
            if c.value is not None:
                length = max(len(s) for s in str(c.value).split("\n"))
                widths[c.column_letter] = max(widths.get(c.column_letter, 0), length)
    for letter, w in widths.items():
        ws.column_dimensions[letter].width = max(min_width, min(max_width, w + 2))


def _safe_title(name: str, used: set) -> str:
    t = "".join(ch for ch in name if ch not in '[]:*?/\\')[:31]
    base, n = t, 2
    while t in used:
        t = f"{base[:28]} {n}"
        n += 1
    used.add(t)
    return t


def _brand_logo(ws, b, anchor="F1", height=56):
    """Put the logo on the sheet. Needs the Pillow library, and Excel can't show SVG, so those are skipped."""
    if b is None or not b.logo_bytes or b.logo_mime == "image/svg+xml":
        return
    try:
        import io
        from openpyxl.drawing.image import Image
        img = Image(io.BytesIO(b.logo_bytes))
        scale = height / img.height
        img.width, img.height = max(1, round(img.width * scale)), height
        ws.add_image(img, anchor)
        b.xlsx_logo = True
    except Exception:  # no Pillow (the iPad version) or an odd picture: the report is fine without it
        pass


def _summary(wb, client, audit_date, card, impact, results, data, crm_name="Salesforce", branding=None):
    b = branding if branding is not None and branding.active else None
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = f"{b.tool_name if b else 'Uroboric '}CRM Data Health Report"
    ws["A1"].font = Font(bold=True, size=18, color=(b.accent[1:].upper() if b and b.accent else NAVY))
    ws["A2"] = f"{client}  |  {crm_name}  |  Audit date {nice_date(audit_date)}"
    ws["A2"].font = Font(size=11, color="555555")
    ws["A3"] = "Data reviewed: " + ", ".join(f"{TABLE_LABELS[k]} ({len(t):,})" for k, t in data.items())
    ws["A3"].font = Font(size=10, color="555555")
    if b and (b.prepared_by or b.contact):
        ws["A4"] = " | ".join(x for x in ((f"Prepared by {b.prepared_by}" if b.prepared_by else ""), b.contact) if x)
        ws["A4"].font = Font(size=10, bold=True, color="555555")
    _brand_logo(ws, b)

    ws["A5"] = "Overall grade"
    ws["A5"].font = Font(bold=True, size=12)
    if card.overall is not None:
        ws["B5"] = card.grade
        ws["B5"].font = Font(bold=True, size=28)
        ws["B5"].fill = PatternFill("solid", fgColor=GRADE_FILL[card.grade])
        ws["B5"].alignment = Alignment(horizontal="center", vertical="center")
        ws["C5"] = f"{card.overall:.0f} / 100"
        ws["C5"].font = Font(bold=True, size=16)
        ws["D5"] = GRADE_PLAIN[card.grade]
    else:
        ws["B5"] = "Not enough data scored yet"
    ws.row_dimensions[5].height = 40
    r = 6
    if card.unscored:
        ws.cell(r, 1, f"Provisional: {card.unscored} of {len(CHECKS)} checks still need your input "
                      "(see the 'Inputs needed' sheet). Categories are scored on the checks completed.") \
            .font = Font(italic=True, color="C00000")
        r += 1
    if card.weights_note:
        ws.cell(r, 1, card.weights_note).font = Font(italic=True, color="C00000")
        r += 1

    r += 1
    _header(ws, r, ["Area", "Points earned", "Points possible", "Weight", "Area score", "Rating",
                    "Checks still to score"])
    for c in card.categories:
        r += 1
        band = (2 if c.pct >= 0.85 else (1 if c.pct >= 0.5 else 0)) if c.pct is not None else None
        vals = [f"{c.number}. {AREAS[c.number][0]}", c.earned, c.possible, c.weight / 100,
                round(c.score, 1) if c.score is not None else None,
                f"{RATING_ICON[band]} {RATING[band]}", c.unscored or None]
        for j, v in enumerate(vals, 1):
            cell = ws.cell(r, j, v)
            cell.border = THIN
        ws.cell(r, 4).number_format = "0%"
        if band is not None:
            ws.cell(r, 5).fill = SCORE_FILL[band]
            ws.cell(r, 6).fill = SCORE_FILL[band]
    r += 1
    ws.cell(r, 1, "Overall grade").font = Font(bold=True)
    ws.cell(r, 4, sum(c.weight for c in card.categories) / 100).number_format = "0%"
    ws.cell(r, 5, round(card.overall, 1) if card.overall is not None else None).font = Font(bold=True)

    r += 2
    ws.cell(r, 1, "What bad data is costing the team").font = Font(bold=True, size=12)
    r += 1
    if impact["hours"] is not None:
        ws.cell(r, 1, "Rep hours lost per year")
        ws.cell(r, 2, round(impact["hours"])).number_format = "#,##0"
        ws.cell(r, 3, f"about {impact['fte']:.1f} full-time reps doing nothing but hitting dead ends")
        r += 1
        if impact["cost"] is not None:
            ws.cell(r, 1, "Cost per year")
            ws.cell(r, 2, round(impact["cost"])).number_format = MONEY
            ws.cell(r, 2).font = Font(bold=True)
            r += 1
    else:
        ws.cell(r, 1, "Enter reps and touches_per_rep_per_day in audit.toml to calculate rep time lost.") \
            .font = Font(italic=True)
        r += 1
    for label, value, how in impact["extras"]:
        ws.cell(r, 1, label)
        if value is not None:
            ws.cell(r, 2, round(value)).number_format = MONEY
        ws.cell(r, 3, how)
        r += 1

    r += 1
    ws.cell(r, 1, "Biggest problems").font = Font(bold=True, size=12)
    for cid in top_problems(results, {c.number: c.weight for c in card.categories}, n=5):
        r += 1
        sc = results[cid].score
        ws.cell(r, 1, f"{cid} {PLAIN[cid][0]}")
        ws.cell(r, 2, f"{RATING_ICON[sc]} {RATING[sc]}").fill = SCORE_FILL[sc]
        ws.cell(r, 3, results[cid].headline)

    r += 2
    ws.cell(r, 1, "Grade scale").font = Font(bold=True)
    hi = 100
    for floor, letter, meaning in GRADES:
        r += 1
        ws.cell(r, 1, f"{letter}  ({floor}-{hi})" if floor else f"{letter}  (below 50)")
        ws.cell(r, 1).fill = PatternFill("solid", fgColor=GRADE_FILL[letter])
        ws.cell(r, 2, meaning)
        hi = floor - 1
    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 16
    ws.column_dimensions["F"].width = 20


def _checks_sheet(wb, results, detail_sheets, crm="salesforce"):
    ws = wb.create_sheet("All checks")
    _header(ws, 1, ["#", "Area", "Check", "Rating", "What we found", "Example from the CRM",
                    "Healthy target", "Why it matters", "How to fix it", "Score (0-2)",
                    "How it was measured (technical)", "Full list on sheet"])
    for i, c in enumerate(CHECKS, start=2):
        res = results[c.id]
        title, why, _ = PLAIN[c.id]
        fix = fix_text(c.id, crm)
        rating = f"{RATING_ICON[res.score]} {RATING[res.score]}"
        tech = " ".join([c.how + ("" if c.how[-1] in ".?!" else "."), f"Result: {res.display}."] + res.notes)
        vals = [c.id, AREAS[c.category][0], title, rating, res.headline, res.example or None, c.target,
                why, fix, res.score, tech, ", ".join(detail_sheets.get(c.id, []))]
        for j, v in enumerate(vals, 1):
            cell = ws.cell(i, j, _clean(v))
            cell.alignment = WRAP
            cell.border = THIN
        for col in (4, 10):
            sc = ws.cell(i, col)
            sc.fill = SCORE_FILL[res.score] if res.score is not None else GREY_FILL
        ws.cell(i, 4).font = Font(bold=True)
        ws.cell(i, 10).alignment = Alignment(horizontal="center", vertical="top")
    for letter, w in zip("ABCDEFGHIJKL", (6, 24, 30, 14, 44, 36, 20, 40, 40, 8, 60, 24)):
        ws.column_dimensions[letter].width = w
    ws.freeze_panes = "D2"
    ws.auto_filter.ref = f"A1:L{len(CHECKS) + 1}"


def _impact_sheet(wb, impact):
    ws = wb.create_sheet("Impact")
    ws["A1"] = "Impact calculator: rep time lost to bad data"
    ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    _header(ws, 3, ["Input", "Value", "Where it came from"])
    r = 3
    for label, value, src in impact["inputs"]:
        r += 1
        ws.cell(r, 1, label)
        ws.cell(r, 2, value)
        ws.cell(r, 3, src)
        if label.startswith("C."):
            ws.cell(r, 2).number_format = '0.0"%"'
        if label.startswith("F."):
            ws.cell(r, 2).number_format = MONEY
    r += 2
    ws.cell(r, 1, "Hours lost per year (A x B x C x D x E / 60)").font = Font(bold=True)
    ws.cell(r, 2, round(impact["hours"]) if impact["hours"] is not None else "needs inputs")
    ws.cell(r, 2).number_format = "#,##0"
    r += 1
    ws.cell(r, 1, "Cost per year (hours lost x F)").font = Font(bold=True)
    ws.cell(r, 2, round(impact["cost"]) if impact["cost"] is not None else "needs inputs")
    ws.cell(r, 2).number_format = MONEY
    if impact["fte"]:
        r += 1
        ws.cell(r, 1, f"That is about {impact['fte']:.1f} full-time reps (2,000 hrs/yr) doing nothing "
                      "but hitting dead ends.").font = Font(italic=True)
    if impact["extras"]:
        r += 2
        _header(ws, r, ["Add on top", "Value", "How it was calculated"])
        for label, value, how in impact["extras"]:
            r += 1
            ws.cell(r, 1, label)
            ws.cell(r, 2, round(value) if value is not None else None).number_format = MONEY
            ws.cell(r, 3, how)
    r += 2
    ws.cell(r, 1, "Keep assumptions conservative and show them openly: a sales leader trusts a number "
                  "they can check.").font = Font(italic=True, color="555555")
    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 90


def _todo_sheet(wb, results):
    ws = wb.create_sheet("Inputs needed")
    todo = [c for c in CHECKS if results[c.id].score is None]
    ws["A1"] = "Checks that still need your input"
    ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    ws["A2"] = ("Fill these in audit.toml, then run the audit again. "
                "Scores: 2 = healthy, 1 = needs attention, 0 = critical or nobody can answer.")
    if not todo:
        ws["A4"] = "All checks are scored."
        return
    _header(ws, 4, ["#", "Check", "How to run it", "Target", "What to add to audit.toml", "Why it's open"])
    for i, c in enumerate(todo, start=5):
        res = results[c.id]
        if c.mode == "measured":
            what = f'[measured]  "{c.id}" = <number in {c.unit}>'
        else:
            what = f'[manual_scores]  "{c.id}" = 0, 1 or 2'
        why = res.notes[0] if res.notes else ("Measured outside the CRM" if c.mode == "measured"
                                               else "Interview or admin review")
        for j, v in enumerate([c.id, c.name, c.how, c.target, what, why], 1):
            cell = ws.cell(i, j, v)
            cell.alignment = WRAP
            cell.border = THIN
    for letter, w in zip("ABCDEF", (6, 28, 60, 24, 36, 60)):
        ws.column_dimensions[letter].width = w
    ws.freeze_panes = "A5"


def _fill_rates(wb, data, used):
    ws = wb.create_sheet(_safe_title("Fill rates", used))
    ws["A1"] = "How full is every field? (sorted by fill rate, per object)"
    ws["A1"].font = Font(bold=True, size=12, color=NAVY)
    rows = []
    for name, t in data.items():
        if name in ("tasks", "contact_roles"):
            continue
        n = len(t)
        for col in t.raw.columns:
            filled = int(t.raw[col].notna().sum())
            rows.append((TABLE_LABELS[name], col, filled, round(100 * filled / n, 1) if n else 0.0))
    df = pd.DataFrame(rows, columns=["Object", "Field", "Records filled", "Fill rate %"]) \
        .sort_values(["Object", "Fill rate %"], ascending=[True, False])
    write_df(ws, df, row=3)
    autosize(ws)
    ws.freeze_panes = "A4"


def _mapping_sheet(wb, data, used):
    ws = wb.create_sheet(_safe_title("Column mapping", used))
    ws["A1"] = ("Which export column was used for each field. If one is wrong or missing, set it "
                "under [columns.<object>] in audit.toml.")
    ws["A1"].font = Font(italic=True)
    rows = []
    for name, t in data.items():
        wanted = list(ALIASES.get(name, {})) + list(PATTERNS.get(name, {}))
        for logical in wanted:
            rows.append((TABLE_LABELS[name], t.path.name, logical, t.mapping.get(logical, "(not found)")))
    write_df(ws, pd.DataFrame(rows, columns=["Object", "File", "Field the audit looks for",
                                             "Column used"]), row=3)
    autosize(ws)


def _sources_sheet(wb, sources):
    ws = wb.create_sheet("Where bad data comes from")
    ws["A1"] = "Where the bad data comes from"
    ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    if not sources:
        ws["A3"] = ("Not available: add CreatedById (or 'Created By') to the contacts, accounts and leads "
                    "exports to trace problems back to who created them.")
        return
    ws["A3"] = sources["headline"]
    ws["A3"].font = Font(bold=True, size=12)
    r = 4
    ws.cell(r, 1, f"Automated tools and integrations created {sources['integration_share']:.0f}% of all problem records.")
    if sources["trend"]:
        r += 1
        ws.cell(r, 1, sources["trend"]["sentence"])
    r += 2
    ws.cell(r, 1, "By who created the record").font = Font(bold=True)
    r = write_df(ws, sources["by_creator"], row=r + 1) + 2
    if sources["by_source"] is not None and len(sources["by_source"]):
        ws.cell(r, 1, "By lead source (sources with at least 10 records)").font = Font(bold=True)
        write_df(ws, sources["by_source"], row=r + 1)
    autosize(ws)
    ws.column_dimensions["A"].width = 34


def _progress_sheet(wb, comp):
    ws = wb.create_sheet("Progress")
    ws["A1"] = "Since the last audit"
    ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    ws["A2"] = comp["headline"]
    ws["A2"].font = Font(bold=True, size=12)
    r = 3
    if comp["cost_sentence"]:
        ws.cell(r, 1, comp["cost_sentence"])
        r += 1
    ws.cell(r, 1, f"{len(comp['better'])} checks got better, {len(comp['worse'])} got worse.")
    df = pd.DataFrame(comp["rows"])
    end = write_df(ws, df, row=r + 2)
    for i in range(r + 3, end + 1):
        cell = ws.cell(i, df.columns.get_loc("Change") + 1)
        fill = {"Better": SCORE_FILL[2], "Worse": SCORE_FILL[0]}.get(cell.value)
        if fill is not None:
            cell.fill = fill
    autosize(ws)
    ws.column_dimensions["A"].width = 8
    ws.freeze_panes = ws.cell(r + 3, 1)


def write_report(path: Path, client, audit_date, card, impact, results, data, sources=None,
                 snap=None, comp=None, crm=None, branding=None):
    wb = Workbook()
    from .crms import NAMES, detect
    crm = crm or detect(data)
    _summary(wb, client, audit_date, card, impact, results, data, NAMES[crm], branding)
    used = {"Summary", "All checks", "Impact", "Inputs needed", "Where bad data comes from", "Progress"}
    if comp:
        _progress_sheet(wb, comp)
    detail_sheets: dict[str, list[str]] = {}
    pending = []
    for c in CHECKS:
        for name, df in results[c.id].details.items():
            if df is None or df.empty:
                continue
            title = _safe_title(f"{c.id} {name}", used)
            detail_sheets.setdefault(c.id, []).append(title)
            pending.append((title, c, df))
    _checks_sheet(wb, results, detail_sheets, crm)
    _impact_sheet(wb, impact)
    _todo_sheet(wb, results)
    _sources_sheet(wb, sources)
    for title, c, df in pending:
        ws = wb.create_sheet(title)
        ws["A1"] = f"{c.id} {c.name}: {results[c.id].display}"
        ws["A1"].font = Font(bold=True, size=12, color=NAVY)
        note = f"Target: {c.target}."
        if len(df) >= 20000:
            note += " Showing the first 20,000 rows."
        ws["A2"] = note
        write_df(ws, df, row=4)
        autosize(ws)
        ws.freeze_panes = "A5"
        ws.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{len(df) + 4}"
    _fill_rates(wb, data, used)
    _mapping_sheet(wb, data, used)
    if snap:
        from .progress import add_snapshot_sheet
        add_snapshot_sheet(wb, snap)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path, detail_sheets
