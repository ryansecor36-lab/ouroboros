"""Round 2: after apply-review, a short follow-up workbook with ONLY the decisions the client left unanswered.

  Clients often answer part of Cleanup_review.xlsx. apply-review loads what was answered; this module builds
  "<client>_round2_review_<date>.xlsx" from the TRUSTED ORIGINAL (the consultant's own kit, never the client's
  returned file) so the client can answer the rest, and so the consultant never has to send the big workbook again.

Who gets what
  * a decision the client left blank (including a group decision left blank, and its members) goes back to the client
  * rows held back by the conflict check or by --fresh are for the consultant (CHECKLIST lists them): not sent again
  * declined rows and rows approved in an earlier round never come back
  * a row that was deleted or altered in the returned workbook is neither answered nor validly blank: it is taken from
    the original (which is trusted) and reported in a warning
  * a valid draft (a New owner picked, or a Keep ID changed, with Approve left blank) is carried into the yellow cell,
    Approve still blank
  * fill-before-merge values travel with their merge (unless the client declined that value)
  * Group decisions are rebuilt over the remaining members only (2 or more, same rules as cleanup.decision_groups)

The round-2 workbook is an ordinary kit workbook (same writer, same version): a new kit id, its own manifest built from
the ORIGINAL manifest's entries, a side-car "<file>.manifest.json" next to it, and _kit facts parent_kit_id,
root_kit_id and round. A small "<kit>.rounds.json" next to the original's side-car records which kit ids were issued
for each round, so applying an EARLIER round after a later one exists can be warned about (never blocked).
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import shutil
import uuid
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

from . import manifest as M
from . import cleanup as C

SIDE = ".manifest.json"
ROUNDS = ".rounds.json"
HELP = "run apply-review again with --original <the kit folder that holds the original Cleanup_review.xlsx>"

# the writer's own column facts: sheet -> (editable columns, hidden columns). Only columns the original has are used,
# so a workbook made before 1.6.0 (no Group columns, no Group decisions tab) still produces a round 2.
SPEC = {"Quick approve": (["Approve all"], ["Group key", "Members"]),
        "Group decisions": (["Approve", "New owner"], ["Group key", "Members hash"]),
        "Field fixes": (["Approve", "New value"], ["Change ID", "Kind", "Merge key"]),
        "Values to clear": (["Approve"], ["Change ID", "Group key"]),
        "Owners": (["Approve", "New owner"], ["Current owner ID", "Change ID", "Group key"]),
        "Merges": (["Approve", "Keep ID"], ["Merge key"]),
        "Merge details": ([], []),
        "Rep to-do": ([], ["Merge key", "Conditional task"]),
        "Leads to convert": (["Approve"], ["Change ID"]),
        "Delete": (["Approve"], ["Change ID"])}
ORANGE = "F8CBAD"


def _s(v) -> str:
    return M.norm(v)


# ------------------------------------------------------------------ finding the trusted original

def _identity(path: Path):
    """(_kit facts, manifest) of a workbook, or None if it isn't a readable kit workbook."""
    import openpyxl
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception:
        return None
    try:
        if "_kit" not in wb.sheetnames or "_manifest" not in wb.sheetnames:
            return None
        info = {_s(r[0]): r[1] for r in wb["_kit"].iter_rows(values_only=True) if r and r[0] is not None}
        rows = [r for r in wb["_manifest"].iter_rows(values_only=True) if r and r[0] is not None]
        rows.sort(key=lambda r: int(float(_s(r[0]))))
        man = M.unpack([_s(r[1]) for r in rows])
        return info, man
    except Exception:
        return None
    finally:
        wb.close()


def side_of(original: Path) -> Path:
    """Where the kit's own side-car lives: next to the kit folder (a first-round kit) or next to the round workbook."""
    if original.name == "Cleanup_review.xlsx":
        return original.parent.parent / (original.parent.name + SIDE)
    return original.with_name(original.stem + SIDE)


def rounds_of(side: Path) -> Path:
    return side.with_name(side.name[:-len(SIDE)] + ROUNDS) if side.name.endswith(SIDE) else side.with_name(side.name + ROUNDS)


def _same_file(a: Path, b: Path) -> bool:
    try:
        return os.path.samefile(a, b)
    except OSError:
        return False


def _side_data(p: Path):
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def _glob(d: Path, pattern: str, limit=60):
    try:
        return sorted(d.glob(pattern))[:limit]
    except OSError:
        return []


def archive_of(side: Path) -> Path:
    """The hidden folder next to a side-car that keeps every follow-up issued from that kit: <kit>.rounds/<kit id>/."""
    base = side.name[:-len(SIDE)] if side.name.endswith(SIDE) else side.stem
    return side.with_name(base + ".rounds")


def _side_candidates(xlsx: Path, man: dict, sidecars, explicit, roots):
    """Side-car files that may belong to THIS kit, in places the consultant controls: next to the returned file, in the
    archive next to a parent kit's side-car, in the ready-to-load folder it was issued in, under --original, and (the
    iPad) under the app's own folders."""
    kid = _s(man.get("kit_id"))
    for s in sidecars:
        yield s
        data = _side_data(s)
        if data and _s(data.get("kit_id")) in {_s(man.get("parent_kit_id")), _s(man.get("root_kit_id"))}:
            yield from _glob(archive_of(s) / kid, "*" + SIDE)
            rd = _load_rounds(rounds_of(s))
            if rd and rd.get("archive_root"):
                yield from _glob(Path(rd["archive_root"]) / kid, "*" + SIDE)
    if explicit is not None:
        p = Path(explicit)
        if p.is_dir():
            yield p.parent / (p.name + SIDE)
            yield from _glob(p, "*" + SIDE)
            yield from _glob(p, "*round*_review_*" + SIDE)
            yield from _glob(p, f"*.rounds/{kid}/*" + SIDE)
            yield from _glob(p.parent, f"*.rounds/{kid}/*" + SIDE)
        else:
            yield side_of(p)
            yield from _glob(archive_of(side_of(p)) / kid, "*" + SIDE)
    for d in dict.fromkeys([xlsx.parent, xlsx.parent.parent]):
        yield from _glob(d, "*round*_review_*" + SIDE)
        yield from _glob(d, "*/*round*_review_*" + SIDE)
        yield from _glob(d, f"*.rounds/{kid}/*" + SIDE)
    for root in roots:
        try:
            yield from sorted(Path(root).rglob("*" + SIDE))[:200]
        except OSError:
            pass


def trusted_sides(xlsx, man: dict, sidecars, explicit=None, roots=()):
    """(good, altered): the side-car files of THIS kit (same kit id) found in trusted places, as (path, data) pairs.
    `altered` holds those whose record differs from the workbook's hidden record (a sign the workbook was changed)."""
    good, altered, seen = [], [], set()
    for p in _side_candidates(Path(xlsx), man, list(sidecars), explicit, list(roots)):
        try:
            key = str(Path(p).resolve())
        except OSError:
            continue
        if key in seen or not Path(p).is_file():
            continue
        seen.add(key)
        data = _side_data(Path(p))
        if data is None or _s(data.get("kit_id")) != _s(man.get("kit_id")):
            continue
        (good if M.canonical(M.strip_side(data)) == M.canonical(man) else altered).append((Path(p), data))
    return good, altered


class Locator:
    """Finds the trusted original of the workbook that came back, once. A candidate must carry the same kit id AND the
    same hidden record as the returned workbook, must not be the returned file, and (when the kit's side-car recorded
    one at issue time) must have the same sha256 as the workbook that was issued: a client's downloaded copy that was
    re-saved never matches. For older kits with no recorded fingerprint, only the Cleanup_review.xlsx inside the kit
    folder that sits next to the side-car is accepted (and `notes` says so)."""

    def __init__(self, xlsx: Path, man: dict, sidecars: list, original=None, roots=()):
        self.xlsx, self.man, self.sidecars = Path(xlsx), man, list(sidecars)
        self.explicit = Path(original) if original else None
        self.roots = [Path(r) for r in roots]
        self._done, self._path, self._why, self.notes = False, None, "", []

    def _identity_ok(self, p: Path):
        ident = _identity(p)
        return (ident is not None and _s(ident[0].get("kit_id")) == _s(self.man.get("kit_id"))
                and M.canonical(ident[1]) == M.canonical(self.man))

    def original(self):
        """Path of the trusted original workbook, or None (then .why says what to do)."""
        if self._done:
            return self._path
        self._done = True
        good, _ = trusted_sides(self.xlsx, self.man, self.sidecars, self.explicit, self.roots)
        digest = next((_s(d.get(M.DIGEST_KEY)) for _, d in good if _s(d.get(M.DIGEST_KEY))), "")
        adjacent = []
        for s, _ in good:
            base = s.name[:-len(SIDE)] if s.name.endswith(SIDE) else s.stem
            adjacent += [s.with_name(base) / "Cleanup_review.xlsx", s.with_name(base + ".xlsx")]
        cands = list(adjacent)
        if self.explicit is not None:
            p = self.explicit
            cands += ([p / "Cleanup_review.xlsx"] + _glob(p, "*round*_review_*.xlsx")) if p.is_dir() else [p]
        if digest:   # the fingerprint binds the file, so anywhere the consultant keeps it will do
            for d in dict.fromkeys([self.xlsx.parent, self.xlsx.parent.parent]):
                cands += _glob(d, "*/Cleanup_review.xlsx", 50) + _glob(d, "*round*_review_*.xlsx", 50) \
                    + _glob(d, "*/*round*_review_*.xlsx", 50)
            for root in self.roots:
                try:
                    cands += sorted(root.rglob("Cleanup_review.xlsx"))[:50] + sorted(root.rglob("*round*_review_*.xlsx"))[:50]
                except OSError:
                    pass
        seen = set()
        for p in cands:
            try:
                key = str(p.resolve())
            except OSError:
                continue
            if key in seen or not p.is_file() or _same_file(p, self.xlsx):
                continue
            seen.add(key)
            if not self._identity_ok(p):
                continue
            if digest and M.file_sha(p) != digest:
                continue
            self._path = p
            if not digest:
                self.notes.append("This kit's side-car has no fingerprint of the workbook that was issued (made before "
                                  "1.6.0), so the original was taken from the kit folder next to the side-car "
                                  f"({p.parent.name}) without a fingerprint check.")
            break
        if self._path is None:
            self._why = ("I couldn't find the original Cleanup_review.xlsx for this kit"
                         if self.explicit is None else
                         f"\"{self.explicit}\" isn't the original of this workbook (a different kit, a re-saved copy, or "
                         "its hidden record doesn't match)")
        return self._path

    @property
    def why(self) -> str:
        return self._why


# ------------------------------------------------------------------ the replay guard

def _load_rounds(p: Path):
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(d, dict) and isinstance(d.get("rounds"), dict):
            return d
    except (OSError, ValueError):
        pass
    return None


def later_round(paths, root: str, this_round: int):
    """The newest round issued after this one for the same root kit (from any rounds file), or 0."""
    best = 0
    for p in paths:
        d = _load_rounds(p) if p else None
        if not d or _s(d.get("root_kit_id")) != _s(root):
            continue
        for k, ids in d["rounds"].items():
            try:
                n = int(k)
            except ValueError:
                continue
            if n > this_round and ids:
                best = max(best, n)
    return best


def replay_message(later: int, this_round: int) -> str:
    return (f"A round {later} was already sent for this kit: rows answered in round {this_round} may already be "
            "loaded. Apply only the newest round.")


def _archive_root(orig_side: Path) -> Path:
    """Where follow-ups are archived: ONE flat folder per root kit, <root kit>.rounds/<kit id>/. A rounds file next to
    the original's side-car remembers it, so round 3 and later are filed beside round 2, not inside it."""
    rd = _load_rounds(rounds_of(orig_side))
    ar = Path(rd["archive_root"]) if rd and rd.get("archive_root") else None
    return ar if ar is not None and ar.parent.is_dir() else archive_of(orig_side)


def _record(paths, root: str, parent_data, round_no: int, kit_id: str, archive_root=None):
    """Add the issued kit id to every rounds file (never fails the run: a read-only place is skipped quietly)."""
    base = {"root_kit_id": root, "rounds": {}}
    for k, v in ((parent_data or {}).get("rounds") or {}).items():
        base["rounds"][k] = list(v)
    ids = base["rounds"].setdefault(str(round_no), [])
    if kit_id not in ids:
        ids.append(kit_id)
    for p in paths:
        try:
            cur = _load_rounds(p)
            data = {"root_kit_id": root, "rounds": {k: list(v) for k, v in base["rounds"].items()}}
            if archive_root is not None:
                data["archive_root"] = str(archive_root)
            if cur and _s(cur.get("root_kit_id")) == _s(root):
                for k, v in cur["rounds"].items():
                    have = data["rounds"].setdefault(k, [])
                    have.extend(i for i in v if i not in have)
            p.write_text(json.dumps(data, sort_keys=True), encoding="utf-8")
        except OSError:
            pass


# ------------------------------------------------------------------ reading the original

def _grab(ws):
    rows = list(ws.iter_rows())
    if not rows:
        return [], []
    cols = [_s(c.value) for c in rows[0]]
    out = []
    for row in rows[1:]:
        if all(c.value is None or _s(c.value) == "" for c in row):
            continue
        out.append({h: row[i].value if i < len(row) else None for i, h in enumerate(cols) if h})
    return [c for c in cols if c], out


def _users(man: dict):
    users, ambiguous = {}, set()
    for label, uid in man.get("users") or []:
        k = re.sub(r"\s+", " ", _s(label)).lower()
        if k in users and users[k][1] != _s(uid):
            ambiguous.add(k)
        users[k] = (_s(label), _s(uid) or _s(label))
    return users, ambiguous


def _valid_owner(who, users, ambiguous, crm):
    """The label to show for a drafted New owner, or None if it isn't an active user (same rule as apply-review)."""
    who = re.sub(r"\s+", " ", _s(who))
    if not who:
        return None
    if users:
        k = who.lower()
        return users[k][0] if k in users and k not in ambiguous else None
    return None if crm == "salesforce" else who


def _df(cols, rows):
    return pd.DataFrame([[r.get(c) for c in cols] for r in rows], columns=cols, dtype=object)


def make(*, xlsx, man, client, audit_date, folder, sidecars, original, roots, keep_dir, ans, blank, declined_fills,
         drafts, warnings, round_no, root_id) -> dict:
    """Build the follow-up workbook into `folder`. Returns {"status": "written" | "nothing" | "missing_original" |
    "error", ...}. Never raises: a problem here must not stop apply-review's own output."""
    loc = Locator(xlsx, man, sidecars, original, roots)
    try:
        orig = loc.original()
        if orig is None:
            return {"status": "missing_original", "message": loc.why + f". To get a follow-up workbook: {HELP}.",
                    "locator": loc}
        return _build(orig, loc, man, client, folder, ans, blank, declined_fills, drafts, warnings, round_no, root_id,
                      keep_dir)
    except Exception as e:  # noqa: BLE001 - the ready-to-load folder is the important output; say what happened
        return {"status": "error", "message": f"I couldn't build the follow-up workbook ({type(e).__name__}: {e}).",
                "locator": loc}


def _build(orig: Path, loc, man, client, folder, ans, blank, declined_fills, drafts, warnings, round_no, root_id,
           keep_dir) -> dict:
    import openpyxl

    ENT = man["entries"]
    crm = _s(man.get("crm"))
    wb = openpyxl.load_workbook(orig, data_only=False)
    sheets = {n: _grab(wb[n]) for n in wb.sheetnames if n in SPEC}
    info = {_s(r[0]): r[1] for r in wb["_kit"].iter_rows(values_only=True) if r and r[0] is not None}
    users, ambiguous = _users(man)

    def un(sheet, key):
        return (sheet, key) not in ans

    problems: dict = {}   # sheet -> rows that were neither answered nor validly blank

    def note(sheet, key):
        if (sheet, key) not in blank:
            problems[sheet] = problems.get(sheet, 0) + 1

    # ---- Merges first: fill-before-merge values follow them
    mcols, mrows = sheets.get("Merges", ([], []))
    mrows_in = [(i, r) for i, r in enumerate(mrows) if un("Merges", _s(r.get("Merge key")))]
    merges_in = {_s(r.get("Merge key")) for _, r in mrows_in}
    # the hidden group list, for the merges that come back
    grp_rows = {}
    if "_groups" in wb.sheetnames:
        gc, gr = _grab(wb["_groups"])
        for r in gr:
            grp_rows.setdefault(_s(r.get("Merge key")), []).append(r)

    # ---- Field fixes
    fcols, frows = sheets.get("Field fixes", ([], []))
    quick_cols, quick_rows = sheets.get("Quick approve", ([], []))
    qkeys_in = {}   # group key -> change ids of its rows that come back
    ff_in = []
    for r in frows:
        cid = _s(r.get("Change ID"))
        ent = ENT.get(cid)
        if ent is None:
            continue
        if _s(r.get("Kind")) == "fill":
            if _s(r.get("Merge key")) in merges_in and ("Field fixes", cid) not in declined_fills:
                ff_in.append(r)
        elif un("Field fixes", cid):
            ff_in.append(r)
            note("Field fixes", cid)
            if ent.get("q"):
                qkeys_in.setdefault(ent["q"], []).append(cid)
    quick_back = {k for k, ids in qkeys_in.items() if un("Quick approve", k) and ids}
    for k in quick_back:
        note("Quick approve", k)

    # ---- single decision sheets
    def pick(name, keycol):
        cols, rows = sheets.get(name, ([], []))
        keep = []
        for r in rows:
            k = _s(r.get(keycol))
            if k in ENT and un(name, k):
                keep.append(r)
                note(name, k)
        return cols, keep

    vcols, vrows = pick("Values to clear", "Change ID")
    ocols, orows = pick("Owners", "Change ID")
    lcols, lrows = pick("Leads to convert", "Change ID")
    dcols, drows = pick("Delete", "Change ID")
    for _, r in mrows_in:
        note("Merges", _s(r.get("Merge key")))

    # ---- Group decisions, rebuilt over the remaining members (same rules as the kit's own grouping)
    new_groups, gkey_of_row = [], {}
    if "Group decisions" in sheets and (vrows or orows):
        kit = C.Kit(crm=crm)
        kit.users = [(u[0], u[1]) for u in man.get("users") or []]   # owner groups need the kit's active-user list
        kit.changes = [{"Kind": "clear", "Object": r.get("Object"), "Field": r.get("Field"), "Why": r.get("Why"),
                        "Current value": r.get("Current value"), "Change ID": _s(r.get("Change ID")),
                        "Name": r.get("Name")} for r in vrows]
        kit.owners = [{"Problem": r.get("Problem"), "Current owner ID": r.get("Current owner ID"),
                       "Current owner": r.get("Current owner"), "Object": r.get("Object"), "Name": r.get("Name"),
                       "Change ID": _s(r.get("Change ID"))} for r in orows]
        new_groups = C.decision_groups(kit)
        for g in new_groups:
            g["old"] = ENT.get(g["ids"][0], {}).get("g", "")
            for cid in g["ids"]:
                gkey_of_row[cid] = g

    # ---- build the tables (original values, in the original order) and the new manifest entries
    ent_out: dict = {}
    tables: dict = {}
    has_gcols = "Group key" in vcols or "Group key" in ocols

    def add(name, cols, rows):
        if rows:
            tables[name] = (_df(cols, rows), *[[c for c in lst if c in cols] for lst in SPEC[name]])

    # Quick approve
    if quick_back:
        qrows = []
        for r in quick_rows:
            k = _s(r.get("Group key"))
            if k in quick_back:
                ids = qkeys_in[k]
                r = dict(r)
                r["Approve all"], r["Changes"], r["Members"] = "", len(ids), C.members_hash(ids)
                qrows.append(r)
                e = dict(ENT[k])
                e["n"], e["m"] = str(len(ids)), C.members_hash(ids)
                ent_out[k] = e
        add("Quick approve", quick_cols, qrows)
    # Field fixes
    frows_out = []
    for r in ff_in:
        cid = _s(r.get("Change ID"))
        r = dict(r)
        e = dict(ENT[cid])
        q = e.get("q", "")
        if q and q in quick_back:   # the group comes back: the row still follows it (pre-approved, as the kit wrote it)
            pass
        else:
            e["q"] = ""
            r["Approve"] = ""
        ent_out[cid] = e
        frows_out.append(r)
    add("Field fixes", fcols, frows_out)
    # Group decisions
    if new_groups:
        gd_cols = sheets["Group decisions"][0]
        grows = []
        for g in new_groups:
            draft = ""
            if g["kind"] == "New owner":
                draft = _valid_owner(drafts.get(("Group decisions", g["old"])), users, ambiguous, crm) or ""
            grows.append({"Approve": "", "Kind": g["kind"], "What": g["what"], "Records": g["n"], "New owner": draft,
                          "Examples": ", ".join(g["examples"]), "Group key": g["key"],
                          "Members hash": C.members_hash(g["ids"])})
            e = M.entry("Group decisions", g["obj"], g["key"], g["field"], g["what"], g["kind"], "dgroup")
            e["n"], e["m"] = str(g["n"]), C.members_hash(g["ids"])
            ent_out[g["key"]] = e
        add("Group decisions", gd_cols, grows)
    # Values to clear / Owners
    out_v = []
    for r in vrows:
        cid = _s(r.get("Change ID"))
        r, e = dict(r), dict(ENT[cid])
        g = gkey_of_row.get(cid)
        r["Approve"], e["g"] = "", g["key"] if g else ""
        if has_gcols:
            r["Group"], r["Group key"] = (g["label"], g["key"]) if g else ("", "")
        ent_out[cid] = e
        out_v.append(r)
    add("Values to clear", vcols, out_v)
    out_o = []
    for r in orows:
        cid = _s(r.get("Change ID"))
        r, e = dict(r), dict(ENT[cid])
        g = gkey_of_row.get(cid)
        r["Approve"], e["g"] = "", g["key"] if g else ""
        pick_owner = _valid_owner(drafts.get(("Owners", cid)), users, ambiguous, crm)
        if pick_owner:
            r["New owner"] = pick_owner
        if has_gcols:
            r["Group"], r["Group key"] = (g["label"], g["key"]) if g else ("", "")
        ent_out[cid] = e
        out_o.append(r)
    add("Owners", ocols, out_o)
    # Merges (+ Merge details, + the hidden group list)
    merge_groups, row_map = [], {}
    out_m = []
    for i, r in mrows_in:
        k = _s(r.get("Merge key"))
        r = dict(r)
        r["Approve"] = ""
        rows_g = grp_rows.get(k, [])
        ids = [_s(x.get("ID")) for x in rows_g]
        keep = _s(drafts.get(("Merges", k)))
        if keep and keep in ids:
            r["Keep ID"] = keep
        out_m.append(r)
        row_map[i + 2] = len(out_m) + 1
        ent_out[k] = dict(ENT[k])
        merge_groups.append({"key": k, "object": _s(rows_g[0].get("Object")) if rows_g else "", "ids": ids,
                             "names": {_s(x.get("ID")): x.get("Name") for x in rows_g},
                             "keep": next((_s(x.get("ID")) for x in rows_g if _s(x.get("Suggested keep")) == "Yes"), ""),
                             "same": {_s(x.get("ID")): _s(x.get("Same person")) == "Yes" for x in rows_g},
                             "fill": {_s(x.get("ID")): json.loads(_s(x.get("Fill values")) or "{}") for x in rows_g}})
    add("Merges", mcols, out_m)
    if out_m and "Merge details" in sheets:
        dcols_, drows_ = sheets["Merge details"]
        ws_d = wb["Merge details"]
        det, marks = [], set()
        for n, r in enumerate(drows_):
            try:
                tab_row = int(float(_s(r.get("Merges tab row"))))
            except ValueError:
                continue
            if tab_row not in row_map:
                continue
            r = dict(r)
            r["Merges tab row"] = row_map[tab_row]
            for j, c in enumerate(dcols_):
                cell = ws_d.cell(n + 2, j + 1)
                if cell.fill is not None and cell.fill.fgColor is not None and str(cell.fill.fgColor.rgb).endswith(ORANGE):
                    marks.add((len(det), c))
            det.append(r)
        if det:
            tables["Merge details"] = (_df(dcols_, det), [], [])
            tables["Merge details"][0].attrs["highlight"] = marks
    add("Leads to convert", lcols, lrows)
    add("Delete", dcols, drows)
    # Rep to-do: ONLY the "close this duplicate deal" task of a deal merge that is back in this round (round 1 left it
    # out because the merge was unanswered). The row carries just that task, so approving the merge now releases it
    # without repeating what round 1 already gave the rep. No other rep to-dos, and no Enrich.
    rcols, rrows = sheets.get("Rep to-do", ([], []))
    rep_rows = [dict(r, **{"To do": _s(r.get("Conditional task"))}) for r in rrows
                if _s(r.get("Conditional task")) and _s(r.get("Merge key")) in merges_in]
    add("Rep to-do", rcols, rep_rows)
    for r in lrows:
        ent_out[_s(r.get("Change ID"))] = dict(ENT[_s(r.get("Change ID"))])
    for r in drows:
        ent_out[_s(r.get("Change ID"))] = dict(ENT[_s(r.get("Change ID"))])

    decision_tabs = [n for n in C.DECISION_TABS if n in tables]
    if not decision_tabs:
        return {"status": "nothing"}

    # ---- what the client will read on Start here
    n_q = len(tables["Quick approve"][0]) if "Quick approve" in tables else 0
    n_g = len(new_groups)
    members = sum(g["n"] for g in new_groups)
    decisions = len(out_v) + len(out_o) + len(out_m) + len(lrows) + len(drows)
    answers = decisions - members + n_g
    items = n_q + answers
    prev = "first review" if round_no <= 1 else f"round {round_no} review"
    nxt = round_no + 1
    kc = {"quick_groups": n_q, "groups": n_g, "decisions": decisions, "answers": answers,
          "fill": {"changes": sum(1 for r in frows_out if _s(r.get("Kind")) == "fill")}}
    kc["minutes"] = C.review_minutes(n_q, decisions, answers, n_g)
    headline = f"Round {nxt}: {items:,} item{'s' if items != 1 else ''} left from your {prev}."

    # ---- identity of the new kit (the same answers always give the same id, so a re-run doesn't change it)
    parent = _s(man.get("kit_id"))
    # (the cells too: carried drafts differ, and a different workbook must never re-use an archived one)
    cells = M.h(json.dumps({n: [[_s(v) for v in row] for row in t[0].itertuples(index=False)]
                            for n, t in sorted(tables.items())}))
    kit_id = uuid.uuid5(uuid.NAMESPACE_URL, f"uroboric-round|{parent}|{nxt}|" + ",".join(sorted(ent_out))
                        + "|" + cells).hex
    audit_date = dt.date.fromisoformat(_s(man.get("audit_date")))
    new_man = {"kit_id": kit_id, "client": _s(man.get("client")), "audit_date": _s(man.get("audit_date")), "crm": crm,
               "entries": ent_out,
               "tables": ({"Rep to-do": M.table_hash(list(tables["Rep to-do"][0].columns),
                                                     tables["Rep to-do"][0].itertuples(index=False))}
                          if "Rep to-do" in tables else {}), "users": man.get("users") or [], "meta": man.get("meta") or {},
               "parent_kit_id": parent, "root_kit_id": root_id, "round": nxt}
    kit = C.Kit(crm=crm, users=[tuple(u) for u in (man.get("users") or [])], meta=man.get("meta") or {},
                merge_groups=merge_groups, kit_id=kit_id)
    white = bool(_s(info.get("white_label")))
    b = None
    if white or _s(info.get("prepared_by")) or _s(info.get("contact")):
        b = SimpleNamespace(prepared_by=_s(info.get("prepared_by")), contact=_s(info.get("contact")),
                            white_label=white, tool_name="" if white else "Uroboric ")
    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(client)).strip("_") or "client"
    name = f"{slug}_round{nxt}_review_{audit_date:%Y-%m-%d}.xlsx"
    path = Path(folder) / name
    side = path.with_name(path.stem + SIDE)
    orig_side = side_of(orig)
    # Every issued workbook + side-car is archived by kit id, never touched by output-folder cleanup: a follow-up that is
    # still with the client can always be found again. Issuing the same kit again re-uses the archived copy (same bytes,
    # same fingerprint) instead of overwriting what the client holds.
    arch_root = _archive_root(orig_side)
    arch = arch_root / kit_id
    kept = True
    if (C._long_path(arch) / name).is_file() and (C._long_path(arch) / side.name).is_file():
        shutil.copy2(C._long_path(arch) / name, path)
        shutil.copy2(C._long_path(arch) / side.name, side)
    else:
        C.write_review_workbook(kit, path, _s(man.get("client")) or client, audit_date, b, tables=tables,
                                manifest=new_man,
                                extra_info={"parent_kit_id": parent, "root_kit_id": root_id, "round": nxt},
                                round2={"headline": headline, "kc": kc})
        side.write_text(json.dumps({**new_man, M.DIGEST_KEY: M.file_sha(path)}, sort_keys=True, separators=(",", ":")),
                        encoding="utf-8")
        for dest in [arch] + ([Path(keep_dir) / kit_id] if keep_dir is not None else []):   # (the iPad: rounds/<kit id>/)
            try:
                dest = C._long_path(dest)
                dest.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, dest / name)
                shutil.copy2(side, dest / side.name)
            except OSError:
                kept = False

    # ---- remember the round (next to the original's side-car, and next to the new one for the next round)
    parent_data = _load_rounds(rounds_of(orig_side))
    _record([rounds_of(orig_side), rounds_of(side)], root_id, parent_data, nxt, kit_id, arch_root)
    try:   # the rounds file travels with the archived pair, so a later round finds the same archive
        shutil.copy2(rounds_of(side), C._long_path(arch) / rounds_of(side).name)
    except OSError:
        pass
    if not kept:
        warnings.insert(0, f"I couldn't keep a copy of the follow-up for checking its return: keep {name} and "
                           f"{side.name} (in this folder) and run apply-review on the client's reply with "
                           "--original <this folder>.")
    warnings.extend(loc.notes)
    for sheet_name, n in problems.items():
        warnings.append(f"Round {nxt}: {n:,} row{'s' if n != 1 else ''} on '{sheet_name}' were deleted or changed in the "
                        "returned workbook (or couldn't be used), so they were taken from the original kit and are "
                        f"included again in {name}.")
    return {"status": "written", "name": name, "path": str(path), "round": nxt, "items": items, "kit_id": kit_id,
            "sheets": {n: len(t[0]) for n, t in tables.items()}, "locator": loc,
            "original": str(orig), "message": ""}
