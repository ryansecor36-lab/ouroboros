"""The plain-English, at-a-glance report: one self-contained HTML page that opens in any browser
and prints cleanly to PDF. It follows the checklist's readout: grade, cost, top problems,
quick wins, then every check in everyday language."""
from __future__ import annotations

from html import escape
from pathlib import Path

from .checklist import CHECKS, CHECKS_BY_ID, GRADES
from .branding import html_css
from .loader import TABLE_LABELS
from .plain import (fix_text, nice_date, AREAS, GRADE_PLAIN, PLAIN, RATING, RATING_ICON, money, quick_wins,
                    top_problems)

SMALL_SAMPLE = 100  # fewer contacts than this and the percentages aren't very meaningful

CSS = """
:root{
  --ink:#1d2433; --muted:#5b6474; --faint:#8a93a3; --line:#e3e7ee; --bg:#f4f6f9; --card:#fff;
  --navy:#1f3a5f;
  --good:#1a7f37; --good-bg:#e5f4ea; --warn:#946200; --warn-bg:#fff3d1; --bad:#c0392b; --bad-bg:#fde9e7;
  --none:#6b7280; --none-bg:#eef0f3;
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 "Segoe UI",system-ui,-apple-system,Roboto,Helvetica,Arial,sans-serif}
.page{max-width:980px;margin:0 auto;padding:32px 20px 48px}
h1,h2,h3{line-height:1.25;margin:0}
h2{font-size:22px;margin-bottom:6px}
.lede{color:var(--muted);margin:0 0 18px}
section{margin-top:36px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px 24px}

/* header */
.eyebrow{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--navy);font-weight:600}
.top h1{font-size:30px;margin-top:4px}
.meta{color:var(--muted);font-size:14px;margin-top:4px}
.banner{margin-top:14px;background:var(--warn-bg);color:#6b4700;border-radius:10px;padding:10px 14px;font-size:14px}

/* grade */
.hero{display:grid;grid-template-columns:auto 1fr;gap:28px;align-items:center;margin-top:24px}
.grade{width:150px;height:150px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff}
.grade .letter{font-size:68px;font-weight:700;line-height:1}
.grade .num{font-size:15px;opacity:.95;margin-top:4px}
.g-A{background:var(--good)} .g-B{background:#4f8f2f} .g-C{background:#d08a00} .g-D{background:var(--bad)}
.verdict h2{font-size:24px}
.verdict p{color:var(--muted);margin:8px 0 0}
.scale{display:flex;gap:6px;margin-top:16px;flex-wrap:wrap}
.scale span{font-size:13px;padding:4px 10px;border-radius:999px;background:var(--none-bg);color:var(--muted)}
.scale span.on{color:#fff;font-weight:600}
.scale .on.s-A{background:var(--good)} .scale .on.s-B{background:#4f8f2f} .scale .on.s-C{background:#d08a00} .scale .on.s-D{background:var(--bad)}

/* money tiles */
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px}
.tile{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px}
.tile .val{font-size:30px;font-weight:700;color:var(--ink)}
.tile .val small{font-size:15px;font-weight:500;color:var(--muted)}
.tile .lbl{font-weight:600;margin-top:2px}
.tile .sub{color:var(--muted);font-size:14px;margin-top:4px}
.tile.main{border-left:6px solid var(--bad)}

/* areas */
.area{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr) 120px;gap:16px;align-items:center;padding:12px 0;border-bottom:1px solid var(--line)}
.area:last-child{border-bottom:0}
.area .name{font-weight:600}
.area .desc{color:var(--muted);font-size:14px}
.bar{height:12px;background:var(--none-bg);border-radius:999px;overflow:hidden}
.bar i{display:block;height:100%;border-radius:999px}
.fill-2{background:var(--good)} .fill-1{background:#e0a400} .fill-0{background:var(--bad)}

/* pills */
.pill{display:inline-flex;align-items:center;gap:6px;font-size:13px;font-weight:600;padding:3px 10px;border-radius:999px;white-space:nowrap}
.pill b{font-size:14px}
.r-2{background:var(--good-bg);color:var(--good)} .r-1{background:var(--warn-bg);color:var(--warn)}
.r-0{background:var(--bad-bg);color:var(--bad)} .r-n{background:var(--none-bg);color:var(--none)}

/* problems */
.problems{display:grid;gap:14px}
.problem{border-left:6px solid var(--bad)}
.problem.sev-1{border-left-color:#e0a400}
.problem h3{font-size:19px;margin:8px 0 4px}
.problem .found{font-size:17px}
.problem dl{display:grid;grid-template-columns:150px 1fr;gap:8px 16px;margin:14px 0 0}
.problem dt{color:var(--muted);font-size:14px;font-weight:600}
.problem dd{margin:0}
.example{font-style:italic}
.where{color:var(--faint);font-size:13px;margin-top:12px}

/* wins */
.wins{counter-reset:w;list-style:none;padding:0;margin:0;display:grid;gap:12px}
.wins li{counter-increment:w;display:grid;grid-template-columns:40px 1fr;gap:12px;align-items:start}
.wins li::before{content:counter(w);width:32px;height:32px;border-radius:50%;background:var(--navy);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700}
.wins .t{font-weight:600}
.wins .d{color:var(--muted);font-size:14px}

/* all checks */
.legend{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px}
.group{margin-top:16px}
.group h3{font-size:17px;display:flex;justify-content:space-between;gap:12px;align-items:baseline;padding-bottom:8px;border-bottom:2px solid var(--ink)}
.group h3 span{font-size:14px;font-weight:500;color:var(--muted)}
.row{display:grid;grid-template-columns:130px minmax(0,1fr) minmax(0,1.2fr) 170px;gap:14px;padding:12px 0;border-bottom:1px solid var(--line);align-items:start}
.row .title{font-weight:600}
.row .why{color:var(--muted);font-size:13.5px;margin-top:2px}
.row .ex{color:var(--muted);font-size:13.5px;font-style:italic;margin-top:2px}
.row .tgt{color:var(--muted);font-size:13.5px}
.row .tgt b{display:block;color:var(--faint);font-size:12px;text-transform:uppercase;letter-spacing:.05em;font-weight:600}
.row.unscored .title,.row.unscored .found{color:var(--muted)}

/* progress */
.progress{border-left:6px solid var(--none)}
.progress.up{border-left-color:var(--good)} .progress.down{border-left-color:var(--bad)}
.prog-head{font-size:19px;font-weight:600}
.prog-bar{padding:40px 8px 34px}
.prog-track{position:relative;height:10px;border-radius:999px;background:linear-gradient(90deg,var(--bad-bg),var(--warn-bg) 50%,var(--good-bg) 85%)}
.prog-track i{position:absolute;top:50%;width:18px;height:18px;margin:-9px 0 0 -9px;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 1px var(--line)}
.prog-track i span{position:absolute;bottom:24px;left:50%;transform:translateX(-50%);white-space:nowrap;font-size:13px;font-weight:600;font-style:normal}
.prog-track .then{background:var(--none)} .prog-track .then span{color:var(--muted);bottom:auto;top:24px}
.prog-track .now{background:var(--navy)} .prog-track .now span{color:var(--navy)}
.prog-cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px;margin-top:16px}
.prog-cols h3{font-size:15px;margin-bottom:6px}
.good-h{color:var(--good)} .bad-h{color:var(--bad)}
.prog-list{list-style:none;padding:0;margin:0;display:grid;gap:6px;font-size:14.5px}
.prog-list span{color:var(--muted);white-space:nowrap}

/* sources */
.src-head{font-size:18px;font-weight:600}
.src-sub{color:var(--muted);margin:8px 0 0}
table.src{margin-top:16px}
.mini{display:inline-block;width:90px;height:8px;background:var(--none-bg);border-radius:999px;overflow:hidden;margin-right:8px;vertical-align:middle}
.mini i{display:block;height:100%;background:var(--navy)}
.tag{font-size:11px;font-weight:600;color:var(--navy);background:#e6edf6;border-radius:999px;padding:1px 7px;margin-left:4px;white-space:nowrap}
@media (max-width:720px){table.src th:nth-child(3),table.src td:nth-child(3),table.src th:nth-child(5),table.src td:nth-child(5){display:none}.mini{width:50px}}

/* assumptions */
table{border-collapse:collapse;width:100%;font-size:14.5px}
td,th{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--muted);font-weight:600;font-size:13px;text-transform:uppercase;letter-spacing:.04em}
td.v{white-space:nowrap;font-weight:600}
footer .ver{margin-top:6px;font-size:11px;color:#9aa0a6}
footer{margin-top:40px;color:var(--faint);font-size:13px;border-top:1px solid var(--line);padding-top:14px}

@media (max-width:720px){
  .hero{grid-template-columns:1fr;justify-items:start}
  .area{grid-template-columns:1fr;gap:6px}
  .row{grid-template-columns:1fr;gap:4px}
  .problem dl{grid-template-columns:1fr;gap:2px}
  .problem dd{margin-bottom:8px}
  .top h1{font-size:26px}
}
@media print{
  body{background:#fff;font-size:12.5px}
  .page{padding:0;max-width:none}
  .card,.tile,.problem,.row,.area,.wins li{break-inside:avoid}
  section{margin-top:24px}
  .all{break-before:page}
}
"""


def _pill(score):
    cls = f"r-{score}" if score is not None else "r-n"
    return f'<span class="pill {cls}"><b>{RATING_ICON[score]}</b>{RATING[score]}</span>'


def _band(pct):
    return 2 if pct >= 0.85 else (1 if pct >= 0.5 else 0)


def _fte_text(fte):
    if fte >= 1:
        return f"about {fte:.1f} full-time reps doing nothing else"
    return f"about {fte * 100:.0f}% of one rep's working year"


def _money_tiles(impact):
    tiles = []
    if impact["cost"] is not None:
        tiles.append(("main", money(impact["cost"]), " a year", "Rep time wasted on bad data",
                      f"{impact['hours']:,.0f} hours of calls and emails that hit dead ends, "
                      f"{_fte_text(impact['fte'])}"))
    sub = {
        "Stale pipeline": ("Open deals that are stale", "Not lost money, but the forecast is overstated by this much"),
        "Pipeline counted twice": ("Deals counted twice", "The same deals appear more than once in the pipeline"),
        "Unworked leads": ("Possible sales from leads nobody followed up", "New leads from the last 90 days, at the usual win rate"),
    }
    for label, value, _ in impact["extras"]:
        if value is None:
            continue
        key = next((k for k in sub if label.startswith(k)), None)
        if key:
            tiles.append(("", money(value), "", *sub[key]))
    return tiles


def write_html(path: Path, client, audit_date, card, impact, results, data, detail_sheets, workbook_name,
               sources=None, cleanup=None, progress=None, crm=None, branding=None):
    from .crms import NAMES, detect
    crm = crm or detect(data)
    crm_name = NAMES[crm]
    weights = {c.number: c.weight for c in card.categories}
    e = escape
    out = []
    w = out.append
    brand = branding if branding is not None and branding.active else None
    tool = brand.tool_name if brand else "Uroboric "
    w(f"<!doctype html><html lang='en'><head><meta charset='utf-8'>"
      f"<meta name='viewport' content='width=device-width,initial-scale=1'>"
      f"<title>{e(str(client))} - {tool}CRM Health Report</title><style>{CSS}{html_css(brand) if brand else ''}</style>"
      "</head><body><main class='page'>")

    # Header
    counts = ", ".join(f"{len(t):,} {TABLE_LABELS[k].lower()}" for k, t in data.items()
                       if k in ("contacts", "accounts", "opportunities", "leads"))
    w("<header class='top'>")
    if brand and (brand.logo_bytes or brand.prepared_by):
        logo = f"<img src='{brand.logo_uri}' alt='{e(brand.prepared_by or 'Logo')}'>" if brand.logo_bytes else ""
        prep = f"<div class='prep'>Prepared by <b>{e(brand.prepared_by)}</b></div>" if brand.prepared_by else ""
        w(f"<div class='brandbar'>{logo}{prep}</div>")
    eyebrow = f"{tool.replace(' ', '')} &middot; " if tool else ""
    w(f"<div class='eyebrow'>{eyebrow}CRM Data Health Report</div>"
      f"<h1>{e(str(client))}</h1><div class='meta'>{e(crm_name)} &middot; {nice_date(audit_date)} &middot; "
      f"Reviewed {e(counts)}</div>")
    if card.unscored:
        w(f"<div class='banner'><b>Preliminary.</b> {card.unscored} of {len(CHECKS)} checks are still being "
          "reviewed, so the grade may change.</div>")
    contacts = data.get("contacts")
    if contacts is not None and 0 < len(contacts) < SMALL_SAMPLE:
        n = len(contacts)
        w(f"<div class='banner'><b>Small sample.</b> Only {n:,} {'contact was' if n == 1 else 'contacts were'} "
          "reviewed, so each record moves the percentages a lot. Treat the grade as a rough guide.</div>")
    for note in getattr(data, "warnings", []):
        w(f"<div class='banner'><b>Heads up.</b> {e(note)}</div>")
    w("</header>")

    # Grade
    if card.overall is not None:
        w(f"<section class='hero'><div class='grade g-{card.grade}'><div class='letter'>{card.grade}</div>"
          f"<div class='num'>{card.overall:.0f} out of 100</div></div><div class='verdict'>"
          f"<h2>{e(GRADE_PLAIN[card.grade])}</h2>"
          "<p>The grade combines six areas of data quality, weighted by how much each one affects the sales team.</p>"
          "<div class='scale'>")
        hi = 100
        for floor, letter, _ in GRADES:
            rng = f"{floor}-{hi}" if floor else f"under {GRADES[-2][0]}"
            on = " on" if letter == card.grade else ""
            w(f"<span class='s-{letter}{on}'>{letter} &middot; {rng}</span>")
            hi = floor - 1
        w("</div></div></section>")

    # Progress since the last audit
    if progress:
        p = progress
        d = p["score_change"]
        cls = "up" if d and d > 0 else ("down" if d and d < 0 else "flat")
        w(f"<section><h2>Since the last audit</h2><div class='card progress {cls}'>"
          f"<div class='prog-head'>{e(p['headline'])}</div>")
        if p["score_before"] is not None and p["score_now"] is not None:
            w("<div class='prog-bar'><div class='prog-track'>"
              f"<i class='then' style='left:{p['score_before']:.0f}%'><span>Before {p['grade_before']} &middot; {p['score_before']:.0f}</span></i>"
              f"<i class='now' style='left:{p['score_now']:.0f}%'><span>Now {p['grade_now']} &middot; {p['score_now']:.0f}</span></i>"
              "</div></div>")
        if p["cost_sentence"]:
            w(f"<p class='src-sub'>{e(p['cost_sentence'])}.</p>")
        for note in p.get("notes", []):
            w(f"<p class='src-sub'>Note: {e(note)}</p>")
        cols = []
        if p["better"]:
            items = "".join(f"<li><b>{e(r['Check'])}</b> <span>{e(r['Before'])} &rarr; {e(r['Now'])}</span></li>"
                            for r in p["better"][:5])
            cols.append(f"<div><h3 class='good-h'>Got better ({len(p['better'])})</h3><ul class='prog-list'>{items}</ul></div>")
        if p["worse"]:
            items = "".join(f"<li><b>{e(r['Check'])}</b> <span>{e(r['Before'])} &rarr; {e(r['Now'])}</span></li>"
                            for r in p["worse"][:5])
            cols.append(f"<div><h3 class='bad-h'>Got worse ({len(p['worse'])})</h3><ul class='prog-list'>{items}</ul></div>")
        if cols:
            w(f"<div class='prog-cols'>{''.join(cols)}</div>")
        w("</div></section>")

    # Money
    tiles = _money_tiles(impact)
    if tiles:
        w("<section><h2>What bad data is costing the team</h2>"
          "<p class='lede'>Estimates are deliberately conservative. The assumptions are listed at the end of this report.</p>"
          "<div class='tiles'>")
        for cls, val, unit, lbl, sub in tiles:
            w(f"<div class='tile {cls}'><div class='val'>{e(val)}<small>{e(unit)}</small></div>"
              f"<div class='lbl'>{e(lbl)}</div><div class='sub'>{e(sub)}</div></div>")
        w("</div></section>")

    # Areas
    w("<section><h2>Score by area</h2><p class='lede'>The longer and greener the bar, the healthier that area is.</p>"
      "<div class='card'>")
    for c in card.categories:
        name, desc = AREAS[c.number]
        if c.pct is None:
            bar, label = "<div class='bar'></div>", _pill(None)
        else:
            b = _band(c.pct)
            bar = f"<div class='bar'><i class='fill-{b}' style='width:{max(c.pct * 100, 2):.0f}%'></i></div>"
            label = _pill(b)
        w(f"<div class='area'><div><div class='name'>{e(name)}</div><div class='desc'>{e(desc)}</div></div>"
          f"{bar}<div>{label}</div></div>")
    w("</div></section>")

    # Top problems
    tops = top_problems(results, weights)
    if tops:
        w(f"<section><h2>The {len(tops)} biggest problems</h2>"
          "<p class='lede'>These hurt the score most and are worth fixing first.</p><div class='problems'>")
        for cid in tops:
            r, (title, why, fix) = results[cid], PLAIN[cid]
            w(f"<div class='card problem sev-{r.score}'>{_pill(r.score)}<h3>{e(title)}</h3>"
              f"<div class='found'>{e(r.headline)}</div><dl>")
            if r.example:
                w(f"<dt>Example from your CRM</dt><dd class='example'>{e(r.example)}</dd>")
            w(f"<dt>Why it matters</dt><dd>{e(why)}</dd><dt>How to fix it</dt><dd>{e(fix_text(cid, crm))}</dd>"
              f"<dt>Healthy looks like</dt><dd>{e(CHECKS_BY_ID[cid].target)}</dd></dl>")
            if detail_sheets.get(cid):
                w(f"<div class='where'>Full list: sheet &ldquo;{e(detail_sheets[cid][0])}&rdquo; in {e(workbook_name)}</div>")
            w("</div>")
        w("</div></section>")

    # Where the bad data comes from
    if sources:
        w("<section><h2>Where the bad data comes from</h2>"
          "<p class='lede'>Cleaning up only lasts if the source is fixed. Every problem record "
          f"({e(sources['traced'])}) was traced back to whoever, or whatever tool, created it.</p><div class='card'>"
          f"<div class='src-head'>{e(sources['headline'])}</div>")
        if sources["integration_share"] >= 1 and not (
                sources["top_is_integration"] and abs(sources["integration_share"] - sources["top_share"]) < 1):
            w(f"<p class='src-sub'>Automated tools and integrations created {sources['integration_share']:.0f}% "
              "of all problem records. People created the rest.</p>")
        if sources["trend"]:
            w(f"<p class='src-sub'>{e(sources['trend']['sentence'])}</p>")
        bc = sources["by_creator"].head(6)
        w("<table class='src'><tr><th>Created by</th><th>Share of all problems</th><th>Records created</th>"
          "<th>Have a problem</th><th>Most common</th></tr>")
        for _, x in bc.iterrows():
            tag = " <span class='tag'>integration</span>" if x["Automated integration"] else ""
            w(f"<tr><td>{e(str(x['Created by']))}{tag}</td>"
              f"<td><div class='mini'><i style='width:{max(x['Share of all problems %'], 1):.0f}%'></i></div>"
              f"{x['Share of all problems %']:.0f}%</td><td>{int(x['Records created']):,}</td>"
              f"<td>{x['Problem rate %']:.0f}%</td><td>{e(x['Most common problems'])}</td></tr>")
        w("</table>")
        bs = sources["by_source"]
        if bs is not None and len(bs) > 1:
            worst = bs.iloc[0]
            best = bs.iloc[-1]
            w(f"<p class='src-sub'>By lead source: records from <b>{e(str(worst['Lead source']))}</b> have problems "
              f"{worst['Problem rate %']:.0f}% of the time, compared with {best['Problem rate %']:.0f}% for "
              f"<b>{e(str(best['Lead source']))}</b>.</p>")
        w(f"<div class='where'>Full breakdown: sheet &ldquo;Where bad data comes from&rdquo; in {e(workbook_name)}</div>"
          "</div></section>")

    # Quick wins
    wins = quick_wins(results, sources=sources, crm=crm)
    if wins:
        w("<section><h2>Quick wins for this week</h2>"
          "<p class='lede'>Things the team can fix on its own, without a big project.</p>"
          "<div class='card'><ol class='wins'>")
        for _, title, detail in wins:
            w(f"<li><div><div class='t'>{e(title)}</div><div class='d'>{e(detail)}</div></div></li>")
        w("</ol></div></section>")

    # Cleanup kit
    if cleanup and (cleanup["ready"] or cleanup["decide"] or cleanup["enrich"]):
        w("<section><h2>The fixes are already prepared</h2>"
          "<p class='lede'>The audit also produced a cleanup kit. Nothing changes in your CRM until your team "
          "reviews and approves each file.</p><div class='tiles'>")
        for n, lbl, sub in (
                (cleanup["ready"], "fixes ready to load", "Names, phone formats, spellings and new owners, each shown as before and after"),
                (cleanup["decide"], "items for your team to decide", "Duplicate merges, leads to convert, junk to delete, deals for reps to update"),
                (cleanup["enrich"], "records that need fresh data", "Missing or outdated details to fill from a data provider, with your approval")):
            if n:
                w(f"<div class='tile'><div class='val'>{n:,}</div><div class='lbl'>{e(lbl)}</div>"
                  f"<div class='sub'>{e(sub)}</div></div>")
        w("</div></section>")

    # All checks
    w("<section class='all'><h2>Every check, in plain English</h2>"
      f"<p class='lede'>All {len(CHECKS)} checks, grouped by area.</p><div class='legend'>"
      f"{_pill(2)}<span>meets the healthy target</span>{_pill(1)}<span>close, but misses it</span>"
      f"{_pill(0)}<span>far from it</span></div>")
    for c in card.categories:
        name, _ = AREAS[c.number]
        scores = [results[x.id].score for x in CHECKS if x.category == c.number]
        parts = [(scores.count(2), "good"), (scores.count(1), "needs work"),
                 (scores.count(0), "problem" if scores.count(0) == 1 else "problems"),
                 (scores.count(None), "not checked yet")]
        summary = " &middot; ".join(f"{n} {label}" for n, label in parts if n)
        w(f"<div class='group'><h3>{e(name)}<span>{summary}</span></h3>")
        for chk in [x for x in CHECKS if x.category == c.number]:
            r, (title, why, _) = results[chk.id], PLAIN[chk.id]
            un = " unscored" if r.score is None else ""
            ex = f"<div class='ex'>{e(r.example)}</div>" if r.example and r.score != 2 else ""
            w(f"<div class='row{un}'><div>{_pill(r.score)}</div>"
              f"<div><div class='title'>{e(title)}</div><div class='why'>{e(why)}</div></div>"
              f"<div><div class='found'>{e(r.headline)}</div>{ex}</div>"
              f"<div class='tgt'><b>Healthy</b>{e(chk.target)}</div></div>")
        w("</div>")
    w("</section>")

    # Assumptions
    w("<section><h2>How the dollar figures were calculated</h2><div class='card'><table>"
      "<tr><th>Assumption</th><th>Value</th><th>Source</th></tr>")
    plain_inputs = {"A.": "Sales reps", "B.": "Calls and emails per rep per day", "C.": "Share of those hitting bad data",
                    "D.": "Minutes wasted per bad call or email", "E.": "Selling days per year",
                    "F.": "Cost of one rep-hour (pay and commission)"}
    for label, value, src in impact["inputs"]:
        k = label[:2]
        if value is None:
            v = "-"
        elif k == "C.":
            v = f"{value:g}%"
        elif k == "F.":
            v = money(value)
        else:
            v = f"{value:,.0f}"
        w(f"<tr><td>{e(plain_inputs.get(k, label))}</td><td class='v'>{e(v)}</td><td>{e(src)}</td></tr>")
    if impact["hours"] is not None:
        w(f"<tr><td><b>Rep time lost</b></td><td class='v'>{impact['hours']:,.0f} hrs</td>"
          "<td>Reps &times; calls per day &times; share bad &times; minutes &times; days &divide; 60</td></tr>")
    for label, value, how in impact["extras"]:
        w(f"<tr><td>{e(label)}</td><td class='v'>{e(money(value))}</td><td>{e(how)}</td></tr>")
    w("</table></div></section>")

    w(f"<footer>")
    if brand and brand.contact:
        who = f" {e(brand.prepared_by)}:" if brand.prepared_by else ""
        w(f"<div class='closing'><b>Questions?</b> Contact{who} {e(brand.contact)}</div>")
    w(f"Every record behind these numbers is listed in {e(workbook_name)}. "
      f"Prepared {nice_date(audit_date)}. This report contains customer data. Share it only with the client "
      "and delete it when the engagement ends.")
    if brand and brand.show_powered_by:
        w("<div class='powered'>Powered by Uroboric</div>")
    from .versions import stamp
    w(f"<div class='ver'>{e(stamp(bool(brand and brand.white_label)).replace('Made with ', ''))}</div>")
    w("</footer>")
    w("</main></body></html>")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(out), encoding="utf-8")
    return path
