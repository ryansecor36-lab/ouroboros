"""Loads audit.toml and fills in the checklist defaults."""
from __future__ import annotations

import copy
import tomllib
from pathlib import Path

from .checklist import DEFAULT_WEIGHTS

DEFAULTS = {
    "client": "Client",
    "crm": "Salesforce",
    "audit_date": None,
    "phone_region": "US",
    "weights": {str(k): v for k, v in DEFAULT_WEIGHTS.items()},
    "impact": {"minutes_per_bad_touch": 2, "selling_days": 230, "hourly_cost": 40},
    "measured": {},
    "manual_scores": {},
    "files": {},
    "columns": {},
}

TEMPLATE = Path(__file__).with_name("audit_template.toml")


def load_config(path: Path | None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    if path is None:
        return cfg
    with open(path, "rb") as f:
        user = tomllib.load(f)
    for k, v in user.items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        else:
            cfg[k] = v
    return cfg
