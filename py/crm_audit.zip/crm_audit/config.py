"""Loads audit.toml and fills in the checklist defaults."""
from __future__ import annotations

import copy
import tomllib
from pathlib import Path

from .checklist import DEFAULT_WEIGHTS

DEFAULTS = {
    "client": "Client",
    "crm": None,  # recognized from the export files unless named in audit.toml
    "audit_date": None,
    "phone_region": "US",
    "weights": {str(k): v for k, v in DEFAULT_WEIGHTS.items()},
    "impact": {"minutes_per_bad_touch": 2, "selling_days": 230, "hourly_cost": 40},
    "measured": {},
    "manual_scores": {},
    "files": {},
    "columns": {},
    # Put your own name, logo and colors on the reports (see audit_template.toml). All optional.
    "branding": {"prepared_by": "", "logo": "", "accent_color": "", "contact": "", "show_powered_by": True},
}

TEMPLATE = Path(__file__).with_name("audit_template.toml")


def load_config(path: Path | None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    if path is None:
        return cfg
    # utf-8-sig: Notepad and Windows PowerShell often start files with an invisible byte-order mark
    user = tomllib.loads(Path(path).read_text(encoding="utf-8-sig"))
    for k, v in user.items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        else:
            cfg[k] = v
    cfg["_base_dir"] = str(Path(path).resolve().parent)  # a relative logo path is looked up here
    return cfg
