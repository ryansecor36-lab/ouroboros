"""Loads audit.toml, checks it, and fills in the checklist defaults.

A mistake in the settings file never shows as a Python traceback: a typing mistake or a wrong kind of
value stops the audit with one plain sentence that names the file, the line or the setting, and a setting
that isn't recognized (a typo) is ignored with a "Heads up" that suggests the likely spelling."""
from __future__ import annotations

import copy
import datetime as dt
import difflib
import json
import re
import tomllib
from pathlib import Path

from .checklist import CHECKS_BY_ID, DEFAULT_WEIGHTS
from .pricing import DEFAULT_PRICING

DEFAULTS = {
    "client": "Client",
    "crm": None,  # recognized from the export files unless named in audit.toml
    "audit_date": None,
    "phone_region": "US",
    "weights": {str(k): v for k, v in DEFAULT_WEIGHTS.items()},
    "impact": {"minutes_per_bad_touch": 2, "selling_days": 230, "hourly_cost": 40},
    "crm_count": 1,  # how many CRMs the client uses (2+ raises the audit price); for your quote only
    # Your own prices (see audit_reference.toml). For your quote only, never in the client's files.
    "pricing": copy.deepcopy(DEFAULT_PRICING),
    "measured": {},
    "manual_scores": {},
    "files": {},
    "columns": {},
    # Put your own name, logo and colors on the reports (see audit_reference.toml). All optional.
    "branding": {"prepared_by": "", "logo": "", "accent_color": "", "contact": "", "show_powered_by": True},
}

# The full annotated list of every setting. A new client folder gets the short starter file instead.
REFERENCE = Path(__file__).with_name("audit_reference.toml")
TEMPLATE = REFERENCE  # older name

IMPACT_KEYS = ["reps", "touches_per_rep_per_day", "bad_touch_pct", "minutes_per_bad_touch", "selling_days",
               "hourly_cost", "lead_to_customer_rate_pct", "avg_deal_size", "admin_hours_per_week",
               "admin_hourly_cost", "minutes_low", "minutes_high", "email_share"]
BRANDING_KEYS = ["prepared_by", "logo", "accent_color", "contact", "show_powered_by",
                 "logo_data"]  # logo_data is what the iPad app sends instead of a file name
TABLE_SETTINGS = ("weights", "impact", "pricing", "branding", "measured", "manual_scores", "files", "columns")
FILE_KEYS = ["contacts", "accounts", "opportunities", "leads", "users", "tasks", "contact_roles",
             "opportunity_history", "job_orders"]
# Also understood in audit.toml (the iPad app sets them from its own screen): how to read 05/06/2026, and
# what each file is called when the file name doesn't say.
EXTRA_SETTINGS = ("date_order", "file_map")
CRM_CHOICES = {"1": "Salesforce", "2": "HubSpot", "3": "Dynamics 365", "4": "Bullhorn",
               "5": "Crelate"}


class ConfigError(ValueError):
    """A problem in audit.toml that stops the audit. The message is written for the person who typed it."""


def toml_string(text: str) -> str:
    """A TOML text value (with quotes), safe for names like O'Brien & "Sons" or C:\\path."""
    return json.dumps(str(text), ensure_ascii=False)


def starter_settings(client: str, crm: str = "", audit_date: dt.date | None = None) -> str:
    """The short audit.toml a new client folder starts with."""
    d = audit_date or dt.date.today()
    return (f"client = {toml_string(client)}\n"
            f"crm = {toml_string(crm)}   # Salesforce, HubSpot, Dynamics 365, Bullhorn or Crelate. Blank = detect automatically\n"
            f"audit_date = \"{d.isoformat()}\"\n"
            "# Everything else is optional: weights, your branding, your prices, column fixes and more.\n"
            "# Every setting is explained in crm_audit\\audit_reference.toml (copy only the lines you want, remove the #).\n"
            "# A misspelled setting is ignored and the report's \"Heads up\" list tells you which one.\n")


def full_settings(client: str) -> str:
    """The whole annotated reference file, with the client's name filled in."""
    text = REFERENCE.read_text(encoding="utf-8")
    return re.sub(r'(?m)^client = ".*"', lambda m: f"client = {toml_string(client)}", text, count=1)


def _fix_hint(msg: str, line_text: str) -> str:
    stripped = line_text.strip()
    if re.search(r"twice|Cannot declare|redefine|Cannot overwrite", msg):
        m = re.match(r"\[+\s*([^\]]+?)\s*\]+", stripped)
        if m:
            return f"The [{m.group(1)}] section appears twice; keep only one."
        return "This setting appears twice; keep only one."
    if "Unterminated string" in msg or (stripped.count('"') % 2 == 1):
        return "A quote isn't closed. Add the missing \" at the end of the value."
    if re.search(r"Expected '\]'|Unclosed|Unterminated|Expected '\}'", msg) or stripped.count("[") != stripped.count("]"):
        return "A bracket isn't closed. Add the missing ] at the end of the line."
    m = re.match(r"""^([A-Za-z0-9_.\-"]+)\s*=\s*(\S.*?)\s*$""", stripped)
    if m and not m.group(2).startswith(('"', "'", "[", "{")):
        key, value = m.group(1), re.sub(r"\s+#.*$", "", m.group(2)).replace('"', "'")
        return f'Put the value in quotes, like {key} = "{value}".'
    return "Each setting looks like name = value, with text in quotes. Check this line and the one above it."


def _syntax_error(path: Path, text: str, e: tomllib.TOMLDecodeError) -> ConfigError:
    msg = str(e)
    m = re.search(r"line (\d+)", msg)
    if not m:
        return ConfigError(f"There's a typing mistake in {path.name}: {msg}. Open it in Notepad and check the last "
                           "line you changed.")
    n = int(m.group(1))
    lines = text.splitlines()
    line_text = lines[n - 1].strip() if 0 < n <= len(lines) else ""
    return ConfigError(f"There's a typing mistake in {path.name} on line {n}: {line_text}. {_fix_hint(msg, line_text)}")


def _read(path: Path) -> str:
    raw = Path(path).read_bytes()
    try:
        # utf-8-sig: Notepad and Windows PowerShell often start files with an invisible byte-order mark
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")  # saved as "ANSI" by an older Notepad


def _show(v) -> str:
    return json.dumps(v, ensure_ascii=False, default=str) if isinstance(v, str) else str(v)


def _suggest(name: str, choices) -> str | None:
    hit = difflib.get_close_matches(str(name), [str(c) for c in choices], n=1, cutoff=0.6)
    return hit[0] if hit else None


class _Checker:
    def __init__(self, fname: str):
        self.fname = fname
        self.warnings: list[str] = []

    def unknown(self, key, known, where: str = ""):
        place = f" in {where} of {self.fname}" if where else f" in {self.fname}"
        near = _suggest(key, known)
        tip = f": did you mean '{near}'? It was ignored." if near else ". It was ignored."
        self.warnings.append(f"Unknown setting '{key}'{place}{tip}")

    def label(self, table, key) -> str:
        return f"The setting '{key}' in {self.fname}" if not table else \
            f"The setting '{key}' under [{table}] in {self.fname}"

    def number(self, table, key, v, example=10, whole=False, minimum=0):
        ok = isinstance(v, (int, float)) and not isinstance(v, bool)
        if not ok:
            raise ConfigError(f"{self.label(table, key)} must be a number, but it says {_show(v)}. "
                              f"Type it without quotes, like {key} = {example}.")
        if v != v or v in (float("inf"), float("-inf")):
            raise ConfigError(f"{self.label(table, key)} must be a normal number.")
        if v < minimum:
            what = "can't be negative" if minimum == 0 else f"must be {minimum:g} or more"
            raise ConfigError(f"{self.label(table, key)} {what}, but it says {v}.")
        if whole and v != int(v):
            raise ConfigError(f"{self.label(table, key)} must be a whole number, but it says {v}.")
        return v

    def table(self, key, v):
        if not isinstance(v, dict):
            raise ConfigError(f"'{key}' in {self.fname} should be a section: a line [{key}] followed by settings "
                              f"underneath it, but it was given a single value ({_show(v)}).")
        return v


def _audit_date(v):
    msg = "audit_date must look like 2026-11-10 (year-month-day)"
    if v is None or v == "":
        return None
    if isinstance(v, dt.datetime):
        return v.date().isoformat()
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", v.strip()):
        try:
            return dt.date.fromisoformat(v.strip()).isoformat()
        except ValueError:
            pass
    shown = f" It says {_show(v)}." if not isinstance(v, str) or v.strip() else ""
    raise ConfigError(f"{msg}.{shown} Or leave the line out to use today's date.")


def _crm_ok(name: str) -> bool:
    from .crms import NAMES
    n = name.strip().lower()
    return any(n == key or n == label.lower() or n.startswith(key[:4]) for key, label in NAMES.items())


def validate(user: dict, fname: str) -> tuple[dict, list[str]]:
    """The settings that were understood, and plain-English warnings for the ones that weren't."""
    from .loader import ALIASES, PATTERNS
    ck = _Checker(fname)
    out: dict = {}
    for key, v in user.items():
        if key not in DEFAULTS and key not in EXTRA_SETTINGS:
            ck.unknown(key, [*DEFAULTS, *EXTRA_SETTINGS])
            continue
        if key == "date_order":
            if str(v).strip().lower() not in ("", "dmy", "mdy"):
                raise ConfigError(f"The setting 'date_order' in {fname} must be \"mdy\" (month first, like 11/10/2026 "
                                  "for November 10) or \"dmy\" (day first), but it says " + _show(v) + ".")
            out[key] = str(v).strip().lower()
            continue
        if key == "file_map":
            from .loader import clean_file_map
            out[key] = clean_file_map(ck.table(key, v), "[file_map]")
            continue
        if key in TABLE_SETTINGS:
            ck.table(key, v)
        elif isinstance(v, dict):
            raise ConfigError(f"'{key}' in {fname} should be a single line like {key} = ..., "
                              f"not a section called [{key}].")
        if key == "audit_date":
            out[key] = _audit_date(v)
        elif key == "client":
            out[key] = str(v).strip() or DEFAULTS["client"]
        elif key == "crm":
            if not isinstance(v, str):
                raise ConfigError(f"The setting 'crm' in {fname} must be text in quotes, like crm = \"Salesforce\".")
            if v.strip() and not _crm_ok(v):
                near = _suggest(v, CRM_CHOICES.values())
                ck.warnings.append(f"The CRM '{v}' in {fname} isn't one Uroboric knows"
                                   + (f": did you mean '{near}'?" if near else " (Salesforce, HubSpot, Dynamics 365, Bullhorn or Crelate).")
                                   + " It was ignored, and the CRM is being detected from the files.")
                out[key] = None
            else:
                out[key] = v.strip() or None
        elif key == "phone_region":
            if not isinstance(v, str):
                raise ConfigError(f"The setting 'phone_region' in {fname} must be a country code in quotes, "
                                  "like phone_region = \"US\".")
            code = v.strip().upper() or DEFAULTS["phone_region"]
            ok = bool(re.fullmatch(r"[A-Z]{2}", code))
            if ok:
                try:
                    import phonenumbers
                    ok = code in phonenumbers.SUPPORTED_REGIONS
                except ImportError:
                    pass
            if not ok:
                raise ConfigError(f"The setting 'phone_region' in {fname} must be a two-letter country code such as "
                                  f"\"US\", \"GB\", \"CA\" or \"AU\", but it says {v!r}.")
            out[key] = code
        elif key == "crm_count":
            out[key] = int(ck.number("", key, v, example=2, whole=True, minimum=1))
        elif key == "weights":
            clean = {}
            for k, w in v.items():
                if str(k) not in DEFAULTS["weights"]:
                    ck.unknown(k, DEFAULTS["weights"], "[weights]")
                    continue
                clean[str(k)] = ck.number("weights", f'"{k}"', w, example=20)
            if clean and sum({**DEFAULTS["weights"], **clean}.values()) <= 0:
                ck.warnings.append(f"The weights in {fname} add up to 0, so the standard weights were used.")
                clean = {}
            out[key] = clean
        elif key == "impact":
            clean = {}
            for k, w in v.items():
                if k not in IMPACT_KEYS:
                    ck.unknown(k, IMPACT_KEYS, "[impact]")
                    continue
                clean[k] = ck.number("impact", k, w)
                if k == "email_share" and not 0 <= clean[k] <= 1:
                    raise ConfigError(f"{ck.label('impact', k)} must be between 0 and 1 (0.5 means half of the "
                                      f"touches are emails), but it says {w}.")
            out[key] = clean
        elif key == "pricing":
            clean = {}
            for k, w in v.items():
                if k not in DEFAULT_PRICING:
                    ck.unknown(k, DEFAULT_PRICING, "[pricing]")
                    continue
                clean[k] = w  # prices are checked (and explained) by the quote itself
            out[key] = clean
        elif key == "branding":
            clean = {}
            for k, w in v.items():
                if k not in BRANDING_KEYS:
                    ck.unknown(k, BRANDING_KEYS, "[branding]")
                    continue
                clean[k] = w
            out[key] = clean
        elif key == "measured":
            clean = {}
            for k, w in v.items():
                if str(k) not in CHECKS_BY_ID:
                    ck.unknown(k, CHECKS_BY_ID, "[measured]")
                    continue
                clean[str(k)] = ck.number("measured", f'"{k}"', w, example=3.5)
            out[key] = clean
        elif key == "manual_scores":
            clean = {}
            for k, w in v.items():
                if str(k) not in CHECKS_BY_ID:
                    ck.unknown(k, CHECKS_BY_ID, "[manual_scores]")
                    continue
                if isinstance(w, bool) or not isinstance(w, (int, float)) or w not in (0, 1, 2):
                    raise ConfigError(f"The score for check \"{k}\" under [manual_scores] in {fname} must be 0, 1 or 2 "
                                      f"(2 = healthy, 1 = needs attention, 0 = critical), but it says {_show(w)}.")
                clean[str(k)] = w
            out[key] = clean
        elif key == "files":
            clean = {}
            for k, w in v.items():
                if k not in FILE_KEYS:
                    ck.unknown(k, FILE_KEYS, "[files]")
                    continue
                if not isinstance(w, str) or not w.strip():
                    raise ConfigError(f"The setting '{k}' under [files] in {fname} must be a file name in quotes, "
                                      f"like {k} = \"{k.title()}.csv\".")
                clean[k] = w
            out[key] = clean
        elif key == "columns":
            clean = {}
            for t, cols in v.items():
                if t not in ALIASES:
                    ck.unknown(t, ALIASES, "[columns]")
                    continue
                if not isinstance(cols, dict):
                    raise ConfigError(f"[columns.{t}] in {fname} should be a section with lines like "
                                      "field = \"Column name in the file\".")
                fields = list(ALIASES[t]) + list(PATTERNS.get(t, {}))
                keep = {}
                for logical, col in cols.items():
                    if logical not in fields:
                        ck.unknown(logical, fields, f"[columns.{t}]")
                        continue
                    if not isinstance(col, str):
                        raise ConfigError(f"The setting '{logical}' under [columns.{t}] in {fname} must be the column's "
                                          f"name in quotes, like {logical} = \"Column name in the file\".")
                    keep[logical] = col
                clean[t] = keep
            out[key] = clean
        else:
            out[key] = v
    return out, ck.warnings


def load_config(path: Path | None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    cfg["_warnings"] = []  # plain-English notes about the settings file; shown as "Heads up" in the report
    if path is None:
        return cfg
    path = Path(path)
    text = _read(path)
    try:
        user = tomllib.loads(text)
    except tomllib.TOMLDecodeError as e:
        raise _syntax_error(path, text, e) from None
    user, notes = validate(user, path.name)
    cfg["_warnings"] = notes
    for k, v in user.items():
        if k == "columns":
            cfg[k].update(v)
        elif isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        else:
            cfg[k] = v
    cfg["_base_dir"] = str(path.resolve().parent)  # a relative logo path is looked up here
    return cfg
