"""Automatic checks: runs the whole test suite the way both versions of the app run it.

  python -m crm_audit test

The laptop version uses rapidfuzz for fuzzy matching. The iPad/browser version (Pyodide) doesn't
have it and falls back to difflib, so the suite is run a second time with rapidfuzz blocked.
Each run is a separate process so the two can't affect each other.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

_BROWSER = ("import sys; sys.modules['rapidfuzz'] = None; import unittest; "
            "unittest.main(module=None, argv=['unittest', 'discover', '-s', 'tests'])")
ENGINES = {
    "desktop": ("Checking the laptop version...",
                [sys.executable, "-m", "unittest", "discover", "-s", "tests"]),
    "browser": ("Checking the iPad/browser version (no rapidfuzz)...",
                [sys.executable, "-c", _BROWSER]),
}


def run(engines=("desktop", "browser"), quiet=False) -> bool:
    """Run the tests for each engine; True only if every one passed.
    quiet=True keeps the test output off the screen unless something fails."""
    failed = []
    for name in engines:
        message, cmd = ENGINES[name]
        if not quiet:
            print(message, flush=True)
        if quiet:
            r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace")
            if r.returncode != 0:
                print(message)
                print(chr(10).join((r.stdout + r.stderr).strip().splitlines()[-40:]))
        else:
            r = subprocess.run(cmd, cwd=ROOT)
        if r.returncode != 0:
            failed.append(name)
    if failed:
        print(f"Checks FAILED in: {', '.join(failed)}.")
    elif not quiet:
        print("All checks passed.")
    return not failed
