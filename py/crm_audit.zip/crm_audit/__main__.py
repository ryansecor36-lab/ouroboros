"""Command line:

  python -m crm_audit run <data folder> [--config audit.toml] [--out report.xlsx]
  python -m crm_audit apply-review <Cleanup_review.xlsx> [--out <folder>] [--fresh <folder of new exports>]
                                               turn the client's reviewed workbook into a ready-to-load folder
  python -m crm_audit quote --records 12000 --reps 18 [--crms 2] [--ready N --decide N --enrich N]
                                               price a job before any audit (for you, not the client)
  python -m crm_audit new <data folder> [--client NAME] [--crm salesforce|...] [--full]
                                               create the folder with a short audit.toml (--full: every option)
  python -m crm_audit wizard-new | wizard-run [folder] | wizard-apply [review.xlsx]
                                               the questions-and-answers versions used by the double-click launchers
  python -m crm_audit backup [--to <folder>]   zip clients, history and reports (keeps the 10 newest)
  python -m crm_audit restore --from <zip> [--force]
                                               put a backup back (won't overwrite newer files unless --force)
  python -m crm_audit sample <folder> [--crm salesforce|hubspot|dynamics|bullhorn]
                                               write fake exports to try the tool
  python -m crm_audit --version                show the Uroboric and library versions
  python -m crm_audit test                     run the automatic checks (laptop and iPad versions)
  python -m crm_audit preflight [--org ALIAS] [--skip-org] [--quick] [--no-build]
                                               everything to run before publishing: unit tests, stress tests,
                                               round trips, app build and the Salesforce test-org round trip
  python -m crm_audit build-web                build the iPad/browser app into webapp/
  python -m crm_audit publish-web              check, rebuild and publish the app to GitHub Pages
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
import webbrowser
from pathlib import Path

from . import branding, cleanup, pricing, progress
from .checks import run_checks
from .config import full_settings, load_config, starter_settings
from .loader import TABLE_LABELS, load_folder
from .plain import AREAS, GRADE_PLAIN, RATING, money, top_problems
from .report import write_report
from .report_html import SMALL_SAMPLE, write_html
from .scoring import build_impact, build_scorecard
from .sources import analyze as analyze_sources


def cmd_run(args):
    folder = Path(args.data)
    cfg_path = Path(args.config) if args.config else folder / "audit.toml"
    if args.config and not cfg_path.exists():
        sys.exit(f"Config not found: {cfg_path}")
    cfg = load_config(cfg_path if cfg_path.exists() else None)
    data = load_folder(folder, cfg)  # a fatal problem stops here, before anything else is printed
    if not cfg_path.exists():
        print(f"No audit.toml in {folder}; using defaults. Run 'new' to create one.")
    brand = branding.apply(data, cfg)
    print("Loaded: " + ", ".join(f"{TABLE_LABELS[k]} {len(t):,} rows ({t.path.name})" for k, t in data.items()))
    ctx, results = run_checks(data, cfg)
    card = build_scorecard(results, cfg)
    impact = build_impact(results, cfg)

    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(cfg["client"])).strip("_") or "client"
    base = Path(args.out).with_suffix("") if args.out else \
        Path("reports") / f"{slug}_CRM_health_{ctx.audit_date:%Y-%m-%d}"
    xlsx = base.parent / (base.name + "_details.xlsx")
    html = base.parent / (base.name + "_report.html")
    sources = analyze_sources(ctx, results)
    kit = cleanup.build(ctx, results)
    kit_dir = cleanup.write(kit, base.parent / f"{slug}_cleanup_{ctx.audit_date:%Y-%m-%d}", cfg["client"],
                            ctx.audit_date, brand)
    snap = progress.snapshot(cfg["client"], ctx.audit_date, card, results, impact, data)
    hist_path = Path("history") / f"{slug}.json"
    history = progress.load_history(hist_path)
    prev = progress.read_snapshot(Path(args.previous)) if args.previous else progress.previous_for(history, snap)
    comp = progress.compare(prev, snap) if prev else None
    _, sheets = write_report(xlsx, cfg["client"], ctx.audit_date, card, impact, results, data, sources,
                             snap, comp, ctx.crm, brand)
    write_html(html, cfg["client"], ctx.audit_date, card, impact, results, data, sheets, xlsx.name, sources,
               kit.summary(), comp, ctx.crm, brand)
    if not args.no_history:
        progress.save_history(hist_path, history, snap)

    line = "-" * 64
    print(f"\n{line}")
    from .scoring import grade_basis
    if card.overall is not None:
        print(f" GRADE {card.grade}  ({card.overall:.0f} out of 100)")
        print(f" {grade_basis(card)}")
        print(f" {GRADE_PLAIN[card.grade]}")
    else:
        print(f" NO GRADE. {grade_basis(card)}")
    if card.unscored:
        bits = []
        if card.needs_input:
            bits.append(f"{card.needs_input} need your answers or a measured number")
        if card.not_checked:
            bits.append(f"{card.not_checked} couldn't be checked from this export")
        print(f" Preliminary: {card.unscored} checks are left out of the grade ({'; '.join(bits)}).")
    if card.partial:
        print(f" Partly checked: {card.partial} check{'s' if card.partial != 1 else ''} measured part of the "
              "information only (the report says which part).")
    if 0 < len(data.get("contacts", [])) < SMALL_SAMPLE:
        n = len(data["contacts"])
        print(f" Small sample: only {n:,} {'contact' if n == 1 else 'contacts'}, so treat the grade as a rough guide.")
    for note in getattr(data, "warnings", []):
        print(f" Heads up: {note}")
    from .crms import consultant_note
    if consultant_note(ctx.crm):  # for you, not the client: never written into their report files
        print(f" Note for you: {consultant_note(ctx.crm)}")
    if brand.logo_bytes and not brand.xlsx_logo:
        why = ("Excel can't show SVG pictures" if brand.logo_mime == "image/svg+xml"
               else "the Pillow add-on isn't installed (pip install pillow)")
        print(f" Note: your logo is on the HTML report but not on the Excel workbook, because {why}.")
    if comp:
        extra = ""
        if comp.get("newly_measured") or comp.get("no_longer_measured"):
            extra = (f", {len(comp.get('newly_measured', []))} newly measured, "
                     f"{len(comp.get('no_longer_measured', []))} no longer measured")
        print(f" {comp['headline']}. {len(comp['better'])} checks better, {len(comp['worse'])} worse{extra}.")
        for note in comp.get("notes", []):
            print(f" Note: {note}")
    print(line)
    for c in card.categories:
        band = (2 if c.pct >= 0.85 else (1 if c.pct >= 0.5 else 0)) if c.pct is not None else None
        print(f"  {RATING[band]:<15} {AREAS[c.number][0]}")
    if impact["cost"] is not None:
        print(f"\n {impact['headline']}.")
        if impact.get("basis"):
            print(f"  {impact['basis']}.")
        if impact.get("defaults"):
            print(f"  Check these assumptions with the client: {', '.join(impact['defaults'])}.")
    elif impact.get("basis"):
        print(f"\n {impact['basis']}.")
    tops = top_problems(results, {c.number: c.weight for c in card.categories})
    if tops:
        print("\n Biggest problems:")
        for i, cid in enumerate(tops, 1):
            print(f"  {i}. {results[cid].headline}")
    if sources:
        print(f"\n Where it comes from: {sources['headline']}.")
        if sources["trend"]:
            print(f"  {sources['trend']['sentence']}")
    for r in [r for r in results.values() if r.status == "error"]:
        print(f"\n ! Check {r.check_id} couldn't run: {'; '.join(r.notes)}")
    print(f"\n Plain-English report:  {html.resolve()}")
    print(f" Detail workbook:       {xlsx.resolve()}")
    ks = kit.summary()
    print(f" Cleanup kit:           {kit_dir.resolve()}")
    print(f"   {kit.headline()}. Send Cleanup_review.xlsx to the client; see READ_ME_FIRST.txt.")
    if not args.no_quote:
        reps, src = pricing.reps_from_audit(cfg, ctx)
        q = pricing.build_quote(pricing.count_records(data), reps, int(cfg.get("crm_count") or 1), ks,
                                pricing=cfg.get("pricing"))
        print("\n" + pricing.format_block(q))
        if reps is not None:
            print(f"  (Reps: {src}.)")
    if card.unscored:
        print(" (The workbook's 'Inputs needed' sheet lists what's left to fill in audit.toml.)")
    from .backup import tip_line
    tip = tip_line()
    if tip:
        print("\n" + tip)
    if not args.no_open and not os.environ.get("UROBORIC_NO_OPEN"):
        try:
            os.startfile(html.resolve())  # Windows: opens in the default browser
        except (AttributeError, OSError):
            webbrowser.open(html.resolve().as_uri())


def cmd_apply_review(args):
    from .apply import apply_review
    sm = apply_review(args.workbook, args.out, fresh=args.fresh)
    print(f"Ready-to-load folder for {sm['client']}: {sm['folder']}\n")
    print("\n".join(sm["approval"]) + "\n")
    print(f"  {sm['approved']:,} approved, {sm['declined']:,} declined, {sm['undecided']:,} left undecided (not applied)"
          + (f", {sm['skipped']:,} skipped" if sm["skipped"] else "")
          + (f", {sm['waiting']:,} held back until their merge is approved" if sm["waiting"] else ""))
    for name, st in sm["sheets"].items():
        print(f"    {name:<17} {st['approved']:>5} approved  {st['declined']:>4} declined  {st['undecided']:>4} undecided"
              + (f"  {st['skipped']:>3} skipped" if st["skipped"] else "")
              + (f"  {st['waiting']:>3} held back" if st["waiting"] else ""))
    print("  Files: " + ", ".join(sm["files"]))
    for w in sm["warnings"]:
        print(f"  Heads up: {w}")
    print("Next: follow CHECKLIST.txt in that folder.")
    return sm


def cmd_quote(args):
    if args.records is None:
        sys.exit("quote needs the number of records. Example:  python -m crm_audit quote --records 12000 --reps 18")
    cfg = load_config(Path(args.config) if args.config else None)
    given = [args.ready, args.decide, args.enrich]
    cleanup_counts = None
    if any(v is not None for v in given):
        cleanup_counts = {"ready": args.ready or 0, "decide": args.decide or 0, "enrich": args.enrich or 0}
    q = pricing.build_quote(args.records, args.reps, args.crms or int(cfg.get("crm_count") or 1),
                            cleanup_counts, args.pilot, cfg.get("pricing"))
    print(pricing.format_block(q))


def cmd_new(args):
    folder = Path(args.data)
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / "audit.toml"
    if dest.exists():
        sys.exit(f"{dest} already exists; not overwriting it.")
    from .crms import NAMES
    client = args.client or folder.name or "Client"
    folder.mkdir(parents=True, exist_ok=True)
    text = full_settings(client) if args.full else starter_settings(client, NAMES.get(args.crm or "", ""))
    dest.write_text(text, encoding="utf-8")
    print(f"Created {dest}. Put the CRM exports (CSV or Excel) in {folder}, then run:  python -m crm_audit run {folder}")


def cmd_sample(args):
    from .sample_data import generate
    folder = generate(Path(args.folder), seed=args.seed, crm=args.crm)
    print(f"Wrote fake {args.crm.title() if args.crm != 'hubspot' else 'HubSpot'} exports and audit.toml to {folder}")
    print(f"Now run:  python -m crm_audit run {folder}")


class _Version(argparse.Action):
    """--version on one unwrapped line."""
    def __call__(self, parser, namespace, values, option_string=None):
        from .versions import long_text
        print(long_text())
        parser.exit()


EVERYDAY = ["new", "run", "apply-review", "quote", "backup", "restore", "wizard-new", "wizard-run", "wizard-apply"]
MAINTENANCE = ["test", "preflight", "build-web", "publish-web", "sample"]


def _group_help(p, sub):
    """Show the commands in two groups (everyday, maintenance) instead of one long list."""
    shown = {a.dest: a.help for a in sub._choices_actions}
    for name, parser in sub.choices.items():
        parser.description = parser.description or shown.get(name)
    sub._choices_actions.clear()
    other = [n for n in sub.choices if n not in EVERYDAY and n not in MAINTENANCE]

    def block(title, names):
        return [title] + [f"  {n:<13} {shown.get(n, '')}" for n in names if n in sub.choices] + [""]
    p.epilog = "\n".join(block("Everyday commands", EVERYDAY)
                         + block("Maintenance (for whoever updates Uroboric)", MAINTENANCE + other)
                         + ["Details for one command:  python -m crm_audit <command> --help"])


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass
    p = argparse.ArgumentParser(prog="crm_audit", description="Uroboric: CRM data health audits for Salesforce, HubSpot, Dynamics 365 and Bullhorn exports",
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--version", action=_Version, nargs=0, help="show the Uroboric and library versions")
    sub = p.add_subparsers(dest="cmd", required=True, metavar="command")
    r = sub.add_parser("run", help="run the audit on a folder of CSV exports")
    r.add_argument("data", help="the folder holding the client's CRM export files (CSV or Excel)")
    r.add_argument("--config", help="use this settings file instead of audit.toml in the folder")
    r.add_argument("--out", help="base name for the report files")
    r.add_argument("--no-open", action="store_true", help="don't open the report in the browser")
    r.add_argument("--previous", help="compare with this earlier audit (a _details.xlsx or history .json)")
    r.add_argument("--no-quote", action="store_true", help="don't print the suggested quote")
    r.add_argument("--no-history", action="store_true", help="don't save this audit to the history folder")
    r.set_defaults(fn=cmd_run)
    ar = sub.add_parser("apply-review", help="turn the client's reviewed Cleanup_review.xlsx into a ready-to-load folder")
    ar.add_argument("workbook", help="the Cleanup_review.xlsx the client sent back")
    ar.add_argument("--out", help="folder to write (default: next to the workbook)")
    ar.add_argument("--fresh", help="a folder of new CRM exports: approved changes whose current value has changed "
                                    "in the CRM since the audit are held back (5_held_back.csv)")
    ar.set_defaults(fn=cmd_apply_review)
    q = sub.add_parser("quote", help="price a job before any audit (for you, not the client)")
    q.add_argument("--records", type=int, help="contacts + accounts + leads + opportunities (needed)")
    q.add_argument("--reps", type=int, help="number of reps; leave out if unknown")
    q.add_argument("--crms", type=int, help="how many CRMs the client uses (default 1)")
    q.add_argument("--ready", type=int, help="pre-approved format fixes (from a finished audit)")
    q.add_argument("--decide", type=int, help="changes that need a decision")
    q.add_argument("--enrich", type=int, help="records to enrich")
    q.add_argument("--pilot", action="store_true", help="use the pilot audit price")
    q.add_argument("--config", help="an audit.toml with your own [pricing]")
    q.set_defaults(fn=cmd_quote)
    n = sub.add_parser("new", help="create a client folder with a short audit.toml")
    n.add_argument("data", help="the folder to create, e.g. clients\\Acme")
    n.add_argument("--client", help="the client's name for the reports (default: the folder name)")
    n.add_argument("--crm", choices=["salesforce", "hubspot", "dynamics", "bullhorn"],
                   help="which CRM (leave out to detect it from the files)")
    n.add_argument("--full", action="store_true", help="write the long settings file that lists every option")
    n.set_defaults(fn=cmd_new)
    w = sub.add_parser("build-web", help="build the iPad/browser app into the webapp folder")
    w.set_defaults(fn=lambda a: __import__("crm_audit.webbuild", fromlist=["main"]).main())
    pw = sub.add_parser("publish-web", help="rebuild the iPad app and publish it to GitHub Pages")
    pw.set_defaults(fn=lambda a: __import__("crm_audit.webbuild", fromlist=["publish"]).publish())
    t = sub.add_parser("test", help="run the automatic checks on both the laptop and iPad versions")
    t.set_defaults(fn=lambda a: None if __import__("crm_audit.selftest", fromlist=["run"]).run() else sys.exit(1))
    pf = sub.add_parser("preflight", help="run every check that should pass before publishing the app")
    pf.add_argument("--org", default="ouroboros-test", help="Salesforce test org alias (default: ouroboros-test)")
    pf.add_argument("--skip-org", action="store_true", help="skip the Salesforce test-org round trip")
    pf.add_argument("--quick", action="store_true", help="skip the big database and the org round trip (fast, for local use)")
    pf.add_argument("--no-build", action="store_true", help="skip building the iPad app (it downloads on first use)")
    pf.set_defaults(fn=lambda a: None if __import__("crm_audit.preflight", fromlist=["run"]).run(
        a.org, a.skip_org, a.quick, not a.no_build) else sys.exit(1))
    s = sub.add_parser("sample", help="write fake Salesforce exports to try the tool")
    s.add_argument("folder", help="the folder to write the fake exports into, e.g. samples\\sample_co")
    s.add_argument("--seed", type=int, default=7, help="a number; the same number always gives the same fake data")
    s.add_argument("--crm", choices=["salesforce", "hubspot", "dynamics", "bullhorn"], default="salesforce",
                   help="which CRM's export format to write")
    s.set_defaults(fn=cmd_sample)
    wn = sub.add_parser("wizard-new", help="ask for the client's name and CRM, then set up their folder")
    wn.set_defaults(fn=lambda a: __import__("crm_audit.wizard", fromlist=["new_client"]).new_client())
    wr = sub.add_parser("wizard-run", help="pick a client folder (or drop one on it) and run the audit")
    wr.add_argument("folder", nargs="?", help="the client's folder; leave out to choose from a list")
    wr.set_defaults(fn=lambda a: __import__("crm_audit.wizard", fromlist=["run_client"]).run_client(a.folder))
    wa = sub.add_parser("wizard-apply", help="pick the client's reviewed workbook and make the ready-to-load folder")
    wa.add_argument("workbook", nargs="?", help="the Cleanup_review.xlsx; leave out to choose it in a window")
    wa.set_defaults(fn=lambda a: __import__("crm_audit.wizard", fromlist=["apply_client"]).apply_client(a.workbook))
    bk = sub.add_parser("backup", help="zip clients, history and reports into one backup file")
    bk.add_argument("--to", help="the folder to put the backup in (remembered for next time)")
    bk.add_argument("--open", action="store_true", help="open the backup folder afterwards")
    bk.set_defaults(fn=lambda a: __import__("crm_audit.backup", fromlist=["cmd_backup"]).cmd_backup(a))
    rs = sub.add_parser("restore", help="put a backup back (never overwrites newer files unless --force)")
    rs.add_argument("--from", dest="source", required=True, help="the Uroboric-backup-....zip to restore")
    rs.add_argument("--force", action="store_true", help="overwrite files that are newer than the backup")
    rs.set_defaults(fn=lambda a: __import__("crm_audit.backup", fromlist=["cmd_restore"]).cmd_restore(a))
    _group_help(p, sub)
    args = p.parse_args(argv)
    try:
        args.fn(args)
    except (FileNotFoundError, ValueError) as e:
        sys.exit(f"Error: {e}")


if __name__ == "__main__":
    main()
