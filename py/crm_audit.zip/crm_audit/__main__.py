"""Command line:

  python -m crm_audit run <data folder> [--config audit.toml] [--out report.xlsx]
  python -m crm_audit quote --records 12000 --reps 18 [--crms 2] [--ready N --decide N --enrich N]
                                               price a job before any audit (for you, not the client)
  python -m crm_audit new <data folder>        create the folder with a blank audit.toml
  python -m crm_audit sample <folder> [--crm salesforce|hubspot|dynamics]
                                               write fake exports to try the tool
  python -m crm_audit test                     run the automatic checks (laptop and iPad versions)
  python -m crm_audit build-web                build the iPad/browser app into webapp/
  python -m crm_audit publish-web              check, rebuild and publish the app to GitHub Pages
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
import webbrowser
from pathlib import Path

from . import branding, cleanup, pricing, progress
from .checks import run_checks
from .config import TEMPLATE, load_config
from .loader import TABLE_LABELS, load_folder
from .plain import AREAS, GRADE_PLAIN, RATING, money, top_problems
from .report import write_report
from .report_html import SMALL_SAMPLE, write_html
from .scoring import build_impact, build_scorecard
from .sources import analyze as analyze_sources


def cmd_run(args):
    folder = Path(args.data)
    cfg_path = Path(args.config) if args.config else folder / "audit.toml"
    if args.config and not cfg_path.exists():
        sys.exit(f"Config not found: {cfg_path}")
    cfg = load_config(cfg_path if cfg_path.exists() else None)
    if not cfg_path.exists():
        print(f"No audit.toml in {folder}; using defaults. Run 'new' to create one.")
    data = load_folder(folder, cfg)
    brand = branding.apply(data, cfg)
    print("Loaded: " + ", ".join(f"{TABLE_LABELS[k]} {len(t):,} rows ({t.path.name})" for k, t in data.items()))
    ctx, results = run_checks(data, cfg)
    card = build_scorecard(results, cfg)
    impact = build_impact(results, cfg)

    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(cfg["client"])).strip("_") or "client"
    base = Path(args.out).with_suffix("") if args.out else \
        Path("reports") / f"{slug}_CRM_health_{ctx.audit_date:%Y-%m-%d}"
    xlsx = base.parent / (base.name + "_details.xlsx")
    html = base.parent / (base.name + "_report.html")
    sources = analyze_sources(ctx, results)
    kit = cleanup.build(ctx, results)
    kit_dir = cleanup.write(kit, base.parent / f"{slug}_cleanup_{ctx.audit_date:%Y-%m-%d}", cfg["client"],
                            ctx.audit_date, brand)
    snap = progress.snapshot(cfg["client"], ctx.audit_date, card, results, impact, data)
    hist_path = Path("history") / f"{slug}.json"
    history = progress.load_history(hist_path)
    prev = progress.read_snapshot(Path(args.previous)) if args.previous else progress.previous_for(history, snap)
    comp = progress.compare(prev, snap) if prev else None
    _, sheets = write_report(xlsx, cfg["client"], ctx.audit_date, card, impact, results, data, sources,
                             snap, comp, ctx.crm, brand)
    write_html(html, cfg["client"], ctx.audit_date, card, impact, results, data, sheets, xlsx.name, sources,
               kit.summary(), comp, ctx.crm, brand)
    if not args.no_history:
        progress.save_history(hist_path, history, snap)

    line = "-" * 64
    print(f"\n{line}")
    if card.overall is not None:
        print(f" GRADE {card.grade}  ({card.overall:.0f} out of 100)")
        print(f" {GRADE_PLAIN[card.grade]}")
    if card.unscored:
        print(f" Preliminary: {card.unscored} checks still need your input.")
    if 0 < len(data.get("contacts", [])) < SMALL_SAMPLE:
        n = len(data["contacts"])
        print(f" Small sample: only {n:,} {'contact' if n == 1 else 'contacts'}, so treat the grade as a rough guide.")
    for note in getattr(data, "warnings", []):
        print(f" Heads up: {note}")
    if brand.logo_bytes and not brand.xlsx_logo:
        why = ("Excel can't show SVG pictures" if brand.logo_mime == "image/svg+xml"
               else "the Pillow add-on isn't installed (pip install pillow)")
        print(f" Note: your logo is on the HTML report but not on the Excel workbook, because {why}.")
    if comp:
        print(f" {comp['headline']}. {len(comp['better'])} checks better, {len(comp['worse'])} worse.")
    print(line)
    for c in card.categories:
        band = (2 if c.pct >= 0.85 else (1 if c.pct >= 0.5 else 0)) if c.pct is not None else None
        print(f"  {RATING[band]:<15} {AREAS[c.number][0]}")
    if impact["cost"] is not None:
        print(f"\n Bad data wastes about {money(impact['cost'])} a year of rep time "
              f"({impact['hours']:,.0f} hours).")
    tops = top_problems(results, {c.number: c.weight for c in card.categories})
    if tops:
        print("\n Biggest problems:")
        for i, cid in enumerate(tops, 1):
            print(f"  {i}. {results[cid].headline}")
    if sources:
        print(f"\n Where it comes from: {sources['headline']}.")
        if sources["trend"]:
            print(f"  {sources['trend']['sentence']}")
    for r in [r for r in results.values() if r.status == "error"]:
        print(f"\n ! Check {r.check_id} couldn't run: {'; '.join(r.notes)}")
    print(f"\n Plain-English report:  {html.resolve()}")
    print(f" Detail workbook:       {xlsx.resolve()}")
    ks = kit.summary()
    print(f" Cleanup kit:           {kit_dir.resolve()}")
    print(f"   {ks['ready']:,} fixes ready to load after review, {ks['decide']:,} need a decision, "
          f"{ks['enrich']:,} records to enrich. Start with READ_ME_FIRST.txt.")
    if not args.no_quote:
        reps, src = pricing.reps_from_audit(cfg, ctx)
        q = pricing.build_quote(pricing.count_records(data), reps, int(cfg.get("crm_count") or 1), ks,
                                pricing=cfg.get("pricing"))
        print("\n" + pricing.format_block(q))
        if reps is not None:
            print(f"  (Reps: {src}.)")
    if card.unscored:
        print(" (The workbook's 'Inputs needed' sheet lists what's left to fill in audit.toml.)")
    if not args.no_open:
        try:
            os.startfile(html.resolve())  # Windows: opens in the default browser
        except (AttributeError, OSError):
            webbrowser.open(html.resolve().as_uri())


def cmd_quote(args):
    cfg = load_config(Path(args.config) if args.config else None)
    given = [args.ready, args.decide, args.enrich]
    cleanup_counts = None
    if any(v is not None for v in given):
        cleanup_counts = {"ready": args.ready or 0, "decide": args.decide or 0, "enrich": args.enrich or 0}
    q = pricing.build_quote(args.records, args.reps, args.crms or int(cfg.get("crm_count") or 1),
                            cleanup_counts, args.pilot, cfg.get("pricing"))
    print(pricing.format_block(q))


def cmd_new(args):
    folder = Path(args.data)
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / "audit.toml"
    if dest.exists():
        sys.exit(f"{dest} already exists; not overwriting it.")
    shutil.copy(TEMPLATE, dest)
    print(f"Created {dest}. Put the CRM exports (CSV or Excel) in {folder} and fill in audit.toml.")


def cmd_sample(args):
    from .sample_data import generate
    folder = generate(Path(args.folder), seed=args.seed, crm=args.crm)
    print(f"Wrote fake {args.crm.title() if args.crm != 'hubspot' else 'HubSpot'} exports and audit.toml to {folder}")
    print(f"Now run:  python -m crm_audit run {folder}")


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass
    p = argparse.ArgumentParser(prog="crm_audit", description="Uroboric: CRM data health audits for Salesforce, HubSpot and Dynamics 365 exports")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run the audit on a folder of CSV exports")
    r.add_argument("data")
    r.add_argument("--config")
    r.add_argument("--out", help="base name for the report files")
    r.add_argument("--no-open", action="store_true", help="don't open the report in the browser")
    r.add_argument("--previous", help="compare with this earlier audit (a _details.xlsx or history .json)")
    r.add_argument("--no-quote", action="store_true", help="don't print the suggested quote")
    r.add_argument("--no-history", action="store_true", help="don't save this audit to the history folder")
    r.set_defaults(fn=cmd_run)
    q = sub.add_parser("quote", help="price a job before any audit (for you, not the client)")
    q.add_argument("--records", type=int, required=True, help="contacts + accounts + leads + opportunities")
    q.add_argument("--reps", type=int, help="number of reps; leave out if unknown")
    q.add_argument("--crms", type=int, help="how many CRMs the client uses (default 1)")
    q.add_argument("--ready", type=int, help="fixes ready to load (from a finished audit)")
    q.add_argument("--decide", type=int, help="records that need a decision")
    q.add_argument("--enrich", type=int, help="records to enrich")
    q.add_argument("--pilot", action="store_true", help="use the pilot audit price")
    q.add_argument("--config", help="an audit.toml with your own [pricing]")
    q.set_defaults(fn=cmd_quote)
    n = sub.add_parser("new", help="create a client folder with a blank audit.toml")
    n.add_argument("data")
    n.set_defaults(fn=cmd_new)
    w = sub.add_parser("build-web", help="build the iPad/browser app into the webapp folder")
    w.set_defaults(fn=lambda a: __import__("crm_audit.webbuild", fromlist=["main"]).main())
    pw = sub.add_parser("publish-web", help="rebuild the iPad app and publish it to GitHub Pages")
    pw.set_defaults(fn=lambda a: __import__("crm_audit.webbuild", fromlist=["publish"]).publish())
    t = sub.add_parser("test", help="run the automatic checks on both the laptop and iPad versions")
    t.set_defaults(fn=lambda a: None if __import__("crm_audit.selftest", fromlist=["run"]).run() else sys.exit(1))
    s = sub.add_parser("sample", help="write fake Salesforce exports to try the tool")
    s.add_argument("folder")
    s.add_argument("--seed", type=int, default=7)
    s.add_argument("--crm", choices=["salesforce", "hubspot", "dynamics"], default="salesforce",
                   help="which CRM's export format to write")
    s.set_defaults(fn=cmd_sample)
    args = p.parse_args(argv)
    try:
        args.fn(args)
    except (FileNotFoundError, ValueError) as e:
        sys.exit(f"Error: {e}")


if __name__ == "__main__":
    main()
