"""Helpers that turn messy CRM values into comparable keys."""
from __future__ import annotations

import re

import phonenumbers

PERSONAL_DOMAINS = {
    "gmail.com", "googlemail.com", "yahoo.com", "ymail.com", "hotmail.com", "outlook.com",
    "live.com", "msn.com", "aol.com", "icloud.com", "me.com", "mac.com", "comcast.net",
    "verizon.net", "att.net", "sbcglobal.net", "optonline.net", "protonmail.com", "proton.me",
    "gmx.com", "mail.com", "cox.net", "charter.net", "earthlink.net",
}

COMPANY_SUFFIXES = {
    "inc", "incorporated", "llc", "ltd", "limited", "corp", "corporation", "co", "company",
    "plc", "lp", "llp", "pc", "pllc", "gmbh", "sa", "ag", "bv", "pty",
}

NICKNAMES = {
    "bob": "robert", "bobby": "robert", "rob": "robert", "robbie": "robert",
    "bill": "william", "billy": "william", "will": "william", "liam": "william",
    "mike": "michael", "mikey": "michael", "jim": "james", "jimmy": "james", "jamie": "james",
    "tom": "thomas", "tommy": "thomas", "dave": "david", "chris": "christopher",
    "dan": "daniel", "danny": "daniel", "joe": "joseph", "joey": "joseph",
    "kate": "katherine", "katie": "katherine", "kathy": "katherine", "cathy": "katherine",
    "liz": "elizabeth", "beth": "elizabeth", "betsy": "elizabeth", "jen": "jennifer",
    "jenny": "jennifer", "matt": "matthew", "nick": "nicholas", "steve": "steven",
    "stephen": "steven", "tony": "anthony", "rick": "richard", "rich": "richard",
    "dick": "richard", "sam": "samuel", "alex": "alexander", "andy": "andrew",
    "drew": "andrew", "ben": "benjamin", "greg": "gregory", "pat": "patrick",
    "jeff": "jeffrey", "ken": "kenneth", "larry": "lawrence", "sue": "susan",
    "meg": "margaret", "maggie": "margaret", "peggy": "margaret", "ed": "edward",
    "eddie": "edward", "ted": "edward", "fred": "frederick", "frank": "francis",
    "jon": "jonathan", "nate": "nathan", "tim": "timothy", "vince": "vincent",
    "abby": "abigail", "deb": "deborah", "debbie": "deborah", "barb": "barbara",
    "chuck": "charles", "charlie": "charles", "hank": "henry", "harry": "henry",
}

US_STATES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California",
    "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa",
    "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi",
    "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire",
    "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York", "NC": "North Carolina",
    "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania",
    "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee",
    "TX": "Texas", "UT": "Utah", "VT": "Vermont", "VA": "Virginia", "WA": "Washington",
    "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming", "DC": "District of Columbia",
    "PR": "Puerto Rico",
}
_STATE_LOOKUP = {}
for _code, _name in US_STATES.items():
    _STATE_LOOKUP[_code.lower()] = _code
    _STATE_LOOKUP[_name.lower()] = _code
_STATE_LOOKUP.update({"penn": "PA", "penna": "PA", "mass": "MA", "calif": "CA", "cali": "CA",
                      "conn": "CT", "fla": "FL", "wash": "WA", "tex": "TX", "jersey": "NJ"})

_COUNTRY_LOOKUP = {
    "us": "US", "usa": "US", "united states": "US", "united states of america": "US",
    "america": "US", "u s": "US", "u s a": "US", "ca": "CA", "can": "CA", "canada": "CA",
    "uk": "GB", "gb": "GB", "united kingdom": "GB", "great britain": "GB", "england": "GB",
    "mx": "MX", "mexico": "MX", "de": "DE", "germany": "DE", "fr": "FR", "france": "FR",
    "ie": "IE", "ireland": "IE", "in": "IN", "india": "IN", "au": "AU", "australia": "AU",
}

JUNK_RE = re.compile(
    r"^(test|testing|tester|asdf\w*|qwerty|xxx+|zzz+|aaa+|n/?a|none|null|nil|unknown|tbd|"
    r"[.\-?_*]+|abc|123+|na|no name|noname|dummy|fake|sample|delete|do not use|dnu)$"
)
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[a-z]{2,}$", re.IGNORECASE)


def is_text(v) -> bool:
    return isinstance(v, str) and v.strip() != ""


def norm_email(v):
    if not is_text(v):
        return None
    return v.strip().lower()


def email_domain(v):
    e = norm_email(v)
    if not e or "@" not in e:
        return None
    return e.rsplit("@", 1)[1]


def business_domain(email):
    d = email_domain(email)
    return d if d and d not in PERSONAL_DOMAINS else None


def norm_domain(v):
    """'https://www.Acme.com/about' -> 'acme.com'"""
    if not is_text(v):
        return None
    w = v.strip().lower()
    w = re.sub(r"^[a-z]+://", "", w)
    if "@" in w:
        w = w.rsplit("@", 1)[1]
    w = re.split(r"[/?#:\s]", w)[0]
    if w.startswith("www."):
        w = w[4:]
    w = w.strip(".")
    if "." not in w or w in PERSONAL_DOMAINS:
        return None
    return w


def norm_company(v):
    """'The Acme, Inc.' / 'ACME INC' / 'Acme L.L.C.' -> 'acme'"""
    if not is_text(v):
        return None
    n = v.lower().replace("&", " and ")
    n = re.sub(r"[^a-z0-9 ]", " ", n)
    tokens = n.split()
    merged, buf = [], ""
    for t in tokens:  # join split initials such as 'l l c' -> 'llc'
        if len(t) == 1 and t.isalpha():
            buf += t
            continue
        if buf:
            merged.append(buf)
            buf = ""
        merged.append(t)
    if buf:
        merged.append(buf)
    if merged and merged[0] == "the":
        merged = merged[1:]
    while len(merged) > 1 and merged[-1] in COMPANY_SUFFIXES:
        merged.pop()
    return " ".join(merged) or None


def norm_first_name(v):
    if not is_text(v):
        return ""
    f = re.sub(r"[^a-z]", "", v.lower())
    return NICKNAMES.get(f, f)


def norm_last_name(v):
    if not is_text(v):
        return ""
    return re.sub(r"[^a-z]", "", v.lower())


def person_key(first, last):
    f, l = norm_first_name(first), norm_last_name(last)
    if not f or not l:
        return None
    return f"{f} {l}"


def canon_state(v):
    if not is_text(v):
        return None
    k = re.sub(r"\s+", " ", v.lower().replace(".", "")).strip()
    return _STATE_LOOKUP.get(k)


def canon_country(v):
    if not is_text(v):
        return None
    k = re.sub(r"\s+", " ", v.lower().replace(".", " ")).strip()
    return _COUNTRY_LOOKUP.get(k) or _COUNTRY_LOOKUP.get(k.replace(" ", "")) or k


def canon_text(v):
    if not is_text(v):
        return None
    k = v.lower().replace("&", " and ")
    k = re.sub(r"[^a-z0-9 ]", " ", k)
    return re.sub(r"\s+", " ", k).strip() or None


FAKE_EMAIL_LOCAL = {"noemail", "no", "none", "na", "unknown", "noreply", "donotreply", "no-reply",
                    "nobody", "fake", "dummy", "x", "xx", "xxx", "tbd", "email", "nomail", "noaddress", "test"}
FAKE_EMAIL_DOMAINS = {"noemail.com", "none.com", "na.com", "nomail.com", "fake.com", "email.com",
                      "domain.com", "company.com", "unknown.com", "test.com", "example.com"}


def is_placeholder_email(v) -> bool:
    """noemail@noemail.com, test@test.com and the like: shared by unrelated people, so never
    evidence that two records are the same person."""
    e = norm_email(v)
    if not e or "@" not in e:
        return False
    local, dom = e.rsplit("@", 1)
    return local in FAKE_EMAIL_LOCAL or dom in FAKE_EMAIL_DOMAINS


def is_junk(v) -> bool:
    return is_text(v) and bool(JUNK_RE.match(v.strip().lower()))


def email_syntax_ok(v) -> bool:
    return is_text(v) and bool(EMAIL_RE.match(v.strip()))


def phone_valid(v, region="US") -> bool:
    if not is_text(v):
        return False
    try:
        return phonenumbers.is_valid_number(phonenumbers.parse(v, region))
    except phonenumbers.NumberParseException:
        return False


def phone_pattern(v):
    """'(201) 555-0100' -> '(999) 999-9999' so formats can be compared."""
    if not is_text(v):
        return None
    return re.sub(r"\d", "9", v.strip())


_SENIORITY_RULES = [
    ("C-level / Owner", r"\b(ceo|cfo|cto|coo|cio|ciso|cmo|cro|cso|chief|president|owner|founder|"
                        r"co-founder|partner|principal|managing director)\b"),
    ("VP", r"\b(vp|svp|evp|avp|vice president)\b"),
    ("Director", r"\b(director|head of|dir)\b"),
    ("Manager", r"\b(manager|mgr|supervisor|team lead|lead)\b"),
]


def seniority_from_title(v):
    if not is_text(v):
        return None
    t = v.lower()
    for label, pattern in _SENIORITY_RULES:
        if re.search(pattern, t):
            return label
    return "Individual contributor"
