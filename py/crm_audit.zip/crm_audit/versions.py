"""Which Uroboric and which libraries made an audit. Stamped into every audit so results can be
compared fairly from month to month. Works on the laptop and in the iPad/browser app (Pyodide)."""
from __future__ import annotations

import sys
from importlib import metadata as md

from . import __version__

LIBS = ("pandas", "numpy", "openpyxl", "phonenumbers")


def _ver(name: str) -> str:
    try:
        return md.version(name)
    except md.PackageNotFoundError:
        return "unknown"


def engine() -> dict:
    """The versions that matter for results. 'fuzzy' is 'rapidfuzz X' on a laptop, 'difflib' in the browser."""
    from .fuzzcompat import USING_RAPIDFUZZ
    d = {"uroboric": __version__, "python": "{}.{}.{}".format(*sys.version_info[:3])}
    for n in LIBS:
        d[n] = _ver(n)
    d["fuzzy"] = f"rapidfuzz {_ver('rapidfuzz')}" if USING_RAPIDFUZZ else "difflib"
    return d


def long_text(e: dict | None = None) -> str:
    """'Uroboric 1.0.0 (pandas X, numpy Y, openpyxl Z, rapidfuzz/difflib, phonenumbers W, Python V)'"""
    e = e or engine()
    return (f"Uroboric {e['uroboric']} (pandas {e['pandas']}, numpy {e['numpy']}, openpyxl {e['openpyxl']}, "
            f"{e['fuzzy']}, phonenumbers {e['phonenumbers']}, Python {e['python']})")


def stamp(white_label: bool = False) -> str:
    """The small line on reports. A white-labelled report shows only the number, never the product name."""
    return f"Version {__version__}" if white_label else f"Made with Uroboric {__version__}"
