"""The 38 checks from the CRM Data Health Audit Checklist, plus 3 added from research into common
CRM user complaints (1.6, 3.8, 4.8), with targets and scoring rules.

Scoring (from the checklist):
  2 = Healthy: meets the target.
  1 = Needs attention: misses the target, but by less than double.
  0 = Critical: misses by double or more, or nobody can answer the question.

Rule kinds:
  ("max", t)        value must be under t            (e.g. "Under 2%")
  ("within", t)     value must be t or less          (e.g. "Within the last 6 months")
  ("min", t)        percentage must be over t        (e.g. "Over 90%"); the miss is measured
                    on the shortfall, so 'over 90%' allows 10% missing, and 1 point means
                    under 20% missing
  ("min_value", t)  plain number must be t or more   (e.g. rep trust "7 or higher")
  ("zero", tol)     target is zero; any non-zero result under tol% earns 1 point
  None              judged by the auditor, entered as 0, 1 or 2
Modes:
  auto      measured from the Salesforce exports
  measured  you enter the number (bounce rate, verifier result...) and the tool scores it
  manual    you enter the 0/1/2 score directly
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Check:
    id: str
    category: int
    name: str
    how: str
    target: str
    mode: str
    rule: tuple | None = None
    unit: str = "%"


CATEGORIES = {
    1: "Duplicates",
    2: "Contact accuracy and decay",
    3: "Field completeness and standardization",
    4: "Ownership, lifecycle and pipeline",
    5: "Lists, imports and integrations",
    6: "Governance and process",
}

DEFAULT_WEIGHTS = {1: 20, 2: 25, 3: 15, 4: 20, 5: 10, 6: 10}

GRADES = [
    (85, "A", "Healthy; a light monitoring retainer is enough"),
    (70, "B", "Leaking time; targeted cleanup on 1-2 categories"),
    (50, "C", "Reps and forecasts are being hurt; full cleanup recommended"),
    (0, "D", "CRM isn't trusted; cleanup plus governance rebuild"),
]

CHECKS = [
    # 1. Duplicates
    Check("1.1", 1, "Duplicate contacts by email",
          "Contacts whose email (lowercased, trimmed) appears more than once",
          "Under 2% of contacts", "auto", ("max", 2)),
    Check("1.2", 1, "Fuzzy duplicate contacts",
          "Same first + last name (nicknames and small typos allowed) at the same company "
          "domain, with different emails", "Under 3%", "auto", ("max", 3)),
    Check("1.3", 1, "Duplicate companies",
          "Accounts sharing a website domain or a name variant ('Acme Inc' vs 'Acme, Inc.')",
          "Under 3% of companies", "auto", ("max", 3)),
    Check("1.4", 1, "Duplicate open deals",
          "Open opportunities on the same account with near-identical names",
          "Zero", "auto", ("zero", 2)),
    Check("1.5", 1, "Dedupe tooling in place",
          "Are Salesforce duplicate/matching rules (or a tool like Dedupely or Insycle) active "
          "and reviewed?", "Rules active and reviewed monthly", "manual"),
    Check("1.6", 1, "Leads that duplicate contacts",
          "Open leads whose email, or name at the same company, already exists as a contact. Also "
          "lists leads from companies that are already accounts, for routing to the account owner",
          "Under 3% of open leads", "auto", ("max", 3)),
    # 2. Contact accuracy and decay
    Check("2.1", 2, "Email bounce rate",
          "Hard bounces from the last 90 days in their email or sequencing tool",
          "Under 2%", "measured", ("max", 2)),
    Check("2.2", 2, "Unverified emails",
          "Run a random sample of 500 contacts through a verifier (NeverBounce, ZeroBounce); "
          "enter the % invalid", "Under 5% invalid", "measured", ("max", 5)),
    Check("2.3", 2, "Job changers",
          "Spot-check 50 key contacts on LinkedIn or use a job-change tool; enter the % who left",
          "Under 10% have left", "measured", ("max", 10)),
    Check("2.4", 2, "Phone validity",
          "Every contact's Phone and Mobile checked for a real, dialable number",
          "Under 15% bad or missing", "auto", ("max", 15)),
    Check("2.5", 2, "Stale records",
          "Contacts with no activity and no data update in 12+ months",
          "Under 25% of database", "auto", ("max", 25)),
    Check("2.6", 2, "Last enrichment date",
          "Months since the database was last enriched or refreshed",
          "Within the last 6 months", "measured", ("within", 6), "months"),
    Check("2.7", 2, "Opt-outs respected",
          "Unsubscribed contacts flagged so they can't be enrolled in sequences",
          "100%", "manual"),
    # 3. Field completeness and standardization
    Check("3.1", 3, "Core contact fields filled",
          "% of contacts with email, phone, job title and an account",
          "Over 90%", "auto", ("min", 90)),
    Check("3.2", 3, "Core company fields filled",
          "% of accounts with industry, employee count, location and website",
          "Over 85%", "auto", ("min", 85)),
    Check("3.3", 3, "Standardized picklists",
          "State, country and industry values checked for spelling variants "
          "('NJ', 'New Jersey', 'N.J.')", "Dropdowns only", "auto", ("zero", 5)),
    Check("3.4", 3, "Job title normalization",
          "Is there a seniority or persona field, and how full is it?",
          "Present and over 80% filled", "auto", ("min", 80)),
    Check("3.5", 3, "Formatting consistency",
          "Names in ALL CAPS or lowercase, junk values ('test', 'asdf'), broken emails, "
          "phones not in the team's main format", "Under 2% bad", "auto", ("max", 2)),
    Check("3.6", 3, "Unused custom fields",
          "Custom fields (__c) under 5% populated", "Fewer than 10", "auto", ("max", 10),
          "fields"),
    Check("3.7", 3, "Required fields enforced",
          "Are key fields required at creation or at stage changes (validation rules, "
          "page layouts)?", "Yes", "manual"),
    Check("3.8", 3, "Placeholder values",
          "Values typed just to get past a required field: $0/$1 deals, close dates years away, 0% or "
          "100% on open deals, 'TBD'/'Contact' titles, fake emails, one phone number on many unrelated "
          "contacts, 'Other' industry", "Under 2% of records", "auto", ("max", 2)),
    # 4. Ownership, lifecycle stages and pipeline hygiene
    Check("4.1", 4, "Orphaned records",
          "Contacts and accounts owned by deactivated users or no one",
          "Under 1%", "auto", ("max", 1)),
    Check("4.2", 4, "Unworked inbound leads",
          "Leads created in the last 90 days with no activity within 48 hours",
          "Under 10%", "auto", ("max", 10)),
    Check("4.3", 4, "Lifecycle stage accuracy",
          "Sample 50 records: are lead statuses / lifecycle stages set and do they match reality?",
          "Over 90% accurate", "manual"),
    Check("4.4", 4, "Stale open deals",
          "Open deals with a close date in the past, or no activity in 30+ days",
          "Under 10% of open pipeline", "auto", ("max", 10)),
    Check("4.5", 4, "Deal stage definitions",
          "Are stage entry and exit criteria written down and followed?",
          "Documented and used", "manual"),
    Check("4.6", 4, "Deal associations",
          "Opportunities linked to an account and at least one contact",
          "Over 95%", "auto", ("min", 95)),
    Check("4.7", 4, "Closed-lost reasons",
          "% of lost opportunities with a reason recorded", "Over 80%", "auto", ("min", 80)),
    Check("4.8", 4, "Deals pushed repeatedly",
          "Open deals whose close date has been moved later 3 or more times (from opportunity history)",
          "Under 10% of open pipeline", "auto", ("max", 10)),
    # 5. Lists, imports and integrations
    Check("5.1", 5, "Import process",
          "Who uploads lists, and is there a checklist (verify, dedupe, map fields, tag source)?",
          "Documented process, 1-2 trusted uploaders", "manual"),
    Check("5.2", 5, "Lead source tracking",
          "% of contacts with a lead source recorded", "Over 90%", "auto", ("min", 90)),
    Check("5.3", 5, "Pre-upload verification",
          "Are purchased or scraped lists verified before import?", "Always", "manual"),
    Check("5.4", 5, "Integration conflicts",
          "Do ZoomInfo, Apollo, marketing automation or forms overwrite good data or create "
          "duplicates?", "No known conflicts", "manual"),
    Check("5.5", 5, "Static list clutter",
          "Count of old, unused list views, reports and campaigns", "Archived regularly",
          "manual"),
    Check("5.6", 5, "Time to build a list",
          "Ask: how long does it take to build a targeted list today?", "Under 1 hour", "manual"),
    # 6. Governance and process
    Check("6.1", 6, "Named data owner", "Is one person accountable for CRM quality?",
          "Yes, with time set aside", "manual"),
    Check("6.2", 6, "Data entry standards",
          "Is there a written guide for how reps create and update records?",
          "Written and shared", "manual"),
    Check("6.3", 6, "User permissions",
          "Who can delete, mass edit, or import (Modify All Data, Data Import Wizard)?",
          "Limited to 1-3 admins", "manual"),
    Check("6.4", 6, "Recurring hygiene",
          "Is any cleanup scheduled (weekly dedupe, quarterly enrichment)?",
          "Automated or on a calendar", "manual"),
    Check("6.5", 6, "Rep trust",
          "Ask reps: 'Do you trust what's in the CRM?' (1-10); enter the average",
          "Average 7 or higher", "measured", ("min_value", 7), "out of 10"),
    Check("6.6", 6, "Data security",
          "Is client data kept out of personal spreadsheets and unapproved AI tools?",
          "Yes", "manual"),
]

CHECKS_BY_ID = {c.id: c for c in CHECKS}


def score_value(rule, value):
    """Turn a measured value into 0, 1 or 2 points using the checklist's rule."""
    if rule is None or value is None:
        return None
    kind, t = rule
    if kind == "max":
        return 2 if value < t else (1 if value < 2 * t else 0)
    if kind == "within":
        return 2 if value <= t else (1 if value < 2 * t else 0)
    if kind == "min":
        missing, allowed = 100 - value, 100 - t
        return 2 if value > t else (1 if missing < 2 * allowed else 0)
    if kind == "min_value":
        return 2 if value >= t else (1 if value >= t / 2 else 0)
    if kind == "zero":
        return 2 if value == 0 else (1 if value < t else 0)
    raise ValueError(f"Unknown rule {kind}")


def grade_for(score):
    for floor, letter, meaning in GRADES:
        if score >= floor:
            return letter, meaning
    return GRADES[-1][1], GRADES[-1][2]
