"""Preflight: everything worth running before the app is published.

  python -m crm_audit preflight [--org ALIAS] [--skip-org] [--quick] [--no-build]

Unit tests alone only prove the pieces work. Preflight also runs the real program on awkward
files, walks the whole client journey (audit -> review workbook -> ready-to-load files), builds the
iPad app and, when a Salesforce test org is connected, loads fixes into it and re-audits.

Stages (a plain-English line is printed for every check):
  1. Unit tests, laptop and iPad/browser engines
  2. Stress tests: awkward files through the real command, on both engines (--quick skips the big database)
  3. Round trips for each CRM's sample and the real HubSpot export
  4. iPad app build (--no-build skips it; it downloads the first time)
  5. Salesforce test-org round trip (--skip-org or --quick skips it)

Everything is done in a temporary folder, which is deleted afterwards (kept, with its path printed,
if something failed). clients/, reports/ and history/ are never touched.
"""
from __future__ import annotations

import csv
import io
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stdout
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_ORG = "ouroboros-test"
BIG_LIMIT_SECONDS = 90
CHECKLIST_MAX_LINES = 80
# The consultant-only Bullhorn note: none of these phrases may appear in anything a client gets
CONSULTANT_PHRASES = ("hasn't yet been checked", "checked against a real export", "built from bullhorn's documentation")
BROWSER_BOOT = ("import sys; sys.modules['rapidfuzz'] = None; "
                "from crm_audit.__main__ import main; main(sys.argv[1:])")


# ------------------------------------------------------------------ the stage runner

class Fail(Exception):
    """A check that did not pass; the message says why in plain English."""


class Skip(Exception):
    """A check that could not be run (not a failure); the message says why."""


def expect(condition, message):
    if not condition:
        raise Fail(message)


@dataclass
class Result:
    stage: str
    name: str
    status: str          # PASS | FAIL | SKIP
    secs: float = 0.0
    detail: str = ""


def _execute(fn):
    """Run one check; returns (status, seconds, detail)."""
    t = time.time()
    try:
        detail = fn()
        status = "PASS"
    except Skip as e:
        status, detail = "SKIP", str(e)
    except Fail as e:
        status, detail = "FAIL", str(e)
    except SystemExit as e:   # tools that call sys.exit("message")
        status, detail = "FAIL", str(e.code) if e.code not in (None, 0) else "stopped"
    except Exception as e:    # a crash in the check itself is still a failure, never a pass
        status, detail = "FAIL", f"{type(e).__name__}: {e}"
    return status, time.time() - t, ("" if detail is None else str(detail))


class Runner:
    def __init__(self, echo=print):
        self.results: list[Result] = []
        self.echo = echo

    def record(self, stage, name, status, secs=0.0, detail=""):
        r = Result(stage, name, status, secs, detail)
        self.results.append(r)
        self.echo(format_line(r))
        return r

    def check(self, stage, name, fn):
        return self.record(stage, name, *_execute(fn))

    def many(self, stage, items, workers=4):
        """Run independent checks side by side; lines are printed in the original order."""
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [(name, pool.submit(_execute, fn)) for name, fn in items]
            return [self.record(stage, name, *f.result()) for name, f in futures]

    def sequence(self, stage, items):
        """Checks that build on each other: after a failure or skip the rest are skipped."""
        broken = None
        for name, fn in items:
            if broken:
                self.record(stage, name, "SKIP", 0.0, f"not run because '{broken}' did not pass")
                continue
            if self.check(stage, name, fn).status != "PASS":
                broken = name

    def skip(self, stage, name, reason):
        return self.record(stage, name, "SKIP", 0.0, reason)

    @property
    def failed(self):
        return [r for r in self.results if r.status == "FAIL"]

    @property
    def ok(self):
        return not self.failed


def format_line(r: Result) -> str:
    tail = f"  {r.detail}" if r.detail else ""
    return f"  {r.status:<4}  {r.secs:6.1f}s  {r.name}{tail}"


def format_table(results: list[Result]) -> str:
    """The summary printed at the end: one row per check, then the totals."""
    width = max([len(r.name) for r in results] + [10])
    lines = ["", "PREFLIGHT SUMMARY", "-" * (width + 20),
             f"{'Check':<{width}}  {'Result':<6} {'Seconds':>8}", "-" * (width + 20)]
    last = None
    for r in results:
        if r.stage != last:
            lines.append(f"[{r.stage}]")
            last = r.stage
        lines.append(f"{r.name:<{width}}  {r.status:<6} {r.secs:>8.1f}")
        if r.status in ("FAIL", "SKIP") and r.detail:
            lines.append(f"    -> {r.detail}")
    n = {s: sum(1 for r in results if r.status == s) for s in ("PASS", "FAIL", "SKIP")}
    lines += ["-" * (width + 20),
              f"{n['PASS']} passed, {n['FAIL']} failed, {n['SKIP']} skipped"]
    return "\n".join(lines)


# ------------------------------------------------------------------ running the real program

def _env():
    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    return env


def engine_cmd(engine, args):
    """The command line for the laptop engine, or the iPad/browser one (rapidfuzz blocked)."""
    if engine == "desktop":
        return [sys.executable, "-m", "crm_audit", *args]
    return [sys.executable, "-c", BROWSER_BOOT, *args]


def run_cli(engine, args, cwd, timeout=600):
    """Run `python -m crm_audit <args>`; returns (exit code, all output, seconds)."""
    t = time.time()
    try:
        p = subprocess.run(engine_cmd(engine, [str(a) for a in args]), cwd=cwd, env=_env(), capture_output=True,
                           text=True, encoding="utf-8", errors="replace", timeout=timeout, stdin=subprocess.DEVNULL)
        return p.returncode, (p.stdout or "") + (p.stderr or ""), time.time() - t
    except subprocess.TimeoutExpired:
        return 124, f"Timed out after {timeout} seconds", time.time() - t


def run_python(engine, code, cwd):
    """Run a snippet of Python with the laptop or browser engine; returns its output."""
    boot = "import sys; sys.modules['rapidfuzz'] = None; " if engine == "browser" else ""
    p = subprocess.run([sys.executable, "-c", boot + code], cwd=cwd, env=_env(), capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=300, stdin=subprocess.DEVNULL)
    if p.returncode:
        raise Fail(f"the snippet crashed: {(p.stderr or p.stdout).strip()[-300:]}")
    return p.stdout.strip()


def audit_args(folder, out_base, quote=False):
    return ["run", folder, "--no-open", "--no-history", *([] if quote else ["--no-quote"]), "--out", out_base]


def find_outputs(out_dir: Path):
    """(report html, details workbook, Cleanup_review.xlsx) written by one run, each None if missing."""
    out_dir = Path(out_dir)
    pick = lambda pat: next(iter(sorted(out_dir.glob(pat))), None)  # noqa: E731
    return pick("*_report.html"), pick("*_details.xlsx"), pick("*_cleanup_*/Cleanup_review.xlsx")


def check_outputs(out_dir):
    """The report, the detail workbook and the review workbook all exist and open."""
    import openpyxl
    html, details, review = find_outputs(out_dir)
    expect(html and html.stat().st_size > 1000, "the HTML report wasn't written")
    for label, p in (("detail workbook", details), ("Cleanup_review.xlsx", review)):
        expect(p, f"the {label} wasn't written")
        try:
            wb = openpyxl.load_workbook(p, read_only=True)
            wb.close()
        except Exception as e:
            raise Fail(f"the {label} can't be opened: {e}") from e
    return html, details, review


# ------------------------------------------------------------------ awkward files

def _csv(path, header, rows, encoding="utf-8"):
    with open(path, "w", newline="", encoding=encoding) as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def _contacts(folder, n=30):
    _csv(Path(folder) / "contacts.csv", ["Id", "First Name", "Last Name", "Email", "Phone", "Created Date"],
         [[f"c{i}", f"First{i}", f"Last{i % 20}", f"p{i}@co{i % 5}.com", "(201) 555-01%02d" % i, "2026-01-05"]
          for i in range(n)])


def _ms(y, m, d):
    import datetime as dt
    return str(int(dt.datetime(y, m, d, tzinfo=dt.timezone.utc).timestamp() * 1000))


def build_title_rows(f):
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["Active Contacts"])
    ws.append([])
    ws.append(["(Do Not Modify) Contact", "First Name", "Last Name", "Email", "Business Phone", "Created On"])
    for i in range(40):
        ws.append([f"g{i}", f"First{i}", f"Last{i % 30}", f"p{i % 35}@co{i % 8}.com", "(201) 555-01%02d" % i, "2026-01-05"])
    wb.save(f / "Active Contacts title row.xlsx")


def build_corrupt_xlsx(f):
    (f / "Active Contacts.xlsx").write_bytes(b"this is not really an excel file")


def build_day_first(f):
    _csv(f / "opportunities.csv", ["Id", "Name", "StageName", "IsClosed", "IsWon", "CloseDate", "Amount"],
         [["006A", "Acme - Renewal", "Proposal", "false", "false", "31/12/2026", "50000"],
          ["006B", "Beta - New", "Proposal", "false", "false", "05/12/2026", "10000"],
          ["006C", "Gamma - Old", "Proposal", "false", "false", "01/02/2026", "7000"]])
    (f / "contacts.csv").write_text("First Name,Last Name,Email\nA,B,a@x.com\n", encoding="utf-8")


def build_no_columns(f):
    (f / "contacts.csv").write_text("foo,bar\n1,2\n", encoding="utf-8")


def build_junk_optional(f):
    _contacts(f)
    (f / "tasks.csv").write_text("foo,bar\n1,2\n", encoding="utf-8")


def build_empty_csv(f):
    (f / "contacts.csv").write_bytes(b"")


def build_header_only(f):
    (f / "contacts.csv").write_text("First Name,Last Name,Email\n", encoding="utf-8")


def build_bom(f):
    _csv(f / "contacts.csv", ["First Name", "Last Name", "Email"], [["Ann", "Lee", "ann@x.com"], ["Bo", "Cruz", "bo@y.com"]],
         encoding="utf-8-sig")


def build_junk_settings(f):
    _contacts(f)
    (f / "audit.toml").write_text(
        'client = "Junk Settings Co"\n[weights]\n1 = 0\n2 = 0\n3 = 0\n4 = 0\n5 = 0\n6 = 0\n'
        '[impact]\nreps = "ten"\nminutes_per_bad_touch = 0\nhourly_cost = "lots"\n', encoding="utf-8")


def build_broken_toml(f):
    _contacts(f)
    (f / "audit.toml").write_text('client = "Oops\n[weights\n', encoding="utf-8")


def build_unused_second_file(f):
    _contacts(f)
    shutil.copy(f / "contacts.csv", f / "contacts_old.csv")


def build_bullhorn_api(f):
    _csv(f / "ClientContact.csv",
         ["id", "firstName", "lastName", "email", "phone", "occupation", "clientCorporation.id", "clientCorporation.name",
          "owner.id", "status", "isDeleted", "dateAdded", "dateLastModified", "dateLastVisit"],
         [["1", "Ann", "Lee", "ann@acme.com", "201-555-0101", "CFO", "10", "Acme Inc", "900", "Active", "false",
           _ms(2024, 1, 5), _ms(2026, 1, 2), _ms(2026, 6, 1)],
          ["2", "Bo", "Cruz", "bo@acme.com", "201-555-0102", "CEO", "10", "Acme Inc", "901", "Archive", "false",
           _ms(2024, 2, 5), _ms(2026, 2, 2), ""],
          ["3", "Cy", "Dunn", "cy@tbdco.com", "201-555-0103", "Owner", "", "TBD", "900", "Active", "false",
           _ms(2024, 3, 5), _ms(2026, 3, 2), ""]])
    _csv(f / "ClientCorporation.csv", ["id", "name", "companyURL", "businessSectorList", "numEmployees", "owners", "status", "dateAdded"],
         [["10", "Acme Inc", "acme.com", "IT Services", "40", "Pat Gone; Sam Active", "Active", _ms(2023, 5, 5)],
          ["11", "Beta LLC", "beta.com", "Staffing", "12", "Sam Active", "Active", _ms(2023, 6, 5)]])
    _csv(f / "CorporateUser.csv", ["id", "name", "username", "enabled", "userType", "isDeleted"],
         [["900", "Pat Gone", "pat.gone", "false", "Standard", "false"],
          ["901", "Sam Active", "sam.active", "true", "Standard", "false"]])
    _csv(f / "JobOrder.csv", ["id", "title", "clientCorporation.id", "clientCorporation.name", "clientContact.id", "status",
                              "isOpen", "owner.id", "dateAdded", "dateClosed"],
         [["50", "Java Dev", "10", "Acme Inc", "1", "Accepting Candidates", "true", "901", _ms(2026, 5, 1), ""],
          ["51", "QA Lead", "10", "Acme Inc", "1", "Filled", "false", "901", _ms(2026, 1, 1), _ms(2026, 3, 1)]])


def build_candidates(f):
    (f / "ClientContact.csv").write_text(
        "ID,First Name,Last Name,Email,Occupation,Skills,Date Available,Desired Salary,Date Added\n"
        "1,Al,Ng,al@x.com,Dev,Java,01/02/2026,90000,01/01/2025\n"
        "2,Bea,Ko,bea@y.com,QA,Python,02/02/2026,80000,01/01/2025\n", encoding="utf-8")


def build_big(f, n=20000):
    """20,000 contacts, 4,000 companies and 6,000 deals."""
    rng = random.Random(5)
    _csv(f / "big contacts.csv", ["Id", "FirstName", "LastName", "Email", "Phone", "Title", "AccountId", "OwnerId", "CreatedDate"],
         [[f"003{i:012d}", rng.choice(["Ann", "Bob", "Cy", "Di"]) + str(rng.randint(0, 1500)),
           rng.choice(["Lee", "Kim", "Ng"]) + str(rng.randint(0, 1500)),
           f"user{rng.randint(0, n * 3 // 4)}@company{rng.randint(0, n // 7)}.com", "(201) 555-01%02d" % (i % 100),
           "Manager", f"001{i % (n // 5):012d}", "005000000000001", "2026-01-05T10:00:00.000Z"] for i in range(n)])
    _csv(f / "big accounts.csv", ["Id", "Name", "Website", "OwnerId"],
         [[f"001{i:012d}", f"Company {i % (n // 7)} {rng.choice(['Inc', 'LLC', ''])}", f"company{i % (n // 7)}.com",
           "005000000000001"] for i in range(n // 5)])
    _csv(f / "big opportunities.csv", ["Id", "Name", "AccountId", "StageName", "IsClosed", "IsWon", "CloseDate", "Amount"],
         [[f"006{i:012d}", f"Deal {i % (n // 15)}", f"001{i % (n // 5):012d}", "Proposal", "false", "false", "2026-12-31",
           rng.randint(1000, 90000)] for i in range(n // 3)])


DAY_FIRST_SNIPPET = (
    "from pathlib import Path; from crm_audit.loader import load_folder; from crm_audit.config import load_config; "
    "d = load_folder(Path('in'), load_config(None)); "
    "print(','.join(x.strftime('%Y-%m-%d') for x in d['opportunities'].date('close_date')))")


def check_day_first(engine, work):
    got = run_python(engine, DAY_FIRST_SNIPPET, work)
    expect(got == "2026-12-31,2026-12-05,2026-02-01",
           f"day-first dates were read wrongly: got {got} (05/12/2026 must be Dec 5, 01/02/2026 must be Feb 1)")


# name, builder, outcome, text the output must contain (any one), extra check
CASES = [
    ("Excel file with title rows above the header", build_title_rows, "ok", ["Contacts 40 rows"], None),
    ("Corrupt .xlsx gives a friendly error", build_corrupt_xlsx, "error", ["couldn't be opened as an Excel file"], None),
    ("Day-first dates (31/12 proves it; 05/12 is Dec 5)", build_day_first, "ok", [], check_day_first),
    ("File with no recognizable columns is refused politely", build_no_columns, "error", ["None of the columns"], None),
    ("Unreadable optional file is skipped with a heads-up", build_junk_optional, "ok", ["Skipped 'tasks.csv'"], None),
    ("Empty CSV gives a friendly error", build_empty_csv, "error", ["is empty"], None),
    ("CSV with only a header row does not crash", build_header_only, "either", [], None),
    ("CSV with a BOM (Excel's Save As CSV)", build_bom, "ok", ["Contacts 2 rows"], None),
    ("Zero weights and junk numbers in audit.toml fall back", build_junk_settings, "ok", [], None),
    ("Broken audit.toml gives a friendly error", build_broken_toml, "error", ["Error:"], None),
    ("A second, unused file produces a heads-up", build_unused_second_file, "ok", ["Not used"], None),
    ("Bullhorn API headers, epoch-millisecond dates, JobOrder file", build_bullhorn_api, "ok",
     ["stand in for opportunities"], None),
    ("Candidate export is flagged", build_candidates, "ok", ["candidate"], None),
]


def run_case(case, engine, tmp: Path):
    name, builder, outcome, needles, extra = case
    work = Path(tempfile.mkdtemp(prefix="case-", dir=tmp))
    folder = work / "in"
    folder.mkdir()
    builder(folder)
    code, out, secs = run_cli(engine, audit_args(folder, work / "out" / "report"), work)
    expect("Traceback" not in out, f"it crashed with a traceback:\n{out[-600:]}")
    if outcome == "ok" or (outcome == "either" and code == 0):
        expect(code == 0, f"expected it to work but it stopped (exit {code}): {out.strip()[-300:]}")
        check_outputs(work / "out")
    else:
        expect(code != 0, "expected a friendly refusal but it carried on")
        expect("Error:" in out, f"it stopped without a plain-English message: {out.strip()[-300:]}")
    if needles:
        expect(any(n.lower() in out.lower() for n in needles), f"the output should mention {needles[0]!r}: {out.strip()[-400:]}")
    if extra:
        extra(engine, work)
    return None


def run_big(engine, tmp: Path):
    work = Path(tempfile.mkdtemp(prefix="big-", dir=tmp))
    folder = work / "in"
    folder.mkdir()
    build_big(folder)
    code, out, secs = run_cli(engine, audit_args(folder, work / "out" / "report"), work, timeout=BIG_LIMIT_SECONDS * 3)
    expect("Traceback" not in out, f"it crashed with a traceback:\n{out[-600:]}")
    expect(code == 0, f"the big database stopped (exit {code}): {out.strip()[-300:]}")
    check_outputs(work / "out")
    expect(secs <= BIG_LIMIT_SECONDS, f"took {secs:.0f}s; the limit is {BIG_LIMIT_SECONDS}s")
    return f"finished in {secs:.0f}s (limit {BIG_LIMIT_SECONDS}s)"


# ------------------------------------------------------------------ round-trip helpers

ID_FILES = [  # file pattern -> columns holding record IDs (None = the first column)
    ("1_update_*.csv", None), ("1_undo_*.csv", None), ("2_clear_*.csv", None),
    ("3_merge_*.csv", ["Keep ID", "Merge IDs"]), ("3_delete.csv", ["Record ID"]),
    ("3_convert_leads.csv", ["Lead ID", "Existing contact ID", "Existing account ID"]),
    ("4_enrich_*.csv", ["Id"]),
]


def read_rows(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.reader(f))


def find_id_problems(folder, known_ids) -> list[str]:
    """Every record ID in a ready-to-load folder must exist in the export it came from."""
    folder, known, problems = Path(folder), {str(i).strip() for i in known_ids}, []
    seen = set()
    for pattern, cols in ID_FILES:
        for path in sorted(folder.glob(pattern)):
            if path in seen:
                continue
            seen.add(path)
            rows = read_rows(path)
            if not rows:
                continue
            header = rows[0]
            idx = [0] if cols is None else [header.index(c) for c in cols if c in header]
            for r in rows[1:]:
                for i in idx:
                    for v in (r[i].split(";") if i < len(r) else []):
                        v = v.strip()
                        if v and v not in known:
                            problems.append(f"{path.name}: ID {v!r} isn't in the export")
    return problems


def update_undo_problems(folder) -> list[str]:
    """Each 1_update file must have a 1_undo file that covers at least the same records and columns.
    The undo file may hold more, but only what the 2_clear files empty (it restores the old values)."""
    folder, problems = Path(folder), []
    clear_ids, clear_cols = set(), set()
    for c in folder.glob("2_clear_*.csv"):
        rows = read_rows(c)
        clear_cols.add(rows[0][1])
        clear_ids |= {r[0] for r in rows[1:]}
    for upd in sorted(folder.glob("1_update_*.csv")):
        undo = folder / upd.name.replace("1_update_", "1_undo_", 1)
        if not undo.exists():
            problems.append(f"{upd.name} has no matching {undo.name}")
            continue
        u, d = read_rows(upd), read_rows(undo)
        if u[0][0] != d[0][0]:
            problems.append(f"{upd.name} and {undo.name} have different ID columns")
        missing_cols = [c for c in u[0] if c not in d[0]]
        extra_cols = [c for c in d[0][1:] if c not in u[0] and c not in clear_cols]
        uid, did = {r[0] for r in u[1:]}, {r[0] for r in d[1:]}
        if missing_cols:
            problems.append(f"{undo.name} can't undo these columns of {upd.name}: {missing_cols}")
        if extra_cols:
            problems.append(f"{undo.name} has columns {extra_cols} that no update or clear file changes")
        if uid - did:
            problems.append(f"{undo.name} lacks {len(uid - did)} records that {upd.name} changes")
        if did - uid - clear_ids:
            problems.append(f"{undo.name} has {len(did - uid - clear_ids)} records that nothing changes")
    return problems


def applied_pairs(folder) -> set:
    """(record ID, column) for every value the ready-to-load files would change or clear."""
    folder, pairs = Path(folder), set()
    for path in sorted(folder.glob("1_update_*.csv")):
        rows = read_rows(path)
        for r in rows[1:]:
            for h, v in zip(rows[0][1:], r[1:]):
                if v != "":
                    pairs.add((r[0], h))
    for path in sorted(folder.glob("2_clear_*.csv")):
        rows = read_rows(path)
        for r in rows[1:]:
            pairs.add((r[0], rows[0][1]))
    return pairs


def update_ids(folder) -> set:
    return {r[0] for p in Path(folder).glob("1_update_*.csv") for r in read_rows(p)[1:]}


def merge_keeps(folder) -> set:
    return {r[0] for p in Path(folder).glob("3_merge_*.csv") for r in read_rows(p)[1:]}


def known_ids(folder, cfg=None) -> set:
    """Every record ID in an export folder, read by the program's own loader."""
    from .config import load_config
    from .loader import load_folder
    ids = set()
    for table in load_folder(Path(folder), cfg or load_config(None)).values():
        for v in table.text("id").dropna():
            v = str(v).strip()
            ids.add(v[:-2] if v.endswith(".0") else v)
    return ids


def phrases_in_tree(root, phrases=CONSULTANT_PHRASES) -> list[str]:
    """Files under root (text files, and inside .xlsx/.zip) that contain any of the phrases."""
    hits = []
    for p in sorted(Path(root).rglob("*")):
        if not p.is_file():
            continue
        if p.suffix.lower() in (".xlsx", ".zip"):
            try:
                with zipfile.ZipFile(p) as z:
                    blobs = [z.read(n) for n in z.namelist() if n.lower().endswith((".xml", ".txt", ".csv", ".json"))]
            except zipfile.BadZipFile:
                blobs = [p.read_bytes()]
        else:
            blobs = [p.read_bytes()]
        text = b"\n".join(blobs).decode("utf-8", errors="ignore").lower().replace("&apos;", "'").replace("&#39;", "'")
        if any(ph in text for ph in phrases):
            hits.append(str(p.relative_to(root)))
    return hits


def edit_review(src, dst) -> dict:
    """What a client does: approve 2 merges, decline 2 field fixes, pick a new owner. Returns what was done."""
    import openpyxl
    wb = openpyxl.load_workbook(src)
    done = {"declined": [], "merges": [], "owner": None}

    def table(name):
        ws = wb[name]
        return ws, {c.value: i + 1 for i, c in enumerate(ws[1]) if c.value}

    if "Field fixes" in wb.sheetnames:
        ws, col = table("Field fixes")
        keys = [(ws.cell(r, col["Record ID"]).value, ws.cell(r, col["Field"]).value) for r in range(2, ws.max_row + 1)]
        for r in range(2, ws.max_row + 1):
            if len(done["declined"]) == 2:
                break
            key = keys[r - 2]
            if (ws.cell(r, col["Approve"]).value == "Yes" and ws.cell(r, col["Kind"]).value != "fill"
                    and keys.count(key) == 1):
                ws.cell(r, col["Approve"]).value = "No"
                done["declined"].append((str(key[0]), str(key[1])))
    if "Merges" in wb.sheetnames:
        ws, col = table("Merges")
        for r in range(2, min(ws.max_row, 3) + 1):
            ws.cell(r, col["Approve"]).value = "Yes"
            done["merges"].append(str(ws.cell(r, col["Keep ID"]).value))
    if "Owners" in wb.sheetnames and "Lists" in wb.sheetnames:
        ws, col = table("Owners")
        people = [r[0] for r in wb["Lists"].iter_rows(min_row=2, values_only=True) if r and r[0]]
        for r in range(2, ws.max_row + 1):
            current = ws.cell(r, col["Current owner"]).value
            new = next((p for p in people if p != current), None)
            if new and ws.cell(r, col["Record ID"]).value:
                ws.cell(r, col["New owner"]).value = new
                done["owner"] = str(ws.cell(r, col["Record ID"]).value)
                break
    wb.save(dst)
    return done


def apply_folder(src, out, tmp):
    """Run apply-review on a workbook; returns the output text."""
    code, text, _ = run_cli("desktop", ["apply-review", src, "--out", out], tmp)
    expect(code == 0 and "Traceback" not in text, f"apply-review stopped (exit {code}): {text.strip()[-400:]}")
    return text


def roundtrip(label, input_folder, tmp: Path):
    """Audit -> untouched apply -> client edits -> apply again, with every promise checked."""
    work = Path(tempfile.mkdtemp(prefix="trip-", dir=tmp))
    code, out, _ = run_cli("desktop", audit_args(input_folder, work / "out" / "report", quote=True), work)
    expect(code == 0 and "Traceback" not in out, f"the audit stopped (exit {code}): {out.strip()[-400:]}")
    expect("Suggested quote" in out and "$" in out.split("Suggested quote", 1)[1], "the price quote wasn't worked out")
    _, _, review = check_outputs(work / "out")
    known = known_ids(input_folder)
    expect(known, "no record IDs could be read from the export")

    # untouched workbook: only the pre-approved safe fixes; nothing hands-on without a decision
    plain = work / "plain"
    apply_folder(review, plain, work)
    bad = find_id_problems(plain, known)
    expect(not bad, "untouched workbook: " + "; ".join(bad[:3]))
    stray = sorted(p.name for p in plain.glob("3_*"))
    expect(not stray, f"files appeared for decisions nobody made: {stray}")

    # the client's edits
    edited = work / "Cleanup_review_edited.xlsx"
    done = edit_review(review, edited)
    final = work / "final"
    apply_folder(edited, final, work)
    bad = find_id_problems(final, known)
    expect(not bad, "after edits: " + "; ".join(bad[:3]))
    bad = update_undo_problems(final)
    expect(not bad, "; ".join(bad[:3]))
    applied = applied_pairs(final)
    back = [p for p in done["declined"] if p in applied]
    expect(not back, f"declined changes were applied anyway: {back}")
    expect(merge_keeps(final) == set(done["merges"]),
           f"approved merges {done['merges']} but the merge files hold {sorted(merge_keeps(final))}")
    if done["owner"]:
        expect(done["owner"] in update_ids(final), f"the new owner chosen for record {done['owner']} wasn't applied")
    checklist = final / "CHECKLIST.txt"
    expect(checklist.exists(), "CHECKLIST.txt wasn't written")
    n_lines = len(checklist.read_text(encoding="utf-8").splitlines())
    expect(n_lines <= CHECKLIST_MAX_LINES, f"CHECKLIST.txt is {n_lines} lines; the limit is {CHECKLIST_MAX_LINES}")
    leaked = phrases_in_tree(work / "out") + phrases_in_tree(plain) + phrases_in_tree(final)
    expect(not leaked, f"the consultant-only note is in client files: {leaked}")
    if label == "bullhorn":
        expect("Note for you" in out, "the consultant note should be printed for you (Bullhorn)")
    return (f"{len(done['declined'])} declined, {len(done['merges'])} merges, owner "
            f"{'picked' if done['owner'] else 'n/a'}, {n_lines}-line checklist")


# ------------------------------------------------------------------ app build

def build_check(tmp: Path):
    from . import webbuild
    out = tmp / "app"
    webbuild.build(out=out)
    for f in ("index.html", "sw.js", "manifest.webmanifest", "app.js", "tour.js", "worker.js", ".nojekyll", "py/wheels.json",
              "py/crm_audit.zip", *[f"pyodide/{c}" for c in webbuild.CORE]):
        expect((out / f).exists(), f"{f} is missing from the built app")
    sw = (out / "sw.js").read_text(encoding="utf-8")
    expect("__VERSION__" not in sw and "__FILES__" not in sw, "sw.js still has unfilled placeholders")
    version = re.search(r"[0-9a-f]{12}", sw)
    expect(version, "sw.js has no version")
    wheels = json.loads((out / "py" / "wheels.json").read_text(encoding="utf-8"))
    expect(wheels and all((out / "py" / w).exists() for w in wheels), "a wheel listed in wheels.json is missing")
    pkg = ROOT / "crm_audit"
    want = {p.relative_to(ROOT).as_posix() for p in pkg.rglob("*")
            if p.is_file() and "__pycache__" not in p.parts and p.name != "webbuild.py"}
    unpacked = tmp / "unzipped"
    with zipfile.ZipFile(out / "py" / "crm_audit.zip") as z:
        have = set(z.namelist())
        lacking = sorted(want - have)
        expect(not lacking, f"crm_audit.zip lacks: {lacking}")
        expect("crm_audit/webbuild.py" not in have, "crm_audit.zip shouldn't hold webbuild.py")
        z.extractall(unpacked)
    probe = ("import sys; sys.modules['rapidfuzz'] = None; import crm_audit.web, crm_audit; "
             f"assert crm_audit.__file__.startswith({str(unpacked)!r}), crm_audit.__file__; print('imported')")
    env = dict(os.environ, PYTHONPATH=str(unpacked), PYTHONIOENCODING="utf-8")
    p = subprocess.run([sys.executable, "-c", probe], cwd=unpacked, env=env, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", stdin=subprocess.DEVNULL)
    expect(p.returncode == 0 and "imported" in p.stdout,
           f"crm_audit.zip doesn't import on its own: {(p.stderr or p.stdout).strip()[-400:]}")
    size = sum(f.stat().st_size for f in out.rglob("*") if f.is_file())
    return f"{size / 1e6:.1f} MB, version {version.group(0)}"


# ------------------------------------------------------------------ Salesforce test org

def _tool():
    import importlib.util
    spec = importlib.util.spec_from_file_location("salesforce_test_org", ROOT / "tools" / "salesforce_test_org.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def org_ready(alias):
    """Raises Skip with the reason if the test org can't be used without a person at the keyboard."""
    exe = shutil.which("sf") or shutil.which("sf.cmd")
    if not exe:
        raise Skip("the Salesforce CLI (sf) isn't installed")
    try:
        p = subprocess.run([exe, "org", "display", "--target-org", alias, "--json"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=90, stdin=subprocess.DEVNULL)
        info = (json.loads(p.stdout or "{}").get("result") or {})
    except (subprocess.TimeoutExpired, ValueError, OSError) as e:
        raise Skip(f"couldn't ask the Salesforce CLI about '{alias}' ({type(e).__name__})") from e
    if p.returncode or info.get("connectedStatus") != "Connected":
        raise Skip(f"'{alias}' isn't signed in; run: sf org login web --alias {alias}")
    url = info.get("instanceUrl", "")
    if not any(s in url for s in (".develop.my.salesforce.com", ".sandbox.my.salesforce.com", ".scratch.my.salesforce.com")):
        raise Skip(f"{url} isn't a Developer Edition or sandbox org, so it won't be touched")
    return info


def score_export(folder):
    """(overall score, grade, {check id: value}) for an export folder."""
    from .checks import run_checks
    from .config import load_config
    from .loader import load_folder
    from .scoring import build_scorecard
    cfg = load_config(None)
    _, results = run_checks(load_folder(Path(folder), cfg), cfg)
    card = build_scorecard(results, cfg)
    return card.overall, card.grade, {k: r.value for k, r in results.items()}


def org_stage(run: Runner, alias, tmp: Path):
    stage = "5 Salesforce test org"
    try:
        info = org_ready(alias)
    except Skip as e:
        run.skip(stage, "Salesforce test-org round trip", str(e))
        return
    tool = _tool()
    st: dict = {}
    work = tmp / "sf"
    work.mkdir()

    def captured(fn, *a, **kw):
        buf, real = io.StringIO(), sys.stdout
        with redirect_stdout(buf):
            try:
                result = fn(*a, **kw)
            finally:
                for line in buf.getvalue().splitlines():
                    sys.__stdout__.write("        " + line.strip() + "\n")
        return result, buf.getvalue()

    def wipe():
        captured(tool.wipe, alias, True)
        return f"{info.get('username', alias)}"

    def load():
        _, text = captured(tool.load, alias)
        expect("Loaded the fake sample company" in text, "the sample didn't finish loading")
        missing = [l.strip() for l in text.splitlines() if "not created" in l]
        expect(not missing, f"Salesforce refused some sample records: {missing[:2]}")

    def export_before():
        captured(tool.export, alias, work / "before")

    def audit_before():
        st["before"] = score_export(work / "before")
        code, out, _ = run_cli("desktop", audit_args(work / "before", work / "out1" / "report"), work)
        expect(code == 0 and "Traceback" not in out, f"the audit of the export stopped: {out.strip()[-300:]}")
        _, _, st["review"] = check_outputs(work / "out1")
        return f"score {st['before'][0]:.1f} (grade {st['before'][1]})"

    def apply():
        apply_folder(st["review"], work / "ready", work)
        bad = find_id_problems(work / "ready", known_ids(work / "before"))
        expect(not bad, "; ".join(bad[:3]))
        for name in ("1_update_contacts.csv", "1_update_accounts.csv"):
            expect((work / "ready" / name).exists(), f"{name} wasn't written")

    def load_fixes():
        total_ok = total = 0
        for name in ("1_update_contacts.csv", "1_update_accounts.csv"):
            (ok, n, bad), _ = captured(tool.update, alias, work / "ready" / name)
            total_ok, total = total_ok + ok, total + n
            expect(ok == n and not bad, f"{name}: only {ok} of {n} updated; first errors: {bad}")
        return f"{total_ok:,} records updated, 0 errors"

    def reaudit():
        captured(tool.export, alias, work / "after")
        after = score_export(work / "after")
        before = st["before"]
        msg = f"score {before[0]:.1f} ({before[1]}) -> {after[0]:.1f} ({after[1]})"
        for cid, label in (("3.5", "format check 3.5"), ("3.3", "picklist check 3.3")):
            b, a = before[2][cid], after[2][cid]
            expect(b is not None and a is not None, f"{label} couldn't be measured")
            msg += f"; {cid} {b:.1f}% -> {a:.1f}%"
            expect(a < b, f"{label} didn't improve; {msg}")
        expect(after[0] >= before[0], f"the score dropped: {msg}")
        return msg + ". The org is left loaded with the post-fix data."

    run.sequence(stage, [
        ("Wipe the test org's sample data", wipe),
        ("Load the sample company into the org", load),
        ("Export it back out", export_before),
        ("Audit the export and write the review workbook", audit_before),
        ("apply-review on the untouched workbook", apply),
        ("Load the update files into the org", load_fixes),
        ("Export again and re-audit: score up, 3.5 and 3.3 better", reaudit),
    ])


# ------------------------------------------------------------------ the whole thing

def js_backup_tests():
    """The app's back up / restore logic, run under Node (skipped when Node isn't installed)."""
    node = shutil.which("node")
    if not node:
        raise Skip("Node.js isn't installed, so the app's back up / restore logic wasn't checked")
    test = ROOT / "tests" / "js" / "backup.test.mjs"
    if not test.exists():
        raise Skip("tests/js/backup.test.mjs not found")
    r = subprocess.run([node, str(test)], capture_output=True, text=True, timeout=120, cwd=ROOT)
    if r.returncode != 0:
        raise Fail("JavaScript backup tests failed: " + (r.stdout + r.stderr).strip()[-600:])


def js_tour_tests():
    """The Guided demo's step definitions, run under Node (skipped when Node isn't installed)."""
    node = shutil.which("node")
    if not node:
        raise Skip("Node.js isn't installed, so the Guided demo's steps weren't checked")
    test = ROOT / "tests" / "js" / "tour.test.mjs"
    if not test.exists():
        raise Skip("tests/js/tour.test.mjs not found")
    r = subprocess.run([node, str(test)], capture_output=True, text=True, timeout=120, cwd=ROOT)
    if r.returncode != 0:
        raise Fail("JavaScript Guided demo tests failed: " + (r.stdout + r.stderr).strip()[-600:])


def _fail(msg):
    raise Fail(msg)


def run_all(org=DEFAULT_ORG, skip_org=False, quick=False, build=True) -> list[Result]:
    from . import selftest
    from .sample_data import generate
    run = Runner()
    tmp = Path(tempfile.mkdtemp(prefix="uroboric-preflight-"))
    started = time.time()
    print(f"Preflight: working in {tmp} (deleted afterwards unless something fails)\n")
    try:
        print("1. Unit tests (laptop and iPad engines)")
        for engine in ("desktop", "browser"):
            run.check("1 Unit tests", f"Unit tests, {'laptop' if engine == 'desktop' else 'iPad/browser'} engine",
                      lambda e=engine: None if selftest.run((e,), quiet=True) else _fail("unit tests failed"))
        run.check("1 Unit tests", "JavaScript backup tests", js_backup_tests)
        run.check("1 Unit tests", "JavaScript Guided demo tests", js_tour_tests)

        print("\n2. Stress tests: awkward files through the real command, on both engines")
        items = [(f"{c[0]} [{e}]", lambda c=c, e=e: run_case(c, e, tmp)) for c in CASES for e in ("desktop", "browser")]
        run.many("2 Stress tests", items, workers=min(4, os.cpu_count() or 2))
        if quick:
            run.skip("2 Stress tests", "Big database (20,000 contacts)", "skipped by --quick")
        else:
            for e in ("desktop", "browser"):
                run.check("2 Stress tests", f"Big database, 20,000 contacts / 4,000 accounts / 6,000 deals [{e}]",
                          lambda e=e: run_big(e, tmp))

        print("\n3. Round trips: audit -> review workbook -> ready-to-load files")
        trips = []
        for crm in ("salesforce", "hubspot", "dynamics", "bullhorn"):
            def go(crm=crm):
                return roundtrip(crm, generate(tmp / f"sample-{crm}", crm=crm), tmp)
            trips.append((f"Round trip: {crm} sample", go))

        def real_hubspot():
            folder = tmp / "hubspot-real"
            shutil.copytree(ROOT / "tests" / "fixtures" / "hubspot_real", folder)
            return roundtrip("hubspot", folder, tmp)
        trips.append(("Round trip: real HubSpot export", real_hubspot))
        run.many("3 Round trips", trips, workers=min(3, os.cpu_count() or 2))

        print("\n4. iPad app build")
        if build:
            run.check("4 App build", "Build the iPad app and import its package", lambda: build_check(tmp))
        else:
            run.skip("4 App build", "Build the iPad app and import its package", "skipped by --no-build")

        print("\n5. Salesforce test org")
        if quick or skip_org:
            run.skip("5 Salesforce test org", "Salesforce test-org round trip",
                     "skipped by " + ("--quick" if quick else "--skip-org"))
        else:
            org_stage(run, org, tmp)
    finally:
        print(format_table(run.results))
        print(f"Total preflight time: {time.time() - started:.0f} seconds")
        if run.failed:
            print(f"\nKept the working files for inspection: {tmp}")
        else:
            shutil.rmtree(tmp, ignore_errors=True)
    return run.results


def org_skipped(results) -> str | None:
    """The reason the Salesforce stage didn't run, or None if it ran."""
    for r in results:
        if r.stage.startswith("5") and r.status == "SKIP" and r.name.startswith("Salesforce test-org"):
            return r.detail
    return None


def run(org=DEFAULT_ORG, skip_org=False, quick=False, build=True, results_out: list | None = None) -> bool:
    """True only if no check failed. Pass a list as results_out to receive the individual results."""
    results = run_all(org, skip_org, quick, build)
    if results_out is not None:
        results_out.extend(results)
    ok = not any(r.status == "FAIL" for r in results)
    print("\nPreflight passed." if ok else "\nPreflight FAILED: see the FAIL lines above.")
    return ok
