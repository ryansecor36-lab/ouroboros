"""Uroboric: runs the CRM Data Health Audit checklist against Salesforce CSV exports."""
__version__ = "0.1.0"
