"""Uroboric: runs the CRM Data Health Audit checklist against CRM exports."""
__version__ = "1.0.0"
