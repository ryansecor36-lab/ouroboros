"""The cleanup kit: turns the audit's findings into files that fix the data.

Nothing here touches the CRM. It produces:
  - Data Loader "Update" CSVs (Id + new values, Salesforce API field names) for safe, mechanical
    fixes: name case, phone format, email typos, state/country/industry spellings, new owners
  - merge plans (which record to keep and why) and "fill before merge" files, so no information
    is lost when duplicates are merged
  - one "clear" file per field for made-up values (these need Data Loader's Insert Null Values)
  - lists that need a person's decision: leads to convert, junk records to review for deletion,
    and a to-do list for each rep's deals
  - an enrichment list of records that need outside data from a provider the client approves
  - a review workbook showing every change as before -> after, and a plain-English read-me
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd
import phonenumbers

from . import normalize as N
from .checks import UnionFind
from .fuzzcompat import fuzz
from .plain import nice_date

# Salesforce API names for the fields the kit can change
API = {
    "contacts": {"first_name": "FirstName", "last_name": "LastName", "email": "Email", "phone": "Phone",
                 "mobile": "MobilePhone", "title": "Title", "state": "MailingState", "country": "MailingCountry",
                 "lead_source": "LeadSource", "owner_id": "OwnerId", "account_id": "AccountId"},
    "accounts": {"website": "Website", "industry": "Industry", "employees": "NumberOfEmployees",
                 "state": "BillingState", "country": "BillingCountry", "city": "BillingCity", "owner_id": "OwnerId"},
}
PLACEHOLDER_FIELD_API = {"Title": "Title", "Email": "Email", "Phone": "Phone", "Industry": "Industry",
                         "Employees": "NumberOfEmployees"}
PLACEHOLDER_LOGICAL = {"Title": "title", "Email": "email", "Phone": "phone", "Industry": "industry",
                       "Employees": "employees"}

# HubSpot and Dynamics import files are matched on their own column labels. The kit uses the
# client's own export headers; these are the defaults when a column wasn't in the export.
# None = the CRM won't take it in an import (HubSpot's Original Source is read-only, for example).
LABELS = {
    "hubspot": {
        "contacts": {"id": "Record ID", "first_name": "First Name", "last_name": "Last Name", "email": "Email",
                     "phone": "Phone Number", "mobile": "Mobile Phone Number", "title": "Job Title",
                     "state": "State/Region", "country": "Country/Region", "owner": "Contact owner",
                     "lead_source": None, "account_id": None},
        "accounts": {"id": "Record ID", "website": "Website URL", "industry": "Industry",
                     "employees": "Number of Employees", "state": "State/Region", "country": "Country/Region",
                     "city": "City", "owner": "Company owner"},
    },
    "dynamics": {
        "contacts": {"id": "(Do Not Modify) Contact", "first_name": "First Name", "last_name": "Last Name",
                     "email": "Email", "phone": "Business Phone", "mobile": "Mobile Phone", "title": "Job Title",
                     "state": "Address 1: State/Province", "country": "Address 1: Country/Region",
                     "owner": "Owner", "lead_source": None, "account_id": None},
        "accounts": {"id": "(Do Not Modify) Account", "website": "Website", "industry": "Industry",
                     "employees": "Number of Employees", "state": "Address 1: State/Province",
                     "country": "Address 1: Country/Region", "city": "Address 1: City", "owner": "Owner"},
    },
}


class Namer:
    """Column names for the kit's load files, in the format this client's CRM imports."""

    def __init__(self, ctx):
        self.crm, self.ctx = ctx.crm, ctx

    def _label(self, obj, key):
        t = self.ctx.t(obj)
        labels = LABELS[self.crm][obj]
        if key in labels and labels[key] is None:
            return None
        src = {"owner": "owner_name"}.get(key, key)
        col = t.mapping.get(src) if t is not None else None
        return col or labels.get(key)

    def f(self, obj, logical):
        if self.crm == "salesforce":
            return API[obj].get(logical)
        return self._label(obj, logical)

    def id(self, obj):
        return "Id" if self.crm == "salesforce" else self._label(obj, "id")

    def owner(self, obj):
        return "OwnerId" if self.crm == "salesforce" else self._label(obj, "owner")


# How each step is carried out, per CRM
HOW = {
    "salesforce": {
        "backup": "Data Export (Setup > Data Export > Export Now) or Data Loader > Export All for every object "
                  "you'll change. Load into a sandbox first if the client has one.",
        "update": "Data Loader > Update > {obj}. Map Id and each column.",
        "owner": "Data Loader > Update > Contact for the first file. Pick owners for the second, then load it the same way.",
        "merge": "In Salesforce use Merge Contacts / Merge Accounts (or a merge tool such as DemandTools or Plauti), "
                 "keeping the 'Keep (master) ID' record. Merging keeps activity history; deleting does not.",
        "convert": "Open each lead > Convert > choose the existing contact.",
        "clear": "Data Loader > Settings > turn ON 'Insert null values', load each file with Update, then turn it OFF again.",
        "delete": "Check each one, then Data Loader > Delete (records go to the Recycle Bin for 15 days).",
        "loader": """Loading a file with Salesforce Data Loader (free, from Salesforce)
  1. Open Data Loader and log in to the client's org.
  2. Choose Update (or Delete for step 9), pick the object (Contact or Account).
  3. Choose the CSV. Click "Auto-Match Fields to Columns" - the column names are Salesforce
     field names, so they match automatically. Check that Id maps to Id.
  4. Run it. Data Loader writes a success file and an error file; check the error file.""",
    },
    "hubspot": {
        "backup": "Export every object you'll change: Contacts and Companies > Export (all properties).",
        "update": "HubSpot > Import > File from computer > One object > {obj}s > 'Update existing records'. "
                  "HubSpot matches rows on Record ID; the column headers are your property names.",
        "owner": "Import the first file the same way (it sets the owner column). Pick owners for the second, then import it.",
        "merge": "Merge in HubSpot (open the record > Actions > Merge), keeping the 'Keep (master) ID' record. "
                 "HubSpot merges two at a time and keeps the activity of both.",
        "convert": "",
        "clear": "HubSpot imports skip blank cells, so clear these with bulk edit: filter the list to the IDs in "
                 "the file, select all, edit the property and leave it empty.",
        "delete": "Check each one, then select them in the list and Delete (they can be restored for 90 days).",
        "loader": """Importing a file into HubSpot
  1. Contacts (or Companies) > Import > Start an import > File from computer > One file > One object.
  2. Choose Contacts or Companies, and tick "Update existing records" with Record ID as the match.
  3. Upload the CSV. The column headers match your property names, so they map automatically.
  4. Blank cells are skipped, so only the changed values are written. Check the import's error list.""",
    },
    "dynamics": {
        "backup": "Export to Excel every view you'll change (All Contacts, All Accounts) and keep the files.",
        "update": "Open your own Excel export of {obj}s, paste in the new values for these rows (matched on the "
                  "hidden '(Do Not Modify)' ID column), and Import from Excel.",
        "owner": "Select the records in a view and use Assign, or update the Owner column the same way as step 2.",
        "merge": "Select two records in a view > Merge, choosing the 'Keep (master) ID' record as the master. "
                 "Dynamics merges two at a time and moves related records to the master.",
        "convert": "Open each lead > Qualify, and choose the existing contact and account.",
        "clear": "Clear these cells in your Excel export and Import from Excel, or use Edit on the selected records.",
        "delete": "Check each one, then select them in a view and Delete.",
        "loader": """Updating records in Dynamics 365
  1. Export the matching view to Excel (it includes the hidden "(Do Not Modify)" ID columns).
  2. For each row in the kit's file, find the same ID in your export and paste in the new values.
     Don't change the hidden columns.
  3. Data > Import from Excel. Dynamics matches rows on the hidden ID and updates those records.
  4. Check the import job for errors.""",
    },
}
CONTACT_FILL = ["phone", "mobile", "title", "account_id", "lead_source", "state", "country"]
ACCOUNT_FILL = ["website", "industry", "employees", "city", "state", "country"]


@dataclass
class Kit:
    changes: list[dict] = field(default_factory=list)   # every field change, for the review sheet
    loads: dict[str, pd.DataFrame] = field(default_factory=dict)   # file name -> Data Loader CSV
    lists: dict[str, pd.DataFrame] = field(default_factory=dict)   # file name -> decision list CSV
    sheets: dict[str, pd.DataFrame] = field(default_factory=dict)  # extra review-workbook sheets
    steps: list[dict] = field(default_factory=list)     # the "Start here" table
    notes: list[str] = field(default_factory=list)
    crm: str = "salesforce"

    def summary(self) -> dict:
        ready = sum(len(df) for df in self.loads.values())
        decide = sum(len(self.lists[k]) for k in self.lists if not k.startswith("10_"))
        enrich = sum(len(self.lists[k]) for k in self.lists if k.startswith("10_"))
        return {"ready": ready, "decide": decide, "enrich": enrich,
                "field_changes": len(self.changes), "files": len(self.loads) + len(self.lists)}


# ------------------------------------------------------------------ value fixers

def proper_name(v: str) -> str:
    def part(p):
        p = p.lower()
        if p.startswith("mc") and len(p) > 2:
            return "Mc" + p[2].upper() + p[3:]
        if "'" in p:
            return "'".join(s[:1].upper() + s[1:] for s in p.split("'"))
        return p[:1].upper() + p[1:]
    return "-".join(" ".join(part(w) for w in seg.split(" ")) for seg in v.split("-"))


def needs_case_fix(v) -> bool:
    return isinstance(v, str) and sum(c.isalpha() for c in v) >= 3 and (v.isupper() or v.islower())


def reformat_phone(raw, main_pattern, region):
    if not isinstance(raw, str):
        return None
    try:
        p = phonenumbers.parse(raw, region)
    except phonenumbers.NumberParseException:
        return None
    if not phonenumbers.is_valid_number(p):
        return None
    nat, cc = str(p.national_number), str(p.country_code)
    home = phonenumbers.region_code_for_number(p) == region
    if main_pattern and home:
        n9 = main_pattern.count("9")
        for digits in (nat, cc + nat):
            if n9 == len(digits):
                it = iter(digits)
                return "".join(next(it) if ch == "9" else ch for ch in main_pattern)
    fmt = phonenumbers.PhoneNumberFormat.NATIONAL if home else phonenumbers.PhoneNumberFormat.INTERNATIONAL
    return phonenumbers.format_number(p, fmt)


def fix_email(v):
    if not isinstance(v, str):
        return None
    new = re.sub(r"\s+", "", v).lower()
    return new if new != v and N.email_syntax_ok(new) else None


def dominant_map(series: pd.Series, canon) -> dict:
    """Each spelling variant -> the spelling most of the CRM already uses for that value."""
    vals = series.dropna()
    out = {}
    if vals.empty:
        return out
    df = pd.DataFrame({"raw": vals, "key": vals.map(canon)}).dropna(subset=["key"])
    for _, grp in df.groupby("key"):
        vc = grp["raw"].value_counts()
        for v in vc.index[1:]:
            out[v] = vc.index[0]
    return out


def _main_phone_pattern(series):
    pats = series.map(N.phone_pattern).dropna()
    return pats.value_counts().index[0] if len(pats) else None


# ------------------------------------------------------------------ building the kit

def _groups_from(results, checks_and_sheets, id_col):
    """Duplicate groups from one or more checks' evidence sheets, merged where they overlap."""
    frames = []
    for cid, sheet in checks_and_sheets:
        df = results[cid].details.get(sheet)
        if df is not None and len(df):
            frames.append(df[["Group", id_col]].assign(src=cid))
    if not frames:
        return []
    allr = pd.concat(frames, ignore_index=True).dropna(subset=[id_col])
    ids = list(dict.fromkeys(allr[id_col]))
    pos = {i: n for n, i in enumerate(ids)}
    uf = UnionFind(len(ids))
    for (src, g), grp in allr.groupby(["src", "Group"]):
        members = [pos[i] for i in grp[id_col]]
        for m in members[1:]:
            uf.union(members[0], m)
    return [[ids[i] for i in g] for g in uf.groups()]


def build(ctx, results) -> Kit:
    kit = Kit(crm=ctx.crm)
    namer = Namer(ctx)
    C, A, O, L = ctx.contacts, ctx.accounts, ctx.opps, ctx.leads
    tC, tA = ctx.t("contacts"), ctx.t("accounts")
    region = ctx.region

    def change(obj, rid, name, api, cur, new, why, file):
        if api is None:  # this CRM doesn't accept that field in an import
            return
        kit.changes.append({"Object": obj, "Record ID": rid, "Name": name, "Field": api,
                            "Current value": cur, "New value": new, "Why": why, "File": file})

    # Junk records go to the delete-review list, so don't polish them
    junk = set()
    if C is not None:
        for rid, f, l, e in zip(C["id"], C["first_name"], C["last_name"], C["email"]):
            dom = N.email_domain(e)
            if any(N.is_junk(x) for x in (f, l)) or dom in {"test.com", "example.com", "asdf.com"}:
                if isinstance(rid, str):
                    junk.add(rid)

    # ---- 02 standardize contacts
    if C is not None and tC.has("id"):
        f = "02_update_contacts_standardize.csv"
        main = _main_phone_pattern(C["phone"])
        states = dominant_map(C["state"], N.canon_state)
        countries = dominant_map(C["country"], N.canon_country)
        for r in C.to_dict("records"):
            rid = r["id"]
            if not isinstance(rid, str) or rid in junk:
                continue
            nm = r["name"]
            for k in ("first_name", "last_name"):
                if needs_case_fix(r[k]):
                    change("Contact", rid, nm, namer.f("contacts", k), r[k], proper_name(r[k]), "name in ALL CAPS or lowercase", f)
            for k in ("phone", "mobile"):
                raw = r[k]
                if isinstance(raw, str) and N.phone_pattern(raw) != main:
                    new = reformat_phone(raw, main, region)
                    if new and new != raw:
                        change("Contact", rid, nm, namer.f("contacts", k), raw, new, "phone put in the team's main format", f)
            new = fix_email(r["email"])
            if new:
                change("Contact", rid, nm, namer.f("contacts", "email"), r["email"], new, "email with spaces or capitals", f)
            for k, m in (("state", states), ("country", countries)):
                if r[k] in m:
                    change("Contact", rid, nm, namer.f("contacts", k), r[k], m[r[k]], "spelled the way most records spell it", f)
    elif C is not None:
        kit.notes.append("The contacts export has no Id column, so no contact update files could be made. "
                         "Export with Data Loader to include record Ids.")

    # ---- 03 standardize accounts
    if A is not None and tA.has("id"):
        f = "03_update_accounts_standardize.csv"
        maps = {"state": dominant_map(A["state"], N.canon_state),
                "country": dominant_map(A["country"], N.canon_country),
                "industry": dominant_map(A["industry"], N.canon_text)}
        for r in A.to_dict("records"):
            rid = r["id"]
            if not isinstance(rid, str):
                continue
            for k, m in maps.items():
                if r[k] in m:
                    change("Account", rid, r["name"], namer.f("accounts", k), r[k], m[r[k]],
                           "spelled the way most records spell it", f)

    # ---- 04 reassign owners
    orph = results["4.1"].details.get("Orphaned records")
    if orph is not None and len(orph):
        f = "04_update_contacts_new_owner.csv"
        acct_owner, acct_owner_name = {}, {}
        if A is not None:
            for aid, oid, on in zip(A["id"], A["owner_id"], A["owner"]):
                if isinstance(aid, str) and isinstance(oid, str) and ctx.owner_status(pd.Series([oid]), pd.Series([on])).iloc[0] == "ok":
                    acct_owner[aid], acct_owner_name[aid] = oid, on
        c_acct = dict(zip(C["id"], C["account_id"])) if C is not None else {}
        rows = []
        for _, r in orph.iterrows():
            sug = sug_name = None
            if r["Object"] == "Contact":
                aid = c_acct.get(r["Record ID"])
                sug, sug_name = acct_owner.get(aid), acct_owner_name.get(aid)
            rows.append({"Object": r["Object"], "Record ID": r["Record ID"], "Name": r["Name"],
                         "Current owner": r["Owner"], "Problem": r["Problem"],
                         "Suggested new owner": sug_name or "Choose an owner",
                         "Suggested OwnerId": sug})
            if sug:
                change("Contact", r["Record ID"], r["Name"], namer.owner("contacts"), r["Owner"], sug_name,
                       "owner left or is missing; given to the account's owner", f)
        kit.sheets["New owners"] = pd.DataFrame(rows)
        loads = [x for x in rows if x["Suggested OwnerId"]]
        if loads:
            kit.loads[f] = pd.DataFrame({  # Salesforce takes the user Id; HubSpot/Dynamics take the name
                namer.id("contacts"): [x["Record ID"] for x in loads],
                namer.owner("contacts"): [x["Suggested OwnerId"] if ctx.crm == "salesforce" else x["Suggested new owner"]
                                          for x in loads]})
        rest = [x for x in rows if not x["Suggested OwnerId"]]
        if rest:
            kit.lists["04_choose_owner.csv"] = pd.DataFrame(rest).drop(columns=["Suggested OwnerId"])

    # ---- 05/06 merges: plan + fill blanks on the record being kept
    _merge_contacts(kit, ctx, results, change, junk)
    _merge_accounts(kit, ctx, results, change)
    _merge_deals(kit, ctx, results)

    # ---- 07 leads to convert into existing contacts
    ld = results["1.6"].details.get("Leads already contacts")
    if ld is not None and len(ld):
        c_acct = dict(zip(C["id"], C["account_id"])) if C is not None else {}
        out = ld.copy()
        out.insert(2, "Existing account ID", out["Existing contact ID"].map(c_acct))
        out["What to do"] = "Convert the lead and attach it to the existing contact (don't create a new one)"
        kit.lists["07_convert_leads_to_existing_contacts.csv"] = out

    # ---- 08 clear made-up values (one file per field: Insert Null Values blanks every mapped column)
    ph = results["3.8"].details.get("Placeholder values")
    if ph is not None and len(ph):
        for obj_label, obj in (("Contact", "contacts"), ("Account", "accounts")):
            sub = ph[(ph["Object"] == obj_label) & ph["Field"].isin(PLACEHOLDER_FIELD_API)]
            for fld, grp in sub.groupby("Field"):
                api = namer.f(obj, PLACEHOLDER_LOGICAL[fld])
                if api is None:
                    continue
                f = f"08_clear_{obj}_{re.sub(r'[^A-Za-z0-9]+', '_', api).strip('_')}.csv"
                ids = [i for i in dict.fromkeys(grp["Record ID"]) if isinstance(i, str) and i not in junk]
                if not ids:
                    continue
                kit.loads[f] = pd.DataFrame({namer.id(obj): ids, api: [""] * len(ids)})
                for _, r in grp[grp["Record ID"].isin(ids)].drop_duplicates("Record ID").iterrows():
                    change(obj_label, r["Record ID"], r["Name"], api, r["Value"], "(blank)",
                           r["Why it looks made up"], f)

    # ---- 09 junk records to review for deletion
    if junk:
        sub = C[C["id"].isin(junk)]
        kit.lists["09_review_delete_contacts.csv"] = pd.DataFrame({
            "Id": sub["id"], "Name": sub["name"], "Email": sub["email"], "Account": sub["account"],
            "Owner": sub["owner"], "Last activity": sub["last_activity"],
            "Why": "test or junk entry; check nothing important is attached, then delete"})

    # ---- 10 enrichment lists (send to a data provider only with the client's approval)
    if C is not None:
        bad_phone = results["2.4"].flagged.get("contacts", set())
        stale = set(results["2.5"].details.get("Stale contacts", pd.DataFrame(columns=["Contact ID"]))["Contact ID"])
        rows = []
        for r in C.to_dict("records"):
            if r["id"] in junk or not isinstance(r["id"], str):
                continue
            need = []
            if r["id"] in bad_phone:
                need.append("phone")
            if not isinstance(r["title"], str) or N.canon_text(r["title"]) in {"tbd", "contact", "employee", "n a", "unknown"}:
                need.append("job title")
            if not isinstance(r["email"], str):
                need.append("email")
            if r["id"] in stale:
                need.append("confirm still at company")
            if need:
                rows.append({"Id": r["id"], "FirstName": r["first_name"], "LastName": r["last_name"],
                             "Email": r["email"], "Company": r["account"], "Company domain": r["domain_key"],
                             "Needs": ", ".join(need)})
        if rows:
            kit.lists["10_enrich_contacts.csv"] = pd.DataFrame(rows)
    if A is not None:
        rows = []
        for r in A.to_dict("records"):
            need = [lbl for k, lbl in (("industry", "industry"), ("employees", "employee count"), ("website", "website"))
                    if not isinstance(r[k], str) or (k == "industry" and N.canon_text(r[k]) in {"other", "unknown"})]
            if not (isinstance(r["state"], str) or isinstance(r["city"], str) or isinstance(r["country"], str)):
                need.append("location")
            if need and isinstance(r["id"], str):
                rows.append({"Id": r["id"], "Name": r["name"], "Website": r["website"], "Needs": ", ".join(need)})
        if rows:
            kit.lists["10_enrich_accounts.csv"] = pd.DataFrame(rows)

    # ---- rep to-do lists
    _rep_worklists(kit, ctx, results)

    # ---- Data Loader update files from the collected changes (blanks are ignored by Data Loader)
    ch = pd.DataFrame(kit.changes)
    if len(ch):
        for f, grp in ch[ch["File"].str.match(r"0[235]_")].groupby("File"):
            wide = grp.pivot_table(index="Record ID", columns="Field", values="New value", aggfunc="last")
            wide = wide.reset_index().rename(columns={"Record ID": namer.id("accounts" if "_accounts_" in f else "contacts")})
            kit.loads[f] = wide.fillna("")
    _steps(kit)
    return kit


def _merge_contacts(kit, ctx, results, change, junk):
    namer = Namer(ctx)
    C = ctx.contacts
    if C is None or not ctx.t("contacts").has("id"):
        return
    groups = _groups_from(results, [("1.1", "Dup contacts (email)"), ("1.2", "Dup contacts (fuzzy)")], "Contact ID")
    if not groups:
        return
    by_id: dict = {}
    for rec in C.to_dict("records"):  # one pass; looking records up one by one in pandas is slow
        by_id.setdefault(rec["id"], rec)
    states = dominant_map(C["state"], N.canon_state)
    countries = dominant_map(C["country"], N.canon_country)
    main = _main_phone_pattern(C["phone"])
    plan, f = [], "05_update_contacts_fill_before_merge.csv"
    for gi, ids in enumerate(sorted(groups, key=len, reverse=True), 1):
        rows = [by_id[i] for i in ids if i in by_id]
        if len(rows) < 2:
            continue

        def rank(r):
            filled = sum(isinstance(r[k], str) for k in ["email", "phone", "mobile", "title", "account_id", "lead_source", "state", "country"])
            la = r["last_activity"].value if pd.notna(r["last_activity"]) else 0
            cr = -(r["created"].value) if pd.notna(r["created"]) else float("-inf")
            return (r["id"] not in junk, filled, la, cr)
        rows.sort(key=rank, reverse=True)
        keep = rows[0]
        why = "most complete record" + (", most recent activity" if pd.notna(keep["last_activity"]) else "")
        for d in rows[1:]:
            same = _same_person(keep, d)
            plan.append({"Merge set": gi, "Keep (master) ID": keep["id"], "Keep name": keep["name"],
                         "Keep email": keep["email"], "Keep owner": keep["owner"],
                         "Merge in (duplicate) ID": d["id"], "Duplicate name": d["name"],
                         "Duplicate email": d["email"], "Duplicate owner": d["owner"], "Why this one is kept": why,
                         "Check first": "" if same else "Names differ: confirm this is the same person before merging"})
        for k in CONTACT_FILL:
            if not isinstance(keep[k], str):
                donor = next((d[k] for d in rows[1:] if isinstance(d[k], str) and _same_person(keep, d)), None)
                if donor is not None:
                    if k == "state":
                        donor = states.get(donor, donor)
                    if k == "country":
                        donor = countries.get(donor, donor)
                    if k in ("phone", "mobile"):
                        donor = reformat_phone(donor, main, ctx.region) or donor
                    change("Contact", keep["id"], keep["name"], namer.f("contacts", k), None, donor,
                           "blank on the record being kept; copied from its duplicate", f)
    if plan:
        kit.lists["06_merge_plan_contacts.csv"] = pd.DataFrame(plan)


def _same_person(a, b) -> bool:
    """A safety check before merging: the names should match (nicknames and small typos allowed)."""
    ka, kb = a["person_key"], b["person_key"]
    if not isinstance(ka, str) or not isinstance(kb, str):
        return False
    return ka == kb or fuzz.ratio(ka, kb) >= 85 or ka.split(" ")[-1] == kb.split(" ")[-1] and ka[0] == kb[0]


def _merge_accounts(kit, ctx, results, change):
    namer = Namer(ctx)
    A, C = ctx.accounts, ctx.contacts
    if A is None or not ctx.t("accounts").has("id"):
        return
    groups = _groups_from(results, [("1.3", "Dup accounts")], "Account ID")
    if not groups:
        return
    n_contacts = C["account_id"].value_counts().to_dict() if C is not None else {}
    by_id: dict = {}
    for rec in A.to_dict("records"):
        by_id.setdefault(rec["id"], rec)
    plan, f = [], "05_update_accounts_fill_before_merge.csv"
    for gi, ids in enumerate(sorted(groups, key=len, reverse=True), 1):
        rows = [by_id[i] for i in ids if i in by_id]
        if len(rows) < 2:
            continue
        rows.sort(key=lambda r: (n_contacts.get(r["id"], 0),
                                 sum(isinstance(r[k], str) for k in ACCOUNT_FILL),
                                 -(r["created"].value) if pd.notna(r["created"]) else float("-inf")), reverse=True)
        keep = rows[0]
        for d in rows[1:]:
            plan.append({"Merge set": gi, "Keep (master) ID": keep["id"], "Keep name": keep["name"],
                         "Keep owner": keep["owner"], "Keep contacts": n_contacts.get(keep["id"], 0),
                         "Merge in (duplicate) ID": d["id"], "Duplicate name": d["name"],
                         "Duplicate owner": d["owner"], "Duplicate contacts": n_contacts.get(d["id"], 0),
                         "Why this one is kept": "has the most contacts and details"})
        for k in ACCOUNT_FILL:
            if not isinstance(keep[k], str):
                donor = next((d[k] for d in rows[1:] if isinstance(d[k], str)), None)
                if donor is not None:
                    change("Account", keep["id"], keep["name"], namer.f("accounts", k), None, donor,
                           "blank on the company being kept; copied from its duplicate", f)
    if plan:
        kit.lists["06_merge_plan_accounts.csv"] = pd.DataFrame(plan)


def _merge_deals(kit, ctx, results):
    O = ctx.opps
    dd = results["1.4"].details.get("Dup open deals")
    if O is None or dd is None or not len(dd):
        return
    la = dict(zip(O["id"], O["last_activity"]))
    plan = []
    by_group: dict = {}
    for rec in dd.to_dict("records"):
        by_group.setdefault(rec["Group"], {})[rec["Opportunity ID"]] = rec
    for g, recs in by_group.items():
        ids = list(recs)
        ids.sort(key=lambda i: la.get(i).value if pd.notna(la.get(i)) else 0, reverse=True)
        keep = recs[ids[0]]
        for i in ids[1:]:
            d = recs[i]
            plan.append({"Set": g, "Keep deal ID": keep["Opportunity ID"], "Keep deal": keep["Opportunity"],
                         "Keep owner": keep["Owner"], "Duplicate deal ID": i, "Duplicate deal": d["Opportunity"],
                         "Duplicate amount": d["Amount"], "Duplicate owner": d["Owner"],
                         "What to do": "Move any notes to the kept deal, then close this one as a duplicate"})
    if plan:
        kit.lists["06_merge_plan_deals.csv"] = pd.DataFrame(plan)


def _rep_worklists(kit, ctx, results):
    O = ctx.opps
    if O is None:
        return
    info = O.set_index("id")
    todo: dict[str, list[str]] = {}

    def add(i, what):
        if isinstance(i, str):
            todo.setdefault(i, [])
            if what not in todo[i]:
                todo[i].append(what)
    st = results["4.4"].details.get("Stale open deals")
    if st is not None:
        for i, why in zip(st["Opportunity ID"], st["Why it's stale"]):
            add(i, "update the close date" if "close date" in why else "log an update or close it")
    pu = results["4.8"].details.get("Deals pushed 3+ times")
    if pu is not None:
        for i, n in zip(pu["Opportunity ID"], pu["Times pushed"]):
            add(i, f"pushed {n} times: set a real date with a reason, or close as lost")
    ph = results["3.8"].details.get("Placeholder values")
    if ph is not None:
        for i, fld, val in zip(ph["Record ID"], ph["Field"], ph["Value"]):
            if fld in ("Amount", "Close date", "Probability"):
                add(i, f"replace the made-up {fld.lower()} ({val})")
    dd = kit.lists.get("06_merge_plan_deals.csv")
    if dd is not None:
        for i in dd["Duplicate deal ID"]:
            add(i, "duplicate deal: close it")
    rows = []
    for i, items in todo.items():
        if i not in info.index:
            continue
        r = info.loc[i]
        r = r.iloc[0] if isinstance(r, pd.DataFrame) else r
        rows.append({"Rep": r["owner"] or "(no owner)", "Deal ID": i, "Deal": r["name"], "Account": r["account"],
                     "Amount": r["amount"], "Close date": r["close_date"], "To do": "; ".join(items)})
    if rows:
        df = pd.DataFrame(rows).sort_values(["Rep", "Amount"], ascending=[True, False])
        kit.lists["11_rep_todo_lists.csv"] = df


def _steps(kit):
    how = HOW[kit.crm]

    def step(n, what, files, text, decide):
        present = [f for f in files if f in kit.loads or f in kit.lists]
        if not present or not text:
            return
        count = sum(len(kit.loads.get(f, kit.lists.get(f))) for f in present)
        kit.steps.append({"Step": n, "What it fixes": what, "Records": count, "Files": ", ".join(present),
                          "How to apply": text, "Needs a decision first?": decide})
    step(2, "Names, phones, emails, state/country spellings (contacts)", ["02_update_contacts_standardize.csv"],
         how["update"].format(obj="Contact"), "No - review the Changes sheet")
    step(3, "State, country and industry spellings (companies)", ["03_update_accounts_standardize.csv"],
         how["update"].format(obj="Account" if kit.crm != "hubspot" else "Companie"), "No - review the Changes sheet")
    step(4, "Records owned by people who left", ["04_update_contacts_new_owner.csv", "04_choose_owner.csv"],
         how["owner"], "Yes, for records with no suggested owner")
    step(5, "Fill blanks on the record being kept, before merging", ["05_update_contacts_fill_before_merge.csv",
                                                                    "05_update_accounts_fill_before_merge.csv"],
         how["update"].format(obj="record") + " Do this before step 6 so nothing is lost.", "No")
    step(6, "Merge duplicate contacts, companies and deals", ["06_merge_plan_contacts.csv", "06_merge_plan_accounts.csv",
                                                            "06_merge_plan_deals.csv"],
         how["merge"], "Yes - confirm each set is really the same person or company")
    step(7, "Leads that are already contacts", ["07_convert_leads_to_existing_contacts.csv"], how["convert"], "Yes")
    step(8, "Made-up values (TBD titles, fake emails, shared fake phones, 'Other' industry)",
         [f for f in kit.loads if f.startswith("08_")], how["clear"], "No - review the Changes sheet")
    step(9, "Test and junk records", ["09_review_delete_contacts.csv"], how["delete"], "Yes")
    step(10, "Records missing outside information", ["10_enrich_contacts.csv", "10_enrich_accounts.csv"],
         "Send to a data provider (ZoomInfo, Apollo, etc.) only with the client's written approval; load the "
         "results back the same way as step 2.", "Yes - client approval to share data")
    step(11, "Deals reps need to update", ["11_rep_todo_lists.csv"],
         "Give each rep their rows; go through them in the next pipeline meeting.", "Yes - by each rep")
    kit.steps.insert(0, {"Step": 1, "What it fixes": "Backup first", "Records": None, "Files": "",
                         "How to apply": how["backup"], "Needs a decision first?": ""})


# ------------------------------------------------------------------ writing the kit

README = """OUROBOROS CLEANUP KIT  -  {client}  -  {date}
==========================================================================

These files fix the problems found in the audit. NOTHING HAS BEEN CHANGED IN {crm_name}.
Every file is reviewed by a person and loaded on purpose, in the order below.

Before you start
  * Back up: {backup}
  * If the client has a sandbox, load there first and check.
  * Open "Cleanup_review.xlsx". The "Changes" sheet shows every field change as
    current value -> new value. Delete any row you don't want from the CSV before loading.

What's in the kit
  {ready:,} fixes are ready to load after review
  {decide:,} items need someone's decision (merges, conversions, deletions, rep updates)
  {enrich:,} records need outside data from a provider the client approves

Steps
{steps}

{loader}

Files that are lists, not loads
  06_merge_plan_*  ->  merge in the CRM, keeping the "Keep" record (see step 6).
  07_convert_leads ->  convert each lead onto the existing contact.
  09_review_delete ->  check, then delete.
  10_enrich_*      ->  only send to a data provider with the client's written approval.
  11_rep_todo      ->  give each rep their own rows.
{notes}"""


def write(kit: Kit, folder: Path, client: str, audit_date, branding=None) -> Path:
    from openpyxl import Workbook
    from openpyxl.styles import Font
    from .report import NAVY, autosize, write_df

    shown = folder
    folder = _long_path(folder)
    if folder.exists():
        for p in folder.iterdir():
            if p.is_file():
                p.unlink()
    folder.mkdir(parents=True, exist_ok=True)
    for name, df in {**kit.loads, **kit.lists}.items():
        out = df.copy()
        for c in out.columns:
            if pd.api.types.is_datetime64_any_dtype(out[c]):
                out[c] = out[c].dt.strftime("%Y-%m-%d")
        out.to_csv(folder / name, index=False, encoding="utf-8-sig")

    wb = Workbook()
    ws = wb.active
    ws.title = "Start here"
    b = branding if branding is not None and branding.active else None
    ws["A1"] = f"{b.tool_name if b else 'Ouroboros '}cleanup kit: {client}"
    ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    from .crms import NAMES
    ws["A2"] = (f"Nothing has been changed in {NAMES[kit.crm]}. Review each step, then load the files in order. "
                "Back up first.")
    s = kit.summary()
    ws["A3"] = (f"{s['ready']:,} fixes ready to load after review  |  {s['decide']:,} items need a decision  |  "
                f"{s['enrich']:,} records need outside data")
    if b and (b.prepared_by or b.contact):
        ws["A4"] = " | ".join(x for x in ((f"Prepared by {b.prepared_by}" if b.prepared_by else ""), b.contact) if x)
    write_df(ws, pd.DataFrame(kit.steps), row=5)
    autosize(ws, max_width=70)
    sheets = {"Changes": pd.DataFrame(kit.changes, columns=["Object", "Record ID", "Name", "Field", "Current value",
                                                             "New value", "Why", "File"])}
    sheets.update(kit.sheets)
    labels = {"06_merge_plan_contacts.csv": "Merge contacts", "06_merge_plan_accounts.csv": "Merge companies",
              "06_merge_plan_deals.csv": "Merge deals", "07_convert_leads_to_existing_contacts.csv": "Leads to convert",
              "09_review_delete_contacts.csv": "Review for deletion", "10_enrich_contacts.csv": "Enrich contacts",
              "10_enrich_accounts.csv": "Enrich companies", "11_rep_todo_lists.csv": "Rep to-do lists",
              "04_choose_owner.csv": "Choose an owner"}
    for f, lbl in labels.items():
        if f in kit.lists:
            sheets[lbl] = kit.lists[f]
    for title, df in sheets.items():
        w2 = wb.create_sheet(title[:31])
        write_df(w2, df, row=1)
        autosize(w2)
        w2.freeze_panes = "A2"
    wb.save(folder / "Cleanup_review.xlsx")

    steps = "\n".join(f"  {st['Step']:>2}. {st['What it fixes']}"
                      + (f"  ({st['Records']:,} records)" if st["Records"] else "")
                      + (f"\n      Files: {st['Files']}" if st["Files"] else "")
                      + f"\n      How:   {st['How to apply']}"
                      for st in kit.steps)
    notes = ("\nNotes\n" + "\n".join("  * " + n for n in kit.notes) + "\n") if kit.notes else ""
    readme = README.format(client=client, date=nice_date(audit_date), steps=steps, notes=notes,
                           crm_name=NAMES[kit.crm].upper(), backup=HOW[kit.crm]['backup'],
                           loader=HOW[kit.crm]['loader'], **s)
    if b:
        head, rule, rest = readme.split("\n", 2)
        if b.white_label:
            head = head.replace("OUROBOROS CLEANUP KIT", "CLEANUP KIT", 1)
        lines = ([f"Prepared by {b.prepared_by}"] if b.prepared_by else []) + \
                ([f"Questions? {b.contact}"] if b.contact else [])
        readme = "\n".join([head, rule] + lines + [rest])
    (folder / "READ_ME_FIRST.txt").write_text(readme, encoding="utf-8")
    return shown


def _long_path(p: Path) -> Path:
    """Windows limits ordinary paths to 260 characters; deep folders plus file names can exceed it.
    The \\\\?\\ prefix lifts that limit. Other systems don't need it."""
    import os
    if os.name != "nt":
        return p
    s = str(p.resolve())
    return Path(s if s.startswith("\\\\?\\") else "\\\\?\\" + s)
