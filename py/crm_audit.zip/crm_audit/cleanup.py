"""The cleanup kit: turns the audit's findings into files that fix the data.

Nothing here touches the CRM. It produces:
  - Data Loader "Update" CSVs (Id + new values, Salesforce API field names) for safe, mechanical
    fixes: name case, phone format, email typos, state/country/industry spellings, new owners
  - merge plans (which record to keep and why) and "fill before merge" files, so no information
    is lost when duplicates are merged
  - one "clear" file per field for made-up values (these need Data Loader's Insert Null Values)
  - lists that need a person's decision: leads to convert, junk records to review for deletion,
    and a to-do list for each rep's deals
  - an enrichment list of records that need outside data from a provider the client approves
  - ONE review workbook (Cleanup_review.xlsx) that the client reviews; `apply-review` (apply.py) turns
    the reviewed workbook into a small ready-to-load folder. build() still prepares every list in memory;
    write() puts them into the workbook.
"""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd
import phonenumbers

from . import normalize as N
from .checks import UnionFind
from .fuzzcompat import fuzz
from .plain import nice_date

# Salesforce API names for the fields the kit can change
API = {
    "contacts": {"first_name": "FirstName", "last_name": "LastName", "email": "Email", "phone": "Phone",
                 "mobile": "MobilePhone", "title": "Title", "state": "MailingState", "country": "MailingCountry",
                 "lead_source": "LeadSource", "owner_id": "OwnerId", "account_id": "AccountId"},
    "accounts": {"website": "Website", "industry": "Industry", "employees": "NumberOfEmployees",
                 "state": "BillingState", "country": "BillingCountry", "city": "BillingCity", "owner_id": "OwnerId"},
}
# Bullhorn's Custom Import takes Bullhorn API field names as column headers (not the labels in a list export),
# so its load files use these. None = no safe way to import it (a country needs Bullhorn's numeric country id).
BULLHORN_API = {
    "contacts": {"first_name": "firstName", "last_name": "lastName", "email": "email", "phone": "phone",
                 "mobile": "mobile", "title": "occupation", "state": "address.state", "country": None,
                 "lead_source": "source", "account_id": "clientCorporation.id"},
    "accounts": {"website": "companyURL", "industry": "businessSectorList", "employees": "numEmployees",
                 "state": "address.state", "country": None, "city": "address.city"},
}
BULLHORN_ID, BULLHORN_OWNER = "id", "owner"
PLACEHOLDER_FIELD_API = {"Title": "Title", "Email": "Email", "Phone": "Phone", "Industry": "Industry",
                         "Employees": "NumberOfEmployees"}
PLACEHOLDER_LOGICAL = {"Title": "title", "Email": "email", "Phone": "phone", "Industry": "industry",
                       "Employees": "employees"}

# HubSpot and Dynamics import files are matched on their own column labels. The kit uses the
# client's own export headers; these are the defaults when a column wasn't in the export.
# None = the CRM won't take it in an import (HubSpot's Original Source is read-only, for example).
LABELS = {
    "hubspot": {
        "contacts": {"id": "Record ID", "first_name": "First Name", "last_name": "Last Name", "email": "Email",
                     "phone": "Phone Number", "mobile": "Mobile Phone Number", "title": "Job Title",
                     "state": "State/Region", "country": "Country/Region", "owner": "Contact owner",
                     "lead_source": None, "account_id": None},
        "accounts": {"id": "Record ID", "website": "Website URL", "industry": "Industry",
                     "employees": "Number of Employees", "state": "State/Region", "country": "Country/Region",
                     "city": "City", "owner": "Company owner"},
    },
    "dynamics": {
        "contacts": {"id": "(Do Not Modify) Contact", "first_name": "First Name", "last_name": "Last Name",
                     "email": "Email", "phone": "Business Phone", "mobile": "Mobile Phone", "title": "Job Title",
                     "state": "Address 1: State/Province", "country": "Address 1: Country/Region",
                     "owner": "Owner", "lead_source": None, "account_id": None},
        "accounts": {"id": "(Do Not Modify) Account", "website": "Website", "industry": "Industry",
                     "employees": "Number of Employees", "state": "Address 1: State/Province",
                     "country": "Address 1: Country/Region", "city": "Address 1: City", "owner": "Owner"},
    },
}


class Namer:
    """Column names for the kit's load files, in the format this client's CRM imports."""

    def __init__(self, ctx):
        self.crm, self.ctx = ctx.crm, ctx

    def _label(self, obj, key):
        t = self.ctx.t(obj)
        labels = LABELS[self.crm][obj]
        if key in labels and labels[key] is None:
            return None
        src = {"owner": "owner_name"}.get(key, key)
        col = t.mapping.get(src) if t is not None else None
        return col or labels.get(key)

    def f(self, obj, logical):
        if self.crm == "salesforce":
            return API[obj].get(logical)
        if self.crm == "bullhorn":
            return BULLHORN_API[obj].get(logical)
        return self._label(obj, logical)

    def id(self, obj):
        if self.crm == "bullhorn":
            return BULLHORN_ID
        return "Id" if self.crm == "salesforce" else self._label(obj, "id")

    def owner(self, obj):
        if self.crm == "bullhorn":
            return BULLHORN_OWNER
        return "OwnerId" if self.crm == "salesforce" else self._label(obj, "owner")


# How each step is carried out, per CRM
HOW = {
    "salesforce": {
        "backup": "Data Export (Setup > Data Export > Export Now) or Data Loader > Export All for every object "
                  "you'll change. Load into a sandbox first if the client has one.",
        "update": "Data Loader > Update > {obj}. Map Id and each column.",
        "owner": "Data Loader > Update > Contact for the first file. Pick owners for the second, then load it the same way.",
        "merge": "In Salesforce use Merge Contacts / Merge Accounts (or a merge tool such as DemandTools or Plauti), "
                 "keeping the 'Keep (master) ID' record. Merging keeps activity history; deleting does not.",
        "convert": "Open each lead > Convert > choose the existing contact.",
        "clear": "Data Loader > Settings > turn ON 'Insert null values', load each file with Update, then turn it OFF again.",
        "delete": "Check each one, then Data Loader > Delete (records go to the Recycle Bin for 15 days).",
        "loader": """Loading a file with Salesforce Data Loader (free, from Salesforce)
  1. Open Data Loader and log in to the client's org.
  2. Choose Update (or Delete for step 9), pick the object (Contact or Account).
  3. Choose the CSV. Click "Auto-Match Fields to Columns" - the column names are Salesforce
     field names, so they match automatically. Check that Id maps to Id.
  4. Run it. Data Loader writes a success file and an error file; check the error file.""",
    },
    "hubspot": {
        "backup": "Export every object you'll change: Contacts and Companies > Export (all properties).",
        "update": "HubSpot > Import > File from computer > One object > {obj}s > 'Update existing records'. "
                  "HubSpot matches rows on Record ID; the column headers are your property names.",
        "owner": "Import the first file the same way (it sets the owner column). Pick owners for the second, then import it.",
        "merge": "Merge in HubSpot (open the record > Actions > Merge), keeping the 'Keep (master) ID' record. "
                 "HubSpot merges two at a time and keeps the activity of both.",
        "convert": "",
        "clear": "HubSpot imports skip blank cells, so clear these with bulk edit: filter the list to the IDs in "
                 "the file, select all, edit the property and leave it empty.",
        "delete": "Check each one, then select them in the list and Delete (they can be restored for 90 days).",
        "loader": """Importing a file into HubSpot
  1. Contacts (or Companies) > Import > Start an import > File from computer > One file > One object.
  2. Choose Contacts or Companies, and tick "Update existing records" with Record ID as the match.
  3. Upload the CSV. The column headers match your property names, so they map automatically.
  4. Blank cells are skipped, so only the changed values are written. Check the import's error list.""",
    },
    "dynamics": {
        "backup": "Export to Excel every view you'll change (All Contacts, All Accounts) and keep the files.",
        "update": "Open your own Excel export of {obj}s, paste in the new values for these rows (matched on the "
                  "hidden '(Do Not Modify)' ID column), and Import from Excel.",
        "owner": "Select the records in a view and use Assign, or update the Owner column the same way as step 2.",
        "merge": "Select two records in a view > Merge, choosing the 'Keep (master) ID' record as the master. "
                 "Dynamics merges two at a time and moves related records to the master.",
        "convert": "Open each lead > Qualify, and choose the existing contact and account.",
        "clear": "Clear these cells in your Excel export and Import from Excel, or use Edit on the selected records.",
        "delete": "Check each one, then select them in a view and Delete.",
        "loader": """Updating records in Dynamics 365
  1. Export the matching view to Excel (it includes the hidden "(Do Not Modify)" ID columns).
  2. For each row in the kit's file, find the same ID in your export and paste in the new values.
     Don't change the hidden columns.
  3. Data > Import from Excel. Dynamics matches rows on the hidden ID and updates those records.
  4. Check the import job for errors.""",
    },
    "bullhorn": {
        "backup": "Bullhorn keeps no export history, so export each list you'll change to CSV first (list view > "
                  "Selected > Export as CSV; admins only). A full backup comes only from Bullhorn Support: ask them.",
        "update": "Contacts and leads: Menu > Tools > Custom Import (Contacts or Leads, up to 1,000 rows a batch, "
                  "column headers are Bullhorn API field names). Companies and opportunities can't go through "
                  "Custom Import: update them by hand, or ask Bullhorn Support or a data-loader partner. "
                  "Check a few records first.",
        "owner": "In a list view, select the records (500 at a time, with no filters set) and change the owner in "
                 "bulk. The file shows who each record should go to. Check a few records first.",
        "merge": "Open the record to keep > Actions > Merge Records, and type the duplicate in 'With This Record'. "
                 "Copy address and custom fields to the kept record first: they don't carry over. The duplicate "
                 "is deleted (companies are archived). Try one pair first.",
        "convert": "Open each lead > Convert, and choose the existing company and the existing contact. "
                   "Converting can't be undone.",
        "clear": "Edit each record and blank the field. (Custom Import may also clear a field when its cell is "
                 "empty, but that isn't confirmed: check on a few records first.)",
        "delete": "Set Status to Archive on each record instead of deleting it (select them in a list view and "
                  "change Status). Check a few records first.",
        "loader": """Updating records in Bullhorn
  1. Menu > Tools > Custom Import. Choose Contacts (or Leads) and the CSV.
  2. The column headers are Bullhorn API field names (id, firstName, occupation...), so they map as they are.
  3. Choose "Create new records and update existing ones". How existing rows are matched isn't documented,
     so load 5 rows first and check them before the full batch (1,000 rows at most per batch).
  4. Companies and opportunities can't be imported this way: update them by hand or ask Bullhorn Support.""",
    },
}
CONTACT_FILL = ["phone", "mobile", "title", "account_id", "lead_source", "state", "country"]
ACCOUNT_FILL = ["website", "industry", "employees", "city", "state", "country"]


@dataclass
class Kit:
    changes: list[dict] = field(default_factory=list)   # every field change, for the review sheet
    loads: dict[str, pd.DataFrame] = field(default_factory=dict)   # file name -> Data Loader CSV
    lists: dict[str, pd.DataFrame] = field(default_factory=dict)   # file name -> decision list CSV
    sheets: dict[str, pd.DataFrame] = field(default_factory=dict)  # extra review-workbook sheets
    steps: list[dict] = field(default_factory=list)     # the "Start here" table
    notes: list[str] = field(default_factory=list)
    crm: str = "salesforce"
    merge_groups: list[dict] = field(default_factory=list)   # duplicate groups, for the Merges sheet
    owners: list[dict] = field(default_factory=list)         # records whose owner left
    users: list[tuple] = field(default_factory=list)         # (name, id) of people who can take ownership
    meta: dict = field(default_factory=dict)                 # id/owner column headers per object
    kit_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    manifest: dict = field(default_factory=dict)             # filled in when the workbook is written

    def counts(self) -> dict:
        """THE ONE SET OF NUMBERS. Every place a person reads a cleanup number (the console after `run`,
        READ_ME_FIRST.txt, the Start here sheet, the HTML report, the iPad result, apply-review's "What will
        change" block) comes from here. The headline unit is "changes": the rows the client sees on the
        review sheets. "records" is the number of distinct CRM records behind them (different only where one
        record has several changes, or where a merge group holds several records).

        Each category: {"changes": rows on its sheet, "records": distinct records}. Plus
          ready  = format fixes (pre-approved), changes only
          decide = every other change a person must say Yes to or act on: clears, owner changes, fill-before-merge
                   values, merge groups, lead conversions, deletions, rep to-dos
          enrich = records to enrich
          decisions = the subset of `decide` that needs an explicit Yes (what review time is estimated from)
          quick_groups, minutes = number of Quick approve groups, estimated review time."""
        def of(kind):
            rows = [c for c in self.changes if c["Kind"] == kind]
            return {"changes": len(rows), "records": len({(c["Object"], c["Record ID"]) for c in rows})}

        def of_list(key, id_col):
            df = self.lists.get(key)
            n = len(df) if df is not None else 0
            return {"changes": n, "records": int(df[id_col].nunique()) if n else 0}
        out = {"format": of("standardize"), "clear": of("clear"), "fill": of("fill"),
               "owners": {"changes": len(self.owners), "records": len({(o["Object"], o["Record ID"]) for o in self.owners})},
               "merges": {"changes": len(self.merge_groups),
                          "records": sum(len(g["ids"]) for g in self.merge_groups)},
               "convert": of_list("07_convert_leads_to_existing_contacts.csv", "Lead ID"),
               "delete": of_list("09_review_delete_contacts.csv", "Id"),
               "todo": of_list("11_rep_todo_lists.csv", "Deal ID")}
        enr = [of_list(k, "Id") for k in self.lists if k.startswith("10_")]
        out["enrich_detail"] = {"changes": sum(e["changes"] for e in enr), "records": sum(e["records"] for e in enr)}
        out["enrich"] = out["enrich_detail"]["changes"]
        out["ready"] = out["format"]["changes"]
        out["decide"] = sum(out[k]["changes"] for k in ("clear", "owners", "fill", "merges", "convert", "delete", "todo"))
        out["decisions"] = sum(out[k]["changes"] for k in ("clear", "owners", "merges", "convert", "delete"))
        out["quick_groups"] = len(format_groups(self))
        out["minutes"] = review_minutes(out["quick_groups"], out["decisions"])
        return out

    def summary(self) -> dict:
        """What web.py and pricing read. ready / decide / enrich keep their 1.2.0 meaning (ready = pre-approved
        format fixes, decide = everything needing a person's Yes or follow-up, enrich = records needing outside
        data) but since 1.3.0 they count CHANGES (rows on the review sheets) everywhere; before, they counted
        load-file rows, which mixed records, field changes and duplicates. "counts" holds the full breakdown."""
        c = self.counts()
        return {"ready": c["ready"], "decide": c["decide"], "enrich": c["enrich"],
                "field_changes": len(self.changes), "files": len(self.loads) + len(self.lists), "counts": c}

    def headline(self) -> str:
        """The one sentence every place uses. It leads with the number that needs a Yes (counts()["decisions"]);
        rep to-dos and fill-before-merge values need no Yes, so they are named separately and only when there are any."""
        c = self.counts()
        text = (f"{c['ready']:,} format fixes pre-approved, {c['decisions']:,} changes need a decision (Yes), "
                f"{c['enrich']:,} records to enrich")
        extra = self.extras()
        return text + ("; also " + " and ".join(extra) if extra else "")

    def extras(self) -> list[str]:
        """The things counted in `decide` that need NO Yes (only the ones that exist)."""
        c = self.counts()
        out = []
        if c["todo"]["changes"]:
            out.append(f"{c['todo']['changes']:,} rep to-dos (suggestions, nothing to fill in)")
        if c["fill"]["changes"]:
            out.append(f"{c['fill']['changes']:,} values copied before merges (they follow their merge)")
        return out

    def breakdown(self) -> list[str]:
        """What the `decisions` number (the rows that need a Yes) is made of, in words (only the categories that exist)."""
        c = self.counts()
        parts = (("clear", "values to clear"), ("owners", "owner changes"), ("merges", "merge groups"),
                 ("convert", "lead conversions"), ("delete", "deletions"))
        return [f"{c[k]['changes']:,} {what}" for k, what in parts if c[k]["changes"]]


def review_minutes(groups: int, decisions: int) -> int:
    """Estimated review time: 1 minute per 10 rows that need a Yes, plus 2 for the quick groups; to the nearest 5."""
    raw = decisions / 10 + (2 if groups else 0)
    return max(5, int(5 * round(raw / 5)))


# ------------------------------------------------------------------ Quick approve groups

FIX_LABEL = {"name in ALL CAPS or lowercase": "capitalisation",
             "phone put in the team's main format": "put in the team's main format",
             "email with spaces or capitals": "tidy spaces and capitals",
             "spelled the way most records spell it": "standard spelling"}


def friendly_field(api) -> str:
    """A field name as a person would say it: MailingState -> State, FirstName -> First name."""
    s = str(api).split(".")[-1]
    s = re.sub(r"^(Address \d+: |Mailing|Billing)", "", s)
    s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", s).strip() or str(api)
    return s[:1].upper() + s[1:].lower()


def format_groups(kit: Kit) -> list[dict]:
    """The Quick approve groups: format fixes grouped by (object, field, kind of fix), in sheet order.
    Each: key (Q1, Q2...), desc, ids (change ids), n, examples."""
    plural = {"Contact": "Contacts", "Account": "Companies" if kit.crm in ("hubspot", "bullhorn") else "Accounts"}
    raw: dict = {}
    for c in kit.changes:
        if c["Kind"] == "standardize":
            raw.setdefault((c["Object"], c["Field"], c["Why"]), []).append(c)
    descs: dict = {}
    for (obj, field, why) in raw:
        descs.setdefault((plural.get(obj, obj), friendly_field(field), FIX_LABEL.get(why, why)), []).append((obj, field, why))
    out = []
    order = {"Contact": 0, "Account": 1}
    for k in sorted(raw, key=lambda k: (order.get(k[0], 9), k[1].lower(), k[2])):
        label = (plural.get(k[0], k[0]), friendly_field(k[1]), FIX_LABEL.get(k[2], k[2]))
        field_name = label[1] if len(descs[label]) == 1 else f"{label[1]} ({k[1]})"
        desc = f"{label[0]} · {field_name} · {label[2]}"
        rows, seen, ex = raw[k], set(), []
        for c in rows:
            pair = (c["Current value"], c["New value"])
            if pair not in seen and len(ex) < 3:
                seen.add(pair)
                ex.append(f"{_short(c['Current value'])} → {_short(c['New value'])}")
        out.append({"desc": desc, "ids": [c["Change ID"] for c in rows], "n": len(rows), "examples": ex,
                    "obj": k[0], "field": k[1]})
    for i, g in enumerate(out, 1):
        g["key"] = f"Q{i}"
    return out


def _short(v, n=40) -> str:
    t = "(blank)" if v is None or (isinstance(v, float) and v != v) or str(v) == "" else str(v)
    return t if len(t) <= n else t[:n - 1] + "…"


# ------------------------------------------------------------------ value fixers

def proper_name(v: str) -> str:
    def part(p):
        p = p.lower()
        if p.startswith("mc") and len(p) > 2:
            return "Mc" + p[2].upper() + p[3:]
        if "'" in p:
            return "'".join(s[:1].upper() + s[1:] for s in p.split("'"))
        return p[:1].upper() + p[1:]
    return "-".join(" ".join(part(w) for w in seg.split(" ")) for seg in v.split("-"))


def needs_case_fix(v) -> bool:
    return isinstance(v, str) and sum(c.isalpha() for c in v) >= 3 and (v.isupper() or v.islower())


def reformat_phone(raw, main_pattern, region):
    if not isinstance(raw, str):
        return None
    try:
        p = phonenumbers.parse(raw, region)
    except phonenumbers.NumberParseException:
        return None
    if not phonenumbers.is_valid_number(p):
        return None
    nat, cc = str(p.national_number), str(p.country_code)
    home = phonenumbers.region_code_for_number(p) == region
    if main_pattern and home:
        n9 = main_pattern.count("9")
        for digits in (nat, cc + nat):
            if n9 == len(digits):
                it = iter(digits)
                return "".join(next(it) if ch == "9" else ch for ch in main_pattern)
    fmt = phonenumbers.PhoneNumberFormat.NATIONAL if home else phonenumbers.PhoneNumberFormat.INTERNATIONAL
    return phonenumbers.format_number(p, fmt)


def fix_email(v):
    if not isinstance(v, str):
        return None
    new = re.sub(r"\s+", "", v).lower()
    return new if new != v and N.email_syntax_ok(new) else None


def dominant_map(series: pd.Series, canon) -> dict:
    """Each spelling variant -> the spelling most of the CRM already uses for that value."""
    vals = series.dropna()
    out = {}
    if vals.empty:
        return out
    df = pd.DataFrame({"raw": vals, "key": vals.map(canon)}).dropna(subset=["key"])
    for _, grp in df.groupby("key"):
        vc = grp["raw"].value_counts()
        for v in vc.index[1:]:
            out[v] = vc.index[0]
    return out


def _main_phone_pattern(series):
    pats = series.map(N.phone_pattern).dropna()
    return pats.value_counts().index[0] if len(pats) else None


# ------------------------------------------------------------------ building the kit

def _full(result, name, default=None):
    """The COMPLETE evidence table for a check. The tables on a result's `details` are what the workbook shows
    (capped at 20,000 rows); the kit must be built from every flagged record, so it reads the whole table."""
    d = result.details
    df = d.full(name) if hasattr(d, "full") else d.get(name)
    return default if df is None else df


def _groups_from(results, checks_and_sheets, id_col, with_src=False):
    """Duplicate groups from one or more checks' evidence sheets, merged where they overlap.
    With with_src=True each group comes with the set of check ids that found it: (ids, {"1.1", ...})."""
    frames = []
    for cid, sheet in checks_and_sheets:
        df = _full(results[cid], sheet)
        if df is not None and len(df):
            frames.append(df[["Group", id_col]].assign(src=cid))
    if not frames:
        return []
    allr = pd.concat(frames, ignore_index=True).dropna(subset=[id_col])
    ids = list(dict.fromkeys(allr[id_col]))
    pos = {i: n for n, i in enumerate(ids)}
    uf = UnionFind(len(ids))
    for (src, g), grp in allr.groupby(["src", "Group"]):
        members = [pos[i] for i in grp[id_col]]
        for m in members[1:]:
            uf.union(members[0], m)
    out = [[ids[i] for i in g] for g in uf.groups()]
    if not with_src:
        return out
    which = {i: n for n, g in enumerate(out) for i in g}
    srcs: dict = {}
    for src, i in zip(allr["src"], allr[id_col]):
        srcs.setdefault(which[i], set()).add(src)
    return [(g, srcs.get(n, set())) for n, g in enumerate(out)]


def build(ctx, results) -> Kit:
    kit = Kit(crm=ctx.crm)
    namer = Namer(ctx)
    C, A, O, L = ctx.contacts, ctx.accounts, ctx.opps, ctx.leads
    tC, tA = ctx.t("contacts"), ctx.t("accounts")
    region = ctx.region
    for obj, label in (("contacts", "Contact"), ("accounts", "Account")):
        if ctx.t(obj) is not None and ctx.t(obj).has("id"):
            kit.meta[obj] = {"label": label, "id": namer.id(obj), "owner": namer.owner(obj)}

    def change(obj, rid, name, api, cur, new, why, file, merge=None, donor=None):
        if api is None:  # this CRM doesn't accept that field in an import
            return
        kind = {"02": "standardize", "03": "standardize", "04": "owner", "05": "fill", "08": "clear"}[file[:2]]
        kit.changes.append({"Object": obj, "Record ID": rid, "Name": name, "Field": api,
                            "Current value": cur, "New value": new, "Why": why, "File": file,
                            "Kind": kind, "Merge key": merge or "", "Change ID": f"C{len(kit.changes) + 1}",
                            "Donor ID": donor[0] if donor else "", "Donor value": donor[1] if donor else ""})

    # Junk records go to the delete-review list, so don't polish them
    junk = set()
    if C is not None:
        for rid, f, l, e in zip(C["id"], C["first_name"], C["last_name"], C["email"]):
            dom = N.email_domain(e)
            if any(N.is_junk(x) for x in (f, l)) or dom in {"test.com", "example.com", "asdf.com"}:
                if isinstance(rid, str):
                    junk.add(rid)

    # ---- 02 standardize contacts
    if C is not None and tC.has("id"):
        f = "02_update_contacts_standardize.csv"
        main = _main_phone_pattern(C["phone"])
        states = dominant_map(C["state"], N.canon_state)
        countries = dominant_map(C["country"], N.canon_country)
        for r in C.to_dict("records"):
            rid = r["id"]
            if not isinstance(rid, str) or rid in junk:
                continue
            nm = r["name"]
            for k in ("first_name", "last_name"):
                if needs_case_fix(r[k]):
                    change("Contact", rid, nm, namer.f("contacts", k), r[k], proper_name(r[k]), "name in ALL CAPS or lowercase", f)
            for k in ("phone", "mobile"):
                raw = r[k]
                if isinstance(raw, str) and N.phone_pattern(raw) != main:
                    new = reformat_phone(raw, main, region)
                    if new and new != raw:
                        change("Contact", rid, nm, namer.f("contacts", k), raw, new, "phone put in the team's main format", f)
            new = fix_email(r["email"])
            if new:
                change("Contact", rid, nm, namer.f("contacts", "email"), r["email"], new, "email with spaces or capitals", f)
            for k, m in (("state", states), ("country", countries)):
                if r[k] in m:
                    change("Contact", rid, nm, namer.f("contacts", k), r[k], m[r[k]], "spelled the way most records spell it", f)
    elif C is not None:
        kit.notes.append("The contacts export has no Id column, so no contact update files could be made. "
                         "Export with Data Loader to include record Ids.")

    # ---- 03 standardize accounts
    if A is not None and tA.has("id"):
        f = "03_update_accounts_standardize.csv"
        maps = {"state": dominant_map(A["state"], N.canon_state),
                "country": dominant_map(A["country"], N.canon_country),
                "industry": dominant_map(A["industry"], N.canon_text)}
        for r in A.to_dict("records"):
            rid = r["id"]
            if not isinstance(rid, str):
                continue
            for k, m in maps.items():
                if r[k] in m:
                    change("Account", rid, r["name"], namer.f("accounts", k), r[k], m[r[k]],
                           "spelled the way most records spell it", f)

    # ---- 04 reassign owners
    people = _active_users(ctx)
    users, label_of, user_notes = label_users(people, ctx.crm)
    kit.notes.extend(user_notes)
    orph = _full(results["4.1"], "Orphaned records")
    if orph is not None and len(orph):
        f = "04_update_contacts_new_owner.csv"
        acct_owner, acct_owner_name = {}, {}
        if A is not None:
            for aid, oid, on in zip(A["id"], A["owner_id"], A["owner"]):
                # Bullhorn exports give owners by name, so a name is enough to suggest
                who = oid if isinstance(oid, str) else (on if ctx.crm == "bullhorn" and isinstance(on, str) else None)
                if isinstance(aid, str) and who and ctx.owner_status(pd.Series([oid]), pd.Series([on])).iloc[0] == "ok":
                    acct_owner[aid], acct_owner_name[aid] = who, on
        c_acct = dict(zip(C["id"], C["account_id"])) if C is not None else {}
        cur_owner_id = {"Contact": dict(zip(C["id"], C["owner_id"])) if C is not None else {},
                        "Account": dict(zip(A["id"], A["owner_id"])) if A is not None else {}}
        rows = []
        for _, r in orph.iterrows():
            sug = sug_name = None
            why_owner = "No suggestion: pick someone"
            if r["Object"] == "Contact":
                aid = c_acct.get(r["Record ID"])
                sug, sug_name = acct_owner.get(aid), acct_owner_name.get(aid)
                if sug_name:
                    why_owner = "Suggested: this person owns the account this contact belongs to"
                elif isinstance(aid, str):
                    why_owner = "No suggestion: the account's own owner has also left or is missing. Pick someone"
                else:
                    why_owner = "No suggestion: this contact isn't linked to an account. Pick someone"
            cid = cur_owner_id.get(r["Object"], {}).get(r["Record ID"])
            sug_label = ""
            if sug_name:
                sug_label = label_of.get(sug) if ctx.crm == "salesforce" and sug in label_of else sug_name
                if sug_label not in [u[0] for u in users]:   # a suggested owner must always be selectable
                    users.append((sug_label, sug if ctx.crm == "salesforce" else sug_name))
                    users.sort(key=lambda kv: kv[0].lower())
            kit.owners.append({"Object": r["Object"], "Record ID": r["Record ID"], "Name": r["Name"],
                               "Current owner": r["Owner"], "Problem": r["Problem"],
                               "Current owner ID": cid if isinstance(cid, str) else "",
                               "New owner": sug_label, "Why this owner": why_owner,
                               "Approve": "",   # a suggestion is only a suggestion: a person says Yes
                               "Change ID": f"O{len(kit.owners) + 1}"})
            rows.append({"Object": r["Object"], "Record ID": r["Record ID"], "Name": r["Name"],
                         "Current owner": r["Owner"], "Problem": r["Problem"],
                         "Suggested new owner": sug_name or "Choose an owner",
                         "Suggested OwnerId": sug})
            if sug:
                change("Contact", r["Record ID"], r["Name"], namer.owner("contacts"), r["Owner"], sug_name,
                       "owner left or is missing; given to the account's owner", f)
        kit.sheets["New owners"] = pd.DataFrame(rows)
        loads = [x for x in rows if x["Suggested OwnerId"]]
        if loads:
            kit.loads[f] = pd.DataFrame({  # Salesforce takes the user Id; HubSpot/Dynamics take the name
                namer.id("contacts"): [x["Record ID"] for x in loads],
                namer.owner("contacts"): [x["Suggested OwnerId"] if ctx.crm == "salesforce" else x["Suggested new owner"]
                                          for x in loads]})
        rest = [x for x in rows if not x["Suggested OwnerId"]]
        if rest:
            kit.lists["04_choose_owner.csv"] = pd.DataFrame(rest).drop(columns=["Suggested OwnerId"])

    # ---- 05/06 merges: plan + fill blanks on the record being kept
    _merge_contacts(kit, ctx, results, change, junk)
    _merge_accounts(kit, ctx, results, change)
    _merge_deals(kit, ctx, results)

    # ---- 07 leads to convert into existing contacts
    ld = _full(results["1.6"], "Leads already contacts")
    if ld is not None and len(ld):
        c_acct = dict(zip(C["id"], C["account_id"])) if C is not None else {}
        out = ld.copy()
        out.insert(2, "Existing account ID", out["Existing contact ID"].map(c_acct))
        out["What to do"] = "Convert the lead and attach it to the existing contact (don't create a new one)"
        kit.lists["07_convert_leads_to_existing_contacts.csv"] = out

    # ---- 08 clear made-up values (one file per field: Insert Null Values blanks every mapped column)
    ph = _full(results["3.8"], "Placeholder values")
    if ph is not None and len(ph):
        for obj_label, obj in (("Contact", "contacts"), ("Account", "accounts")):
            sub = ph[(ph["Object"] == obj_label) & ph["Field"].isin(PLACEHOLDER_FIELD_API)]
            for fld, grp in sub.groupby("Field"):
                api = namer.f(obj, PLACEHOLDER_LOGICAL[fld])
                if api is None:
                    continue
                f = f"08_clear_{obj}_{re.sub(r'[^A-Za-z0-9]+', '_', api).strip('_')}.csv"
                ids = [i for i in dict.fromkeys(grp["Record ID"]) if isinstance(i, str) and i not in junk]
                if not ids:
                    continue
                kit.loads[f] = pd.DataFrame({namer.id(obj): ids, api: [""] * len(ids)})
                for _, r in grp[grp["Record ID"].isin(ids)].drop_duplicates("Record ID").iterrows():
                    change(obj_label, r["Record ID"], r["Name"], api, r["Value"], "(blank)",
                           r["Why it looks made up"], f)

    # ---- 09 junk records to review for deletion
    if junk:
        sub = C[C["id"].isin(junk)]
        ctx_cols = {}
        if O is not None and ctx.t("opportunities").has("contact_id"):   # open deals that name this contact
            opn = O[~O["is_closed"]]["contact_id"].value_counts()
            ctx_cols["Open deals"] = sub["id"].map(opn).fillna(0).astype(int)
        tasks = ctx.t("tasks")
        if tasks is not None and tasks.has("who_id"):   # activities logged against this contact
            logged = tasks.text("who_id").value_counts()
            ctx_cols["Logged activities"] = sub["id"].map(logged).fillna(0).astype(int)
        kit.lists["09_review_delete_contacts.csv"] = pd.DataFrame({
            "Id": sub["id"], "Name": sub["name"], "Email": sub["email"], "Account": sub["account"],
            "Owner": sub["owner"], "Last activity": sub["last_activity"], "Created": sub["created"], **ctx_cols,
            "Why": "test or junk entry; check nothing important is attached, then delete"})

    # ---- 10 enrichment lists (send to a data provider only with the client's approval)
    if C is not None:
        bad_phone = results["2.4"].flagged.get("contacts", set())
        stale = set(_full(results["2.5"], "Stale contacts", pd.DataFrame(columns=["Contact ID"]))["Contact ID"])
        rows = []
        for r in C.to_dict("records"):
            if r["id"] in junk or not isinstance(r["id"], str):
                continue
            need = []
            if r["id"] in bad_phone:
                need.append("phone")
            if not isinstance(r["title"], str) or N.canon_text(r["title"]) in {"tbd", "contact", "employee", "n a", "unknown"}:
                need.append("job title")
            if not isinstance(r["email"], str):
                need.append("email")
            if r["id"] in stale:
                need.append("confirm still at company")
            if need:
                rows.append({"Id": r["id"], "FirstName": r["first_name"], "LastName": r["last_name"],
                             "Email": r["email"], "Company": r["account"], "Company domain": r["domain_key"],
                             "Needs": ", ".join(need)})
        if rows:
            kit.lists["10_enrich_contacts.csv"] = pd.DataFrame(rows)
    if A is not None:
        rows = []
        for r in A.to_dict("records"):
            need = [lbl for k, lbl in (("industry", "industry"), ("employees", "employee count"), ("website", "website"))
                    if not isinstance(r[k], str) or (k == "industry" and N.canon_text(r[k]) in {"other", "unknown"})]
            if not (isinstance(r["state"], str) or isinstance(r["city"], str) or isinstance(r["country"], str)):
                need.append("location")
            if need and isinstance(r["id"], str):
                rows.append({"Id": r["id"], "Name": r["name"], "Website": r["website"], "Needs": ", ".join(need)})
        if rows:
            kit.lists["10_enrich_accounts.csv"] = pd.DataFrame(rows)

    # ---- rep to-do lists
    _rep_worklists(kit, ctx, results)
    kit.users = users

    # ---- Data Loader update files from the collected changes (blanks are ignored by Data Loader)
    ch = pd.DataFrame(kit.changes)
    if len(ch):
        for f, grp in ch[ch["File"].str.match(r"0[235]_")].groupby("File"):
            wide = grp.pivot_table(index="Record ID", columns="Field", values="New value", aggfunc="last")
            wide = wide.reset_index().rename(columns={"Record ID": namer.id("accounts" if "_accounts_" in f else "contacts")})
            kit.loads[f] = wide.fillna("")
    _steps(kit)
    return kit


# ------------------------------------------------------------------ what differs inside a merge group

def _norm_cmp(v, kind="text") -> str:
    """A value in a form two records can be compared in (blank -> "")."""
    if v is None or (not isinstance(v, (str, list, tuple)) and pd.isna(v)):
        return ""
    if isinstance(v, pd.Timestamp):
        return v.strftime("%Y-%m-%d")
    if kind == "phone":
        return re.sub(r"\D", "", str(v))
    if kind == "num":
        try:
            return repr(float(v))
        except (TypeError, ValueError):
            pass
    return re.sub(r"\s+", " ", str(v)).strip().casefold()


def _show(v):
    """A value as a cell shows it: dates as text, blanks as None."""
    if v is None or (not isinstance(v, (str, list, tuple)) and pd.isna(v)):
        return None
    if isinstance(v, pd.Timestamp):
        return v.strftime("%Y-%m-%d")
    return v


def _differences(rows, keep, fields) -> str:
    """"Phone, Title differ; Email same": which fields hold different values across the members of one group.
    fields: [(label, getter(record), kind)]. A field that is filled on some members and blank on the kept one is
    called out too (it is what the fill-before-merge values are for)."""
    differ, differ_blank, same, blank_keep, only_keep, some = [], [], [], [], [], []
    for label, get, kind in fields:
        vals = [_norm_cmp(get(r), kind) for r in rows]
        filled = [v for v in vals if v]
        if len(set(filled)) > 1:
            # several different values; say so too when the kept record is one of the blanks
            (differ_blank if not _norm_cmp(get(keep), kind) else differ).append(label)
        elif len(filled) == len(rows):   # "same" means present and equal on every member
            same.append(label)
        elif filled:
            if not _norm_cmp(get(keep), kind):
                blank_keep.append(label)
            elif len(filled) == 1:
                only_keep.append(label)
            else:
                some.append(label)
    parts = []
    for names, what in ((differ, "differ"), (differ_blank, "differ (blank on the kept record)"), (same, "same"), (blank_keep, "blank on the kept record"),
                        (only_keep, "only on the kept record"), (some, "missing on some")):
        if names:
            parts.append(", ".join(names) + " " + what)
    return "; ".join(parts) or "Nothing to compare"


def _detail_rows(object_label, mkey, rows, keep, fields) -> list[dict]:
    """One row per member record for the Merge details sheet. "_diff" lists the columns whose value differs from
    the kept record's (the sheet highlights them)."""
    out = []
    for r in rows:
        d = {"Group": f"{object_label} set {mkey.split(':')[-1]}", "Object": object_label,
             "Role": "Suggested keep" if r is keep else "Merge in", "ID": r["id"], "Name": r.get("name"), "_diff": []}
        for label, get, kind in fields:
            d[label] = _show(get(r))
            have = _norm_cmp(get(r), kind)
            if r is not keep and have and have != _norm_cmp(get(keep), kind):
                d["_diff"].append(label)
        out.append(d)
    return out


def _field(key):
    return lambda r: r.get(key)


CONTACT_COMPARE = [("Email", _field("email"), "text"), ("Phone", _field("phone"), "phone"),
                   ("Mobile", _field("mobile"), "phone"), ("Title", _field("title"), "text"),
                   ("Account", _field("account"), "text"), ("Owner", _field("owner"), "text"),
                   ("Created", _field("created"), "text"), ("Last activity", _field("last_activity"), "text")]
DEAL_COMPARE = [("Amount", _field("amount"), "num"), ("Stage", _field("stage"), "text"),
                ("Close date", _field("close_date"), "text"), ("Owner", _field("owner"), "text"),
                ("Last activity", _field("last_activity"), "text")]


def _contact_reason(srcs) -> str:
    parts = []
    if "1.1" in srcs:
        parts.append("Same email address")
    if "1.2" in srcs:
        parts.append("Similar name at the same company")
    return "; ".join(parts) or "Possible duplicate"


def _merge_contacts(kit, ctx, results, change, junk):
    namer = Namer(ctx)
    C = ctx.contacts
    if C is None or not ctx.t("contacts").has("id"):
        return
    groups = _groups_from(results, [("1.1", "Dup contacts (email)"), ("1.2", "Dup contacts (fuzzy)")], "Contact ID",
                          with_src=True)
    if not groups:
        return
    by_id: dict = {}
    for rec in C.to_dict("records"):  # one pass; looking records up one by one in pandas is slow
        by_id.setdefault(rec["id"], rec)
    states = dominant_map(C["state"], N.canon_state)
    countries = dominant_map(C["country"], N.canon_country)
    main = _main_phone_pattern(C["phone"])
    plan, f = [], "05_update_contacts_fill_before_merge.csv"
    for gi, (ids, srcs) in enumerate(sorted(groups, key=lambda g: len(g[0]), reverse=True), 1):
        rows = [by_id[i] for i in ids if i in by_id]
        if len(rows) < 2:
            continue

        def rank(r):
            filled = sum(isinstance(r[k], str) for k in ["email", "phone", "mobile", "title", "account_id", "lead_source", "state", "country"])
            la = r["last_activity"].value if pd.notna(r["last_activity"]) else 0
            cr = -(r["created"].value) if pd.notna(r["created"]) else float("-inf")
            return (r["id"] not in junk, filled, la, cr)
        rows.sort(key=rank, reverse=True)
        keep = rows[0]
        why = "most complete record" + (", most recent activity" if pd.notna(keep["last_activity"]) else "")
        mkey = f"contacts:{gi}"
        fills, sames = {}, {}
        for r in rows:  # what each member could lend the kept record (already in the team's formats)
            vals = {}
            for k in CONTACT_FILL:
                h, v = namer.f("contacts", k), r[k]
                if h is None or not isinstance(v, str):
                    continue
                if k == "state":
                    v = states.get(v, v)
                elif k == "country":
                    v = countries.get(v, v)
                elif k in ("phone", "mobile"):
                    v = reformat_phone(v, main, ctx.region) or v
                vals[h] = v
            fills[r["id"]] = vals
            sames[r["id"]] = r is keep or _same_person(keep, r)
        kit.merge_groups.append({
            "key": mkey, "object": "contacts", "keep": keep["id"], "ids": [r["id"] for r in rows],
            "names": {r["id"]: r["name"] for r in rows}, "why": why, "fill": fills, "same": sames,
            "check": "" if all(sames.values()) else "Names differ: confirm this is the same person before merging",
            "reason": _contact_reason(srcs),
            "differs": _differences(rows, keep, [("Name", _field("name"), "text")] + CONTACT_COMPARE[:6]),
            "detail": _detail_rows("Contact", mkey, rows, keep, CONTACT_COMPARE)})
        for d in rows[1:]:
            same = _same_person(keep, d)
            plan.append({"Merge set": gi, "Keep (master) ID": keep["id"], "Keep name": keep["name"],
                         "Keep email": keep["email"], "Keep owner": keep["owner"],
                         "Merge in (duplicate) ID": d["id"], "Duplicate name": d["name"],
                         "Duplicate email": d["email"], "Duplicate owner": d["owner"], "Why this one is kept": why,
                         "Check first": "" if same else "Names differ: confirm this is the same person before merging"})
        for k in CONTACT_FILL:
            if not isinstance(keep[k], str):
                dd = next((d for d in rows[1:] if isinstance(d[k], str) and _same_person(keep, d)), None)
                donor = dd[k] if dd is not None else None
                if donor is not None:
                    raw_donor = donor
                    if k == "state":
                        donor = states.get(donor, donor)
                    if k == "country":
                        donor = countries.get(donor, donor)
                    if k in ("phone", "mobile"):
                        donor = reformat_phone(donor, main, ctx.region) or donor
                    change("Contact", keep["id"], keep["name"], namer.f("contacts", k), None, donor,
                           "blank on the record being kept; copied from its duplicate", f, merge=mkey,
                           donor=(dd["id"], raw_donor))
    if plan:
        kit.lists["06_merge_plan_contacts.csv"] = pd.DataFrame(plan)


def _same_person(a, b) -> bool:
    """A safety check before merging: the names should match (nicknames and small typos allowed)."""
    ka, kb = a["person_key"], b["person_key"]
    if not isinstance(ka, str) or not isinstance(kb, str):
        return False
    return ka == kb or fuzz.ratio(ka, kb) >= 85 or ka.split(" ")[-1] == kb.split(" ")[-1] and ka[0] == kb[0]


def _merge_accounts(kit, ctx, results, change):
    namer = Namer(ctx)
    A, C = ctx.accounts, ctx.contacts
    if A is None or not ctx.t("accounts").has("id"):
        return
    groups = [g for g, _ in _groups_from(results, [("1.3", "Dup accounts")], "Account ID", with_src=True)]
    if not groups:
        return
    n_contacts = C["account_id"].value_counts().to_dict() if C is not None else {}
    by_id: dict = {}
    for rec in A.to_dict("records"):
        by_id.setdefault(rec["id"], rec)
    plan, f = [], "05_update_accounts_fill_before_merge.csv"
    for gi, ids in enumerate(sorted(groups, key=len, reverse=True), 1):
        rows = [by_id[i] for i in ids if i in by_id]
        if len(rows) < 2:
            continue
        rows.sort(key=lambda r: (n_contacts.get(r["id"], 0),
                                 sum(isinstance(r[k], str) for k in ACCOUNT_FILL),
                                 -(r["created"].value) if pd.notna(r["created"]) else float("-inf")), reverse=True)
        keep = rows[0]
        mkey = f"accounts:{gi}"
        same_site = len({r["domain"] for r in rows if isinstance(r["domain"], str)}) == 1 \
            and sum(isinstance(r["domain"], str) for r in rows) > 1
        same_name = len({r["name_n"] for r in rows if isinstance(r["name_n"], str)}) == 1 \
            and sum(isinstance(r["name_n"], str) for r in rows) > 1
        reason = " and ".join(x for x, ok in (("Same company name", same_name), ("same website", same_site)) if ok) \
            or "Same company name or website (linked through other records)"
        acct_fields = [("Website", _field("website"), "text"),
                       ("City/State", lambda r: ", ".join(x for x in (r.get("city"), r.get("state"))
                                                          if isinstance(x, str)), "text"),
                       ("Owner", _field("owner"), "text"),
                       ("Contacts", lambda r: n_contacts.get(r["id"], 0) if C is not None else None, "num"),
                       ("Created", _field("created"), "text")]
        kit.merge_groups.append({
            "key": mkey, "object": "accounts", "keep": keep["id"], "ids": [r["id"] for r in rows],
            "names": {r["id"]: r["name"] for r in rows}, "why": "has the most contacts and details", "check": "",
            "fill": {r["id"]: {namer.f("accounts", k): r[k] for k in ACCOUNT_FILL
                               if namer.f("accounts", k) and isinstance(r[k], str)} for r in rows},
            "same": {r["id"]: True for r in rows}, "reason": reason,
            "differs": _differences(rows, keep, [("Name", _field("name"), "text")] + acct_fields[:3]),
            "detail": _detail_rows(object_labels(kit.crm)["accounts"], mkey, rows, keep, acct_fields)})
        for d in rows[1:]:
            plan.append({"Merge set": gi, "Keep (master) ID": keep["id"], "Keep name": keep["name"],
                         "Keep owner": keep["owner"], "Keep contacts": n_contacts.get(keep["id"], 0),
                         "Merge in (duplicate) ID": d["id"], "Duplicate name": d["name"],
                         "Duplicate owner": d["owner"], "Duplicate contacts": n_contacts.get(d["id"], 0),
                         "Why this one is kept": "has the most contacts and details"})
        for k in ACCOUNT_FILL:
            if not isinstance(keep[k], str):
                dd = next((d for d in rows[1:] if isinstance(d[k], str)), None)
                if dd is not None:
                    change("Account", keep["id"], keep["name"], namer.f("accounts", k), None, dd[k],
                           "blank on the company being kept; copied from its duplicate", f, merge=mkey,
                           donor=(dd["id"], dd[k]))
    if plan:
        kit.lists["06_merge_plan_accounts.csv"] = pd.DataFrame(plan)


def _merge_deals(kit, ctx, results):
    O = ctx.opps
    dd = _full(results["1.4"], "Dup open deals")
    if O is None or dd is None or not len(dd):
        return
    la = dict(zip(O["id"], O["last_activity"]))
    O_by_id: dict = {}
    for rec in O.to_dict("records"):
        O_by_id.setdefault(rec["id"], rec)
    plan = []
    by_group: dict = {}
    for rec in dd.to_dict("records"):
        by_group.setdefault(rec["Group"], {})[rec["Opportunity ID"]] = rec
    for g, recs in by_group.items():
        ids = list(recs)
        ids.sort(key=lambda i: la.get(i).value if pd.notna(la.get(i)) else 0, reverse=True)
        keep = recs[ids[0]]
        members = [O_by_id.get(i) or {"id": i, "name": recs[i]["Opportunity"], "amount": recs[i].get("Amount"),
                                      "owner": recs[i].get("Owner")} for i in ids]
        kept = members[0]
        kit.merge_groups.append({
            "key": f"deals:{g}", "object": "deals", "keep": keep["Opportunity ID"], "ids": ids,
            "names": {i: recs[i]["Opportunity"] for i in ids}, "why": "most recent activity", "check": "",
            "fill": {}, "same": {i: True for i in ids}, "reason": "Same deal name and account",
            "differs": _differences(members, kept, [("Name", _field("name"), "text")] + DEAL_COMPARE[:4]),
            "detail": _detail_rows("Deal", f"deals:{g}", members, kept, DEAL_COMPARE)})
        for i in ids[1:]:
            d = recs[i]
            plan.append({"Set": g, "Keep deal ID": keep["Opportunity ID"], "Keep deal": keep["Opportunity"],
                         "Keep owner": keep["Owner"], "Duplicate deal ID": i, "Duplicate deal": d["Opportunity"],
                         "Duplicate amount": d["Amount"], "Duplicate owner": d["Owner"],
                         "What to do": "Move any notes to the kept deal, then close this one as a duplicate"})
    if plan:
        kit.lists["06_merge_plan_deals.csv"] = pd.DataFrame(plan)


DUP_TASK = "If the merge on the Merges tab is approved: close this duplicate deal"
SALES_MANAGER = "Sales manager"   # whose list holds the deals whose owner has left


def _rep_worklists(kit, ctx, results):
    O = ctx.opps
    if O is None:
        return
    info = O.set_index("id")
    todo: dict[str, list[str]] = {}

    def add(i, what):
        if isinstance(i, str):
            todo.setdefault(i, [])
            if what not in todo[i]:
                todo[i].append(what)
    st = _full(results["4.4"], "Stale open deals")
    if st is not None:
        for i, why in zip(st["Opportunity ID"], st["Why it's stale"]):
            add(i, f"{why[:1].upper() + why[1:]}: review it in the next pipeline meeting and update the stage, next "
                   "step and close date, or close it if it's dead")
    pu = _full(results["4.8"], "Deals pushed 3+ times")
    if pu is not None:
        for i, n in zip(pu["Opportunity ID"], pu["Times pushed"]):
            add(i, f"Close date moved {n} times: agree a realistic date with your manager, or close it if it's no longer real")
    ph = _full(results["3.8"], "Placeholder values")
    if ph is not None:
        for i, fld, val in zip(ph["Record ID"], ph["Field"], ph["Value"]):
            if fld in ("Amount", "Close date", "Probability"):
                add(i, f"replace the made-up {fld.lower()} ({val})")
    dd = kit.lists.get("06_merge_plan_deals.csv")
    if dd is not None:
        for i in dd["Duplicate deal ID"]:
            add(i, DUP_TASK)
    merge_of = {i: g["key"] for g in kit.merge_groups if g["object"] == "deals" for i in g["ids"] if i != g["keep"]}
    status = {}
    for i, st in zip(O["id"], ctx.owner_status(O["owner_id"], O["owner_name"])):
        status.setdefault(i, st)
    rows = []
    for i, items in todo.items():
        if i not in info.index:
            continue
        r = info.loc[i]
        r = r.iloc[0] if isinstance(r, pd.DataFrame) else r
        rep_name = r["owner"] or "(no owner)"
        if status.get(i, "ok") != "ok":   # a person who left can't work the list: the sales manager reassigns it first
            who = f"Owner {r['owner']} is no longer active" if status[i] == "inactive owner" and r["owner"] \
                else "This deal has no active owner"
            items = [f"{who}: reassign this deal, then do the rest of this to-do"] + items
            rep_name = SALES_MANAGER
        rows.append({"Rep": rep_name, "Deal ID": i, "Deal": r["name"], "Account": r["account"],
                     "Amount": r["amount"], "Close date": r["close_date"], "To do": "; ".join(items),
                     # hidden: the one task that only applies if a merge is approved, and which merge
                     "Merge key": merge_of.get(i, "") if DUP_TASK in items else "",
                     "Conditional task": DUP_TASK if DUP_TASK in items else ""})
    if rows:
        df = pd.DataFrame(rows).sort_values(["Rep", "Amount"], ascending=[True, False])
        kit.lists["11_rep_todo_lists.csv"] = df


def _active_users(ctx) -> list:
    """(name, id) of everyone who can take over records: active people, not integration users.
    From the users export when there is one, otherwise from the owners seen on the records.
    Two people can share a name, so this keeps every (name, id) pair."""
    from .checks import INACTIVE_NAME_RE
    pairs: list = []
    if ctx.users_loaded:
        for i, n in ctx.user_names.items():
            if i in ctx.inactive_ids or i in ctx.integration_ids or n.lower() in ctx.inactive_names \
                    or INACTIVE_NAME_RE.search(n):
                continue
            pairs.append((n, i))
    else:
        for df in (ctx.contacts, ctx.accounts, ctx.opps, ctx.leads):
            if df is None or "owner_id" not in df.columns or "owner_name" not in df.columns:
                continue
            st = ctx.owner_status(df["owner_id"], df["owner_name"])
            lbl = ctx.owner_label(df["owner_id"], df["owner_name"])
            for i, n, ok in zip(df["owner_id"], lbl, st):
                if ok == "ok" and isinstance(n, str):
                    pairs.append((n, i if isinstance(i, str) else n))
    return list(dict.fromkeys(pairs))


def label_users(pairs, crm) -> tuple[list, dict, list]:
    """The owner pick-list: (label, id) sorted, {id: label}, and notes.
    Salesforce loads user ids, so people who share a name get a unique label: "Name (...last 4 of id)".
    The other CRMs load names, which can't tell two people apart: those keep the plain name and a note says so."""
    by_name: dict = {}
    for n, i in pairs:
        by_name.setdefault(re.sub(r"\s+", " ", n).strip().lower(), []).append((n, i))
    out, label_of, notes = [], {}, []
    for group in by_name.values():
        if len(group) == 1 or crm != "salesforce":
            n, i = group[0]
            out.append((n, i))
            label_of[i] = n
            if len(group) > 1:
                notes.append(f"Two active users are both named \"{n}\", and {NAMES_ONLY[crm]} loads owners by name, "
                             "so an owner change to that name can't tell them apart. Check those records by hand.")
            continue
        for n, i in group:
            lab, k = f"{n} (...{i[-4:]})", 4
            while any(lab == o[0] for o in out) or sum(1 for _, j in group if j[-k:] == i[-k:]) > 1 and k < len(i):
                k += 1
                lab = f"{n} (...{i[-k:]})"
            out.append((lab, i))
            label_of[i] = lab
    return sorted(out, key=lambda kv: kv[0].lower()), label_of, notes


NAMES_ONLY = {"hubspot": "HubSpot", "dynamics": "Dynamics 365", "bullhorn": "Bullhorn", "salesforce": "Salesforce"}


def _steps(kit):
    how = HOW[kit.crm]

    def step(n, what, files, text, decide):
        present = [f for f in files if f in kit.loads or f in kit.lists]
        if not present or not text:
            return
        count = sum(len(kit.loads.get(f, kit.lists.get(f))) for f in present)
        kit.steps.append({"Step": n, "What it fixes": what, "Records": count, "Files": ", ".join(present),
                          "How to apply": text, "Needs a decision first?": decide})
    step(2, "Names, phones, emails, state/country spellings (contacts)", ["02_update_contacts_standardize.csv"],
         how["update"].format(obj="Contact"), "No - formatting only (approved in advance)")
    step(3, "State, country and industry spellings (companies)", ["03_update_accounts_standardize.csv"],
         how["update"].format(obj="Account" if kit.crm != "hubspot" else "Companie"),
         "No - formatting only (approved in advance)")
    step(4, "Records owned by people who left", ["04_update_contacts_new_owner.csv", "04_choose_owner.csv"],
         how["owner"], "Yes - every owner change needs a Yes")
    step(5, "Fill blanks on the record being kept, before merging", ["05_update_contacts_fill_before_merge.csv",
                                                                    "05_update_accounts_fill_before_merge.csv"],
         how["update"].format(obj="record") + " Do this before step 6 so nothing is lost.",
         "Yes - only with its merge")
    step(6, "Merge duplicate contacts, companies and deals", ["06_merge_plan_contacts.csv", "06_merge_plan_accounts.csv",
                                                            "06_merge_plan_deals.csv"],
         how["merge"], "Yes - confirm each set is really the same person or company")
    step(7, "Leads that are already contacts", ["07_convert_leads_to_existing_contacts.csv"], how["convert"], "Yes")
    step(8, "Made-up values (TBD titles, fake emails, shared fake phones, 'Other' industry)",
         [f for f in kit.loads if f.startswith("08_")], how["clear"], "Yes - each value to clear needs a Yes")
    step(9, "Test and junk records", ["09_review_delete_contacts.csv"], how["delete"], "Yes")
    step(10, "Records missing outside information", ["10_enrich_contacts.csv", "10_enrich_accounts.csv"],
         "Send to a data provider (ZoomInfo, Apollo, etc.) only with the client's written approval; load the "
         "results back the same way as step 2.", "Yes - client approval to share data")
    step(11, "Deals reps need to update", ["11_rep_todo_lists.csv"],
         "Give each rep their rows; go through them in the next pipeline meeting.", "Yes - by each rep")
    kit.steps.insert(0, {"Step": 1, "What it fixes": "Backup first", "Records": None, "Files": "",
                         "How to apply": how["backup"], "Needs a decision first?": ""})


# ------------------------------------------------------------------ writing the kit

KIT_VERSION = 3
APPROVE_CHOICES = "Yes,No"

README = """UROBORIC CLEANUP KIT  -  {client}  -  {date}
==========================================================================

NOTHING HAS BEEN CHANGED IN {crm_name}.

This folder holds one file for the client: Cleanup_review.xlsx. It lists every proposed
change. {ready:,} format fixes are pre-approved, in {groups} groups on the "Quick approve" tab (capitalisation,
phone and email format, spelling of states, countries and industries: nothing is removed). {decisions:,} changes need
a decision (a Yes) from the client ({parts}), and {enrich:,} records need outside data.{extras}
About {minutes} minutes for the client to review: {groups} quick groups, {decisions:,} decisions.

What to do
  1. Send Cleanup_review.xlsx to the client. They check the Quick approve groups (set any to No), set Approve to
     Yes or No on the decision tabs, fill in the yellow cells, save, and send the file back.
  2. Run:   .\\audit.ps1 apply-review "<path to the reviewed workbook>"
     (iPad app: "Apply review", next to "Cleanup kit".)
  3. Open the folder it creates ({slug}_ready_to_load_<date>) and follow CHECKLIST.txt.
     Anything the client left blank is NOT applied.

If the client's own admin does the loading, send them that folder.
{notes}"""


def object_labels(crm: str) -> dict:
    """What each kind of record is called in this CRM."""
    return {"contacts": "Contact", "accounts": "Company" if crm in ("hubspot", "bullhorn") else "Account",
            "deals": "Deal", "opportunities": "Deal", "leads": "Lead"}


def write(kit: Kit, folder: Path, client: str, audit_date, branding=None) -> Path:
    """The kit folder: the review workbook and a short note for the consultant."""
    from .crms import NAMES

    shown = folder
    folder = _long_path(folder)
    if folder.exists():
        for p in folder.iterdir():
            if p.is_file():
                p.unlink()
    folder.mkdir(parents=True, exist_ok=True)
    b = branding if branding is not None and branding.active else None
    write_review_workbook(kit, folder / "Cleanup_review.xlsx", client, audit_date, b)

    s = kit.counts()
    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(client)).strip("_") or "client"
    notes = ("\nNotes\n" + "\n".join("  * " + n for n in kit.notes) + "\n") if kit.notes else ""
    readme = README.format(client=client, date=nice_date(audit_date), notes=notes, slug=slug,
                           crm_name=NAMES[kit.crm].upper(), ready=s["ready"], enrich=s["enrich"],
                           groups=s["quick_groups"], minutes=s["minutes"], decisions=s["decisions"],
                           parts=", ".join(kit.breakdown()) or "none",
                           extras=(" Also: " + "; ".join(kit.extras()) + ".") if kit.extras() else "")
    if b:
        head, rule, rest = readme.split("\n", 2)
        if b.white_label:
            head = head.replace("UROBORIC CLEANUP KIT", "CLEANUP KIT", 1)
        lines = ([f"Prepared by {b.prepared_by}"] if b.prepared_by else []) + \
                ([f"Questions? {b.contact}"] if b.contact else [])
        readme = "\n".join([head, rule] + lines + [rest])
    from .versions import stamp
    readme = readme.rstrip("\n") + "\n\n" + stamp(bool(b and b.white_label)) + "\n"
    (folder / "READ_ME_FIRST.txt").write_text(readme, encoding="utf-8")
    # the integrity record, next to the kit (not inside the folder that goes to the client)
    side = _long_path(shown.parent / f"{shown.name}.manifest.json")
    side.write_text(json.dumps(kit.manifest, sort_keys=True, separators=(",", ":")), encoding="utf-8")
    return shown


def _sheet_rows(kit: Kit) -> dict:
    """The review workbook's tables: sheet name -> (DataFrame, editable columns, hidden columns)."""
    labels = object_labels(kit.crm)
    out = {}

    # Field fixes: pure FORMAT fixes are pre-approved (Yes). Fill-before-merge values start blank: they only
    # apply together with their merge. Anything that empties a field goes on "Values to clear" instead.
    rows, clears = [], []
    groups = format_groups(kit)
    group_of = {cid: g for g in groups for cid in g["ids"]}
    if groups:
        out["Quick approve"] = (pd.DataFrame([
            {"Approve all": "Yes", "Group description": g["desc"], "Changes": g["n"],
             "Example 1": (g["examples"] + ["", "", ""])[0], "Example 2": (g["examples"] + ["", "", ""])[1],
             "Example 3": (g["examples"] + ["", "", ""])[2], "Note": QUICK_NOTE,
             "Group key": g["key"], "Members": members_hash(g["ids"])} for g in groups]),
            ["Approve all"], ["Group key", "Members"])
    for c in kit.changes:
        if c["Kind"] == "owner":
            continue
        if c["Kind"] == "clear":
            clears.append({"Approve": "", "Object": c["Object"], "Record ID": c["Record ID"], "Name": c["Name"],
                           "Field": c["Field"], "Current value": c["Current value"], "Why": c["Why"],
                           "Change ID": c["Change ID"]})
            continue
        why = c["Why"]
        if c["Kind"] == "fill":
            why = "Fill before merge (applies only if its merge is approved): " + why
        rows.append({"Approve": "Yes" if c["Kind"] == "standardize" else "", "Object": c["Object"],
                     "Record ID": c["Record ID"], "Name": c["Name"],
                     "Field": c["Field"], "Current value": c["Current value"], "New value": c["New value"],
                     "Why": why, "Change ID": c["Change ID"], "Kind": c["Kind"], "Merge key": c["Merge key"],
                     "Group": group_of[c["Change ID"]]["desc"] if c["Change ID"] in group_of else FILL_GROUP})
    if rows:   # sorted by group, so each Quick approve group sits together (fill-before-merge values last)
        pos = {g["desc"]: n for n, g in enumerate(groups)}
        rows.sort(key=lambda r: pos.get(r["Group"], len(pos)))
        out["Field fixes"] = (pd.DataFrame(rows), ["Approve", "New value"], ["Change ID", "Kind", "Merge key"])
    if clears:
        out["Values to clear"] = (pd.DataFrame(clears), ["Approve"], ["Change ID"])

    if kit.owners:
        df = pd.DataFrame([{"Approve": o["Approve"], "Object": o["Object"], "Record ID": o["Record ID"],
                            "Name": o["Name"], "Current owner": o["Current owner"], "Problem": o["Problem"],
                            "New owner": o["New owner"], "Why this owner": o["Why this owner"],
                            "Current owner ID": o["Current owner ID"],
                            "Change ID": o["Change ID"]}
                           for o in kit.owners])
        out["Owners"] = (df, ["Approve", "New owner"], ["Current owner ID", "Change ID"])

    if kit.merge_groups:
        rows = []
        for g in kit.merge_groups:
            others = [i for i in g["ids"] if i != g["keep"]]
            rows.append({"Approve": "", "Object": labels[g["object"]], "Keep ID": g["keep"],
                         "Merge IDs": ";".join(others), "Keep name": g["names"][g["keep"]],
                         "Merge names": "; ".join(str(g["names"][i]) for i in others),
                         "Why this one is kept": g["why"], "Check first": g["check"], "Merge key": g["key"],
                         # new in 1.5.0, after the hidden key so every older column keeps its position
                         "Match reason": g["reason"], "Differences": g["differs"],
                         "Group": g["detail"][0]["Group"]})
        out["Merges"] = (pd.DataFrame(rows), ["Approve", "Keep ID"], ["Merge key"])

        # Merge details: every member of every group, side by side (information only; apply-review ignores it)
        det = []
        for n, g in enumerate(kit.merge_groups, 2):
            for d in g["detail"]:
                det.append({"Merges tab row": n, **d})
        order = ["Email", "Phone", "Mobile", "Title", "Account", "Website", "City/State", "Contacts", "Amount",
                 "Stage", "Close date", "Owner", "Created", "Last activity"]
        base = ["Merges tab row", "Group", "Object", "Role", "ID", "Name"]
        dd = pd.DataFrame(det)
        keep_cols = [c for c in order if c in dd.columns and dd[c].notna().any()]   # columns the export lacks are left out
        marks = {(i, c) for i, d in enumerate(det) for c in d["_diff"] if c in keep_cols}
        dd = dd[base + keep_cols].astype(object).where(dd[base + keep_cols].notna(), None)
        dd.attrs["highlight"] = marks
        out["Merge details"] = (dd, [], [])

    ld = kit.lists.get("07_convert_leads_to_existing_contacts.csv")
    if ld is not None and len(ld):
        df = pd.DataFrame({"Approve": "", "Lead ID": ld["Lead ID"], "Lead name": ld["Lead name"],
                           "Lead email": ld["Lead email"], "Existing contact ID": ld["Existing contact ID"],
                           "Existing contact": ld["Existing contact"], "Existing account ID": ld["Existing account ID"],
                           "Change ID": [f"L{n}" for n in range(1, len(ld) + 1)]})
        out["Leads to convert"] = (df, ["Approve"], ["Change ID"])

    dl = kit.lists.get("09_review_delete_contacts.csv")
    if dl is not None and len(dl):
        extra = {c: dl[c] for c in ("Account", "Owner", "Created", "Last activity", "Open deals", "Logged activities")
                 if c in dl.columns and dl[c].notna().any()}
        df = pd.DataFrame({"Approve": "", "Object": "Contact", "Record ID": dl["Id"], "Name": dl["Name"],
                           "Email": dl["Email"], "Why": dl["Why"], **extra,
                           "Change ID": [f"D{n}" for n in range(1, len(dl) + 1)]})
        out["Delete"] = (_dates_as_text(df), ["Approve"], ["Change ID"])

    rep = kit.lists.get("11_rep_todo_lists.csv")
    if rep is not None and len(rep):
        out["Rep to-do"] = (_dates_as_text(rep), [], ["Merge key", "Conditional task"])

    parts = []
    for key, obj in (("10_enrich_contacts.csv", "Contact"), ("10_enrich_accounts.csv", "Account")):
        if key in kit.lists:
            parts.append(kit.lists[key].assign(Object=obj))
    if parts:
        cols = ["Object", "Id", "FirstName", "LastName", "Email", "Company", "Company domain", "Name", "Website", "Needs"]
        out["Enrich"] = (pd.concat(parts, ignore_index=True).reindex(columns=cols), [], [])
    return out


QUICK_NOTE = "To make exceptions, set individual rows to No on the 'Field fixes' tab"
FILL_GROUP = "Fill before merge"


def members_hash(ids) -> str:
    from . import manifest as M
    return M.h("|".join(sorted(ids)))


def _dates_as_text(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            df[c] = df[c].dt.strftime("%Y-%m-%d")
    return df


def build_manifest(kit: Kit, tables: dict, client, audit_date) -> dict:
    """Every proposed change, as hashes, so apply-review can tell the workbook came back unaltered."""
    from . import manifest as M
    ent = {}
    by_id = {c["Change ID"]: c for c in kit.changes}
    qkey = {}
    if "Quick approve" in tables:
        gs = {g["key"]: g for g in format_groups(kit)}
        for r in tables["Quick approve"][0].to_dict("records"):
            g = gs[r["Group key"]]
            e = M.entry("Quick approve", g["obj"], r["Group key"], g["field"], g["desc"], "", "group")
            e["n"], e["m"] = str(g["n"]), members_hash(g["ids"])
            ent[r["Group key"]] = e
            qkey.update({cid: g["key"] for cid in g["ids"]})
    if "Field fixes" in tables:
        for r in tables["Field fixes"][0].to_dict("records"):
            e = M.entry("Field fixes", r["Object"], r["Record ID"], r["Field"],
                        r["Current value"], r["New value"], r["Kind"])
            e["m"] = M.norm(r["Merge key"])
            e["q"] = qkey.get(r["Change ID"], "")
            e["x"] = {"Group": M.h(r["Group"])}
            src = by_id.get(r["Change ID"], {})
            if r["Kind"] == "fill" and src.get("Donor ID"):
                e["d"], e["dv"] = M.norm(src["Donor ID"]), M.h(src["Donor value"])
            ent[r["Change ID"]] = e
    if "Values to clear" in tables:
        for r in tables["Values to clear"][0].to_dict("records"):
            ent[r["Change ID"]] = M.entry("Values to clear", r["Object"], r["Record ID"], r["Field"],
                                          r["Current value"], "", "clear")
    if "Owners" in tables:
        for r in tables["Owners"][0].to_dict("records"):
            e = M.entry("Owners", r["Object"], r["Record ID"], "owner", "", r["New owner"], "owner")
            e["c"] = M.h(f"{M.norm(r['Current owner ID'])}|{M.norm(r['Current owner'])}")
            ent[r["Change ID"]] = e
    if "Merges" in tables:
        by_key = {g["key"]: g for g in kit.merge_groups}
        for r in tables["Merges"][0].to_dict("records"):
            g = by_key[r["Merge key"]]
            e = M.entry("Merges", r["Object"], r["Keep ID"], "merge", "", r["Merge IDs"], "merge")
            e["c"] = M.group_hash(g["ids"], g["names"], g["same"], g["fill"], g["keep"])
            ent[r["Merge key"]] = e
    if "Leads to convert" in tables:
        for r in tables["Leads to convert"][0].to_dict("records"):
            e = M.entry("Leads to convert", "Lead", r["Lead ID"], "convert", r["Existing contact ID"], "", "convert")
            e["x"] = {c: M.h(r[c]) for c in ("Lead name", "Lead email", "Existing contact", "Existing account ID")}
            ent[r["Change ID"]] = e
    if "Delete" in tables:
        for r in tables["Delete"][0].to_dict("records"):
            e = M.entry("Delete", r["Object"], r["Record ID"], "delete", "", "", "delete")
            e["c"] = M.h(f"{M.norm(r['Name'])}|{M.norm(r['Email'])}")
            e["x"] = {"Why": M.h(r["Why"])}
            ent[r["Change ID"]] = e
    tabs = {}
    for name in ("Rep to-do", "Enrich"):   # information-only sheets that become hand-off files
        if name in tables:
            df = tables[name][0]
            tabs[name] = M.table_hash(list(df.columns), df.itertuples(index=False))
    return {"kit_id": kit.kit_id, "client": str(client), "audit_date": f"{audit_date:%Y-%m-%d}",
            "crm": kit.crm, "entries": ent, "tables": tabs,
            # lookups that feed the load files live here, not in the editable workbook: the owner pick-list
            # (label -> user id) and the id / owner column headers per object
            "users": [[u[0], u[1]] for u in kit.users], "meta": kit.meta}


DECISION_TABS = ("Quick approve", "Values to clear", "Owners", "Merges", "Leads to convert", "Delete")
REFERENCE_TABS = ("Field fixes", "Merge details", "Rep to-do", "Enrich")
DECISION_COLOR, REFERENCE_COLOR = "2E75B6", "A6A6A6"
START_PREAPPROVED = ("Already approved (Approve = Yes): formatting only: capitalisation, phone and email format, "
                     "and the spelling of states, countries and industries. No information is removed.")


def _start_here(ws, kit: Kit, tables: dict, client, b, crm_name: str) -> list:
    """The first sheet: what to do and a live progress table. Returns the formulas to put in AFTER the workbook's
    text is sanitised (sanitising stores every string as text, which would switch a formula off)."""
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from .report import NAVY

    counts = {k: len(v[0]) for k, v in tables.items()}
    kc = kit.counts()
    width = 5   # columns A:E
    r = [1]
    heights = {}

    def text(t, font=None, chars=105):
        row = r[0]
        c = ws.cell(row, 1, t)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        if font:
            c.font = font
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=width)
        lines = max(1, -(-len(t) // chars)) if t else 1
        ws.row_dimensions[row].height = (21 if font and font.size and font.size > 12 else 15.5) * lines
        r[0] += 1

    bold = Font(bold=True, size=12, color=NAVY)
    text(f"{b.tool_name if b else 'Uroboric '}cleanup review: {client}", Font(bold=True, size=14, color=NAVY))
    text(f"Nothing has been changed in {crm_name}. This workbook only lists changes we suggest. "
         "Nothing happens until you send it back and the changes are loaded on purpose.")
    text(kit.headline() + ".")
    text(f"About {kc['minutes']} minutes: {kc['quick_groups']} quick groups, {kc['decisions']:,} decisions.")
    if b and (b.prepared_by or b.contact):
        text(" | ".join(x for x in ((f"Prepared by {b.prepared_by}" if b.prepared_by else ""), b.contact) if x))
    text("")
    text("What to do", bold)
    steps = []
    if "Quick approve" in tables:
        steps.append("Check the Quick approve tab. " + START_PREAPPROVED + " Set a group to No if you don't want it.")
    steps.append("Answer each decision tab below (blue tabs): fill the yellow cells with Yes or No. Everything else "
                 "needs a Yes from you: suggested owners are filled in but NOT approved, and a blank row is not applied. "
                 "On Owners pick the new owner from the list; on Merges you may change Keep ID.")
    steps.append("Save the file and send it back.")
    for n, t in enumerate(steps, 1):
        text(f"{n}.  {t}")
    text("")
    formulas = []
    present = [n for n in DECISION_TABS if n in tables]
    if present:
        text("Your progress", bold)
        head = ["Tab", "To decide", "Yes", "No", "Left"]
        thin = Side(style="thin", color="BFBFBF")
        fill = PatternFill("solid", fgColor=NAVY)
        for j, h in enumerate(head, 1):
            c = ws.cell(r[0], j, h)
            c.font, c.fill = Font(bold=True, color="FFFFFF"), fill
            c.alignment = Alignment(horizontal="left" if j == 1 else "center")
        r[0] += 1
        for name in present:
            df = tables[name][0]
            n = len(df)
            col = "A"   # Approve / Approve all
            rng = f"'{name}'!{col}2:{col}{n + 1}"
            row = r[0]
            ws.cell(row, 1, name)
            ws.cell(row, 2, n)
            formulas.append((f"C{row}", f'=COUNTIF({rng},"Yes")'))
            formulas.append((f"D{row}", f'=COUNTIF({rng},"No")'))
            left = f"=B{row}-C{row}-D{row}"
            if name == "Owners":   # a Yes with no New owner picked isn't finished either
                L = _col_letter(list(df.columns).index("New owner") + 1)
                left += f'+COUNTIFS({rng},"Yes",\'{name}\'!{L}2:{L}{n + 1},"")'
            formulas.append((f"E{row}", left))
            for j in range(1, width + 1):
                ws.cell(row, j).border = Border(bottom=thin)
                if j > 1:
                    ws.cell(row, j).alignment = Alignment(horizontal="center")
            r[0] += 1
        text("Left = rows still waiting for a Yes or No" + (" (on Owners, also Yes rows with no new owner chosen)."
                                                            if "Owners" in present else "."))
        text("")
    ref = [n for n in REFERENCE_TABS if n in tables]
    if ref:
        text("Reference tabs (nothing to decide)", bold)
        fill_n = kc["fill"]["changes"]
        desc = {"Field fixes": "every formatting fix one by one, for exceptions (set a row to No). You may edit a New "
                               "value, but it can't be empty (to clear a value, use Values to clear)."
                               + (f" The {fill_n:,} values copied before merges sit at the end: blank Approve, they "
                                  "follow their merge." if fill_n else ""),
                "Merge details": "every record in every merge group side by side; orange cells differ from the SUGGESTED keep record "
                                 "(not a Keep ID you change). Still useful if you change Keep ID on Merges; match rows by Group.",
                "Rep to-do": "suggestions for each rep, not approved changes. Nothing to fill in.",
                "Enrich": "records missing details an outside data provider could fill, for information."}
        for name in ref:
            text(f"{name} ({counts[name]:,} rows):  {desc[name]}")
    ws.column_dimensions["A"].width = 42
    for L in "BCDE":
        ws.column_dimensions[L].width = 17
    return formulas


def _col_letter(n: int) -> str:
    from openpyxl.utils import get_column_letter
    return get_column_letter(n)


def write_review_workbook(kit: Kit, path: Path, client: str, audit_date, b=None):
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Protection
    from openpyxl.utils import get_column_letter
    from openpyxl.workbook.protection import WorkbookProtection
    from openpyxl.worksheet.datavalidation import DataValidation
    from .crms import NAMES
    from .report import autosize, sanitize_workbook, write_df

    YELLOW = PatternFill("solid", fgColor="FFF2A8")
    ORANGE = PatternFill("solid", fgColor="F8CBAD")
    tables = _sheet_rows(kit)
    wb = Workbook()
    ws = wb.active
    ws.title = "Start here"
    start_formulas = _start_here(ws, kit, tables, client, b, NAMES[kit.crm])
    ws.sheet_properties.tabColor = DECISION_COLOR
    order = [n for n in (*DECISION_TABS, *REFERENCE_TABS) if n in tables]

    users = [u[0] for u in kit.users]
    for title in order:
        df, editable, hidden = tables[title]
        w2 = wb.create_sheet(title)
        w2.sheet_properties.tabColor = DECISION_COLOR if title in DECISION_TABS else REFERENCE_COLOR
        n = len(df)
        cols = list(df.columns)
        write_df(w2, df, row=1)
        autosize(w2, max_width=45)
        if "Approve" in cols:
            w2.column_dimensions["A"].width = 10
        if "Approve all" in cols:
            w2.column_dimensions["A"].width = 12
            w2.column_dimensions["B"].width = 60
        for rowi, name in df.attrs.get("highlight", ()):   # cells that differ from the kept record
            w2.cell(rowi + 2, cols.index(name) + 1).fill = ORANGE
        w2.freeze_panes = "A2"
        w2.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{n + 1}"
        for name in editable:
            j = cols.index(name) + 1
            for r in range(2, n + 2):
                cell = w2.cell(r, j)
                cell.fill = YELLOW
                cell.protection = Protection(locked=False)
                if name in ("Keep ID", "New value"):
                    cell.number_format = "@"   # typed digits stay text, so IDs and phone numbers survive
        if "Approve" in editable or "Approve all" in editable:
            dv = DataValidation(type="list", formula1=f'"{APPROVE_CHOICES}"', allow_blank=True,
                                showErrorMessage=True, errorTitle="Approve", error="Choose Yes or No.")
            w2.add_data_validation(dv)
            dv.add(f"A2:A{n + 1}")
        if "New owner" in editable and users:
            j = get_column_letter(cols.index("New owner") + 1)
            dv = DataValidation(type="list", formula1=f"=Lists!$A$2:$A${len(users) + 1}", allow_blank=True,
                                showErrorMessage=True, errorTitle="New owner", error="Pick a name from the list.")
            w2.add_data_validation(dv)
            dv.add(f"{j}2:{j}{n + 1}")
        for name in hidden:
            w2.column_dimensions[get_column_letter(cols.index(name) + 1)].hidden = True
        _lock(w2)
    _lock(ws)

    # Hidden sheets: the pick-list of people, the duplicate groups, and what apply-review needs
    lists = wb.create_sheet("Lists")
    lists.append(["Name", "ID"])
    for name, uid in kit.users:
        lists.append([name, uid])
    groups = wb.create_sheet("_groups")
    groups.append(["Merge key", "Object", "ID", "Name", "Suggested keep", "Same person", "Fill values"])
    for g in kit.merge_groups:
        for i in g["ids"]:
            groups.append([g["key"], g["object"], i, g["names"][i], "Yes" if i == g["keep"] else "",
                           "Yes" if g["same"][i] else "No", json.dumps(g["fill"].get(i, {}))])
    from . import manifest as M
    kit.manifest = build_manifest(kit, tables, client, audit_date)
    chunks = M.pack(kit.manifest)
    man = wb.create_sheet("_manifest")
    for i, chunk in enumerate(chunks, 1):
        man.append([i, chunk])
    meta = wb.create_sheet("_kit")
    info = {"kit_version": KIT_VERSION, "kit_id": kit.kit_id, "manifest_chunks": len(chunks),
            "manifest_sha": M.digest(chunks), "crm": kit.crm, "client": str(client),
            "audit_date": f"{audit_date:%Y-%m-%d}", "prepared_by": b.prepared_by if b else "",
            "contact": b.contact if b else "", "white_label": "yes" if (b and b.white_label) else "",
            "meta": json.dumps(kit.meta)}
    for k, v in info.items():
        meta.append([k, v])
    for h in (lists, groups, man, meta):
        h.sheet_state = "hidden"
        _lock(h)
    wb.security = WorkbookProtection(lockStructure=True)
    sanitize_workbook(wb)
    for ref, formula in start_formulas:   # our own formulas, put in after sanitising (it would store them as text)
        ws[ref].value = formula
    wb.save(path)


def _lock(ws):
    """Protect a sheet (no password) so only the unlocked cells can be changed; sorting and filtering stay on."""
    ws.protection.sheet = True
    ws.protection.sort = False
    ws.protection.autoFilter = False
    ws.protection.formatColumns = False


def _long_path(p: Path) -> Path:
    """Windows limits ordinary paths to 260 characters; deep folders plus file names can exceed it.
    The \\\\?\\ prefix lifts that limit. Other systems don't need it."""
    import os
    if os.name != "nt":
        return p
    s = str(p.resolve())
    return Path(s if s.startswith("\\\\?\\") else "\\\\?\\" + s)
