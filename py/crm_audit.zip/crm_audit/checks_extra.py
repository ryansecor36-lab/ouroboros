"""Checks added from research into what CRM users complain about most:
  1.6  leads that are already contacts (and leads that belong to existing accounts)
  3.8  placeholder values typed just to get past a required field
  4.8  deals whose close date keeps getting pushed
"""
from __future__ import annotations

import re

import pandas as pd

from . import normalize as N
from .checklist import Check
from .checks import Context, Result, _cap, _freq, _ids, _missing, fmt_pct, pct
from .plain import money

# ------------------------------------------------ 1.6 Leads that duplicate contacts


def c_1_6(ctx: Context, chk: Check) -> Result:
    L, C = ctx.leads, ctx.contacts
    if L is None:
        return _missing(chk, "leads")
    if C is None:
        return _missing(chk, "contacts")
    open_ = L[~L["is_converted"]].copy()
    if open_.empty:
        return Result(chk.id, value=0.0, display="No unconverted leads", headline="There are no open leads")
    contact_emails = {e for e in C["email_n"].dropna() if not N.is_placeholder_email(e)}
    by_person = {}
    for pk, dom, cid in zip(C["person_key"], C["domain_key"], C["id"]):
        if isinstance(pk, str) and isinstance(dom, str):
            by_person.setdefault((pk, dom), cid)
    email_to_contact = {e: i for e, i in zip(C["email_n"], C["id"]) if isinstance(e, str)}
    open_["domain"] = open_["email"].map(N.business_domain)
    open_["person_key"] = [N.person_key(f, l) for f, l in zip(open_["first_name"], open_["last_name"])]
    match, how = [], []
    for e, pk, dom in zip(open_["email_n"], open_["person_key"], open_["domain"]):
        if isinstance(e, str) and e in contact_emails:
            match.append(email_to_contact[e]); how.append("same email as a contact")
        elif isinstance(pk, str) and isinstance(dom, str) and (pk, dom) in by_person:
            match.append(by_person[(pk, dom)]); how.append("same name at the same company")
        else:
            match.append(None); how.append(None)
    open_["contact_match"], open_["how"] = match, how
    dup = open_[open_["contact_match"].notna()]
    r = Result(chk.id, value=pct(len(dup), len(open_)))
    r.display = f"{fmt_pct(r.value)} ({len(dup):,} of {len(open_):,} open leads already exist as contacts)"
    r.flagged = {"leads": _ids(open_, open_["contact_match"].notna())}
    names = dict(zip(C["id"], C["name"]))
    owners = dict(zip(C["id"], C["owner"]))
    out = dup.assign(contact=dup["contact_match"].map(names), contact_owner=dup["contact_match"].map(owners))
    cols = {"id": "Lead ID", "name": "Lead name", "email": "Lead email", "company": "Company",
            "owner": "Lead owner", "how": "Why it matches", "contact_match": "Existing contact ID",
            "contact": "Existing contact", "contact_owner": "Contact owner"}
    r.details["Leads already contacts"] = _cap(out[list(cols)].rename(columns=cols))
    if len(dup):
        r.headline = (f"{len(dup):,} open leads are people already in the CRM as contacts"
                      + _freq(r.value, "open leads"))
        x = out.iloc[0]
        diff_owner = isinstance(x["owner"], str) and isinstance(x["contact_owner"], str) and x["owner"] != x["contact_owner"]
        r.example = (f'"{x["name"]}" came in as a new lead but is already a contact'
                     + (f". The lead went to {x['owner']}; the contact belongs to {x['contact_owner']}"
                        if diff_owner else ""))
        split = int(sum(1 for a, b in zip(out["owner"], out["contact_owner"])
                        if isinstance(a, str) and isinstance(b, str) and a != b))
        if split:
            r.notes.append(f"{split:,} of these leads are owned by a different rep than the existing contact, "
                           "so two reps may be working the same person.")
    else:
        r.headline = "No open leads duplicate an existing contact"

    # Leads from companies that are already accounts (lead-to-account matching / routing)
    A = ctx.accounts
    if A is not None:
        dom_to_acct = {d: i for d, i in zip(A["domain"], A["id"]) if isinstance(d, str)}
        name_to_acct = {n: i for n, i in zip(A["name_n"], A["id"]) if isinstance(n, str)}
        rest = open_[open_["contact_match"].isna()].copy()
        rest["account_match"] = [dom_to_acct.get(d) if isinstance(d, str) and d in dom_to_acct
                                 else name_to_acct.get(N.norm_company(c))
                                 for d, c in zip(rest["domain"], rest["company"])]
        hits = rest[rest["account_match"].notna()]
        if len(hits):
            an = dict(zip(A["id"], A["name"]))
            ao = dict(zip(A["id"], A["owner"]))
            hits = hits.assign(account=hits["account_match"].map(an), account_owner=hits["account_match"].map(ao))
            wrong = int(sum(1 for a, b in zip(hits["owner"], hits["account_owner"])
                            if isinstance(a, str) and isinstance(b, str) and a != b))
            r.notes.append(f"Another {len(hits):,} open leads come from companies that are already accounts; "
                           f"{wrong:,} of them went to a different rep than the account owner.")
            r.extras["account_leads"] = len(hits)
            r.extras["account_leads_misrouted"] = wrong
            cols = {"id": "Lead ID", "name": "Lead name", "email": "Lead email", "company": "Company",
                    "owner": "Lead owner", "account": "Existing account", "account_owner": "Account owner"}
            r.details["Leads from existing accounts"] = _cap(hits[list(cols)].rename(columns=cols))
    r.extras["count"] = len(dup)
    return r


# ----------------------------------------------------- 3.8 Placeholder values

FAKE_AMOUNTS = {0.0, 1.0, 12345.0, 123456.0, 99999.0, 999999.0, 1111.0, 11111.0, 111111.0}
GENERIC_TITLES = {"contact", "employee", "staff", "n a", "na", "tbd", "unknown", "none", "other", "x",
                  "title", "job title", "person", "user", "customer", "main contact", "primary contact"}
PLACEHOLDER_INDUSTRY = {"other", "unknown", "n a", "na", "none", "tbd", "misc", "miscellaneous", "general",
                        "not specified", "select one"}
FAKE_EMAIL_LOCAL = N.FAKE_EMAIL_LOCAL - {"test"}  # 'test' entries are counted as junk (3.5) instead
FAKE_EMAIL_DOMAINS = N.FAKE_EMAIL_DOMAINS


def c_3_8(ctx: Context, chk: Check) -> Result:
    C, A, O = ctx.contacts, ctx.accounts, ctx.opps
    if C is None and A is None and O is None:
        return _missing(chk, "contacts, accounts or opportunities")
    rows = []

    def add(obj, rid, name, fld, value, why):
        rows.append({"Object": obj, "Record ID": rid, "Name": name, "Field": fld, "Value": value, "Why it looks made up": why})

    examined, flagged = 0, {"contacts": set(), "accounts": set(), "opportunities": set()}
    notes = []
    if O is not None:
        op = O[~O["is_closed"]]
        examined += len(op)
        prob = pd.to_numeric(op["probability"].map(lambda v: re.sub(r"[%\s]", "", v) if isinstance(v, str) else None),
                             errors="coerce") if ctx.t("opportunities").has("probability") else None
        if prob is not None and prob.notna().any() and prob.max() <= 1:
            prob = prob * 100  # HubSpot exports probability as a fraction (0.2 = 20%)
        far = ctx.audit_date + pd.DateOffset(years=3)
        for i, (rid, nm, amt, cd) in enumerate(zip(op["id"], op["name"], op["amount"], op["close_date"])):
            if pd.notna(amt) and float(amt) in FAKE_AMOUNTS:
                add("Deal", rid, nm, "Amount", f"${amt:,.0f}", "placeholder amount"); flagged["opportunities"].add(rid)
            if pd.notna(cd) and cd > far:
                add("Deal", rid, nm, "Close date", f"{cd:%Y-%m-%d}", "close date years in the future"); flagged["opportunities"].add(rid)
            if prob is not None:
                p = prob.iloc[i]
                if pd.notna(p) and p in (0, 100):
                    add("Deal", rid, nm, "Probability", f"{p:.0f}%", f"{p:.0f}% chance on a deal that is still open")
                    flagged["opportunities"].add(rid)
        if len(op):
            month_end = op["close_date"].dropna().map(lambda d: d.is_month_end)
            if len(month_end) >= 20:
                share = 100 * month_end.mean()
                if share >= 30:
                    notes.append(f"{share:.0f}% of open deals are set to close on the last day of a month, a sign "
                                 "reps pick a default date rather than a real one.")
    if C is not None:
        examined += len(C)
        digits = C["phone"].map(lambda v: re.sub(r"\D", "", v)[-10:] if isinstance(v, str) else None)
        shared = digits.dropna().groupby(digits.dropna()).filter(lambda s: len(s) >= 5).unique()
        acct_key = C["account"].fillna(C["domain_key"])
        for ph in shared:
            mask = digits == ph
            if acct_key[mask].nunique() >= 3:
                for rid, nm, raw in zip(C.loc[mask, "id"], C.loc[mask, "name"], C.loc[mask, "phone"]):
                    add("Contact", rid, nm, "Phone", f"{raw} (on {int(mask.sum())} contacts)",
                        "same phone number on many unrelated contacts")
                    flagged["contacts"].add(rid)
        for rid, nm, title, email in zip(C["id"], C["name"], C["title"], C["email"]):
            if N.canon_text(title) in GENERIC_TITLES:
                add("Contact", rid, nm, "Title", title, "placeholder job title"); flagged["contacts"].add(rid)
            if isinstance(email, str) and "@" in email:
                local, dom = email.strip().lower().rsplit("@", 1)
                if local in FAKE_EMAIL_LOCAL or dom in FAKE_EMAIL_DOMAINS:
                    add("Contact", rid, nm, "Email", email, "fake email address"); flagged["contacts"].add(rid)
    if A is not None:
        examined += len(A)
        for rid, nm, ind, emp in zip(A["id"], A["name"], A["industry"], A["employees"]):
            if N.canon_text(ind) in PLACEHOLDER_INDUSTRY:
                add("Account", rid, nm, "Industry", ind, "placeholder industry"); flagged["accounts"].add(rid)
            if isinstance(emp, str) and emp.strip() == "0":
                add("Account", rid, nm, "Employees", emp, "employee count of 0"); flagged["accounts"].add(rid)
    n = sum(len(v) for v in flagged.values())
    r = Result(chk.id, value=pct(n, examined))
    r.display = f"{fmt_pct(r.value)} of records ({n:,} of {examined:,}) contain a placeholder value"
    r.notes = notes
    r.flagged = {k: v for k, v in flagged.items() if v}
    df = pd.DataFrame(rows, columns=["Object", "Record ID", "Name", "Field", "Value", "Why it looks made up"])
    r.details["Placeholder values"] = _cap(df)
    if n:
        r.headline = f"{n:,} records contain values that look typed in just to get past a required field"
        by = df["Why it looks made up"].value_counts()
        ex = df[df["Why it looks made up"] == by.index[0]].iloc[0]
        r.example = f'{ex["Object"]} "{ex["Name"]}" has {ex["Field"].lower()} "{ex["Value"]}" ({by.index[0]})'
        r.notes.insert(0, "By type: " + ", ".join(f"{k} {v:,}" for k, v in by.items()))
    else:
        r.headline = "No placeholder values found"
    r.extras = {"count": n}
    return r


# ------------------------------------------------- 4.8 Close dates pushed repeatedly


def _push_counts(ctx: Context):
    h = ctx.t("opportunity_history")
    if h is None or not h.has("opportunity_id"):
        return None, None
    df = pd.DataFrame({"opp": h.text("opportunity_id"), "at": h.date("created")})
    if h.has("field") and h.has("new_value"):  # OpportunityFieldHistory
        df["field"] = h.text("field").fillna("").str.replace(r"[^a-z]", "", regex=True, case=False).str.lower()
        df["old"] = pd.to_datetime(h.text("old_value"), errors="coerce", format="mixed")
        df["new"] = pd.to_datetime(h.text("new_value"), errors="coerce", format="mixed")
        cd = df[df["field"] == "closedate"]
        pushed = cd[(cd["new"] > cd["old"])]
        counts = pushed.groupby("opp").size()
        first = cd.sort_values("at").groupby("opp")["old"].first()
        return counts, first
    if h.has("close_date"):  # OpportunityHistory: one row per change, with the close date at that time
        df["cd"] = h.date("close_date")
        df = df.dropna(subset=["opp", "cd"]).sort_values(["opp", "at"])
        df["prev"] = df.groupby("opp")["cd"].shift()
        counts = df[df["cd"] > df["prev"]].groupby("opp").size()
        first = df.groupby("opp")["cd"].first()
        return counts, first
    return None, None


def c_4_8(ctx: Context, chk: Check) -> Result:
    O = ctx.opps
    if O is None:
        return _missing(chk, "opportunities")
    counts, first = _push_counts(ctx)
    if counts is None:
        return Result(chk.id, display="Needs opportunity history export",
                      notes=["Export OpportunityHistory (OpportunityId, CloseDate, CreatedDate) or "
                             "OpportunityFieldHistory (OpportunityId, Field, OldValue, NewValue, CreatedDate) "
                             "as opportunity_history.csv. Salesforce keeps only the latest close date on the "
                             "deal itself, so the history file is the only way to see how often it moved."])
    op = O[~O["is_closed"]].copy()
    if op.empty:
        return Result(chk.id, value=0.0, display="No open opportunities", headline="There are no open deals")
    op["pushes"] = op["id"].map(counts).fillna(0).astype(int)
    op["first_date"] = op["id"].map(first)
    op["days_pushed"] = (op["close_date"] - op["first_date"]).dt.days
    bad = op["pushes"] >= 3
    total = op["amount"].sum()
    amt = float(op.loc[bad, "amount"].sum())
    value = 100 * amt / total if total > 0 else pct(int(bad.sum()), len(op))
    r = Result(chk.id, value=value)
    r.display = f"{fmt_pct(value)} of open pipeline: {int(bad.sum()):,} deals pushed 3+ times, ${amt:,.0f}"
    r.extras = {"count": int(bad.sum()), "amount": amt}
    once = int((op["pushes"] >= 1).sum())
    r.notes.append(f"{once:,} of {len(op):,} open deals have had their close date pushed at least once.")
    out = op[bad].sort_values(["pushes", "amount"], ascending=False)
    cols = {"id": "Opportunity ID", "name": "Opportunity", "account": "Account", "owner": "Owner",
            "amount": "Amount", "first_date": "Original close date", "close_date": "Current close date",
            "pushes": "Times pushed", "days_pushed": "Days pushed in total"}
    r.details["Deals pushed 3+ times"] = _cap(out[list(cols)].rename(columns=cols))
    if bad.any():
        r.headline = (f"{int(bad.sum()):,} open deals worth {money(amt)} have had their close date pushed "
                      "back 3 or more times")
        x = out.iloc[0]
        days = f", {int(x['days_pushed']):,} days later than first planned" if pd.notna(x["days_pushed"]) else ""
        r.example = f'"{x["name"]}" ({money(x["amount"]) if pd.notna(x["amount"]) else "no amount"}) has been pushed {x["pushes"]} times{days}'
        by_owner = out.groupby("owner")["amount"].sum().sort_values(ascending=False)
        if len(by_owner) > 1:
            r.notes.append(f"Biggest share: {by_owner.index[0]} ({money(by_owner.iloc[0])}).")
    else:
        r.headline = "No open deal has been pushed back 3 or more times"
    return r


EXTRA_AUTO = {"1.6": c_1_6, "3.8": c_3_8, "4.8": c_4_8}
