"""Reads Salesforce CSV exports (Data Loader / Data Export with API names, or report exports
with field labels) and maps their columns to the fields the checks need."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd


def norm_header(h) -> str:
    return re.sub(r"[^a-z0-9]", "", str(h).lower())


_OWNER_ID = ["OwnerId", "Owner ID", "Owner.Id"]
_DATES = {
    "last_activity": ["LastActivityDate", "Last Activity", "Last Activity Date"],
    "last_modified": ["LastModifiedDate", "Last Modified Date", "Last Modified"],
    "created": ["CreatedDate", "Created Date", "Date Created"],
    "created_by_id": ["CreatedById", "Created By ID", "CreatedBy.Id"],
    "created_by_name": ["Created By", "Created By Name", "CreatedBy.Name", "Created By: Full Name"],
}

ALIASES: dict[str, dict[str, list[str]]] = {
    "contacts": {
        "id": ["Id", "Contact ID", "ContactId"],
        "first_name": ["FirstName", "First Name"],
        "last_name": ["LastName", "Last Name"],
        "email": ["Email", "Email Address"],
        "phone": ["Phone", "Business Phone", "Work Phone"],
        "mobile": ["MobilePhone", "Mobile", "Mobile Phone"],
        "title": ["Title", "Job Title"],
        "account_id": ["AccountId", "Account ID", "Account.Id"],
        "account_name": ["Account Name", "Account.Name", "Account", "Company", "Company Name"],
        "owner_id": _OWNER_ID + ["Contact Owner ID"],
        "owner_name": ["Contact Owner", "Owner Name", "Owner", "Owner Full Name", "Owner.Name"],
        "opted_out": ["HasOptedOutOfEmail", "Email Opt Out", "Email Opt-Out"],
        "lead_source": ["LeadSource", "Lead Source", "Contact Source", "Original Source"],
        "state": ["MailingState", "Mailing State/Province", "Mailing State", "State",
                  "State/Province"],
        "country": ["MailingCountry", "Mailing Country", "Country"],
        **_DATES,
    },
    "accounts": {
        "id": ["Id", "Account ID", "AccountId"],
        "name": ["Name", "Account Name"],
        "website": ["Website", "Company Domain Name", "Domain"],
        "industry": ["Industry"],
        "employees": ["NumberOfEmployees", "Employees", "Number of Employees"],
        "state": ["BillingState", "Billing State/Province", "Billing State", "State",
                  "State/Province"],
        "country": ["BillingCountry", "Billing Country", "Country"],
        "city": ["BillingCity", "Billing City", "City"],
        "owner_id": _OWNER_ID + ["Account Owner ID"],
        "owner_name": ["Account Owner", "Owner Name", "Owner", "Owner.Name"],
        **_DATES,
    },
    "opportunities": {
        "id": ["Id", "Opportunity ID", "OpportunityId"],
        "name": ["Name", "Opportunity Name"],
        "account_id": ["AccountId", "Account ID", "Account.Id"],
        "account_name": ["Account Name", "Account.Name", "Account"],
        "stage": ["StageName", "Stage"],
        "is_closed": ["IsClosed", "Closed"],
        "is_won": ["IsWon", "Won"],
        "close_date": ["CloseDate", "Close Date"],
        "amount": ["Amount", "Opportunity Amount"],
        "owner_id": _OWNER_ID + ["Opportunity Owner ID"],
        "owner_name": ["Opportunity Owner", "Owner Name", "Owner", "Owner.Name"],
        "contact_id": ["ContactId", "Contact ID", "Primary Contact ID"],
        "contact_name": ["Primary Contact", "Contact Name", "Contact"],
        "probability": ["Probability", "Probability (%)"],
        **_DATES,
    },
    "leads": {
        "id": ["Id", "Lead ID", "LeadId"],
        "first_name": ["FirstName", "First Name"],
        "last_name": ["LastName", "Last Name"],
        "company": ["Company", "Company / Account"],
        "email": ["Email"],
        "status": ["Status", "Lead Status"],
        "is_converted": ["IsConverted", "Converted"],
        "lead_source": ["LeadSource", "Lead Source"],
        "owner_id": _OWNER_ID + ["Lead Owner ID"],
        "owner_name": ["Lead Owner", "Owner Name", "Owner", "Owner.Name"],
        **_DATES,
    },
    "users": {
        "id": ["Id", "User ID", "UserId"],
        "name": ["Name", "Full Name", "User"],
        "first_name": ["FirstName", "First Name"],  # Salesforce Data Export has no Name for users
        "last_name": ["LastName", "Last Name"],
        "is_active": ["IsActive", "Active"],
        "profile": ["Profile.Name", "Profile", "Profile Name"],
        "user_type": ["UserType", "User Type"],
    },
    "opportunity_history": {
        "opportunity_id": ["OpportunityId", "Opportunity ID"],
        "close_date": ["CloseDate", "Close Date"],
        "field": ["Field", "Field / Event"],
        "old_value": ["OldValue", "Old Value"],
        "new_value": ["NewValue", "New Value"],
        "created": ["CreatedDate", "Created Date", "Edit Date", "Last Modified"],
    },
    "tasks": {
        "who_id": ["WhoId", "Who ID", "Name ID", "Lead/Contact ID"],
        "created": ["CreatedDate", "Created Date", "Date Created"],
    },
    "contact_roles": {
        "opportunity_id": ["OpportunityId", "Opportunity ID"],
        "contact_id": ["ContactId", "Contact ID"],
    },
}

# Fields found by pattern when the name varies between orgs (custom fields)
PATTERNS = {
    "contacts": {"seniority": r"seniority|persona|joblevel|managementlevel|buyerrole"},
    "opportunities": {"loss_reason": r"(loss|lost).*reason|reason.*(loss|lost)"},
}

# Which file belongs to which table. Order matters: more specific names are matched first.
FILE_NAMES = {
    "contact_roles": ["opportunitycontactroles", "opportunitycontactrole", "contactroles",
                      "contactrole"],
    "opportunity_history": ["opportunityhistory", "opportunityfieldhistory", "opphistory",
                            "dealhistory", "opportunitieshistory"],
    "tasks": ["tasks", "task", "activities", "activity"],
    "users": ["users", "user"],
    "leads": ["leads", "lead"],
    "opportunities": ["opportunities", "opportunity", "opps", "deals"],
    "accounts": ["accounts", "account", "companies", "company"],
    "contacts": ["contacts", "contact"],
}

TABLE_LABELS = {
    "contacts": "Contacts", "accounts": "Accounts", "opportunities": "Opportunities",
    "leads": "Leads", "users": "Users", "tasks": "Tasks",
    "contact_roles": "Opportunity Contact Roles", "opportunity_history": "Opportunity History",
}

_FOOTER_RE = re.compile(r"copyright|confidential|generated by|grand total|salesforce\.com", re.I)


@dataclass
class Table:
    name: str
    path: Path
    raw: pd.DataFrame
    mapping: dict[str, str] = field(default_factory=dict)

    def __len__(self):
        return len(self.raw)

    def has(self, f: str) -> bool:
        return f in self.mapping

    def text(self, f: str) -> pd.Series:
        if f in self.mapping:
            return self.raw[self.mapping[f]].astype(object)
        return pd.Series([None] * len(self.raw), index=self.raw.index, dtype=object)

    def date(self, f: str) -> pd.Series:
        s = self.text(f)
        d = pd.to_datetime(s, errors="coerce", utc=True, format="mixed")
        return d.dt.tz_localize(None)

    def number(self, f: str) -> pd.Series:
        s = self.text(f).map(lambda v: re.sub(r"[$,\s]", "", v) if isinstance(v, str) else None)
        return pd.to_numeric(s, errors="coerce")

    def flag(self, f: str) -> pd.Series:
        return self.text(f).map(
            lambda v: isinstance(v, str) and v.strip().lower() in {"true", "1", "yes", "y", "checked", "x"}
        ).astype(bool)


def read_csv(path: Path) -> pd.DataFrame:
    last_err = None
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            df = pd.read_csv(path, dtype=object, keep_default_na=False, encoding=enc)
            break
        except UnicodeDecodeError as e:
            last_err = e
    else:
        raise last_err
    df.columns = [str(c).strip() for c in df.columns]
    df = df.map(lambda v: (v.strip() or None) if isinstance(v, str) else None)
    # Drop the copyright / totals footer that Salesforce report exports add
    filled = df.notna().sum(axis=1)
    first = df.iloc[:, 0].astype(str)
    footer = (filled <= 1) & first.str.contains(_FOOTER_RE)
    df = df[~footer & (filled > 0)].reset_index(drop=True)
    return df


def map_columns(table: str, df: pd.DataFrame, overrides: dict | None = None) -> dict[str, str]:
    normed = {}
    for c in df.columns:
        normed.setdefault(norm_header(c), c)
    mapping = {}
    for logical, aliases in ALIASES.get(table, {}).items():
        for a in aliases:
            if norm_header(a) in normed:
                mapping[logical] = normed[norm_header(a)]
                break
    for logical, pattern in PATTERNS.get(table, {}).items():
        for nh, c in normed.items():
            if re.search(pattern, nh):
                mapping[logical] = c
                break
    for logical, col in (overrides or {}).items():
        if col in df.columns:
            mapping[logical] = col
        else:
            raise ValueError(f"[columns.{table}] {logical} = '{col}': no such column in the file")
    return mapping


def find_files(folder: Path, overrides: dict) -> dict[str, Path]:
    found: dict[str, Path] = {}
    for table, fname in overrides.items():
        p = (folder / fname) if not Path(fname).is_absolute() else Path(fname)
        if not p.exists():
            raise FileNotFoundError(f"[files] {table} = '{fname}' was not found")
        found[table] = p
    remaining = [p for p in sorted(folder.glob("*.csv")) if p not in found.values()]
    for exact in (True, False):
        for table, names in FILE_NAMES.items():
            if table in found:
                continue
            for p in remaining:
                stem = norm_header(p.stem)
                hit = stem in names if exact else any(stem.startswith(n) or stem.endswith(n) for n in names)
                if hit:
                    found[table] = p
                    remaining.remove(p)
                    break
    return found


def load_folder(folder: Path, cfg: dict) -> dict[str, Table]:
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"Data folder not found: {folder}")
    files = find_files(folder, cfg.get("files", {}))
    if not files:
        raise FileNotFoundError(f"No CSV exports found in {folder}. Expected files such as "
                                "contacts.csv, accounts.csv, opportunities.csv.")
    tables = {}
    for name in TABLE_LABELS:
        if name not in files:
            continue
        path = files[name]
        df = read_csv(path)
        mapping = map_columns(name, df, cfg.get("columns", {}).get(name))
        tables[name] = Table(name, path, df, mapping)
    return tables
