"""Reads CRM exports (CSV or Excel) from Salesforce, HubSpot, Microsoft Dynamics 365 or Bullhorn and maps
their columns to the fields the checks need.

  Salesforce  Data Loader / Data Export (API names such as FirstName) or report exports (labels)
  HubSpot     CRM exports from the Contacts, Companies and Deals lists (labels such as "Record ID",
              "Contact owner", "Lifecycle Stage"); CSV or XLSX
  Dynamics    "Export to Excel" from a view (labels such as "Created On", with hidden
              "(Do Not Modify) Contact" ID columns), or Dataverse logical names (emailaddress1)
  Bullhorn    list exports (Selected > Export as CSV) with display labels such as "Date Added",
              "Occupation", "Client Corporation", or REST API names (dateAdded, clientCorporation.id)
              with dates as MM/DD/YYYY, ISO or epoch milliseconds. Header matching ignores case and
              punctuation, so "Date Added" and dateAdded are the same alias.
"""
from __future__ import annotations

import csv
import datetime as dt
import re
import warnings
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd


def norm_header(h) -> str:
    return re.sub(r"[^a-z0-9]", "", str(h).lower())


_OWNER_ID = ["OwnerId", "Owner ID", "Owner.Id", "ownerid", "HubSpot Owner ID"]
_DATES = {
    "last_activity": ["LastActivityDate", "Last Activity", "Last Activity Date", "Last Contacted",
                      "notes_last_updated", "Date Last Visit", "Last Visit", "Last Email Received",
                      "Last Note Date", "dateLastComment"],
    "last_modified": ["LastModifiedDate", "Last Modified Date", "Last Modified", "Modified On", "modifiedon",
                      "(Do Not Modify) Modified On", "Date Last Modified"],
    "created": ["CreatedDate", "Created Date", "Date Created", "Create Date", "Created On", "createdon",
                "Date Added"],
    "created_by_id": ["CreatedById", "Created By ID", "CreatedBy.Id", "createdby"],
    "created_by_name": ["Created By", "Created By Name", "CreatedBy.Name", "Created By: Full Name",
                        # HubSpot's "Created by user ID" holds the creator's name; which tool created the
                        # record ("Record source") is read separately by the checks
                        "Created by user ID", "Original Source Drill-Down 1"],
}

ALIASES: dict[str, dict[str, list[str]]] = {
    "contacts": {
        "id": ["Id", "Contact ID", "ContactId", "Record ID", "(Do Not Modify) Contact", "contactid", "ATS ID"],
        "name": ["Name", "Full Name", "fullname"],  # only used when there are no first/last name columns
        "first_name": ["FirstName", "First Name", "firstname"],
        "last_name": ["LastName", "Last Name", "lastname"],
        "email": ["Email", "Email Address", "emailaddress1"],
        "phone": ["Phone", "Business Phone", "Work Phone", "Phone Number", "telephone1"],
        "mobile": ["MobilePhone", "Mobile", "Mobile Phone", "Mobile Phone Number", "mobilephone"],
        "title": ["Title", "Job Title", "jobtitle", "Occupation"],
        "account_id": ["AccountId", "Account ID", "Account.Id", "Associated Company IDs (Primary)",
                       "Associated Company ID", "Associated Company IDs", "parentcustomerid",
                       "Client Corporation ID", "Company ID"],
        "account_name": ["Associated Company (Primary)", "Associated Company", "Account Name", "Account.Name",
                         "Account", "Company", "Company Name", "Client Corporation", "Client Corporation Name"],
        "owner_id": _OWNER_ID + ["Contact Owner ID"],
        "owner_name": ["Contact Owner", "Owner Name", "Owner", "Owner Full Name", "Owner.Name"],
        "opted_out": ["HasOptedOutOfEmail", "Email Opt Out", "Email Opt-Out", "Unsubscribed from all email",
                      "Do not allow Emails", "donotemail", "Mass Mail Opt Out"],
        # HubSpot's own "Original Source" / "Original Traffic Source" is set automatically (imports get
        # "Offline Sources"), so it says nothing about whether reps record where a lead came from
        "lead_source": ["LeadSource", "Lead Source", "Contact Source", "leadsourcecode", "Source"],
        "state": ["MailingState", "Mailing State/Province", "Mailing State", "State", "State/Province",
                  "State/Region", "Address 1: State/Province", "address1_stateorprovince", "Address State"],
        "country": ["MailingCountry", "Mailing Country", "Country", "Country/Region",
                    "Address 1: Country/Region", "address1_country", "Address Country Name", "Country Name"],
        "status": ["Status", "Contact Status"],  # Bullhorn: "Archive" marks a record nobody uses any more
        "is_deleted": ["Is Deleted", "IsDeleted"],

        "lifecycle_stage": ["Lifecycle Stage", "lifecyclestage"],  # HubSpot: leads are contacts
        **_DATES,
    },
    "accounts": {
        "id": ["Id", "Account ID", "AccountId", "Record ID", "(Do Not Modify) Account", "accountid", "ATS ID"],
        "name": ["Name", "Account Name", "Company name", "Company Name", "Company", "Client Corporation",
                 "Client Corporation Name"],
        "website": ["Website", "Company Domain Name", "Website URL", "Domain", "websiteurl", "Company URL"],
        "industry": ["Industry", "industrycode", "Business Sector", "industryList", "businessSectorList"],
        "employees": ["NumberOfEmployees", "Employees", "Number of Employees", "numberofemployees",
                      "numEmployees"],
        "state": ["BillingState", "Billing State/Province", "Billing State", "State", "State/Province",
                  "State/Region", "Address 1: State/Province", "address1_stateorprovince", "Address State"],
        "country": ["BillingCountry", "Billing Country", "Country", "Country/Region",
                    "Address 1: Country/Region", "address1_country", "Address Country Name", "Country Name"],
        "city": ["BillingCity", "Billing City", "City", "Address 1: City", "address1_city", "Address City"],
        "owner_id": _OWNER_ID + ["Account Owner ID", "Owners ID"],
        # Bullhorn companies can have several owners in one cell ("Ann Lee; Bo Cruz"); the checks use the first
        "owner_name": ["Account Owner", "Owner Name", "Owner", "Owner.Name", "Company owner", "Owners",
                       "Primary Owner"],
        "status": ["Status", "Company Status"],
        "is_deleted": ["Is Deleted", "IsDeleted"],

        **_DATES,
    },
    "opportunities": {
        "id": ["Id", "Opportunity ID", "OpportunityId", "Record ID", "(Do Not Modify) Opportunity",
               "opportunityid"],
        "name": ["Name", "Opportunity Name", "Deal Name", "Topic", "Title", "Opportunity Title", "Job Title"],
        "account_id": ["AccountId", "Account ID", "Account.Id", "Associated Company IDs (Primary)",
                       "Associated Company ID", "Associated Company IDs", "parentaccountid", "Client Corporation ID",
                       "Company ID"],
        "account_name": ["Account Name", "Account.Name", "Account", "Associated Company",
                         "Associated Company (Primary)", "Potential Customer", "Client Corporation",
                         "Client Corporation Name", "Company", "Company Name"],
        "stage": ["StageName", "Stage", "Deal Stage", "Sales Stage", "Pipeline Phase", "stepname"],
        "is_closed": ["IsClosed", "Closed", "Is Deal Closed?", "Is closed"],
        "is_won": ["IsWon", "Won", "Is Closed Won", "Is closed won"],
        "status": ["Status", "statecode"],  # Dynamics: Open / Won / Lost
        "is_open": ["Is Open"],  # Bullhorn
        "is_deleted": ["Is Deleted", "IsDeleted"],
        "close_date": ["CloseDate", "Close Date", "Est. Close Date", "Actual Close Date", "estimatedclosedate",
                       "Expected Close Date", "Date Closed"],
        # Bullhorn keeps both: expected while open, actual once closed
        "expected_close": ["Expected Close Date"],
        "actual_close": ["Actual Close Date", "Date Closed"],
        "amount": ["Amount", "Opportunity Amount", "Est. Revenue", "Actual Revenue", "estimatedvalue", "Deal Value"],
        "owner_id": _OWNER_ID + ["Opportunity Owner ID"],
        "owner_name": ["Opportunity Owner", "Owner Name", "Owner", "Owner.Name", "Deal owner"],
        "contact_id": ["ContactId", "Contact ID", "Primary Contact ID", "Associated Contact IDs",
                       "Associated Contact IDs (Primary)", "parentcontactid", "Client Contact ID"],
        "contact_name": ["Primary Contact", "Contact Name", "Contact", "Associated Contact", "Client Contact"],
        "probability": ["Probability", "Probability (%)", "Deal probability", "closeprobability",
                        "Win Probability", "Win Probability %"],
        "loss_reason": ["Closed Lost Reason", "Status Reason", "Reason Closed"],  # Dynamics: Status Reason
        **_DATES,
    },
    "leads": {
        "id": ["Id", "Lead ID", "LeadId", "Record ID", "(Do Not Modify) Lead", "leadid"],
        "first_name": ["FirstName", "First Name", "firstname"],
        "last_name": ["LastName", "Last Name", "lastname"],
        "company": ["Company", "Company / Account", "Company Name", "companyname"],
        "email": ["Email", "emailaddress1"],
        "status": ["Status", "Lead Status", "Lead stage", "statecode"],
        "is_converted": ["IsConverted", "Converted"],
        "lead_source": ["LeadSource", "Lead Source", "leadsourcecode"],
        "owner_id": _OWNER_ID + ["Lead Owner ID"],
        "owner_name": ["Lead Owner", "Owner Name", "Owner", "Owner.Name", "Lead owner"],
        "is_deleted": ["Is Deleted", "IsDeleted"],
        **_DATES,
    },
    "users": {
        "id": ["Id", "User ID", "UserId", "(Do Not Modify) User", "systemuserid"],
        "name": ["Name", "Full Name", "User", "fullname"],
        "first_name": ["FirstName", "First Name"],  # Salesforce Data Export has no Name for users
        "last_name": ["LastName", "Last Name"],
        "is_active": ["IsActive", "Active", "Enabled", "Is Enabled", "Status", "User Status"],
        "is_deleted": ["Is Deleted", "IsDeleted"],
        "username": ["Username", "User Name"],
        "profile": ["Profile.Name", "Profile", "Profile Name", "Access Mode", "Security Roles"],
        "user_type": ["UserType", "User Type", "Application ID", "Seat"],
    },
    "opportunity_history": {
        "opportunity_id": ["OpportunityId", "Opportunity ID"],
        "close_date": ["CloseDate", "Close Date"],
        "field": ["Field", "Field / Event"],
        "old_value": ["OldValue", "Old Value"],
        "new_value": ["NewValue", "New Value"],
        "created": ["CreatedDate", "Created Date", "Edit Date", "Last Modified"],
    },
    "tasks": {
        "who_id": ["WhoId", "Who ID", "Name ID", "Lead/Contact ID", "Person ID", "Person Reference ID"],
        "created": ["CreatedDate", "Created Date", "Date Created", "Created On", "Date Added"],
    },
    "contact_roles": {
        "opportunity_id": ["OpportunityId", "Opportunity ID"],
        "contact_id": ["ContactId", "Contact ID"],
    },
}

# Fields found by pattern when the name varies between orgs (custom fields)
PATTERNS = {
    "contacts": {"seniority": r"seniority|persona|joblevel|managementlevel|buyerrole"},
    "opportunities": {"loss_reason": r"(loss|lost).*reason|reason.*(loss|lost)"},
}

# Which file belongs to which table. Order matters: more specific names are matched first.
FILE_NAMES = {
    "contact_roles": ["opportunitycontactroles", "opportunitycontactrole", "contactroles",
                      "contactrole"],
    "opportunity_history": ["opportunityhistory", "opportunityfieldhistory", "opphistory",
                            "dealhistory", "opportunitieshistory"],
    "tasks": ["tasks", "task", "activities", "activity", "notes", "note", "appointments", "appointment"],
    "users": ["users", "user", "systemusers", "corporateusers", "corporateuser"],
    "leads": ["leads", "lead"],
    "opportunities": ["opportunities", "opportunity", "opps", "deals"],
    # Bullhorn job orders: only used as the deals table when there is no Opportunity export (see load_folder)
    "job_orders": ["joborders", "joborder", "jobs", "job"],
    "accounts": ["accounts", "account", "companies", "company", "clientcorporations", "clientcorporation"],
    "contacts": ["contacts", "contact", "clientcontacts", "clientcontact"],
}
# Third pass: the name appears anywhere, e.g. "hubspot-crm-exports-all-contacts-2026-11-10" or
# Dynamics' "My Active Contacts 11-10-2026 9-21-22 AM". Only the plural, unambiguous words.
FILE_WORDS = {
    "contact_roles": ["contactroles"], "opportunity_history": ["opportunityhistory", "dealhistory"],
    "tasks": ["tasks", "activities"], "users": ["users"], "leads": ["leads"],
    "opportunities": ["opportunities", "deals"], "accounts": ["accounts", "companies"],
    "contacts": ["contacts"], "job_orders": ["joborders"],
}
EXTENSIONS = (".csv", ".xlsx")

TABLE_LABELS = {
    "contacts": "Contacts", "accounts": "Accounts", "opportunities": "Opportunities",
    "leads": "Leads", "users": "Users", "tasks": "Tasks",
    "contact_roles": "Opportunity Contact Roles", "opportunity_history": "Opportunity History",
}

CORE_TABLES = {"contacts", "accounts", "opportunities", "leads"}


class Loaded(dict):
    """The tables that were read, plus warnings about files that were skipped."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.warnings: list[str] = []
        self.assumptions: dict = {}  # what was assumed about dates and phone numbers (see read_assumptions)


_FOOTER_RE = re.compile(r"copyright|confidential|generated by|grand total|salesforce\.com", re.I)
TRUE_WORDS = {"true", "1", "yes", "y", "checked", "x", "enabled", "active"}


@dataclass
class Table:
    name: str
    path: Path
    raw: pd.DataFrame
    mapping: dict[str, str] = field(default_factory=dict)
    day_first: bool | None = None  # True/False when the person said how slash dates read; None = work it out
    blank: dict[str, str] = field(default_factory=dict)  # field -> column that is in the file but empty in every row

    def __len__(self):
        return len(self.raw)

    def state(self, f: str) -> str:
        """absent    = no such column in the file
        blank     = the column is there but empty in every record (real CRM data: nobody filled it in)
        populated = at least one record has a value"""
        cache = self.__dict__.setdefault("_state", {})
        if f not in cache:
            col = self.mapping.get(f) or self.blank.get(f)
            if col is None or col not in self.raw.columns:
                cache[f] = "absent"
            elif len(self.raw) and self.raw[col].isna().all():
                cache[f] = "blank"
            else:
                cache[f] = "populated"
        return cache[f]

    def has(self, f: str) -> bool:
        """The column is there and at least one record has a value."""
        return self.state(f) == "populated"

    def present(self, f: str) -> bool:
        """The column is in the export (even if every record leaves it empty)."""
        return self.state(f) != "absent"

    def text(self, f: str) -> pd.Series:
        if f in self.mapping:
            return self.raw[self.mapping[f]].astype(object)
        return pd.Series([None] * len(self.raw), index=self.raw.index, dtype=object)

    def date(self, f: str) -> pd.Series:
        s = self.text(f).map(_epoch_ms_to_iso)  # Bullhorn's API gives dates as epoch milliseconds
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            d = pd.to_datetime(s, errors="coerce", utc=True, format="mixed",
                               dayfirst=self.day_first if self.day_first is not None else _is_day_first(s))
        return d.dt.tz_localize(None)

    def number(self, f: str) -> pd.Series:
        s = self.text(f).map(lambda v: re.sub(r"[$,\s]", "", v) if isinstance(v, str) else None)
        return pd.to_numeric(s, errors="coerce")

    def flag(self, f: str) -> pd.Series:
        return self.text(f).map(lambda v: isinstance(v, str) and v.strip().lower() in TRUE_WORDS).astype(bool)


_EPOCH_MS = re.compile(r"^\s*\d{13}\s*$")


def _epoch_ms_to_iso(v):
    """'1767225600000' (13 digits) -> '2026-01-01T00:00:00'. Anything else comes back unchanged."""
    if isinstance(v, str) and _EPOCH_MS.match(v):
        try:
            return pd.Timestamp(int(v), unit="ms").isoformat()
        except (ValueError, OverflowError):
            return v
    return v


_SLASH_DATE = re.compile(r"^\s*(\d{1,2})[/.\-](\d{1,2})[/.\-]\d{2,4}")


def _is_day_first(s: pd.Series) -> bool:
    """05/06/2026 is June 5 in a European export and May 6 in a US one. A column settles it itself:
    if some value reads 31/12/2026 (first number above 12) and none reads 12/31/2026, it's day-first."""
    first_big = second_big = 0
    for v in s.dropna().head(5000):
        m = _SLASH_DATE.match(str(v))
        if m:
            first_big += int(m.group(1)) > 12
            second_big += int(m.group(2)) > 12
    return first_big > 0 and second_big == 0


def _known_headers() -> set:
    global _KNOWN
    if _KNOWN is None:
        _KNOWN = {norm_header(a) for t in ALIASES.values() for names in t.values() for a in names}
    return _KNOWN


_KNOWN = None


def _header_row(rows: list[list]) -> int:
    """Index of the header row. Exports sometimes have a title ("Active Contacts") and a blank row
    above it. Pick the row with the most recognized column names; otherwise the first wide row."""
    known = _known_headers()
    best, best_hits, first_wide = 0, 0, None
    for i, row in enumerate(rows[:15]):
        cells = [norm_header(v) for v in row if isinstance(v, str) and v.strip()]
        if len(cells) >= 2 and first_wide is None:
            first_wide = i
        hits = sum(c in known for c in cells)
        if hits > best_hits:
            best, best_hits = i, hits
    return best if best_hits else (first_wide or 0)


def _tidy(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [str(c).strip() for c in df.columns]
    df = df.map(lambda v: (v.strip() or None) if isinstance(v, str) else None)
    # Drop the copyright / totals footer that Salesforce report exports add
    filled = df.notna().sum(axis=1)
    first = df.iloc[:, 0].astype(str) if len(df.columns) else pd.Series([], dtype=str)
    footer = (filled <= 1) & first.str.contains(_FOOTER_RE)
    return df[~footer & (filled > 0)].reset_index(drop=True)


def _cell_text(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    if isinstance(v, (dt.datetime, pd.Timestamp)):
        return v.isoformat()
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def _count_records(path: Path, enc: str, top: int) -> int:
    """Non-blank CSV records after the first `top` lines, header included (quoted line breaks count once)."""
    n = 0
    with open(path, newline="", encoding=enc) as f:
        for i, row in enumerate(csv.reader(f)):
            if i >= top and row:
                n += 1
    return n


def read_table(path: Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".xlsx":
        # The data is on the first sheet (Dynamics adds a hidden sheet after it)
        try:
            raw = pd.read_excel(path, sheet_name=0, header=None, dtype=object, engine="openpyxl")
        except Exception as e:  # damaged, password-protected, or not really an Excel file
            raise ValueError(f"'{path.name}' couldn't be opened as an Excel file. It may be damaged or "
                             "password-protected. Open it in Excel, save it again as .xlsx or CSV, "
                             "and try once more.") from None
        cells = raw.map(_cell_text)
        top = _header_row(cells.head(15).values.tolist())
        df = cells.iloc[top + 1:].reset_index(drop=True)
        df.columns = [("" if v is None else str(v)) or f"Column {i + 1}" for i, v in enumerate(cells.iloc[top])]
        return _tidy(df)
    last_err = None
    skipped = 0
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            df = pd.read_csv(path, dtype=object, keep_default_na=False, encoding=enc)
            break
        except UnicodeDecodeError as e:
            last_err = e
        except pd.errors.EmptyDataError:
            raise ValueError(f"'{path.name}' is empty: there is nothing in it to read. Export it again from the "
                             "CRM, or remove it from the folder.") from None
        except pd.errors.ParserError:
            df = None  # ragged rows (a title line above a wider table); handled below
            break
    else:
        raise last_err
    if df is None or not any(norm_header(c) in _known_headers() for c in df.columns):
        # A title or blank lines may sit above the real header: look for it in the first lines
        for enc in ("utf-8-sig", "cp1252"):
            try:
                with open(path, newline="", encoding=enc) as f:
                    head = [row for _, row in zip(range(15), csv.reader(f))]
                break
            except UnicodeDecodeError:
                head = []
        top = _header_row(head)
        if head and (top > 0 or df is None):
            try:
                # The C parser drops data lines that have MORE fields than the header (it pads shorter ones),
                # identically on every pandas version. Its own counters differ between versions, so the number
                # of dropped lines is worked out separately: records the csv module sees, minus rows kept.
                df = pd.read_csv(path, dtype=object, keep_default_na=False, encoding=enc, skiprows=top,
                                 on_bad_lines="skip")
                skipped = max(0, _count_records(path, enc, top) - 1 - len(df))
            except Exception:  # noqa: BLE001
                if df is None:
                    raise ValueError(f"'{path.name}' couldn't be read as a table. Check that it's a CSV with one "
                                     "header row.") from None
    out = _tidy(df)
    out.attrs["bad_lines"] = skipped
    return out


read_csv = read_table  # older name, kept for anything that still calls it


def _is_blank(df: pd.DataFrame, col) -> bool:
    return bool(df[col].isna().all())


def map_columns(table: str, df: pd.DataFrame, overrides: dict | None = None,
                dropped: list | None = None, blank: dict | None = None) -> dict[str, str]:
    """Maps fields to columns. A column that is empty in every row is NOT put in the mapping (real HubSpot
    exports include every property), but it isn't "missing from the export" either: it is reported in
    `blank` ({field: column}) and its header is added to `dropped` when that list is given. The checks tell
    the two apart: absent (no column), blank (column, no values) and populated."""
    normed = {}
    for c in df.columns:
        normed.setdefault(norm_header(c), c)
    mapping, empty = {}, {}
    for logical, aliases in ALIASES.get(table, {}).items():
        for a in aliases:
            if norm_header(a) in normed:
                col = normed[norm_header(a)]
                if len(df) and _is_blank(df, col):
                    empty.setdefault(logical, col)
                    continue
                mapping[logical] = col
                break
    for logical, pattern in PATTERNS.get(table, {}).items():
        for nh, c in normed.items():
            if re.search(pattern, nh):
                if len(df) and _is_blank(df, c):
                    empty.setdefault(logical, c)
                    continue
                mapping[logical] = c
                break
    for logical, col in (overrides or {}).items():
        if col in df.columns:
            mapping[logical] = col
        else:
            raise ValueError(f"[columns.{table}] {logical} = '{col}': no such column in the file")
    for logical, col in empty.items():
        if logical not in mapping:
            if blank is not None:
                blank[logical] = col
            if dropped is not None and col not in dropped:
                dropped.append(col)
    return mapping


CANDIDATE_HEADERS = {"skills", "primaryskills", "secondaryskills", "specialties", "dateavailable",
                     "desiredsalary", "desiredsalarylow", "desiredsalaryhigh", "desiredpayrate", "willrelocate",
                     "workauthorized", "candidatestatus", "candidateid", "candidate"}


# Fields worth a heads-up when their column is missing but a near-miss header is there:
# (what to call it, the fields that would satisfy it)
IMPORTANT_FIELDS = {
    "contacts": [("First Name", ["first_name"]), ("Last Name", ["last_name"]), ("Email", ["email"]),
                 ("Phone", ["phone"]), ("Account / Company", ["account_id", "account_name"]),
                 ("Owner", ["owner_id", "owner_name"]), ("Created Date", ["created"])],
    "accounts": [("Owner", ["owner_id", "owner_name"]), ("Created Date", ["created"])],
    "leads": [("First Name", ["first_name"]), ("Last Name", ["last_name"]), ("Email", ["email"]),
              ("Company", ["company"]), ("Owner", ["owner_id", "owner_name"]), ("Created Date", ["created"])],
    "opportunities": [("Stage", ["stage"]), ("Amount", ["amount"]), ("Close Date", ["close_date"]),
                      ("Account / Company", ["account_id", "account_name"]),
                      ("Owner", ["owner_id", "owner_name"]), ("Created Date", ["created"])],
}


def near_miss_notes(table: str, df: pd.DataFrame, mapping: dict) -> list[str]:
    """'Contacts: no First Name column found - did you mean the column FirstNme?' for an important field
    whose column wasn't recognized while an unrecognized header is one typo away from a known name."""
    import difflib
    notes = []
    leftover = {norm_header(c): c for c in df.columns if c not in mapping.values() and norm_header(c)}
    for label, fields in IMPORTANT_FIELDS.get(table, []):
        if any(f in mapping for f in fields) or not leftover:
            continue
        names = {norm_header(a) for f in fields for a in ALIASES.get(table, {}).get(f, [])}
        best, best_ratio = None, 0.0
        for nh, col in leftover.items():
            if nh in names:
                continue
            for n in names:
                r = difflib.SequenceMatcher(None, nh, n).ratio()
                if r > best_ratio:
                    best, best_ratio = col, r
        if best is not None and best_ratio >= 0.85:
            notes.append(f"{TABLE_LABELS[table]}: no {label} column found - did you mean the column '{best}'? "
                         f"Rename it in the file or map it under [columns.{table}].")
    return notes


def _looks_like_candidates(path: Path, df: pd.DataFrame) -> bool:
    """Two or more candidate-only columns (or one, when the file is called Candidates)."""
    hits = {norm_header(c) for c in df.columns} & CANDIDATE_HEADERS
    return len(hits) >= 2 or (bool(hits) and "candidate" in norm_header(path.stem))


def _looks_like_bullhorn_jobs(path: Path) -> bool:
    """A job-orders file is only read as deals when it is plainly a Bullhorn export."""
    from .crms import bullhorn_score
    if "joborder" in norm_header(path.stem):
        return True
    try:
        return bullhorn_score(read_table(path).columns) >= 1
    except Exception:  # noqa: BLE001
        return False


SKIP = "skip"  # a file_map value meaning "don't use this file"


FILE_KINDS = [*TABLE_LABELS, "job_orders"]  # what a file can be said to be (plus "skip" in file_map)


def clean_file_map(file_map, source: str = "[file_map]") -> dict:
    """{file name: table or "skip"}, checked. A bad entry is a plain one-line error naming it."""
    from .config import ConfigError
    if file_map in (None, {}):
        return {}
    if not isinstance(file_map, dict):
        raise ConfigError(f"{source} must be a list of file name = kind of file lines.")
    out = {}
    for k, v in file_map.items():
        name = Path(str(k)).name if isinstance(k, str) and k.strip() else ""
        kind = v.strip().lower() if isinstance(v, str) else ""
        if not name or kind not in FILE_KINDS + [SKIP]:
            raise ConfigError(f"In {source}, '{k}' must be one of {', '.join(FILE_KINDS)} or {SKIP}"
                              + (f" (it says {v!r})." if v not in (None, "") else "."))
        out[name] = kind
    return out


def find_files(folder: Path, overrides: dict, file_map: dict | None = None) -> dict[str, Path]:
    """Which file is which table. What the person said explicitly ([files] in audit.toml, or file_map from the
    app) always wins, one explicit source per table, and switches name detection off for that table. A file
    marked "skip" is never used by any path. Everything else is recognized from the file name."""
    from .config import ConfigError
    found: dict[str, Path] = {}
    file_map = clean_file_map(file_map)
    skipped = {n for n, k in file_map.items() if k == SKIP}
    said: dict[str, str] = {}
    for fname, table in file_map.items():
        if table == SKIP:
            continue
        if table in said:
            raise ConfigError(f"Two files are marked as the same kind of data ({TABLE_LABELS.get(table, table)}): "
                              f"'{said[table]}' and '{fname}'. Pick one and set the other to skip.")
        if not (folder / fname).is_file():
            raise ConfigError(f"The settings (audit.toml or the app) say '{fname}' is the "
                              f"{TABLE_LABELS.get(table, 'Job orders')} file, but that file isn't in the folder.")
        said[table] = fname
        found[table] = folder / fname
    for table, fname in overrides.items():
        if table not in FILE_KINDS:
            raise ConfigError(f"In [files], '{table}' isn't a kind of CRM file (use {', '.join(FILE_KINDS)}).")
        p = (folder / fname) if not Path(fname).is_absolute() else Path(fname)
        if not p.is_file():
            raise FileNotFoundError(f"[files] {table} = '{fname}' was not found")
        if p.name in skipped:
            raise ConfigError(f"'{p.name}' is set to skip but [files] says it is the {TABLE_LABELS.get(table, table)} file.")
        if table in said and said[table] != p.name:
            raise ConfigError(f"Two settings disagree about the {TABLE_LABELS.get(table, table)} file: [files] says "
                              f"'{fname}' and [file_map] says '{said[table]}'. Keep only one.")
        found[table] = p
    remaining = [p for p in sorted(folder.iterdir()) if p.is_file() and p.suffix.lower() in EXTENSIONS
                 and not p.name.startswith("~$") and p not in found.values() and p.name not in file_map
                 and p.name not in skipped]
    for how in ("exact", "edge", "contains"):
        for table, names in FILE_NAMES.items():
            if table in found:
                continue
            for p in remaining:
                stem = norm_header(p.stem)
                if how == "exact":
                    hit = stem in names
                elif how == "edge":
                    hit = any(stem.startswith(n) or stem.endswith(n) for n in names)
                else:
                    hit = any(w in stem for w in FILE_WORDS[table])
                if hit:
                    found[table] = p
                    remaining.remove(p)
                    break
    return found


def load_folder(folder: Path, cfg: dict) -> dict[str, Table]:
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"Data folder not found: {folder}")
    file_map = cfg.get("file_map") or {}
    files = find_files(folder, cfg.get("files", {}), file_map)
    jobs = files.pop("job_orders", None)  # Bullhorn: stands in for opportunities only when there are none
    why_unused: dict = {}
    jobs_as_deals = False
    if jobs is not None and "opportunities" in files:
        why_unused[jobs] = (f"Not used: '{jobs.name}' holds job orders, but there is an Opportunity export, so that "
                            "one is used. Job orders and opportunities are never mixed in one audit.")
    elif jobs is not None and _looks_like_bullhorn_jobs(jobs):
        files["opportunities"] = jobs
        jobs_as_deals = True
    if not files:
        raise FileNotFoundError(f"No CRM exports found in {folder}. Expected CSV or Excel files such as "
                                "contacts.csv, accounts.csv, opportunities.csv.")
    tables = Loaded()
    used = set(files.values())
    for p in sorted(folder.iterdir()):  # say so when a file in the folder isn't being read
        if p.is_file() and p.suffix.lower() in EXTENSIONS and not p.name.startswith("~$") and p not in used \
                and file_map.get(p.name) != SKIP:
            tables.warnings.append(why_unused.get(p) or
                                   f"Not used: '{p.name}' wasn't recognized as one of the CRM exports, or another "
                                   "file was already used for the same kind of data.")
    for name in TABLE_LABELS:
        if name not in files:
            continue
        path = files[name]
        df = read_table(path)
        if df.attrs.get("bad_lines"):
            n = df.attrs["bad_lines"]
            tables.warnings.append(f"'{path.name}': {n:,} line{'s' if n != 1 else ''} had the wrong number of "
                                   "columns and were skipped, so the numbers may be slightly low. Export the file "
                                   "again if that's not expected.")
        dropped: list = []
        blank: dict = {}
        mapping = map_columns(name, df, cfg.get("columns", {}).get(name), dropped, blank)
        if not mapping and len(df.columns):
            seen = ", ".join(str(c) for c in list(df.columns)[:8])
            if name in CORE_TABLES:  # grading a file nothing was read from would be misleading
                raise ValueError(
                    f"None of the columns in '{path.name}' were recognized as {TABLE_LABELS[name]} fields "
                    f"(found: {seen}). Check that it's the right file and that its first row holds the column "
                    "names, or map the columns under [columns] in audit.toml.")
            tables.warnings.append(f"Skipped '{path.name}': its columns weren't recognized as "
                                   f"{TABLE_LABELS[name]} fields (found: {seen}).")
            continue
        if dropped:
            tables.warnings.append(f"{TABLE_LABELS[name]}: these columns are in the export but empty in every row, "
                                   f"so the CRM holds no values for them: {', '.join(dropped)}. Each check says "
                                   "whether that counts as a finding or leaves it unchecked.")
        order = str(cfg.get("date_order") or "").lower()
        tables[name] = Table(name, path, df, mapping, {"dmy": True, "mdy": False}.get(order), blank)
        tables.warnings.extend(near_miss_notes(name, df, mapping))
        if name == "contacts" and _looks_like_candidates(path, df):
            tables.warnings.append(
                f"'{path.name}' looks like a candidate list (it has columns such as Skills or Desired Salary), "
                "not client contacts. Candidate records aren't part of the sales audit. Please send the Client "
                "Contacts export instead: the list of people at your client companies, not the candidates.")
        if name == "opportunities" and jobs_as_deals:
            tables.warnings.append(
                f"There is no Opportunity export, so the job orders in '{path.name}' stand in for opportunities. "
                "Job orders track open staffing requests rather than the sales pipeline, so treat the deal checks "
                "as a rough guide.")
    if not tables:
        raise ValueError("None of the files could be read as CRM data.")
    tables.assumptions = read_assumptions(tables, cfg)
    if tables.assumptions["dates_unsure"]:
        tables.warnings.append(tables.assumptions["dates_unsure"])
    tables.warnings[:0] = cfg.get("_warnings") or []  # typos found in audit.toml come first
    return tables


# ---------------------------------------------------------------- what was assumed about dates and phones

_REGION_ADJ = {"US": "United States", "CA": "Canadian", "GB": "United Kingdom", "IE": "Irish",
               "AU": "Australian", "NZ": "New Zealand", "DE": "German", "FR": "French", "IN": "Indian",
               "MX": "Mexican", "ES": "Spanish", "IT": "Italian", "NL": "Dutch", "SE": "Swedish",
               "ZA": "South African", "SG": "Singapore", "AE": "United Arab Emirates", "BR": "Brazilian",
               "JP": "Japanese"}
DATE_FIELDS = ("last_activity", "last_modified", "created", "close_date", "expected_close", "actual_close")


def region_name(code: str) -> str:
    return _REGION_ADJ.get(code, code)


def read_assumptions(tables: dict, cfg: dict) -> dict:
    """What the audit assumed that the person might not know: how slash dates (05/06/2026) were read, and which
    country phone numbers were checked against. Slash dates are ambiguous. A column settles it by itself when some
    value has a first or second number above 12; otherwise they are read month first, and if such dates exist
    the report says so (`dates_unsure`) so a European export isn't silently misread."""
    order = str(cfg.get("date_order") or "").lower()
    first_big = second_big = slash = 0
    unsure: list[str] = []
    detected_dmy = detected_mdy = False
    for name, t in tables.items():
        for f in DATE_FIELDS:
            if not t.has(f):
                continue
            vals = t.text(f).dropna().head(5000)
            fb = sb = amb = n = 0
            for v in vals:
                m = _SLASH_DATE.match(str(v))
                if not m:
                    continue
                n += 1
                a, b = int(m.group(1)), int(m.group(2))
                fb += a > 12
                sb += b > 12
                amb += a <= 12 and b <= 12 and a != b
            slash += n
            first_big += fb
            second_big += sb
            if fb and not sb:
                detected_dmy = True
            elif sb and not fb:
                detected_mdy = True
            elif amb and not order:  # nothing in this column settles it
                unsure.append(f"{TABLE_LABELS.get(name, name)}: {t.mapping[f]}")
    if order in ("dmy", "mdy"):
        how, source = order, "set"
    elif slash and detected_dmy and not detected_mdy:
        how, source = "dmy", "detected"
    elif slash and detected_mdy and not detected_dmy:
        how, source = "mdy", "detected"
    elif slash:
        how, source = "mdy", "assumed"
    else:
        how, source = None, "none"
    region = str(cfg.get("phone_region") or "US").upper()
    unsure_msg = ""
    if unsure and source != "set":
        cols = ", ".join(unsure[:4]) + (" and others" if len(unsure) > 4 else "")
        unsure_msg = ("Dates written like 05/06/2026 can mean May 6 or June 5, and nothing in the file settles which "
                      f"({cols}). They were read month first. If your CRM writes day first, set date_order = \"dmy\" "
                      "in audit.toml (or choose it on the file-check screen) and run the audit again.")
    return {"date_order": how, "date_source": source, "slash_dates": slash > 0, "dates_unsure": unsure_msg,
            "phone_region": region, "phone_region_name": region_name(region)}


def assumption_lines(a: dict | None) -> list[tuple[str, str, str]]:
    """(what, value, where it came from) for the report's assumptions table."""
    if not a:
        return []
    out = []
    if a.get("date_order"):
        txt = "day/month/year" if a["date_order"] == "dmy" else "month/day/year"
        src = {"set": "you set this (date_order in audit.toml or the file-check screen)",
               "detected": "the dates in the file settled it (some value has a day above 12)",
               "assumed": "nothing in the file settles it, so month first was assumed (the usual US order)"}[a["date_source"]]
        out.append(("How dates like 05/06/2026 were read", f"Read as {txt}", src))
    else:
        out.append(("How dates like 05/06/2026 were read", "No slash-style dates",
                    "the dates in these files are written in a form with no month/day ambiguity"))
    reg = a.get("phone_region", "US")
    out.append(("Which country phone numbers were checked against",
                f"Checked as {a.get('phone_region_name', reg)} numbers",
                "phone_region in audit.toml (default US); numbers with their own country code are checked as written"))
    return out
