"""Entry points for the iPad / browser app. The app's web worker calls these through Pyodide.
Everything runs inside the browser: files are written to Pyodide's in-memory disk, never uploaded."""
from __future__ import annotations

import json
import re
import shutil
import zipfile
from pathlib import Path

from . import branding, cleanup, pricing, progress
from .checks import run_checks
from .checklist import CHECKS
from .config import load_config
from .crms import consultant_note
from .loader import TABLE_LABELS, find_files, load_folder
from .report import write_report
from .report_html import _band, write_html
from .plain import AREAS, GRADE_PLAIN, PLAIN, RATING, money, top_problems
from .scoring import build_impact, build_scorecard
from .sources import analyze as analyze_sources

WORK = Path("/tmp/crm_audit")


def _progress(msg):
    try:
        from js import reportProgress  # provided by the web worker
        reportProgress(msg)
    except Exception:
        print(msg)


def _apply_settings(cfg: dict, settings: dict) -> dict:
    """Merge what was typed into the app over the defaults (or the sample's audit.toml)."""
    if settings.get("client"):
        cfg["client"] = settings["client"]
    for key in ("reps", "touches_per_rep_per_day", "hourly_cost", "lead_to_customer_rate_pct",
                "avg_deal_size", "admin_hours_per_week"):
        v = settings.get("impact", {}).get(key)
        if v not in (None, ""):
            cfg["impact"][key] = float(v)
    for cid, v in settings.get("manual_scores", {}).items():
        if v in (0, 1, 2):
            cfg["manual_scores"][cid] = int(v)
    for cid, v in settings.get("measured", {}).items():
        if v not in (None, ""):
            cfg["measured"][cid] = float(v)
    # "Your branding" panel: kept on the device and only ever used to build the report
    b = settings.get("branding")
    if isinstance(b, dict):
        for key in ("prepared_by", "contact", "accent_color", "logo_data", "show_powered_by"):
            if key in b:
                cfg["branding"][key] = b[key]
    return cfg


def _run(folder: Path, cfg: dict, previous: dict | None = None, sample: bool = False,
         demo: bool = False) -> dict:
    _progress("Reading the exports")
    data = load_folder(folder, cfg)
    brand = branding.apply(data, cfg)
    loaded = {TABLE_LABELS[k]: len(t) for k, t in data.items()}
    _progress(f"Running {len(CHECKS)} checks")
    ctx, results = run_checks(data, cfg)
    card = build_scorecard(results, cfg)
    impact = build_impact(results, cfg)
    _progress("Tracing where the bad data comes from")
    sources = analyze_sources(ctx, results)
    _progress("Writing the report")
    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(cfg["client"])).strip("_") or "client"
    base = f"{slug}_CRM_health_{ctx.audit_date:%Y-%m-%d}"
    out = WORK / "out"
    out.mkdir(parents=True, exist_ok=True)
    xlsx = out / f"{base}_details.xlsx"
    html = out / f"{base}_report.html"
    _progress("Preparing the cleanup kit")
    kit = cleanup.build(ctx, results)
    kit_dir = cleanup.write(kit, out / f"{slug}_cleanup_{ctx.audit_date:%Y-%m-%d}", cfg["client"], ctx.audit_date, brand)
    kit_zip = out / f"{kit_dir.name}.zip"
    manifest_path = out / f"{kit_dir.name}.manifest.json"
    with zipfile.ZipFile(kit_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(kit_dir.iterdir()):
            z.write(p, f"{kit_dir.name}/{p.name}")
        z.write(manifest_path, f"{kit_dir.name}/{manifest_path.name}")
    snap = progress.snapshot(cfg["client"], ctx.audit_date, card, results, impact, data)
    if previous and previous.get("audit_date", "") >= snap["audit_date"]:
        previous = None  # a re-run on the same day isn't "progress"
    example_progress = False
    if sample and demo and not previous:
        # Guided demo on the made-up sample only: an example earlier audit so the progress section can be shown.
        # It lives only in this comparison; snap (what the app may save to history) is untouched.
        previous, example_progress = progress.example_earlier(snap), True
    comp = progress.compare(previous, snap) if previous else None
    _, sheets = write_report(xlsx, cfg["client"], ctx.audit_date, card, impact, results, data, sources,
                             snap, comp, ctx.crm, brand)
    write_html(html, cfg["client"], ctx.audit_date, card, impact, results, data, sheets, xlsx.name, sources,
               kit.summary(), comp, ctx.crm, brand)
    # For the consultant's Quote panel only: kept out of the report files above
    reps, reps_src = pricing.reps_from_audit(cfg, ctx)
    quote_in = {"records": pricing.count_records(data), "reps": reps, "reps_source": reps_src,
                "crm_count": int(cfg.get("crm_count") or 1), "cleanup": kit.summary(),
                "client": str(cfg["client"]), "prepared_by": str(cfg["branding"].get("prepared_by") or ""),
                "pricing": cfg.get("pricing")}
    tour = _tour(cfg, ctx, card, impact, results, sources, kit.summary(), comp, sample, example_progress)
    errors = [f"{r.check_id}: {'; '.join(r.notes)}" for r in results.values() if r.status == "error"]
    return {
        "html": html.read_text(encoding="utf-8"),
        "xlsx_path": str(xlsx), "xlsx_name": xlsx.name, "html_name": html.name,
        "kit_path": str(kit_zip), "kit_name": kit_zip.name, "kit": kit.summary(),
        "manifest": manifest_path.read_text(encoding="utf-8"),
        "snapshot": snap, "progress": comp["headline"] if comp else None,
        "grade": card.grade, "score": round(card.overall) if card.overall is not None else None,
        "quote_inputs": quote_in, "quote": _quote(quote_in), "tour": tour,
        "unscored": card.unscored, "client": str(cfg["client"]), "loaded": loaded, "errors": errors,
        # For the consultant's status line only: never written into the report files
        "consultant_notes": [n for n in [consultant_note(ctx.crm)] if n],
    }


def _tour(cfg, ctx, card, impact, results, sources, cleanup, comp, is_sample, example_progress) -> dict:
    """The report's own numbers for the Guided demo (plain data, so the app builds the cards from it
    instead of scraping the report text). No prices of the consultant's services are in here."""
    from .crms import NAMES
    weights = {c.number: c.weight for c in card.categories}
    areas = [{"name": AREAS[c.number][0], "pct": round(c.pct, 4) if c.pct is not None else None,
              "rating": RATING[_band(c.pct) if c.pct is not None else None]} for c in card.categories]
    tops = [{"title": PLAIN[cid][0], "headline": results[cid].headline} for cid in top_problems(results, weights)]
    return {
        "grade": card.grade if card.overall is not None else None,
        "score": round(card.overall) if card.overall is not None else None,
        "grade_line": GRADE_PLAIN[card.grade] if card.overall is not None else None,
        "areas": areas, "problems": tops,
        "cost": impact["cost"], "cost_text": money(impact["cost"]) if impact["cost"] is not None else None,
        "hours": round(impact["hours"]) if impact["hours"] is not None else None,
        "sources_headline": sources["headline"] if sources else None,
        "has_progress": bool(comp), "progress_headline": comp["headline"] if comp else None,
        "progress_is_example": example_progress,
        "has_cleanup": bool(cleanup and (cleanup["ready"] or cleanup["decide"] or cleanup["enrich"])),
        "crm_name": NAMES[ctx.crm], "client_name": str(cfg["client"]), "is_sample": bool(is_sample),
    }


def _quote(s: dict) -> dict:
    q = pricing.build_quote(s["records"], s.get("reps"), s.get("crm_count") or 1, s.get("cleanup"),
                            bool(s.get("pilot")), s.get("pricing"))
    q["reps_source"] = s.get("reps_source", "")
    q["text"] = pricing.quote_text(q, s.get("client", ""), s.get("prepared_by", ""))
    return q


def quote_json(settings_json: str) -> str:
    """Recalculate the consultant's quote (pilot price on/off, a different rep count). Pass the
    result's quote_inputs, plus optional pilot and reps. Pricing defaults to DEFAULT_PRICING;
    a "pricing" dict in the settings overrides it."""
    s = json.loads(settings_json)
    reps = s.get("reps")
    s["reps"] = int(reps) if reps not in (None, "") else None
    return json.dumps(_quote(s))


def identify(names_json: str) -> str:
    """Which table each uploaded file name will be read as, so the app can show it before running."""
    names = json.loads(names_json)
    tmp = WORK / "probe"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    for n in names:
        (tmp / Path(n).name).write_text("x\n", encoding="utf-8")
    found = find_files(tmp, {})
    return json.dumps({p.name: TABLE_LABELS[t] for t, p in found.items()})


def run_uploaded(settings_json: str) -> str:
    """The app has already written the CSVs to /tmp/crm_audit/data."""
    settings = json.loads(settings_json)
    cfg = _apply_settings(load_config(None), settings)
    return json.dumps(_run(WORK / "data", cfg, settings.get("previous")), default=str)


def run_sample(settings_json: str) -> str:
    from .sample_data import generate
    settings = json.loads(settings_json)
    _progress("Building a sample company with realistic problems")
    folder = WORK / "sample"
    if folder.exists():
        shutil.rmtree(folder)
    generate(folder, seed=7, crm=settings.get("crm") or "salesforce")
    cfg = load_config(folder / "audit.toml")
    # The sample keeps its own interview answers; only a typed company name or rep count overrides it
    cfg = _apply_settings(cfg, {"client": settings.get("client"), "impact": settings.get("impact", {}),
                                "branding": settings.get("branding")})
    return json.dumps(_run(folder, cfg, sample=True, demo=bool(settings.get("demo"))), default=str)


def reset_data_dir():
    d = WORK / "data"
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    return str(d)


def reset_review_dir():
    d = WORK / "review"
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    return str(d)


def reset_workspace() -> str:
    """"Start another client": delete everything this worker holds for the previous client (uploaded exports,
    sample, probe files, reports, kits, the reviewed workbook and the load files). Nothing else is touched."""
    removed = 0
    for name in ("data", "sample", "probe", "out", "review"):
        d = WORK / name
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)
            removed += 1
    return json.dumps({"removed": removed, "left": sorted(p.name for p in WORK.iterdir()) if WORK.exists() else []})


def apply_uploaded() -> str:
    """The app has written the reviewed workbook to /tmp/crm_audit/review/review.xlsx (and, if it still has it,
    the kit's manifest as review.manifest.json). Returns the ready-to-load folder as a zip, a one-line result,
    and the counts; or {"error": plain-English message}."""
    from .apply import ApplyError, apply_review
    try:
        sm = apply_review(WORK / "review" / "review.xlsx")
    except ApplyError as e:
        return json.dumps({"error": str(e)})
    folder = Path(sm["folder"])
    slug = re.sub(r"[^A-Za-z0-9]+", "_", sm["client"]).strip("_") or "client"
    zip_path = WORK / "review" / f"{slug}_ready_to_load.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, f"{folder.name}/{p.relative_to(folder).as_posix()}")
    line = (f"{sm['approved']:,} approved, {sm['declined']:,} declined, {sm['undecided']:,} left undecided "
            f"(not applied). The zip has your files and CHECKLIST.txt.")
    if sm["warnings"]:
        line += f" {len(sm['warnings'])} thing{'s' if len(sm['warnings']) != 1 else ''} to check: " + sm["warnings"][0]
    return json.dumps({"zip_path": str(zip_path), "zip_name": zip_path.name, "line": line, "summary": sm})


def checklist_json() -> str:
    """The questions the app shows in its interview section."""
    from .plain import PLAIN
    return json.dumps([{"id": c.id, "category": c.category, "title": PLAIN[c.id][0], "how": c.how,
                        "target": c.target, "mode": c.mode, "unit": c.unit}
                       for c in CHECKS if c.mode in ("manual", "measured")])
