"""Entry points for the iPad / browser app. The app's web worker calls these through Pyodide.
Everything runs inside the browser: files are written to Pyodide's in-memory disk, never uploaded."""
from __future__ import annotations

import json
import re
import shutil
import zipfile
from pathlib import Path

from . import branding, cleanup, pricing, progress
from .checks import run_checks
from .checklist import CHECKS
from .config import load_config
from .crms import consultant_note
from .loader import ALIASES, EXTENSIONS, SKIP, TABLE_LABELS, clean_file_map, find_files, load_folder, map_columns, norm_header, read_table
from .report import write_report
from .report_html import _band, write_html
from .plain import AREAS, GRADE_PLAIN, PLAIN, RATING, money, top_problems
from .scoring import build_impact, build_scorecard, grade_basis
from .sources import analyze as analyze_sources

WORK = Path("/tmp/crm_audit")


def _progress(msg):
    try:
        from js import reportProgress  # provided by the web worker
        reportProgress(msg)
    except Exception:
        print(msg)


IMPACT_LABELS = {"reps": "Number of reps", "touches_per_rep_per_day": "Touches per rep per day",
                 "hourly_cost": "Hourly cost", "lead_to_customer_rate_pct": "Lead-to-customer rate",
                 "avg_deal_size": "Average deal size", "admin_hours_per_week": "Admin hours per week"}


def _typed_number(v, label: str, allow_negative: bool = False) -> float:
    """A number typed into the app. Text where a number belongs stops the audit with a plain sentence
    (shown on the app's error screen) instead of a crash."""
    from .config import ConfigError
    try:
        n = float(str(v).replace(",", "").replace("$", "").strip())
    except (TypeError, ValueError):
        raise ConfigError(f"{label} must be a number, but it says \"{v}\". Type digits only, like 10.") from None
    if n != n or n in (float("inf"), float("-inf")):
        raise ConfigError(f"{label} must be a normal number.")
    if n < 0 and not allow_negative:
        raise ConfigError(f"{label} can't be negative, but it says {v}.")
    return n


def _apply_settings(cfg: dict, settings: dict) -> dict:
    """Merge what was typed into the app over the defaults (or the sample's audit.toml)."""
    if settings.get("client"):
        cfg["client"] = settings["client"]
    for key in ("reps", "touches_per_rep_per_day", "hourly_cost", "lead_to_customer_rate_pct",
                "avg_deal_size", "admin_hours_per_week"):
        v = settings.get("impact", {}).get(key)
        if v not in (None, ""):
            cfg["impact"][key] = _typed_number(v, IMPACT_LABELS.get(key, key))
    for cid, v in settings.get("manual_scores", {}).items():
        if v in (0, 1, 2):
            cfg["manual_scores"][cid] = int(v)
    for cid, v in settings.get("measured", {}).items():
        if v not in (None, ""):
            cfg["measured"][cid] = _typed_number(v, f"The number you entered for check {cid}", allow_negative=True)
    # "Check your files" screen: what the person said each file is, the CRM, and how slash dates read
    fm = settings.get("file_map")
    if fm not in (None, {}, []):
        from .loader import clean_file_map
        cfg["file_map"] = clean_file_map(fm, "the file choices")
    if str(settings.get("date_order") or "").lower() in ("dmy", "mdy"):
        cfg["date_order"] = str(settings["date_order"]).lower()
    if settings.get("crm_override"):
        cfg["crm"] = str(settings["crm_override"])
    # "Your branding" panel: kept on the device and only ever used to build the report
    b = settings.get("branding")
    if isinstance(b, dict):
        for key in ("prepared_by", "contact", "accent_color", "logo_data", "show_powered_by"):
            if key in b:
                cfg["branding"][key] = b[key]
    return cfg


def _run(folder: Path, cfg: dict, previous: dict | None = None, sample: bool = False,
         demo: bool = False) -> dict:
    _progress("Reading the exports")
    data = load_folder(folder, cfg)
    brand = branding.apply(data, cfg)
    loaded = {TABLE_LABELS[k]: len(t) for k, t in data.items()}
    _progress(f"Running {len(CHECKS)} checks")
    ctx, results = run_checks(data, cfg)
    card = build_scorecard(results, cfg)
    impact = build_impact(results, cfg)
    _progress("Tracing where the bad data comes from")
    sources = analyze_sources(ctx, results)
    _progress("Writing the report")
    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(cfg["client"])).strip("_") or "client"
    base = f"{slug}_CRM_health_{ctx.audit_date:%Y-%m-%d}"
    out = WORK / "out"
    out.mkdir(parents=True, exist_ok=True)
    xlsx = out / f"{base}_details.xlsx"
    html = out / f"{base}_report.html"
    _progress("Preparing the cleanup kit")
    kit = cleanup.build(ctx, results)
    kit_dir = cleanup.write(kit, out / f"{slug}_cleanup_{ctx.audit_date:%Y-%m-%d}", cfg["client"], ctx.audit_date, brand)
    kit_zip = out / f"{kit_dir.name}.zip"
    manifest_path = out / f"{kit_dir.name}.manifest.json"
    with zipfile.ZipFile(kit_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(kit_dir.iterdir()):
            z.write(p, f"{kit_dir.name}/{p.name}")
        z.write(manifest_path, f"{kit_dir.name}/{manifest_path.name}")
    snap = progress.snapshot(cfg["client"], ctx.audit_date, card, results, impact, data)
    if previous and previous.get("audit_date", "") >= snap["audit_date"]:
        previous = None  # a re-run on the same day isn't "progress"
    example_progress = False
    if sample and demo and not previous:
        # Guided demo on the made-up sample only: an example earlier audit so the progress section can be shown.
        # It lives only in this comparison; snap (what the app may save to history) is untouched.
        previous, example_progress = progress.example_earlier(snap), True
    comp = progress.compare(previous, snap) if previous else None
    _, sheets = write_report(xlsx, cfg["client"], ctx.audit_date, card, impact, results, data, sources,
                             snap, comp, ctx.crm, brand)
    write_html(html, cfg["client"], ctx.audit_date, card, impact, results, data, sheets, xlsx.name, sources,
               kit.summary(), comp, ctx.crm, brand)
    # For the consultant's Quote panel only: kept out of the report files above
    reps, reps_src = pricing.reps_from_audit(cfg, ctx)
    quote_in = {"records": pricing.count_records(data), "reps": reps, "reps_source": reps_src,
                "crm_count": int(cfg.get("crm_count") or 1), "cleanup": kit.summary(),
                "client": str(cfg["client"]), "prepared_by": str(cfg["branding"].get("prepared_by") or ""),
                "pricing": cfg.get("pricing")}
    tour = _tour(cfg, ctx, card, impact, results, sources, kit.summary(), comp, sample, example_progress)
    errors = [f"{r.check_id}: {'; '.join(r.notes)}" for r in results.values() if r.status == "error"]
    return {
        "html": html.read_text(encoding="utf-8"),
        "xlsx_path": str(xlsx), "xlsx_name": xlsx.name, "html_name": html.name,
        "kit_path": str(kit_zip), "kit_name": kit_zip.name, "kit": kit.summary(),
        "manifest": manifest_path.read_text(encoding="utf-8"),
        "snapshot": snap, "progress": comp["headline"] if comp else None,
        "grade": card.grade, "score": round(card.overall) if card.overall is not None else None,
        "quote_inputs": quote_in, "quote": _quote(quote_in), "tour": tour,
        "unscored": card.unscored, "client": str(cfg["client"]), "loaded": loaded, "errors": errors,
        # For the consultant's status line only: never written into the report files
        "consultant_notes": [n for n in [consultant_note(ctx.crm)] if n],
    }


def _tour(cfg, ctx, card, impact, results, sources, cleanup, comp, is_sample, example_progress) -> dict:
    """The report's own numbers for the Guided demo (plain data, so the app builds the cards from it
    instead of scraping the report text). No prices of the consultant's services are in here."""
    from .crms import NAMES
    weights = {c.number: c.weight for c in card.categories}
    areas = [{"name": AREAS[c.number][0], "pct": round(c.pct, 4) if c.pct is not None else None,
              "rating": RATING[_band(c.pct) if c.pct is not None else None]} for c in card.categories]
    tops = [{"title": PLAIN[cid][0], "headline": results[cid].headline} for cid in top_problems(results, weights)]
    return {
        "grade": card.grade if card.overall is not None else None,
        "score": round(card.overall) if card.overall is not None else None,
        "grade_line": GRADE_PLAIN[card.grade] if card.overall is not None else None,
        "areas": areas, "problems": tops,
        "cost": impact["cost"], "cost_text": money(impact["cost"]) if impact["cost"] is not None else None,
        "cost_range": impact.get("cost_text"), "hours_range": impact.get("hours_text"),
        "grade_basis": grade_basis(card), "grade_status": card.status, "grade_coverage": round(card.coverage * 100),
        "checks_measured": card.measured, "checks_applicable": card.applicable, "checks_partial": card.partial,
        "hours": round(impact["hours"]) if impact["hours"] is not None else None,
        "sources_headline": sources["headline"] if sources else None,
        "cost_basis": impact.get("basis"), "cost_defaults": bool(impact.get("defaults")),
        "has_progress": bool(comp), "progress_headline": comp["headline"] if comp else None,
        "progress_note": _progress_note(comp),
        "progress_is_example": example_progress,
        "has_cleanup": bool(cleanup and (cleanup["ready"] or cleanup["decide"] or cleanup["enrich"])),
        "crm_name": NAMES[ctx.crm], "client_name": str(cfg["client"]), "is_sample": bool(is_sample),
    }


def _progress_note(comp) -> str | None:
    """One plain sentence for the demo when the two audits didn't measure the same checks."""
    if not comp:
        return None
    n, d = len(comp.get("newly_measured") or []), len(comp.get("no_longer_measured") or [])
    if not (n or d):
        return None
    bits = ([f"{n} newly measured"] if n else []) + ([f"{d} no longer measured"] if d else [])
    return "Checks measured in only one of the two audits are listed separately (" + ", ".join(bits) + ")."


def _quote(s: dict) -> dict:
    q = pricing.build_quote(s["records"], s.get("reps"), s.get("crm_count") or 1, s.get("cleanup"),
                            bool(s.get("pilot")), s.get("pricing"))
    q["reps_source"] = s.get("reps_source", "")
    q["text"] = pricing.quote_text(q, s.get("client", ""), s.get("prepared_by", ""))
    return q


def quote_json(settings_json: str) -> str:
    """Recalculate the consultant's quote (pilot price on/off, a different rep count). Pass the
    result's quote_inputs, plus optional pilot and reps. Pricing defaults to DEFAULT_PRICING;
    a "pricing" dict in the settings overrides it."""
    s = json.loads(settings_json)
    reps = s.get("reps")
    s["reps"] = int(reps) if reps not in (None, "") else None
    return json.dumps(_quote(s))


def identify(names_json: str) -> str:
    """Which table each uploaded file name will be read as, so the app can show it before running."""
    names = json.loads(names_json)
    tmp = WORK / "probe"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    for n in names:
        (tmp / Path(n).name).write_text("x\n", encoding="utf-8")
    found = find_files(tmp, {})
    return json.dumps({p.name: TABLE_LABELS[t] for t, p in found.items()})


# ---------------------------------------------------------------- "Check your files"
INSPECT = WORK / "inspect"
_PARSED: dict = {}  # file name -> (DataFrame or None, error text or "", error kind): each file is read once per set
_DATE_FIELDS = ("last_activity", "last_modified", "created", "close_date", "expected_close", "actual_close")
_SLASH = re.compile(r"^\s*(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})")


def reset_inspect_dir() -> str:
    """Empty folder for the files the person just chose, so they can be looked at before the audit runs."""
    _PARSED.clear()
    if INSPECT.exists():
        shutil.rmtree(INSPECT, ignore_errors=True)
    INSPECT.mkdir(parents=True)
    return str(INSPECT)


def clear_inspect() -> None:
    _PARSED.clear()
    if INSPECT.exists():
        shutil.rmtree(INSPECT, ignore_errors=True)


def _parse(path: Path):
    if path.name not in _PARSED:
        try:
            _PARSED[path.name] = (read_table(path), "", "")
        except ValueError as e:
            msg = str(e)
            _PARSED[path.name] = (None, msg, "empty" if " is empty" in msg else "unreadable")
        except Exception as e:  # noqa: BLE001 - whatever pandas says, the person gets one plain sentence
            _PARSED[path.name] = (None, f"'{path.name}' couldn't be read ({type(e).__name__}).", "unreadable")
    return _PARSED[path.name]


def _crm_scores(columns) -> dict:
    from .crms import _SIGNS
    cols = {norm_header(c) for c in columns}
    sc = {crm: sum(1 for x in signs if x in cols) for crm, signs in _SIGNS.items()}
    if sc["bullhorn"] < 2:
        sc["bullhorn"] = 0
    return sc


def _best_crm(sc: dict):
    best = max(sc, key=sc.get)
    top = sc[best]
    if top < 2 or sorted(sc.values())[-2] == top:
        return None  # no clear signal from this file alone
    return best


def _date_facts(frames: list, order: str | None) -> dict:
    """Slash dates like 05/06/2026 read two ways. Say whether the data itself settles it, with up to three examples."""
    first_big = second_big = 0
    ambiguous: list = []
    seen: set = set()
    slash = 0
    for df, mapping in frames:
        for f in _DATE_FIELDS:
            col = mapping.get(f)
            if not col:
                continue
            for v in df[col].dropna().head(3000):
                m = _SLASH.match(str(v))
                if not m:
                    continue
                a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
                slash += 1
                first_big += a > 12
                second_big += b > 12
                if a <= 12 and b <= 12 and a != b and str(v).strip() not in seen and len(ambiguous) < 3:
                    seen.add(str(v).strip())
                    ambiguous.append({"raw": str(v).strip(), "mdy": f"{y:04d}-{a:02d}-{b:02d}", "dmy": f"{y:04d}-{b:02d}-{a:02d}"})
    proof = "dmy" if first_big and not second_big else "mdy" if second_big and not first_big else None
    return {"slash_dates": slash > 0, "has_ambiguous": bool(ambiguous), "proof": proof, "mixed": bool(first_big and second_big),
            "examples": ambiguous, "chosen": order if order in ("dmy", "mdy") else None}


def inspect_files(settings_json: str) -> str:
    """Facts about the files the person chose, before anything is audited: what each looks like (by its name, or
    by what the person said in file_map), its size and columns, the CRM, and how its dates will be read."""
    s = json.loads(settings_json)
    file_map = clean_file_map(s.get("file_map"), "the file choices")
    order = str(s.get("date_order") or "").lower() or None
    folder = INSPECT
    paths = sorted(p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in EXTENSIONS
                   and not p.name.startswith("~$")) if folder.exists() else []
    by_name = {p.name: t for t, p in find_files(folder, {}).items()} if paths else {}
    files, frames, crm_total = [], [], {k: 0 for k in ("salesforce", "hubspot", "dynamics", "bullhorn")}
    for p in paths:
        detected = by_name.get(p.name)
        table = file_map.get(p.name, detected or SKIP)
        df, err, kind = _parse(p)
        row = {"name": p.name, "detected": detected, "table": None if table == SKIP else table,
               "rows": None, "columns": None, "useful": None, "bad_lines": 0, "error": err or None,
               "error_kind": kind or None, "crm": None}
        if df is not None:
            row["rows"], row["columns"] = int(len(df)), int(len(df.columns))
            row["bad_lines"] = int(df.attrs.get("bad_lines") or 0)
            sc = _crm_scores(df.columns)
            row["crm"] = _best_crm(sc)
            if row["table"]:
                mapping = map_columns("opportunities" if row["table"] == "job_orders" else row["table"], df)
                row["useful"] = len(mapping)
                frames.append((df, mapping))
                for k, v in sc.items():
                    crm_total[k] += v
        files.append(row)
    best = max(crm_total, key=crm_total.get)
    from .crms import NAMES
    detected_crm = best if crm_total[best] else "salesforce"
    return json.dumps({"files": files, "crm": detected_crm, "crm_name": NAMES[detected_crm],
                       "crm_evidence": crm_total[best] > 0, "dates": _date_facts(frames, order)})


def run_uploaded(settings_json: str) -> str:
    """The app has already written the CSVs to /tmp/crm_audit/data."""
    clear_inspect()
    settings = json.loads(settings_json)
    cfg = _apply_settings(load_config(None), settings)
    return json.dumps(_run(WORK / "data", cfg, settings.get("previous")), default=str)


def run_sample(settings_json: str) -> str:
    from .sample_data import generate
    settings = json.loads(settings_json)
    _progress("Building a sample company with realistic problems")
    folder = WORK / "sample"
    if folder.exists():
        shutil.rmtree(folder)
    generate(folder, seed=7, crm=settings.get("crm") or "salesforce")
    cfg = load_config(folder / "audit.toml")
    # The sample keeps its own interview answers; only a typed company name or rep count overrides it
    cfg = _apply_settings(cfg, {"client": settings.get("client"), "impact": settings.get("impact", {}),
                                "branding": settings.get("branding")})
    return json.dumps(_run(folder, cfg, sample=True, demo=bool(settings.get("demo"))), default=str)


def reset_data_dir():
    d = WORK / "data"
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    return str(d)


def reset_review_dir():
    d = WORK / "review"
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    return str(d)


def reset_workspace() -> str:
    """"Start another client": delete everything this worker holds for the previous client (uploaded exports,
    sample, probe files, reports, kits, the reviewed workbook and the load files). Nothing else is touched."""
    removed = 0
    _PARSED.clear()
    for name in ("data", "sample", "probe", "inspect", "out", "review", "rounds"):
        d = WORK / name
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)
            removed += 1
    return json.dumps({"removed": removed, "left": sorted(p.name for p in WORK.iterdir()) if WORK.exists() else []})


def apply_uploaded() -> str:
    """The app has written the reviewed workbook to /tmp/crm_audit/review/review.xlsx (and, if it still has it,
    the kit's manifest as review.manifest.json). Returns the ready-to-load folder as a zip, a one-line result,
    and the counts; or {"error": plain-English message}."""
    from .apply import ApplyError, apply_review
    try:
        # the kit this worker made (out/) and the follow-up workbooks it made (rounds/) are where the original is looked for
        sm = apply_review(WORK / "review" / "review.xlsx", search_roots=[WORK / "out", WORK / "rounds"],
                          keep_dir=WORK / "rounds")
    except ApplyError as e:
        return json.dumps({"error": str(e)})
    folder = Path(sm["folder"])
    slug = re.sub(r"[^A-Za-z0-9]+", "_", sm["client"]).strip("_") or "client"
    zip_path = WORK / "review" / f"{slug}_ready_to_load.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, f"{folder.name}/{p.relative_to(folder).as_posix()}")
    line = (f"{sm['approved']:,} approved, {sm['declined']:,} declined, {sm['undecided']:,} left undecided "
            f"(not applied). The zip has your files and CHECKLIST.txt.")
    r2 = sm.get("round2")
    if r2 and r2["status"] == "written":
        line += (f" {r2['items']:,} decision{'s were' if r2['items'] != 1 else ' was'} left blank: the zip also holds "
                 f"{r2['name']} (round {r2['round']}) to send to the client.")
    elif r2 and r2["status"] == "missing_original":
        line += (" Some decisions were left blank, but this device no longer holds the original kit to build a follow-up "
                 "workbook from (it is kept only while the app stays open). On a computer, run apply-review with "
                 "--original <the kit folder>.")
    elif r2:
        line += " Some decisions were left blank. " + (r2.get("message") or "No follow-up workbook was made.")
    if sm["warnings"]:
        line += f" {len(sm['warnings'])} thing{'s' if len(sm['warnings']) != 1 else ''} to check: " + sm["warnings"][0]
    return json.dumps({"zip_path": str(zip_path), "zip_name": zip_path.name, "line": line, "summary": sm})


def checklist_json() -> str:
    """The questions the app shows in its interview section."""
    from .plain import PLAIN
    return json.dumps([{"id": c.id, "category": c.category, "title": PLAIN[c.id][0], "how": c.how,
                        "target": c.target, "mode": c.mode, "unit": c.unit}
                       for c in CHECKS if c.mode in ("manual", "measured")])
